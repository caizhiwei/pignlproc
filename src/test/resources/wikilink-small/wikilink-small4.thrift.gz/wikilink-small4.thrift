  >��    Thttp://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine   2;<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Ronald Reagan Speaks Out Against Socialized Medicine | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine/rss" title="Comments on: Ronald Reagan Speaks Out Against Socialized Medicine" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Reagan" shape="rect">Reagan</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/RonaldReagan" shape="rect">RonaldReagan</a>
              <br clear="none"></br>
              <a title="OperationCoffeeCup" rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/OperationCoffeeCup" shape="rect">OperationCoffee</a>
              ...
              <br clear="none"></br>
              <a title="SocializedHealthCare" rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/SocializedHealthCare" shape="rect">SocializedHealt</a>
              ...
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Medicare" shape="rect">Medicare</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Ronald%20Reagan%20Speaks%20Out%20Against%20Socialized%20Medicine%20http%3A%2F%2Fmefi%2Eus%2Fw%2F84242" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Ronald Reagan Speaks Out Against Socialized Medicine
        <br clear="none"></br>
        <span class="smallcopy">
          August 18, 2009 11:59 AM  
          <a href="http://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://www.youtube.com/watch?v=fRdLpem-AAs" shape="rect">Ronald Reagan Speaks Out Against Socialized Medicine.</a>
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        Via
        <a href="http://en.wikipedia.org/wiki/Ronald_Reagan_Speaks_Out_Against_Socialized_Medicine" shape="rect">Wikipedia</a>
        :
        <em>
          Ronald Reagan Speaks Out Against Socialized Medicine is a 1961 LP recorded by Ronald Reagan. In this 11-minute recording, Reagan &quot;criticized Social Security for supplanting private savings and warned that subsidized medicine would curtail Americans' freedom&quot; and that &quot;pretty soon your son won't decide when he's in school, where he will go or what he will do for a living. He will wait for the government to tell him.&quot;
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        The LP was a product of
        <a href="http://en.wikipedia.org/wiki/Operation_Coffee_Cup" shape="rect">Operation Coffee Cup</a>
        , a stealth program by the American Medical Associaltion in opposition to what would later be Medicare.
        <br clear="none"></br>
        <br clear="none"></br>
        A history of the campaign from
        <a href="http://www.huffingtonpost.com/rj-eskow/operation-coffeecup-reaga_b_45444.html" shape="rect">HuffPost</a>
        .
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/31765" shape="rect">Astro Zombie</a>
        (56 comments total)
        <span id="favcnt184242">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/84242" shape="rect">11 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2700393" shape="rect"></a>
    <div class="comments">
      I was concerned about Ronald Reagan speaking out at this time, especially considering who posted this.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/86692" shape="rect">mr_crash_davis mark II: Jazz Odyssey</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700393" shape="rect">12:02 PM</a>
        on August 18, 2009 [
        <a title="26 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700393" shape="rect">26 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700396" shape="rect"></a>
    <div class="comments">
      Zombie Ronald Reagan Speaks Out Against Medicine:
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;BRAAAAIIIIIINNNNNSSSS!!!&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23407" shape="rect">It's Raining Florence Henderson</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700396" shape="rect">12:03 PM</a>
        on August 18, 2009 [
        <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700396" shape="rect">8 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700409" shape="rect"></a>
    <div class="comments">
      Alzheimer's Ronald Reagan Speaks Out Against Medicine:
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;BRAAAAIIIIIINNNNN!!!&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/64543" shape="rect">Christ, what an asshole</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700409" shape="rect">12:06 PM</a>
        on August 18, 2009 [
        <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700409" shape="rect">5 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700413" shape="rect"></a>
    <div class="comments">
      The lack of cognitive depth in that is frightening, but not surprising.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/67167" shape="rect">kldickson</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700413" shape="rect">12:09 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700414" shape="rect"></a>
    <div class="comments">
      Phew, he's still dead. I thought I might have to go dig out my Reagan Youth buttons and No Business as Usual Day stickers.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17735" shape="rect">mygothlaundry</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700414" shape="rect">12:09 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700414" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700418" shape="rect"></a>
    <div class="comments">
      There you go again.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21045" shape="rect">shmegegge</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700418" shape="rect">12:10 PM</a>
        on August 18, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700418" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700424" shape="rect"></a>
    <div class="comments">
      I was more afraid it was going to be &quot;faith based&quot; health care, in which case, Ronald Reagan speaking out right now would be even more... biblical?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/34601" shape="rect">yeloson</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700424" shape="rect">12:15 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700427" shape="rect"></a>
    <div class="comments">
      Under a British-style socialized medicine system, Ronald Reagan would be dead.
      <br clear="none"></br>
      <br clear="none"></br>
      Think about that.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/43080" shape="rect">game warden to the events rhino</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700427" shape="rect">12:16 PM</a>
        on August 18, 2009 [
        <a title="26 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700427" shape="rect">26 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700434" shape="rect"></a>
    <div class="comments">
      Under a British-style socialized medicine system, Ronald Reagan would
      <em>still</em>
      be dead.
      <br clear="none"></br>
      <br clear="none"></br>
      If socialists can't raise the dead, I don't want my taxes paying for it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30706" shape="rect">Blazecock Pileon</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700434" shape="rect">12:19 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700434" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700435" shape="rect"></a>
    <div class="comments">
      <i>...a stealth program by the American Medical Associaltion in opposition to what would later be Medicare.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      <b>
        <i>...a stealth program by the American Medical Associaltion in opposition to what would later be Medicare.</i>
      </b>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/49143" shape="rect">DU</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700435" shape="rect">12:19 PM</a>
        on August 18, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700435" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700436" shape="rect"></a>
    <div class="comments">
      On the one hand, for reasonable people it seems like this is a direct counterexample to the claims of the far right on health care reform.  On the other, those people are insane and will instead interpret it as &quot;St. Gipper was right!  Never forget the wisdom of holy Regan!&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/55219" shape="rect">a robot made out of meat</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700436" shape="rect">12:19 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700437" shape="rect"></a>
    <div class="comments">
      Under a British-style socialized medical system, Reagan's diagnosis of Alzheimer's would've been made six months before he was elected.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/206" shape="rect">wendell</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700437" shape="rect">12:19 PM</a>
        on August 18, 2009 [
        <a title="13 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700437" shape="rect">13 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700439" shape="rect"></a>
    <div class="comments">
      Wait, Ronald Reagan's dead?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/43080" shape="rect">game warden to the events rhino</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700439" shape="rect">12:19 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700442" shape="rect"></a>
    <div class="comments">
      Why did Ronald Reagan
      <a href="http://www.metafilter.com/84229/The-Views-From-Your-Sickbed#2700048" shape="rect">hate what our Founding Fathers stood for</a>
      ?!
      <br clear="none"></br>
      <br clear="none"></br>
      Did he really believe that opposing healthcare for all Americans promoted the general welfare.. because I doubt Jefferson felt the same way, and he wrote that bit.
      <br clear="none"></br>
      <br clear="none"></br>
      Reagan and his ilk were just fine at securing the blessings of liberty for themselves.
      <br clear="none"></br>
      <br clear="none"></br>
      Securing the blessings of liberty for ourselves -- meaning all of us -- and for our posterity?! Not so much.
      <br clear="none"></br>
      <br clear="none"></br>
      One thing our Founding Fathers weren't is selfish.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/4898" shape="rect">markkraft</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700442" shape="rect">12:20 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700442" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700451" shape="rect"></a>
    <div class="comments">
      I remember I first heard this just days before I was whisked away from my parents and interred at Liberal Education Center 454-TX to be molded into the very successful young Obama Youth Socialist Church Bulldozer I am today. I disagreed with it when I heard it then, but after my bulldozing accident when Federal law mandated that I wait three years to have my arm put in a cast -- with a requirement that an elected official be present to make sure absolutely no one associated with my health care would profit one thin dime -- that's when I decided to save up and buy some posterboard and markers with the 4% of my post-tax earning the government allows me to keep and go picket at the White House with my government-mandated homosexual life-partner Steve.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/20052" shape="rect">chasing</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700451" shape="rect">12:23 PM</a>
        on August 18, 2009 [
        <a title="19 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700451" shape="rect">19 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700454" shape="rect"></a>
    <div class="comments">
      The Samantha-Fox-Speaks-Out-Against-Socialized-Medicine 12&quot; Picture Disc was so much more convincing.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76785" shape="rect">Dumsnill</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700454" shape="rect">12:24 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700454" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700459" shape="rect"></a>
    <div class="comments">
      Carter vs. Reagan:
      <a href="http://www.youtube.com/watch?v=Wi9y5-Vo61w" shape="rect">&quot;There you go again&quot;</a>
      <br clear="none"></br>
      <br clear="none"></br>
      <a href="http://www.larrydewitt.net/Essays/Reagan.htm" shape="rect">This essay</a>
      is the best background of Reagan and Medicare.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92677" shape="rect">@troy</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700459" shape="rect">12:26 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700459" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700472" shape="rect"></a>
    <div class="comments">
      Wait, what about enemy inflation? How can we
      <em>still</em>
      be fighting against
      <strong>socialized</strong>
      medicine after all this time? Surely new enemies have arisen or grown in the last fifty years, and by now we should be struggling against islamofascist medicine or evilChinesecommunist medicine or gayagendatheywanttobrainwashourchildren medicine?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/85808" shape="rect">Sova</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700472" shape="rect">12:31 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700472" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700484" shape="rect"></a>
    <div class="comments">
      It's not as good as his seminal Phil Spector-produced record &quot;Ronald Reagan Speaks Out Against Unmurdered Nuns in El Salvador.&quot; It's often said that only 3000 people ever bought it, but all of them started a death squad.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/95313" shape="rect">&quot;Elbows&quot; O'Donoghue</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700484" shape="rect">12:33 PM</a>
        on August 18, 2009 [
        <a title="23 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700484" shape="rect">23 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700502" shape="rect"></a>
    <div class="comments">
      <i>
        Wait, what about enemy inflation? How can we still be fighting against socialized medicine after all this time? Surely new enemies have arisen or grown in the last fifty years, and by now we should be struggling against islamofascist medicine or evilChinesecommunist medicine or gayagendatheywanttobrainwashourchildren medicine?
      </i>
      <br clear="none"></br>
      <br clear="none"></br>
      CRISIS ON INFINITE MEDICARE!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/25884" shape="rect">Artw</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700502" shape="rect">12:39 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700526" shape="rect"></a>
    <div class="comments">
      Reagan warns at the end about what will happen if Medicare becomes a reality:
      <br clear="none"></br>
      <br clear="none"></br>
      <small>
        Write those letters now; call your friends and them to write them. If you donâ€™t, this program I promise you, will pass just as surely as the sun will come up tomorrow, and behind it will come other federal programs that will invade every area of freedom as we have known it in this country. Until, one day, as Normal Thomas said we will awake to find that we have socialism. And if you donâ€™t do this and if I donâ€™t do it, one of these days you and I are going to spend our sunset years telling our children and our childrenâ€™s children, what it once was like in America when men were free.
      </small>
      <br clear="none"></br>
      <br clear="none"></br>
      Remember what it was once like in America, when men were free? Good times.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/28637" shape="rect">EarBucket</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700526" shape="rect">12:47 PM</a>
        on August 18, 2009 [
        <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700526" shape="rect">5 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700563" shape="rect"></a>
    <div class="comments">
      <i>we will awake to find that we have socialism.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Nope, we still only have socialism in our dreams.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17432" shape="rect">uncleozzy</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700563" shape="rect">12:59 PM</a>
        on August 18, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700563" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700569" shape="rect"></a>
    <div class="comments">
      <i>The Samantha-Fox-Speaks-Out-Against-Socialized-Medicine 12&quot; Picture Disc was so much more convincing.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      You think so? I found it interesting for about three minutes. Then very interesting. Then suddenly I lost interest.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16634" shape="rect">lumpenprole</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700569" shape="rect">1:00 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700569" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700571" shape="rect"></a>
    <div class="comments">
      Thanks for giving me a little flashback into why I hated that simpleminded smug bastard so much.
      <br clear="none"></br>
      <br clear="none"></br>
      Meanwhile NPR's afternoon call-in show has been drawing the right-wingers left and right. &quot;I want the government 100% out of all things having to do with healthcare!&quot; shouts one caller as I was driving back from lunch. &quot;Only pure capitalism will ensure healthcare works properly! We haven't let pure capitalism do its job!&quot; Good grief. I feel like we're approaching a conceptual convergence of purifying capitalism and General Jack Ripper's precious American bodily fluids. (Cue Viagra ad.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/29809" shape="rect">aught</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700571" shape="rect">1:02 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700588" shape="rect"></a>
    <div class="comments">
      <i>&quot;Nope, we still only have socialism in our dreams.&quot;</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Ah, yes, sweet socialism. Can't wait until we have government provided medical care, food, and housing here in America. Hopefully government provided TV, cell phones, and Internet too. Only then will my dream of staying home in my underwear, posting on the Blue all day and surfing porn instead of working every day come true!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92265" shape="rect">TheFlamingoKing</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700588" shape="rect">1:10 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700590" shape="rect"></a>
    <div class="comments">
      call-in-shows suck balls and scott simons program is no different. I don't want to hear what todd truckdriver and missy metermaid want to spout, I want someone knowledgeable who invested the time to dig into an argument and evaluate it to give me an actual overview based on which I can come to my own conclusion.
      <br clear="none"></br>
      <br clear="none"></br>
      that said I don't know why this was FPP-worthy at all. reagan was a dopy actor that got elected because enough people had a boner for cowboys and disliked peanut farmers.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30775" shape="rect">krautland</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700590" shape="rect">1:11 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700590" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700593" shape="rect"></a>
    <div class="comments">
      <em>Carter vs. Reagan: &quot;There you go again&quot;</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Context is everything. Boy howdy.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18526" shape="rect">nola</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700593" shape="rect">1:12 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700607" shape="rect"></a>
    <div class="comments">
      <em>
        Ah, yes, sweet socialism. Can't wait until we have government provided medical care, food, and housing here in America. Hopefully government provided TV, cell phones, and Internet too. Only then will my dream of staying home in my underwear, posting on the Blue all day and surfing porn instead of working every day come true!
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      If that's socialism, then fuckin' a, sign me up.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19123" shape="rect">NoMich</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700607" shape="rect">1:18 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700613" shape="rect"></a>
    <div class="comments">
      <em>
        Ah, yes, sweet socialism. Can't wait until we have government provided medical care, food, and housing here in America. Hopefully government provided TV, cell phones, and Internet too. Only then will my dream of staying home in my underwear, posting on the Blue all day and surfing porn instead of working every day come true!
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      *fap fap fap*
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18526" shape="rect">nola</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700613" shape="rect">1:20 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700613" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700615" shape="rect"></a>
    <div class="comments">
      Yeah, man, the only helping hand anyone needs is the invisible one!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17432" shape="rect">uncleozzy</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700615" shape="rect">1:22 PM</a>
        on August 18, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700615" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700619" shape="rect"></a>
    <div class="comments">
      The invisible hand kinda gave us the finger didn't it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/40584" shape="rect">Mister_A</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700619" shape="rect">1:24 PM</a>
        on August 18, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700619" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700627" shape="rect"></a>
    <div class="comments">
      It isn't that Reagan
      <i>believed</i>
      this, it's that he was well compensated to act as though he believed it. He probably didn't have an actual care in the world outside of, oh, &quot;what's for dinner, mommy?&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23718" shape="rect">blixco</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700627" shape="rect">1:27 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700641" shape="rect"></a>
    <div class="comments">
      <em>that got elected because enough people had a boner for cowboys and disliked peanut farmers.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I'm guessing this was a comment made by someone from Europe.  I guess that because Europeans often seem to think that Americans care about cowboys as much as Europeans apparently do.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/51575" shape="rect">The World Famous</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700641" shape="rect">1:31 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700641" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700643" shape="rect"></a>
    <div class="comments">
      Wouldn't &quot;pure capitalism&quot; mean doing away with all insurance companies completely?  I mean, pooling resources to minimize individual risk... that's not capitalism, is it?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700643" shape="rect">1:31 PM</a>
        on August 18, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700643" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700648" shape="rect"></a>
    <div class="comments">
      I can't believe Reagan was a douchebag all the way back in 1961!
      <br clear="none"></br>
      <br clear="none"></br>
      *snicker*
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/74627" shape="rect">Ron Thanagar</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700648" shape="rect">1:33 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700650" shape="rect"></a>
    <div class="comments">
      The Invisible Hand is ok.
      <br clear="none"></br>
      <br clear="none"></br>
      The Invisibile Death Panel, not so much.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16106" shape="rect">mazola</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700650" shape="rect">1:33 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700653" shape="rect"></a>
    <div class="comments">
      <em>Wait, Ronald Reagan's dead?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      No, you heathen, not anymore. On the third day, He rose again.
      <br clear="none"></br>
      <br clear="none"></br>
      <br clear="none"></br>
      <br clear="none"></br>
      <em>Duh.</em>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15909" shape="rect">grubi</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700653" shape="rect">1:34 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700676" shape="rect"></a>
    <div class="comments">
      On the other hand...in 1961, we didn't have the wealth of data that shows how relatively poor the US health care system is performing (% of GDP, $ per capita, overall wellness of society, etc.).  So it's more understandable, to me at least, that someone would challenge &quot;socialized medicine&quot; on more of a philosophical basis back then.  In 2009, however, based on the performance of our system vs others, I don't see how that line of reasoning continues to resonate.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/80367" shape="rect">brandman</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700676" shape="rect">1:50 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700676" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700680" shape="rect"></a>
    <div class="comments">
      Thank you for this post. I'll be forwarding it to others, as one of my favorite things is to talk to people (60+) who are facing retirement or are already retired, about all those &quot;terrible&quot; socialist things... you know, like Social Security and Medicare. It's worth it to see their gears grinding over this, having to argue that socialized medicine is not ok, but Medicare is something they will eagerly accept.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45714" shape="rect">Houstonian</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700680" shape="rect">1:52 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700681" shape="rect"></a>
    <div class="comments">
      Don't like socialism? Cool, let's define that term. If you define it as government-back agencies providing for the people at the people's expense, and you don't want that, then we got a lot of stuff to dismantle.
      <br clear="none"></br>
      <br clear="none"></br>
      The armed forces, Medicare, Medicaid, Social Security, most of the educational system, police forces, fire departments.... heavens, let's not allow the government to PROVIDE FOR THE COMMON DEFENSE or PROMOTE THE GENERAL WELFARE or anything.
      <br clear="none"></br>
      <br clear="none"></br>
      That would be (*shudder*)
      <em>socialism!</em>
      And if we have
      <em>socialism!</em>
      , then we sure as shit won't work for a living anymore.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15909" shape="rect">grubi</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700681" shape="rect">1:52 PM</a>
        on August 18, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700681" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700689" shape="rect"></a>
    <div class="comments">
      It never ceases to amaze me how the Right is still flogging the idea that any form of government involvement in maintenance of quality of life is socialism. Opposition to public option health care now will, in 20 years time, probably seem the same as former Senator Dick Cheney's opposition to the Clean Water and Air Act does today. I still wonder if that guy collects his drinking water from rain barrels.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700689" shape="rect">1:57 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700689" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700702" shape="rect"></a>
    <div class="comments">
      <em>The armed forces, Medicare, Medicaid, Social Security, most of the educational system, police forces, fire departments.... heavens, let's not allow the government to PROVIDE FOR THE COMMON DEFENSE or PROMOTE THE GENERAL WELFARE or anything.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I know a lot of well-educated Republicans who would propose exactly this and who have, in discussions where I have made that exact point, responded that they do believe that all of those things should be completely privatized and unregulated.
      <br clear="none"></br>
      <br clear="none"></br>
      Because it is a political debate, it is not about logic or persuasion.  It is about holding a battle line at all costs.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/51575" shape="rect">The World Famous</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700702" shape="rect">2:01 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700702" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700708" shape="rect"></a>
    <div class="comments">
      Great Dambalaah brought him back in the body of a Laugh-a-Lot baby.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/24530" shape="rect">qvantamon</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700708" shape="rect">2:04 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700717" shape="rect"></a>
    <div class="comments">
      Is this i-ronnie?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45298" shape="rect">MuffinMan</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700717" shape="rect">2:09 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700717" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700743" shape="rect"></a>
    <div class="comments">
      <em>The LP was a product of Operation Coffee Cup, a stealth program by the American Medical Associaltion in opposition to what would later be Medicare.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      This is what lured my father, an educated and very intelligent neurosurgeon, into drinking the right-wing KoolAid. He was so angry about &quot;socialized medicine&quot; that he refused to accept Medicare patients, and treated them for free off the books. He grew tighter and tighter with the Reagan movement, subscribed to Human Events and National Review, and eventually became a Reagan delegate at the '76 convention.
      <br clear="none"></br>
      <br clear="none"></br>
      He was a hero to me as I grew up and I reflexively adopted his conservative stance, which at the time seemed to be based on some principles. I knew from my mother that when he was an Air Force flight surgeon, he had disobeyed his alcoholic superior officer and performed surgery on the base commander's daughter's appendix, potentially saving her life. He's in his 80s now, tied to his oxygen (from 57 years of smoking 2 packs a day), and watching FauxNews in his armchair. He repeats all the stupid talking points and doesn't bother trying to understand the wider context of anything beyond what his narrow sources present. It saddens me.
      <br clear="none"></br>
      <br clear="none"></br>
      The irony is that he quit practice when he was 62 and recently he disclosed to me the event that triggered his quitting. He had a patient who he felt needed surgery, but the patient's coverage was denied. He was so disgusted that he did the surgery gratis and then sold his practice. The irony? It was a private insurance company.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21634" shape="rect">Mental Wimp</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700743" shape="rect">2:30 PM</a>
        on August 18, 2009 [
        <a title="17 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700743" shape="rect">17 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700764" shape="rect"></a>
    <div class="comments">
      <em>He was so angry about &quot;socialized medicine&quot; that he refused to accept Medicare patients, and treated them for free off the books.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Can we get more conservative-minded doctors of this ilk these days?  I have more than one medical question I need answered and teeth that need tending, and haven't had insurance in over a decade.  I'd be happy to pretend I was on Medic-suffix in order to get off-the-books care from someone who really is a &quot;compassionate conservative.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700764" shape="rect">2:45 PM</a>
        on August 18, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700764" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700774" shape="rect"></a>
    <div class="comments">
      The America I know and love is not one in which my parents or my baby with Down Syndrome will have to stand in front of Obama's &quot;brains panel&quot; so his bureaucrats can decide, based on a subjective judgment of their &quot;level of productivity in society,&quot; whether they are worthy of not having their brains eaten by zombies. Such a system is downright evil.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50346" shape="rect">l33tpolicywonk</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700774" shape="rect">2:50 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700774" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700819" shape="rect"></a>
    <div class="comments">
      I wish I could find the video of his colonscopy online
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30104" shape="rect">A189Nut</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700819" shape="rect">3:21 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700824" shape="rect"></a>
    <div class="comments">
      <i>Don't like socialism? Cool, let's define that term. If you define it as government-back agencies providing for the people at the people's expense, and you don't want that, then we got a lot of stuff to dismantle.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Indeed.
      <br clear="none"></br>
      <br clear="none"></br>
      You can call pretty much anything &quot;common defense&quot; or &quot;general welfare&quot; - that doesn't make it so.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23938" shape="rect">stewiethegreat</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700824" shape="rect">3:24 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700898" shape="rect"></a>
    <div class="comments">
      <a href="http://wonkette.com/410585/evil-evil-woman-yells-heil-hitler-at-jewish-guy-defending-israels-health-care-system#comments" shape="rect">
        Crazed anti-healthcare woman in an Isreali Defense Force t-shirt screams &quot;Heil Hitler&quot; at a Jewish Isreali-American when he praises their government-run healthcare system.
      </a>
      <br clear="none"></br>
      <br clear="none"></br>
      (I'm linking to the Wonkette thread because the video doesn't seem to work anymore.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18247" shape="rect">dirigibleman</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700898" shape="rect">4:11 PM</a>
        on August 18, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700898" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700903" shape="rect"></a>
    <div class="comments">
      Crazed blimp-like man spells &quot;Israeli&quot; wrong twice in a single sentence.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18247" shape="rect">dirigibleman</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700903" shape="rect">4:13 PM</a>
        on August 18, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700903" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700930" shape="rect"></a>
    <div class="comments">
      <a href="http://www.theonion.com/content/video/study_most_children_strongly" shape="rect">Study: Most Children Strongly Opposed to Childrens Healthcare</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/34026" shape="rect">floam</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700930" shape="rect">4:39 PM</a>
        on August 18, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2700930" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2700997" shape="rect"></a>
    <div class="comments">
      <i>then we got a lot of stuff to dismantle</i>
      <br clear="none"></br>
      <br clear="none"></br>
      You been listenin' to Sarah Palin'
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/53579" shape="rect">valentinepig</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2700997" shape="rect">5:12 PM</a>
        on August 18, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2701077" shape="rect"></a>
    <div class="comments">
      Amusing comment from the Wonkette thread:
      <br clear="none"></br>
      <br clear="none"></br>
      WELL Iâ€™M PROUD TO BE AN AMERICAN
      <br clear="none"></br>
      WHERE AT LEAST I KNOW Iâ€™M FREE
      <br clear="none"></br>
      AND Iâ€™LL SCREAM HEIL HITLER TO ANYONE
      <br clear="none"></br>
      WHOSE NOT THE SAME AS ME
      <br clear="none"></br>
      AND I HATE THE PUBLIC OPTION
      <br clear="none"></br>
      CAUSE FREEDOM ISNâ€™T FREE
      <br clear="none"></br>
      ITS EXPENSIVE AS HELL, AND ITS HOW I CAN TELL
      <br clear="none"></br>
      YOUâ€™RE NOT AS RICH AS ME
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/12990" shape="rect">jokeefe</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2701077" shape="rect">6:05 PM</a>
        on August 18, 2009 [
        <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2701077" shape="rect">8 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2701567" shape="rect"></a>
    <div class="comments">
      <em>You can call pretty much anything &quot;common defense&quot; or &quot;general welfare&quot; - that doesn't make it so.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Wait, what?
      <br clear="none"></br>
      <br clear="none"></br>
      The military and the police aren't providing for the common defense? Medicare, Medicaid, and education aren't promoting the general welfare?
      <br clear="none"></br>
      <br clear="none"></br>
      Are you nuts?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15909" shape="rect">grubi</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2701567" shape="rect">5:22 AM</a>
        on August 19, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2702030" shape="rect"></a>
    <div class="comments">
      Socialism does not mean whatever right-wing loons with AK-47s want it to mean, nor does it even mean what a lot of left-wingers want it to mean.
      <br clear="none"></br>
      <br clear="none"></br>
      Socialism, as defined by the political theorists who originally conceived of it, is a temporary transitional condition that a formerly capitalist state passes through on its way to full blown communism.
      <br clear="none"></br>
      <br clear="none"></br>
      Socialism is defined by the government seizing the means of economic and industrial production by force--meaning, the state forcefully seizes all farmland, privately owned natural resources, factories, warehouses, retail stores, the distribution mechanisms for manufactured goods, etc.--and then imposes state control over all those means of economic production, using central planning, until such time as conditions are right for the transition to a full-fledged communist state, at which point (in theory, though this has never actually happened in practice) the means of production would be turned over to the workers, who would then establish a worker's paradise.
      <br clear="none"></br>
      <br clear="none"></br>
      Now, acknowledging the above, if anyone can look me in the eye for even one second and tell me with a straight face they honestly believe health care reform is going to bring us even the tiniest fraction closer to this happening in America, then I'll gladly buy at least a half-ounce of whatever it is they're smoking.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/39114" shape="rect">saulgoodman</a>
        at
        <a target="_self" href="/84242/Ronald-Reagan-Speaks-Out-Against-Socialized-Medicine#2702030" shape="rect">9:16 AM</a>
        on August 19, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2702030" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/84241/Do-I-know-you" shape="rect">« Older</a>
      What you don't know about your friends: The proble...  |  Two girls, one bike....
      <a target="_self" href="/84243/fixie-hipster" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/93824/FDR-People-who-are-hungry-people-who-are-out-of-a-job-are-the-stuff-of-which-dictatorships-are-made" shape="rect">FDR: &quot;People who are hungry, people who are out of...</a>
      <span class="smallcopy">July 16, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/64539/Ronald-Reagan-A-Graphic-Biography" shape="rect">Ronald Reagan: A Graphic Biography</a>
      <span class="smallcopy">September 8, 2007</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/59509/Tim-OBrien-Every-Time-Youah-forget-it" shape="rect">Tim O'Brien: Every Time You...ah, forget it.</a>
      <span class="smallcopy">March 16, 2007</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/33498/RIP-RWR" shape="rect">R.I.P. R.W.R.</a>
      <span class="smallcopy">June 5, 2004</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/8141/The-Reagan-Papers" shape="rect">The Reagan Papers?</a>
      <span class="smallcopy">June 7, 2001</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    decide   ,�     recorded   ,     program   .     August   )[     bike   ́     Medicare   .Z     freedom   ,�     
opposition   .8     curtail   ,�     Security   ,]         1http://en.wikipedia.org/wiki/Operation_Coffee_Cup    Operation Coffee Cup   -�     nwill go or what he will do for a living. He will wait for the government to tell him." The LP was a product of    �, a stealth program by the American Medical Associaltion in opposition to what would later be Medicare. A history of the campaign from HuffPost .    Operation Coffee Cup      9202a8c04000641f80000000004f7e52    >��    Bhttp://www.metafilter.com/84366/The-little-girl-with-the-big-voice    {�<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>&quot;The little girl with the big voice.&quot; | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/84366/The-little-girl-with-the-big-voice" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/84366/The-little-girl-with-the-big-voice/rss" title="Comments on: 'The little girl with the big voice.'" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/TimiYuro" shape="rect">TimiYuro</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/soul" shape="rect">soul</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/rhythmandblues" shape="rect">rhythmandblues</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/country" shape="rect">country</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/singer" shape="rect">singer</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20%27The%20little%20girl%20with%20the%20big%20voice%2E%27%20http%3A%2F%2Fmefi%2Eus%2Fw%2F84366" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/84366/The-little-girl-with-the-big-voice" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        &quot;The little girl with the big voice.&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          August 22, 2009 7:18 AM  
          <a href="http://www.metafilter.com/84366/The-little-girl-with-the-big-voice/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/84366/The-little-girl-with-the-big-voice/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://www.timi-yuro.com/index.php?option=com_content&amp;view=article&amp;id=3&amp;Itemid=4" shape="rect">Timi Yuro</a>
        , an Italian-American singer born in Chicago (where, the story goes, her nanny snuck her into clubs to watch singers like Dinah Washington and Mildred Bailey), was arguable the greatest
        <a href="http://en.wikipedia.org/wiki/Blue-eyed_soul" shape="rect">blue-eyed soul</a>
        artist of the '60s.
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        In 1961 she had her first (and biggest) hit with a cover of Roy Hamilton's emotional ballad
        <a href="http://www.youtube.com/watch?v=BPy-Memj0vE" shape="rect">&quot;Hurt&quot;</a>
        , so powerfully sung that many listeners first assumed she was a man, African-American, or both. Follow-ups
        <a href="http://www.youtube.com/watch?v=yyrKInU5Dp4" shape="rect">&quot;I Believe&quot;</a>
        (a duet with
        <a href="http://en.wikipedia.org/wiki/Johnnie_Ray" shape="rect">Johnnie Ray</a>
        ) and
        <a href="http://www.youtube.com/watch?v=K84AxywaeKs&amp;feature=PlayList&amp;p=C7CF470BB77615A9&amp;index=0" shape="rect">&quot;Let Me Call You Sweetheart&quot;</a>
        were also successful, but established her in the public's mind as a cabaret performer rather than a soul singer. This all changed with the release of her next single, the r&amp;b barnburner
        <a href="http://www.youtube.com/watch?v=9qjTQRscacs&amp;feature=related" shape="rect">&quot;What's A Matter Baby&quot;</a>
        and the 1963 LP
        <i>Make The World Go Away</i>
        , a collection of soulful country covers that included goose pimple-inducing renditions of
        <a href="http://www.youtube.com/watch?v=cOtYZhhjriY" shape="rect">&quot;Leavin' On Your Mind&quot;</a>
        and
        <a href="http://www.youtube.com/watch?v=oHD2WNgp64E" shape="rect">the title track</a>
        , which would prove to be her last significant U.S. hit.
        <a href="http://www.youtube.com/watch?v=BARjGgJfaI0" shape="rect">&quot;Can't Stop Running Away&quot;</a>
        and
        <a href="http://www.youtube.com/watch?v=SW8ZEXgRztM" shape="rect">&quot;Interlude&quot;</a>
        went on to become
        <a href="http://en.wikipedia.org/wiki/Northern_soul" shape="rect">Northern Soul</a>
        favourites, but by the end of the '60s she had more or less left the music business, resurfacing only to record a few stray singles (including a 1979 cover of
        <a href="http://www.youtube.com/watch?v=8NaAMFW8Elc" shape="rect">&quot;Nothing Takes The Place Of You&quot;</a>
        ) before she was diagnosed with throat cancer in 1980. In 1984 she was forced to undergo a tracheotomy operation, which ended her singing career, but she lived on until March 30th, 2004, when she passed at the age of 63.
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17480" shape="rect">The Card Cheat</a>
        (8 comments total)
        <span id="favcnt184366">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/84366" shape="rect">16 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2706616" shape="rect"></a>
    <div class="comments">
      Nice post. My own favourite:
      <a href="http://www.youtube.com/watch?v=20XMx-ijnW8" shape="rect">It'll never be over for me</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/20844" shape="rect">PeterMcDermott</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706616" shape="rect">7:52 AM</a>
        on August 22, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2706616" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706739" shape="rect"></a>
    <div class="comments">
      Hurt is a wonderful song!
      <br clear="none"></br>
      <br clear="none"></br>
      I first became aware of Timi Yuro through her association with Johnnie Ray. They did few songs together if I recall correctly. Johnnie had more than his share of cheese but he also had some great, great
      <a href="http://www.youtube.com/watch?v=rVn0SIvakFU" shape="rect">songs</a>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      Looking forward to hearing some more Timi.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18460" shape="rect">ericthegardener</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706739" shape="rect">10:44 AM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706742" shape="rect"></a>
    <div class="comments">
      Just listened to your link PeterMcDermott. I gotta get me some of that!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18460" shape="rect">ericthegardener</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706742" shape="rect">10:48 AM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706750" shape="rect"></a>
    <div class="comments">
      Not to dominate the thread but I forgot to post the Johnnie Ray/Timi Yuro
      <a href="http://www.youtube.com/watch?v=yyrKInU5Dp4" shape="rect">song</a>
      . Frankly not nearly as cool as her solo stuff.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18460" shape="rect">ericthegardener</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706750" shape="rect">10:56 AM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706883" shape="rect"></a>
    <div class="comments">
      Thanks. My mom had a bunch of Timi Yuro albums, but I have not heard her since I was a kid.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/356" shape="rect">litlnemo</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706883" shape="rect">2:17 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706943" shape="rect"></a>
    <div class="comments">
      Elvis covered &quot;Hurt&quot; in the Aloha concert. Was he doing the Timi version or the original? Me thinks the girl...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/31704" shape="rect">bonefish</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2706943" shape="rect">3:20 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707027" shape="rect"></a>
    <div class="comments">
      Thanks for posting this
      <b>Card Cheat</b>
      , you've brought back a bunch of old memories. Timi's voice is significant part of my youthful years. I see that despite the small number of comments you've run a high percentage of Mefites favoriting this post.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21071" shape="rect">X4ster</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2707027" shape="rect">5:43 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707105" shape="rect"></a>
    <div class="comments">
      Her
      <em>nanny</em>
      ?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/51566" shape="rect">ethnomethodologist</a>
        at
        <a target="_self" href="/84366/The-little-girl-with-the-big-voice#2707105" shape="rect">7:37 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/84365/With-whom-it-starts" shape="rect">« Older</a>
      Healthcare reform has agitated right-wing extremis...  |  The Atlanta Journal-Constituti...
      <a target="_self" href="/84367/Calley-Apologizes-for-My-Lai-Massacre" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/114417/Response-Records-Answers-to-Hit-Songs" shape="rect">Response Records: Answers to Hit Songs</a>
      <span class="smallcopy">March 31, 2012</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/111121/Drink-up-yall" shape="rect">Drink up, y'all!</a>
      <span class="smallcopy">December 30, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/67346/Eight-Bars-of-Soul" shape="rect">Eight Bars of Soul</a>
      <span class="smallcopy">December 11, 2007</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/66202/Barbara-Lynn-Ozen-songwriter-guitarist-singer" shape="rect">Barbara Lynn Ozen: songwriter, guitarist, singer.</a>
      <span class="smallcopy">November 4, 2007</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/43215/Luther-Vandross-RIP" shape="rect">Luther Vandross: RIP</a>
      <span class="smallcopy">July 1, 2005</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    Leavin   1     arguable   ,     track   1n     resurfacing   3     eyed   ,n     forced   4     minutes   �     cancer   3�     	listeners   -�     would   1         +http://en.wikipedia.org/wiki/Blue-eyed_soul    blue-eyed soul   ,i     �in Chicago (where, the story goes, her nanny snuck her into clubs to watch singers like Dinah Washington and Mildred Bailey), was arguable the greatest    �artist of the '60s. In 1961 she had her first (and biggest) hit with a cover of Roy Hamilton's emotional ballad "Hurt" , so powerfully    blue-eyed soul      9202a8c04000641f80000000002b31dc     (http://en.wikipedia.org/wiki/Johnnie_Ray    Johnnie Ray   .�     �emotional ballad "Hurt" , so powerfully sung that many listeners first assumed she was a man, African-American, or both. Follow-ups "I Believe" (a duet with    �) and "Let Me Call You Sweetheart" were also successful, but established her in the public's mind as a cabaret performer rather than a soul    Johnnie Ray      9202a8c04000641f80000000001d3d1c     *http://en.wikipedia.org/wiki/Northern_soul    Northern Soul   2�     �and the title track , which would prove to be her last significant U.S. hit. "Can't Stop Running Away" and "Interlude" went on to become    �favourites, but by the end of the '60s she had more or less left the music business, resurfacing only to record a few stray singles    Northern Soul      9202a8c04000641f8000000000255a8c    >��    ;http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams    �p<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Noepe: &quot;Land Amid the Streams.&quot; | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams/rss" title="Comments on: Noepe: 'Land Amid the Streams.'" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Martha%27sVineyard" shape="rect">Martha'sVineyard</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Massachusetts" shape="rect">Massachusetts</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Obama" shape="rect">Obama</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/BarackObama" shape="rect">BarackObama</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Noepe%3A%20%27Land%20Amid%20the%20Streams%2E%27%20http%3A%2F%2Fmefi%2Eus%2Fw%2F84376" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Noepe: &quot;Land Amid the Streams.&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          August 22, 2009 4:48 PM  
          <a href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        This weekend the Obama family arrives on the Massachusetts' island of
        <a href="http://en.wikipedia.org/wiki/Martha's_Vineyard" shape="rect">Martha's </a>
        <a href="http://www.plumtv.com/vineyard/" shape="rect">Vineyard</a>
        for a week-long vacation. While known as a summer colony/destination for New Englanders, tourists and the
        <a href="http://www.usatoday.com/travel/destinations/2009-08-20-marthas-vineyard_N.htm" shape="rect">famous</a>
        <sup>
          <small>
            <a href="http://www.amazon.com/exec/obidos/ASIN/0385505663/metafilter-20/ref=nosim/" shape="rect">1</a>
          </small>
        </sup>
        the island has a
        <a href="http://www.marthasvineyardhistory.org/" shape="rect">storied history </a>
        from its early pre-colonial days to today. The Obamas' visit highlights the
        <a href="http://www.washingtonpost.com/wp-dyn/content/article/2009/08/19/AR2009081904045.html" shape="rect">island's proud connection</a>
        to its deep
        <a href="http://www.mvheritagetrail.org/" shape="rect"> African-American heritage</a>
        as a &quot;
        <a href="http://www.time.com/time/magazine/article/0,9171,1916312,00.html" shape="rect">well integrated</a>
        &quot; community (especially
        <a href="http://ngm.nationalgeographic.com/ngm/0306/feature8/" shape="rect">Oaks</a>
        <a href="http://ngm.nationalgeographic.com/ngm/0306/feature8/fulltext.html" shape="rect">Bluff</a>
        )
        <sup>
          <small>
            <a href="http://www.oakbluffsmv.com/OBA/Welcome_to_Oak_Bluffs,_Massachusetts_The_Best_of_Marthas_Vineyard.html" shape="rect">2</a>
          </small>
        </sup>
        from the days that freed slaves and retired black whalers settled and established homes and businesses on the island.
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        <sup>
          <small>*</small>
        </sup>
        -- Art Buchwald, Carly Simon, Dan Aykroyd, Henry Louis Gates Jr., James Taylor, Jim Belushi [buried in Abel's Hill Cemetery in Chilmark], Mike Wallace, Spike Lee, Ted Danson, Vernon Jordan, Walter Cronkite, etc.
        <br clear="none"></br>
        <br clear="none"></br>
        '
        <a href="http://www.amazon.com/exec/obidos/ASIN/0385505663/metafilter-20/ref=nosim/" shape="rect">Finding Martha's Vineyard: African Americans at Home on an Island</a>
        ' by Jill Nelson.
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://www.herringcreekfarm.com/museum_landusage.htm" shape="rect">Noepe: Land Amid the Streams</a>
        .
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
        (25 comments total)
        <span id="favcnt184376">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/84376" shape="rect">6 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2706990" shape="rect"></a>
    <div class="comments">
      Screw the Congressional healthcare plan, I want the Presidential vacation plan.
      <br clear="none"></br>
      <br clear="none"></br>
      <small>(and John Belushi died, not Jim)</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16464" shape="rect">Frank Grimes</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2706990" shape="rect">4:52 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2706999" shape="rect"></a>
    <div class="comments">
      You are right!
      <br clear="none"></br>
      <br clear="none"></br>
      It's *John Belushi*! As memoralized in his friend's song &quot;
      <a href="http://www.youtube.com/watch?v=-FYcm8tmSU4" shape="rect">That's Why I'm Here</a>
      &quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2706999" shape="rect">5:08 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707002" shape="rect"></a>
    <div class="comments">
      <a href="http://www.thegrio.com/2009/08/on-sunday-president-obama-and.php" shape="rect">A Shearer Cottage Inn register from 1934 features names of notable African Americans</a>
      , including that of composer, arranger, and baritone soloist &quot;Harry&quot; T. Burleigh, in Oak Bluffs, on the island of Martha's Vineyard.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/951" shape="rect">netbros</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707002" shape="rect">5:12 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707005" shape="rect"></a>
    <div class="comments">
      Oak Bluffs, not Oaks Bluff.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/75777" shape="rect">Zambrano</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707005" shape="rect">5:16 PM</a>
        on August 22, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707005" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707010" shape="rect"></a>
    <div class="comments">
      <a href="http://en.wikipedia.org/wiki/Martha's_Vineyard_(band)" shape="rect">Martha's Vineyard</a>
      was a famous Perth band. I knew of the band before the place. Then I had one of those quirky &quot;I knew the least famous version before the most famous version&quot; moments that I'm sure most of us have had.
      <br clear="none"></br>
      <br clear="none"></br>
      JFK? Martha's Vineyard? WTF?!
      <br clear="none"></br>
      <br clear="none"></br>
      <small>
        <small>The big news in Australia regarding this was that Michelle was wearing shorts when she alighted from Airforce One.</small>
      </small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16013" shape="rect">uncanny hengeman</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707010" shape="rect">5:23 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707020" shape="rect"></a>
    <div class="comments">
      <em>Oak Bluffs, not Oaks Bluff.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      My bad. Too much â€œ
      <a href="http://www.offshoreale.com/" shape="rect">Ale</a>
      <a href="http://www.nytimes.com/2009/08/16/fashion/16vineyard.html" shape="rect">to the Chief</a>
      â€�
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707020" shape="rect">5:39 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707040" shape="rect"></a>
    <div class="comments">
      <a href="http://www.thegrio.com/2009/08/on-sunday-president-obama-and.php" shape="rect">Martha's Vineyard is rooted in black history</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707040" shape="rect">5:58 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707042" shape="rect"></a>
    <div class="comments">
      Meanwhile, Obama's visit means the airports on Martha's Vineyard are
      <a href="http://www.mvgazette.com/article.php?22523" shape="rect">largely shut down for a week</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15582" shape="rect">Nelson</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707042" shape="rect">5:58 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707059" shape="rect"></a>
    <div class="comments">
      There's only one real airport, and it didn't shut down when the Clintons came for their vacations, why should it now?
      <br clear="none"></br>
      <br clear="none"></br>
      I lived there for eight years, it's beautiful, but living is hard if you don't have big bucks. I often worked two and sometimes three jobs, spent summers doing illegal guerrilla camping in tents and vans. Whenever they mention the highest gas prices in the US just add 50 cents and you'll have the price on MV.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92538" shape="rect">mareli</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707059" shape="rect">6:22 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707060" shape="rect"></a>
    <div class="comments">
      <a href="http://en.wikipedia.org/wiki/Chappaquiddick_incident" shape="rect">Chappaquiddick</a>
      is right next door.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/91903" shape="rect">Antidisestablishmentarianist</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707060" shape="rect">6:25 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707082" shape="rect"></a>
    <div class="comments">
      Cindy Sheehan is waiting there for him, to protest the war. She's also really peeved that the
      <a href="http://www.washingtonexaminer.com/opinion/blogs/beltway-confidential/ABCs-Charles-Gibson-to-Cindy-Sheehan-Thanks-for-your-sacrifice-Now-get-lost-53803917.html" shape="rect">TV networks and newspapers</a>
      are ignoring her.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/85140" shape="rect">Chocolate Pickle</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707082" shape="rect">6:51 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707141" shape="rect"></a>
    <div class="comments">
      The Vineyard's alternative voice,
      <a href="http://wvvy.org/" shape="rect">WVVY</a>
      , low power community run FM radio station, real live Islander's ramble and muse between music and the odd technical glitch.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23000" shape="rect">flummox</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707141" shape="rect">8:01 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707164" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams#2707082" shape="rect">Chocolate Pickle</a>
      : &quot;
      <i>Cindy Sheehan...</i>
      &quot;
      <br clear="none"></br>
      <small>
        <em>
          <a href="http://en.wikipedia.org/wiki/Cindy_Sheehan#Anti-war_campaign" shape="rect">
            <br clear="none"></br>
            Sheehan states she initially questioned the urgency of the invasion of Iraq, but did not become active in the anti-war effort until after her son's death.
          </a>
        </em>
      </small>
      <br clear="none"></br>
      <br clear="none"></br>
      <a href="http://www.usatoday.com/life/movies/news/2004-06-28-fahrenheit-lipscomb_x.htm" shape="rect">Lila Lipscomb</a>
      <br clear="none"></br>
      <br clear="none"></br>
      It is tragic that tragedy is required for some to see the truth.  It is just as tragic that I suspect those people
      <em>only</em>
      see the truth because of their relatively-tiny consequent tragedy.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/93779" shape="rect">Rat Spatula</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707164" shape="rect">8:47 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707165" shape="rect"></a>
    <div class="comments">
      <small>
        Like I can talk... wtf have
        <em>I</em>
        done...
      </small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/93779" shape="rect">Rat Spatula</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707165" shape="rect">8:48 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707167" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams#2707164" shape="rect">Me</a>
      : &quot;
      <i>I suspect those people only see the truth</i>
      &quot;
      <br clear="none"></br>
      <br clear="none"></br>
      This is being disingenuously generous to myself.  The actual thought was more like, &quot;even after their personal tragedy, they do not see the truth; they see only the horror of their personal experience.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      <small>either way I'm just as culpable... what crooked timber...</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/93779" shape="rect">Rat Spatula</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707167" shape="rect">8:51 PM</a>
        on August 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707175" shape="rect"></a>
    <div class="comments">
      <i>I want the Presidential vacation plan.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      You know, if we here in the US could have, basically, the entire month of August off, the way most of Europe (not involved in the tourist trade) does, perhaps out economy would be as quick to rebound as France and Germany's?
      <br clear="none"></br>
      <br clear="none"></br>
      Sometimes it sucks to live in a second-world country, where you squirrel away your comp-time and vacation just so you can be around when your wife gives birth...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50104" shape="rect">Slap*Happy</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707175" shape="rect">9:11 PM</a>
        on August 22, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707175" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707180" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/84376/Noepe-Land-Amid-the-Streams#2707175" shape="rect">Slap*Happy</a>
      : &quot;
      <i>Sometimes it sucks to live in a second-world country...</i>
      &quot;
      <br clear="none"></br>
      <br clear="none"></br>
      Are you saying your corn-syrup rations are unsatisfactory, Citizen?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/93779" shape="rect">Rat Spatula</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707180" shape="rect">9:15 PM</a>
        on August 22, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707180" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707402" shape="rect"></a>
    <div class="comments">
      I love the Vineyard.  I fell in love with it despite the people crowding it.  Like it had a shining.
      <br clear="none"></br>
      The whole damn island's almost like a spa, even when you're working a grill and getting orders yelled at you.  Worked like a dog and felt refreshed just by the commute back home.
      <br clear="none"></br>
      <br clear="none"></br>
      <a href="http://www.firstpeople.us/FP-Html-Legends/Moshup-the-Giant-Wampanoag.html" shape="rect">Thanks Moshup!</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14319" shape="rect">Busithoth</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707402" shape="rect">6:22 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707666" shape="rect"></a>
    <div class="comments">
      Was there a couple of weeks ago for a stay. Lot's of scary black helicopters doing flyby's.  Goddamn Gubmit!!
      <br clear="none"></br>
      <br clear="none"></br>
      *Shakes fist at sky.*
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14914" shape="rect">Skygazer</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707666" shape="rect">10:50 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707720" shape="rect"></a>
    <div class="comments">
      You all know they are there for Chelsea Clinton's wedding?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30104" shape="rect">A189Nut</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2707720" shape="rect">11:49 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708143" shape="rect"></a>
    <div class="comments">
      Yeah, well I'm just freaking thrilled that the Prez can hop off for a vacation after only a few months of pandering to lobbyists, Republicans, Blue Dogs, and ramping up Afganistan.
      <br clear="none"></br>
      <br clear="none"></br>
      Meanwhile 50 million Americans are still without healthcare, millions and millions have lost their jobs and their homes, tent cities are springing up around the country, food bank shelves are empty, social services don't exist, and people are carrying loaded semiautomatics to &quot;town halls&quot;.
      <br clear="none"></br>
      <br clear="none"></br>
      Meet the new boss...same as the old boss.
      <br clear="none"></br>
      <br clear="none"></br>
      There are no words to describe how disappointed I am by this presidency.  Hope, my fucking ass.  There is no hope.  There is only money speaking truthiness to power, same as it has ever been.
      <br clear="none"></br>
      <br clear="none"></br>
      Enjoy the vacation.  Those of us without jobs or health insurance who are praying that we don't get sick, or that our kids don't fall down on the playground, and wondering how we're going to pay off the credit cards that are floating us...we sure do hope you and the richy-richs you bailed out with our money don't have to see any of the suffering you helped create while you play tennis and go yachting.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/13269" shape="rect">dejah420</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2708143" shape="rect">7:38 PM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708143" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708223" shape="rect"></a>
    <div class="comments">
      McCain/Palin would be better?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2708223" shape="rect">9:05 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708584" shape="rect"></a>
    <div class="comments">
      <em>McCain/Palin would be better?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      The point is that according to the filmstrips I saw in third grade, we're supposed to have solar-powered hovercars by now.
      <br clear="none"></br>
      <br clear="none"></br>
      Instead we have the POWER OF THE INTERNET broadcasting TAILS OF SANTAMARIA in the White House.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/93779" shape="rect">Rat Spatula</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2708584" shape="rect">7:29 AM</a>
        on August 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708589" shape="rect"></a>
    <div class="comments">
      Sorry to interrupt the political ramblings - just meant to point to a recent
      <a href="http://www.ft.com/cms/s/2/e737b6c6-87a1-11de-9280-00144feabdc0,dwp_uuid=a712eb94-dc2b-11da-890d-0000779e2340.html" shape="rect">article</a>
      by the Financial Times on the rather interesting Brazilian presence on the island.
      <br clear="none"></br>
      Feel free to get back to your regularly scheduled politics debate - I am sure that is what the OP intended.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/94203" shape="rect">MessageInABottle</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2708589" shape="rect">7:33 AM</a>
        on August 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708606" shape="rect"></a>
    <div class="comments">
      It is still OK if Jim Belushi is buried there, though, isn't it?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19533" shape="rect">Cookiebastard</a>
        at
        <a target="_self" href="/84376/Noepe-Land-Amid-the-Streams#2708606" shape="rect">8:00 AM</a>
        on August 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/84375/A-Sense-of-History" shape="rect">« Older</a>
      A Sense of History...  |  Sure, every band geek has hear...
      <a target="_self" href="/84377/Extended-Range-Instruments" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/111146/The-fallacy-in-this-reasoning-is-glaring" shape="rect">&quot;The fallacy in this reasoning is glaring.&quot;</a>
      <span class="smallcopy">December 31, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/96715/The-Case-for-Obama" shape="rect">The Case for Obama</a>
      <span class="smallcopy">October 15, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/91775/BBC-World-Service-Documentaries" shape="rect">BBC World Service Documentaries</a>
      <span class="smallcopy">May 8, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/72245/A-moment-in-history-Obama-Wins-Presidential-Nomination" shape="rect">A moment in history; Obama Wins Presidential...</a>
      <span class="smallcopy">June 3, 2008</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/68729/Yes-We-Can" shape="rect">Yes, We Can.</a>
      <span class="smallcopy">February 2, 2008</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    homes   .l     Land   '�     Aykroyd   /&     While   )�     Jill   0�     buried   /a     deep   ,     Abel's   /k     Jordan   /�     long   )�         .http://en.wikipedia.org/wiki/Martha's_Vineyard    Martha's   )f     �Twitter Facebook Noepe: "Land Amid the Streams." August 22, 2009 4:48 PM   Subscribe This weekend the Obama family arrives on the Massachusetts' island of    �Vineyard for a week-long vacation. While known as a summer colony/destination for New Englanders, tourists and the famous 1 the island has a storied history    Martha's      9202a8c04000641f80000000000766ee    >��    (http://www.metafilter.com/84384/Cat-food   .�<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Cat food. | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/84384/Cat-food" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/84384/Cat-food/rss" title="Comments on: Cat food." type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/scifi" shape="rect">scifi</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/science" shape="rect">science</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/fiction" shape="rect">fiction</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/sciencefiction" shape="rect">sciencefiction</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/southafrica" shape="rect">southafrica</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/africa" shape="rect">africa</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/apartheid" shape="rect">apartheid</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/movies" shape="rect">movies</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/filmmaker" shape="rect">filmmaker</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/neill%5Fblomkamp" shape="rect">neill_blomkamp</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/blomkamp" shape="rect">blomkamp</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/alive%5Fin%5Fjoburg" shape="rect">alive_in_joburg</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/district9" shape="rect">district9</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Cat%20food%2E%20http%3A%2F%2Fmefi%2Eus%2Fw%2F84384" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/84384/Cat-food" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Cat food.
        <br clear="none"></br>
        <span class="smallcopy">
          August 23, 2009 3:26 AM  
          <a href="http://www.metafilter.com/84384/Cat-food/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/84384/Cat-food/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://www.avclub.com/articles/district-9-director-neill-blomkamp,31606/" shape="rect">Welcome to District 9.</a>
        Director Neill Blomkamp turns his sci-fi short
        <a href="http://www.youtube.com/watch?v=YZ1vHRs_EOs" shape="rect">&quot;Alive in Joburg&quot;</a>
        into
        <a href="http://www.scifisquad.com/2009/08/08/a-dozen-things-you-may-not-know-about-district-9/" shape="rect">a full-length</a>
        <a href="http://www.metacritic.com/film/titles/district9" shape="rect">feature</a>
        <a href="http://en.wikipedia.org/wiki/District_9" shape="rect">film</a>
        -
        <a href="http://www.tor.com/index.php?option=com_content&amp;view=blog&amp;id=51552" shape="rect">examining xenophobia</a>
        in an allegory of
        <a href="http://en.wikipedia.org/wiki/South_Africa_under_apartheid" shape="rect">Apartheid</a>
        , set in a slum recalling
        <a href="http://www.districtsix.co.za/frames.htm" shape="rect">District 6</a>
        of
        <a href="http://en.wikipedia.org/wiki/District_Six,_Cape_Town" shape="rect">Cape Town</a>
        in South Africa.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          (135 comments total)
          <span id="favcnt184384">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/84384" shape="rect">11 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2707335" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/55053/Finally-a-good-video-game-movie" shape="rect">Previously</a>
        and
        <a href="http://www.metafilter.com/mefi/48069" shape="rect">previouslier</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/7504" shape="rect">effbot</a>
          at
          <a target="_self" href="/84384/Cat-food#2707335" shape="rect">3:31 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707335" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707339" shape="rect"></a>
      <div class="comments">
        <a href="http://www.boingboing.net/2009/08/20/bang-bang-club.html" shape="rect">bang bang club</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23476" shape="rect">infini</a>
          at
          <a target="_self" href="/84384/Cat-food#2707339" shape="rect">3:44 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707339" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707342" shape="rect"></a>
      <div class="comments">
        I saw it, I rate it highly and respect its message, but I really didn't
        <i>like</i>
        it. There wasn't one single human character in that whole film that I wouldn't have gladly burst apart with a lightning gun myself. The take-away message of District 9 is that Human Beings Truly Suck, and it will hold you down and carve that message on your forehead.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11128" shape="rect">aeschenkarnos</a>
          at
          <a target="_self" href="/84384/Cat-food#2707342" shape="rect">3:48 AM</a>
          on August 23, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707342" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707350" shape="rect"></a>
      <div class="comments">
        <i>Alien Nation</i>
        was too subtle, eh?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20122" shape="rect">fleacircus</a>
          at
          <a target="_self" href="/84384/Cat-food#2707350" shape="rect">4:17 AM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707350" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707354" shape="rect"></a>
      <div class="comments">
        Mmmm... spoiled Milk....
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18052" shape="rect">cavalier</a>
          at
          <a target="_self" href="/84384/Cat-food#2707354" shape="rect">4:24 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707361" shape="rect"></a>
      <div class="comments">
        <em>Alien Nation was too subtle, eh?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I like Alien Nation, the film and the series, but that's a fairly clean, not terribly confronting take on a xenophobia with aliens story. This film is far bleaker; as aeschenkarnos says - the humans aren't terribly sympathetic at all.
        <br clear="none"></br>
        <br clear="none"></br>
        Alien Nation, after all, was more of a buddy cop take on the situation more than an analysis on the tools we use to oppress those who are different than us.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/84384/Cat-food#2707361" shape="rect">4:53 AM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707361" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707368" shape="rect"></a>
      <div class="comments">
        I liked the aliens in district 9, hated the humans - but really the movie beat you over the head so hard with apartheid that it was hard just to enjoy. And conveniently it's setup for a sequel in three years.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18925" shape="rect">bigmusic</a>
          at
          <a target="_self" href="/84384/Cat-food#2707368" shape="rect">5:11 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707369" shape="rect"></a>
      <div class="comments">
        I'm glad he was allowed to use the South African accents and colloquialisms in the movie. I think it helped with the documentary-ish feel.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2707369" shape="rect">5:14 AM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707369" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707370" shape="rect"></a>
      <div class="comments">
        I was disappointed in District 9.  I thought it would go in a different direction and explore xenophobia more deeply.  To me it just didn't really go anywhere - perhaps the inevitable sequel district 10 will.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20603" shape="rect">Bort</a>
          at
          <a target="_self" href="/84384/Cat-food#2707370" shape="rect">5:15 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707370" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707377" shape="rect"></a>
      <div class="comments">
        We were discussing this earlier on John Perry Barlow's Facebook -- he was surprised how sentimental / heartwarming it was -- where I said...
        <br clear="none"></br>
        <br clear="none"></br>
        &quot;The one thing though that ruined the illusion for my girlfriend is that in the middle of the final fight, armed with a wide variety of fancy, alien weaponry, he reaches out and throws a pig at the bad guys.
        <br clear="none"></br>
        <br clear="none"></br>
        &quot;Hurl a pig at it&quot; would be a great expression for brute force kludges....
        <br clear="none"></br>
        <br clear="none"></br>
        <em>
          &quot;Were you able to fix the software problem? Do you have the information I was looking for?&quot;
          <br clear="none"></br>
          &quot;I couldn't fix it, but I hurled a pig at it, and got the data for you.&quot;
        </em>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/4898" shape="rect">markkraft</a>
          at
          <a target="_self" href="/84384/Cat-food#2707377" shape="rect">5:36 AM</a>
          on August 23, 2009 [
          <a title="9 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707377" shape="rect">9 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707380" shape="rect"></a>
      <div class="comments">
        Add me to the disappointed list. Warning, spoiler alert... When it started out, I thought hmm, this looks interesting. Then it degenerated into another shoot em up action adventure. And there were plenty of things which didn't make sense to pull you right out of the movie, e.g., some sort of dual purpose juice that not only turns humans into aliens but also is a power source for the spaceship. Also, it took twenty seconds for the little alien to figure out how to make the mother ship come over and pick them up; a feat which grown up aliens couldn't accomplish in twenty years.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/85794" shape="rect">digsrus</a>
          at
          <a target="_self" href="/84384/Cat-food#2707380" shape="rect">5:40 AM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707380" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707389" shape="rect"></a>
      <div class="comments">
        Warning, more spoiler alert...
        <br clear="none"></br>
        well, digsrus, to be fair, the movie showed that the alien tech all had a strong biological component, which is why humans couldn't fire alien weapons. So it's not unthinkable that the fuel might have side effects if ingested by humans.
        <br clear="none"></br>
        Also, it took 20 years to collect enough material to make the fuel. After that, the picking up part was easy. How long would it take you to start a car with an empty tank, if you had to make the gasoline from scratch?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17357" shape="rect">bashos_frog</a>
          at
          <a target="_self" href="/84384/Cat-food#2707389" shape="rect">6:05 AM</a>
          on August 23, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707389" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707393" shape="rect"></a>
      <div class="comments">
        That last point (grown up aliens not figuring it out in 20 yrs) was discussed at the end of the AV Club interview. His explanation for it was more or less what I'd decided for myself just after seeing it.
        <br clear="none"></br>
        <br clear="none"></br>
        I really enjoyed it - it was a simple, original plot, performed well with good special effects. That's all I really need for a good night out at the movies, and sadly, it's not something I experience terribly often in the glut of sequels, reimaginings and remakes.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2707393" shape="rect">6:08 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707393" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707399" shape="rect"></a>
      <div class="comments">
        It wasn't perfect but I like it for a few reasons: it wasn't a remake or sequel; I liked the South African setting which made even the normal everyday stuff seem a little alien; the effects were mostly very well done and felt like they obeyed real physics;  I didn't quite know where it was going while I was watching it.  For a pop-corn escape-into-air-conditioning-for-two-hours summer movie, that's good enough for me.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18117" shape="rect">octothorpe</a>
          at
          <a target="_self" href="/84384/Cat-food#2707399" shape="rect">6:19 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707411" shape="rect"></a>
      <div class="comments">
        I greatly enjoyed it.  Though, one shouldn't address or examine it too deeply.  It's a fantastic popcorn movie, as octothorpe noted, and sometimes that's all a good movie needs to be.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/26998" shape="rect">Atreides</a>
          at
          <a target="_self" href="/84384/Cat-food#2707411" shape="rect">6:33 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707413" shape="rect"></a>
      <div class="comments">
        markkraft, I though the &quot;hurl the pig&quot; moment was a bit of a turnabout is fair play, given that MNU were testing the weapons on pig carcasses. It got a chuckle out of the theater I was in.
        <br clear="none"></br>
        <br clear="none"></br>
        I quite enjoyed it, and frankly I'm stunned it only cost $30 million. The effects weren't quite on par with, say, your Transformers 2, but certainly close enough that I wonder where the extra $170 million went on that movie.
        <br clear="none"></br>
        <br clear="none"></br>
        And I liked the fact that Vinkus wasn't a hero from the outset: he was just as willing to be an species-ist a-hole as everyone else. And his motivations were purely selfish until the very end, and even then I don't think you could say he was terribly enlightened in an &quot;underneath it all we're all the same!&quot; sort of way.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17359" shape="rect">schoolgirl report</a>
          at
          <a target="_self" href="/84384/Cat-food#2707413" shape="rect">6:34 AM</a>
          on August 23, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707413" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707414" shape="rect"></a>
      <div class="comments">
        Spoiler alert:
        <br clear="none"></br>
        <br clear="none"></br>
        I liked that I did not like the humans all the time. It made their behavior more unpredictable. I learned to not expect the moral choice to be made by them every time. Sure that was frustrating - just when I'm getting into the momentum of the action, getting to where I expected him to do the right thing and there the main guy goes again - doing something selfish or asinine and ruining the direction I want things to go in. But that makes the movie better when I can't guess what happens. I like struggling to like the protagonist despite his selfish faults. And then at the end of course - he's suffering ultimate loneliness from both species - I wouldn't wish that punishment of the evil father-in-law. Well maybe I would.
        <br clear="none"></br>
        <br clear="none"></br>
        I liked this a lot. I knew nothing about it going in and that often helps. I had no built up expectations. It's given me lots of fun stuff to ponder over since as well which I also enjoy.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37026" shape="rect">dog food sugar</a>
          at
          <a target="_self" href="/84384/Cat-food#2707414" shape="rect">6:35 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707416" shape="rect"></a>
      <div class="comments">
        BTW, did I see a brief
        <a href="http://www.metafilter.com/48069/Do-Androids-Dream-of-Light-Clerical-Duty" shape="rect">Tetra Vaal</a>
        reference near the end of the film? The term sticks in my mind, but I can't recall where it showed up.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17359" shape="rect">schoolgirl report</a>
          at
          <a target="_self" href="/84384/Cat-food#2707416" shape="rect">6:37 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707425" shape="rect"></a>
      <div class="comments">
        Again spoiler comment:
        <br clear="none"></br>
        <br clear="none"></br>
        One question - why didn't the aliens not use their superior weapons on the Nigerians and really - any humans? Why do worker aliens have weapons they don't use but rather trade for cat food? Does the worker alien just want to follow someone and they accepted the Nigerian leadership in the district? Maybe the Nigerians were not really leaders - maybe they were just opportunists in the district? Is this a comment on the behavior of a repressed and lost group who has no direction or leadership and therefore no defense to the brutality put upon them by a larger more organized group?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37026" shape="rect">dog food sugar</a>
          at
          <a target="_self" href="/84384/Cat-food#2707425" shape="rect">6:45 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707430" shape="rect"></a>
      <div class="comments">
        You'd think that workers who could make such sweet weapons would be able to frame a house and put up sheet rock.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/85794" shape="rect">digsrus</a>
          at
          <a target="_self" href="/84384/Cat-food#2707430" shape="rect">6:52 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707444" shape="rect"></a>
      <div class="comments">
        I enjoyed the film, and thought it was fascinating on many levels.   But I had very serious reservations about its political implications.  A friend and I talked about this extensively after the movie, and he summarized our conversation
        <a href="http://www.slate.com/blogs/blogs/browbeat/archive/2009/08/18/what-does-district-9-have-to-say-about-apartheid.aspx" shape="rect">here</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Also, the portrayal of Nigerian gangsters in the movie is straight-up, uncritically xenophobic.  This may be less obvious in an American/European context where the cultural stereotype of Nigerians often is more of a con-man type criminal, but, read any trashy SA daily and you will encounter the repeated image of Nigerians as dangerous, weapon-wielding, warlords - exactly as they are portrayed here.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2707444" shape="rect">7:07 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707444" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707446" shape="rect"></a>
      <div class="comments">
        Expecting to absolutely love this movie,
        <a href="http://gerrycanavan.blogspot.com/2009/08/district-9.html" shape="rect">I was pretty disappointed.</a>
        Nothing that happens in the second half of the film is as compelling as the first forty minutes, or even close, and by the end all pretense of higher thematic interest is lost in the usual mess of shouting and explosions.
        <br clear="none"></br>
        <br clear="none"></br>
        &quot;Alive in Joburg&quot; is the first forty minutes without the wrong-turn second half, and I like it a lot.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/63732" shape="rect">gerryblog</a>
          at
          <a target="_self" href="/84384/Cat-food#2707446" shape="rect">7:10 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707462" shape="rect"></a>
      <div class="comments">
        <em>There wasn't one single human character in that whole film that I wouldn't have gladly burst apart with a lightning gun myself.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I found Wikus van der Merwe to be a very likeable character.  Great to see a normal dweeb putzing through things rather than a superman for a change.
        <a href="http://exiledonline.com/district-9-not-bad/" shape="rect">This reviewer</a>
        expresses my feelings well.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17588" shape="rect">Meatbomb</a>
          at
          <a target="_self" href="/84384/Cat-food#2707462" shape="rect">7:40 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707463" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/84384/Cat-food#2707425" shape="rect">dog food sugar</a>
        , they explained in the film that the aliens were all from a worker caste based around a hive system, and without leadership from a higher caste they weren't capable of much of anything.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/53083" shape="rect">billypilgrim</a>
          at
          <a target="_self" href="/84384/Cat-food#2707463" shape="rect">7:41 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707463" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707474" shape="rect"></a>
      <div class="comments">
        Yeah - I guess I have difficulty grasping a caste behavior structure. What happened to the leaders for their caste? Did they all die in the month before humans entered the hovering ship? Was Christopher one of them? Were they not even on that ship, and instead led the caste remotely?
        <br clear="none"></br>
        <br clear="none"></br>
        And the husband just pointed out to me that maybe the aliens noted their futile position they were in for waging war - outnumbered on an alien planet. This could be interesting for the sequel as their numbers are growing in district 10.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37026" shape="rect">dog food sugar</a>
          at
          <a target="_self" href="/84384/Cat-food#2707474" shape="rect">7:50 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707485" shape="rect"></a>
      <div class="comments">
        also, whether or not there is a plot device that explains why the aliens were so incapable, disorganized, and confused, one has to ask why portray the oppressed group in this way in a film that is so obviously making analogies to contemporary situations of economic and racial oppression and violence?  people living in poverty, in shacks, under racist regimes have produced some of the most important and vibrant political movements of the 20th and 21st century.  but it is a common belief/fantasy on the part of the world's middle-class, that people living in these conditions are victims stripped of their ability to act, to form communities, to have a political life.  this film is symptomatic of this fantasy.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2707485" shape="rect">8:01 AM</a>
          on August 23, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707485" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707486" shape="rect"></a>
      <div class="comments">
        Best SF movie since
        <a href="http://www.imdb.com/title/tt0206634/" shape="rect"> Children of Men</a>
        .  Suck it haters=you're better off watching the plot-less, mind-numbing GG that is Transformers2.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18416" shape="rect">HyperBlue</a>
          at
          <a target="_self" href="/84384/Cat-food#2707486" shape="rect">8:01 AM</a>
          on August 23, 2009 [
          <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707486" shape="rect">8 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707487" shape="rect"></a>
      <div class="comments">
        GG=CG
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18416" shape="rect">HyperBlue</a>
          at
          <a target="_self" href="/84384/Cat-food#2707487" shape="rect">8:02 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707504" shape="rect"></a>
      <div class="comments">
        As a big Halo fan, I'm both excited by and
        <i>incredibly jealous</i>
        of District 9. That was supposed to be
        <b>our</b>
        artful scifi masterpiece, dammit!
        <br clear="none"></br>
        <br clear="none"></br>
        Ever since Blomkamp debuted
        <a href="http://www.youtube.com/watch?v=yUcreY0X33k&amp;fmt=18" shape="rect">Arms Race/Landfall</a>
        (his series of live-action Halo shorts) I was absolutely raring to see his cinematic interpretation of my favorite game. The promise of Peter Jackson bringing his
        <a href="http://www.wetanz.com/" shape="rect">Weta Workshop</a>
        SFX chops along for the ride only ratcheted up the anticipation.
        <br clear="none"></br>
        <br clear="none"></br>
        But then
        <a href="http://news.softpedia.com/news/039-Halo-039-Movie-Dropped-by-Studio-38480.shtml" shape="rect">it fell apart</a>
        in excruciatingly slow-motion fashion, due to venal political bickering and disagreements over price. It seems like 20th Century Fox was the impetus of the fight -- it wanted more control over the project that Universal wasn't willing to give. Just chalk that one up along with the long list of other great things Fox has fucked up.
        <br clear="none"></br>
        <br clear="none"></br>
        That was bad enough. But then the project had to get converted into this District 9, an achingly similar vision that was just different enough to remind one of what could have been. It certainly doesn't help that Blomkamp has given interview responses
        <a href="http://www.avclub.com/articles/district-9-director-neill-blomkamp,31606/" shape="rect">such as</a>
        :
        <blockquote>
          In Halo, I was most interested in the human societyâ€”humans 500 years from now, with different planets, and hardware, and the U.S. involvement, and how the Marines have been established in this colonial force, and the industrial military complex that gave birth to Master Chief.
        </blockquote>
        ...sentiments which make the Halo backstory lover in me cringe. He would have done this
        <i>right</i>
        . He would have treated a story I cherished with maturity and respect -- had the potential to make the first truly great video game film. But now rumor has it that if the movie gets made at all, it might get the writer of the
        <i>G.I. Joe</i>
        movie on board. Blech.
        <br clear="none"></br>
        <br clear="none"></br>
        And naturally, while this decade-old blockbuster franchise rots in development hell, every other two-bit brand on the face of the Earth is set to grace the silver screen. A partial list,
        <a href="http://io9.com/5342283/10-video+game-movies-youll-see-before-halo/gallery/" shape="rect">according to io9</a>
        :
        <blockquote>Dead Space, BioShock, Duke Nukem, Area 51, Mass Effect, inFAMOUS, Asteroids, World of Warcraft, Gears of War, The Sims</blockquote>
        Hey, don't forget
        <a href="http://popwatch.ew.com/2009/05/18/battleship-movi/" shape="rect">Battleship</a>
        ,
        <a href="http://www.cinematical.com/2007/06/18/ridley-scott-to-make-monopoly-movie/" shape="rect">Monopoly</a>
        ,
        <a href="http://www.wired.com/geekdad/2009/08/lego-movie/" shape="rect">Lego</a>
        , and
        <a href="http://screenrant.com/universal-options-stretch-armstrong-movie-april-2011-release-robf-11479/" shape="rect">Stretch Armstrong</a>
        !
        <br clear="none"></br>
        <br clear="none"></br>
        <small>
          Seriously...
          <i>Stretch Armstrong?</i>
          Kill me now, people.
        </small>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/62135" shape="rect">Rhaomi</a>
          at
          <a target="_self" href="/84384/Cat-food#2707504" shape="rect">8:22 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707510" shape="rect"></a>
      <div class="comments">
        Somehow, I had managed to avoid everything about this movie until I stepped into the theater to see it.  I knew it was about aliens.  I was pleasantly surprised to find myself crying at the end.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/86988" shape="rect">MaritaCov</a>
          at
          <a target="_self" href="/84384/Cat-food#2707510" shape="rect">8:30 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707521" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/84384/Cat-food#2707485" shape="rect">huffa</a>
        : &quot;
        <i>it is a common belief/fantasy on the part of the world's middle-class, that people living in these conditions are victims stripped of their ability to act, to form communities, to have a political life. this film is symptomatic of this fantasy.</i>
        &quot;
        <br clear="none"></br>
        <br clear="none"></br>
        huffa, that you for your thoughts on this. I noticed the really uncritical use of the Nigerians as the old, bad-guy other and kept waiting for a postmodern wink or acknowledgement of the fundamental squickiness of the trope, but, nope. That set me to puzzling over what, exactly, the allegory was critiquing or celebrating. You have solved the puzzle for me, I think. Christopher Johnson is some sort of Mandela doppelganger, I guess.
        <br clear="none"></br>
        <br clear="none"></br>
        I think it's interesting and worth noting - without scolding or fingerwaving or anything - that This film can be considered in the context of the mature-period films that Jackson has directed (The
        <em>LoTR</em>
        films,
        <em>King Kong</em>
        ) as a film fundamentally concerned with the colonial experience of the Other in modern society. That is, although the film is Blomkamp's, the concerns and themes appeal directly to the central issues of Jackson's work.
        <br clear="none"></br>
        <br clear="none"></br>
        Finally, the actor who portrays Wikus Van De Merwe (Sharlto Copley) appears very briefly in
        <em>Alive in Joburg,</em>
        but, more interestingly, is listed as a producer of the same film. His IMDB entry does not show him with a production credit on District 9, but intriguingly credits him as VFX producer on 2004's
        <a href="http://www.imdb.com/title/tt0399877/" shape="rect">
          <em>What the Bleep do We Know?</em>
          ,
        </a>
        a woo-woo Ramtha handwaver which provoked
        <a href="http://www.metafilter.com/37177/there-is-no-dog" shape="rect">local dissection</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2707521" shape="rect">8:40 AM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707521" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707523" shape="rect"></a>
      <div class="comments">
        <em>I really enjoyed it - it was a simple, original plot, performed well with good special effects.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        That was part of the reason I enjoyed it on a meta- level; my absolute astonishment that a science fiction movie an original narrative reflecting on apartheid, set in Johannesburg, starring absolutely no one anybody outside the RSA film and theatre world has ever heard of, and made for about the craft services budget of a Michel Bay movie could wind up at the top of the North American box office.  Seriously, when I first heard about it a month or three earlier, I wondered if it would even get released.
        <br clear="none"></br>
        <br clear="none"></br>
        During my adolescence, Spielberg and Lucas set the template for summer blockbusters:in the course of about five years we had
        <em>Star Wars</em>
        and
        <em>Close Encounters</em>
        and
        <em>Raiders of the Lost Ark</em>
        and
        <em>E.T.</em>
        and non-Lucasbergian pieces like
        <em>Alien</em>
        were all smashingly successful, and more or less ensured that from that day to this that genre films were the ones likeliest to wind up atop the box office ladder.  (Not that genredom is a ticket to success, but my parents lived in a world as young adults where
        <em>The Sound of Music</em>
        or
        <em>Love Story</em>
        could be the box office smash of the year.)  What Hollywood has missed, though, is that all of these late-70's/early-80's successful genre films were original stories: often they were drawing inspiration from things like
        <em>Flash Gordon</em>
        or
        <em>The Perils of Pauline</em>
        or somesuch, but there had not been a property called
        <em>Star Wars</em>
        for years or decades before the movie came out.
        <br clear="none"></br>
        <br clear="none"></br>
        After I saw
        <em>District 9</em>
        , I had a look at boxofficemojo.com to see the top ten films for the last ten years.  Of that hundred movies, maybe fifty or sixty are what we might call genre movies, and (not counting kids' movies) I think maybe three or four of them are not based on a TV series or a comic book or a novel  or an older movie or a fucking amusement park ride.
        <br clear="none"></br>
        <br clear="none"></br>
        I also liked that the director uses film grammar to set us up as feeling van der Merwe is the sympathetic character, and where Hollywood movie relentlessly foreground the main character, surrounding him with an assortment of dweebs, morons, and pricks to make sure we really like the protagonist,
        <em>District 9</em>
        presents the central (human) character as equal part dweeb, moron, and prick.  It leaves the audience floundering about for someone to connect with.  The intent is for us to connect with Christopher, who is presented from his first appearance as having recognizable and largely understandable motivations.  Christopher and his child are the only aliens with recognizably human body language and, if I am not mistaken, the only ones whose eyes we ever see clearly.
        <br clear="none"></br>
        <br clear="none"></br>
        The movie has its shortfalls: van der Merwe experiences a too-sudden shift from greedy bastard to selfless martyr, the MNU is presented as a little too one-dimensionally evil, and whether or not it was intended , the ending suggests the filmmakers were planning for a sequel.  Still, it came across as the most original piece of sf I have seen on screen in a while.  Compared to paint-by-numbers stuff like
        <em>Star Trek</em>
        and
        <em>Terminator:Salvation</em>
        , it is unbelievably good.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78804" shape="rect">ricochet biscuit</a>
          at
          <a target="_self" href="/84384/Cat-food#2707523" shape="rect">8:43 AM</a>
          on August 23, 2009 [
          <a title="16 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707523" shape="rect">16 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707525" shape="rect"></a>
      <div class="comments">
        <a href="http://io9.com/5341120/5-things-you-didnt-know-about-district-9" shape="rect">5 Things You Didn't Know About District 9</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/80649" shape="rect">The Whelk</a>
          at
          <a target="_self" href="/84384/Cat-food#2707525" shape="rect">8:44 AM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707525" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707543" shape="rect"></a>
      <div class="comments">
        From
        <a href="http://io9.com/5341120/5-things-you-didnt-know-about-district-9" shape="rect">The Whelk's link</a>
        (which has a bunch of interesting stuff in it):
        <br clear="none"></br>
        <br clear="none"></br>
        Blomkamp, about the interviews seen in
        <em>Alive in Joburg</em>
        : &quot;I was asking black South Africans about black Nigerians and Zimbabweans. That's actually where the idea came from was there are aliens living in South Africa, I asked 'What do you feel about Zimbabwean Africans living here?' And those answers â€” they weren't actors, those are real answers...&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        Which reframes the Nigerians seen in D9, I think, as Blomkamp's direct interpretation of ZA's post-apartheid Other.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2707543" shape="rect">9:03 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707555" shape="rect"></a>
      <div class="comments">
        <i>I though the &quot;hurl the pig&quot; moment was a bit of a turnabout is fair play</i>
        <br clear="none"></br>
        <br clear="none"></br>
        biscotti and I thought the &quot;hurl the pig&quot; moment was a reference to Half-Life 2 and using the gravity gun to kill Civil Protection with whatever's handy.
        <br clear="none"></br>
        <br clear="none"></br>
        I also really liked the splud gun.  I'm not going to call it a lightning gun -- you point it at people and they go SPLUD!, so it's a splud gun.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15862" shape="rect">ROU_Xenophobe</a>
          at
          <a target="_self" href="/84384/Cat-food#2707555" shape="rect">9:16 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707566" shape="rect"></a>
      <div class="comments">
        <em>When it started out, I thought hmm, this looks interesting. Then it degenerated into another shoot em up action adventure. And there were plenty of things which didn't make sense to pull you right out of the movie</em>
        <br clear="none"></br>
        <br clear="none"></br>
        That's exactly how I felt about The Matrix.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11661" shape="rect">Cyrano</a>
          at
          <a target="_self" href="/84384/Cat-food#2707566" shape="rect">9:27 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707566" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707570" shape="rect"></a>
      <div class="comments">
        Good job at mentioning District 6, most people dont get the connection and think the movie is a metaphor for muslims or something...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15981" shape="rect">carfilhiot</a>
          at
          <a target="_self" href="/84384/Cat-food#2707570" shape="rect">9:31 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707595" shape="rect"></a>
      <div class="comments">
        <em>You'd think that workers who could make such sweet weapons would be able to frame a house and put up sheet rock.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        <strong>digsrus</strong>
        , have yu seen the home-repair skills of the average auto worker? ( /snark )
        <br clear="none"></br>
        <br clear="none"></br>
        Snark aside, it takes very little intelligence to assemble goods. Designing them is another story. Intelligence helps, at all stages of the process, but the process can be designed for &quot;gammas&quot; from Brave New World, with a few &quot;betas&quot; for oversight.
        <br clear="none"></br>
        <br clear="none"></br>
        I didn't need the &quot;worker bees without a queen&quot; explanation. I just assumed the ship was a worker transport that got grounded, and the hero of the story was the lone surviving flight officer (and therefore, the lone surviving intellectual amongst pawns). It presumes a larger divide in education and ability than exists in our species, but that doesn't make it unbelievable for another species.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/67383" shape="rect">IAmBroom</a>
          at
          <a target="_self" href="/84384/Cat-food#2707595" shape="rect">9:49 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707595" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707603" shape="rect"></a>
      <div class="comments">
        Rhaomi-
        <br clear="none"></br>
        <br clear="none"></br>
        I wouldn't be surprised if this is the test movie for Blomkamp to prove that he can make a movie on a budget, and that his style would make money. The Halo movie would easily cost around 100 million to get ramped up, just because of the digital effects and set design that would be required, and the more recent rumors the last time I heard was Microsoft / Bungie had taken their rights back, and were working on producing the film independent of a major studio (similar to Marvel), just to ensure they can control their property.
        <br clear="none"></br>
        <br clear="none"></br>
        So D9 was a $30 million demo reel by Blomkamp and Jackson to show that they could make a successful and profitable special effects heavy alien space action movie that had some level of gravitas to it, and not it turn into some Terminator Salvation fiasco. And with Bungie Game Studios / Microsoft / Weta deciding to go it alone, they would probably save money going with no name actors with the idea that they have enough god damned draw just by the word HALO appearing on their poster, they don't need to pay for a Vin Diesel or The Rock to draw in the summer action movie goers.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2707603" shape="rect">9:54 AM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707603" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707610" shape="rect"></a>
      <div class="comments">
        After I watched this movie with my friends, we were talking about it and I started mentioning a lot of the plot holes, and they both got really defensive.
        <br clear="none"></br>
        <br clear="none"></br>
        To me, this was movie was okay, but I feel like it's going to be put on a pedestal by a lot of science fiction fans.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/93166" shape="rect">kylej</a>
          at
          <a target="_self" href="/84384/Cat-food#2707610" shape="rect">9:58 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707610" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707617" shape="rect"></a>
      <div class="comments">
        After the downward spiral of the movie yanked me right out of South Africa back to my theatre in New Jersey, I started thinking thoughts along the lines of 'Wikus is a dead ringer for the offspring of Michael Scott from &quot;The Office&quot; mating with Robert Deniro from &quot;The Deer Hunter&quot; ,' and 'Boy, he was lucky he grew back the correct thumbless arm that you evidently need to operate the mech suit.'
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/85794" shape="rect">digsrus</a>
          at
          <a target="_self" href="/84384/Cat-food#2707617" shape="rect">10:02 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707640" shape="rect"></a>
      <div class="comments">
        I'm not surprised it may be getting pedestal treatment.  How long has it been since there was a science fiction film which wasn't based on an existing property?  It's a shame that creating something new is such a rare thing in movies anymore.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
          at
          <a target="_self" href="/84384/Cat-food#2707640" shape="rect">10:20 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707641" shape="rect"></a>
      <div class="comments">
        I thoroughly enjoyed the movie. Yes, it had its problems. But it was very refreshing to see a new, original sci-fi film -- so many, lately, have been awful blockbusters based on crappy old franchises. (And, yeah, I say that as someone who also really liked the new
        <i>Star Trek</i>
        .) The last time I remember feeling that way about a sci-fi movie was when I was watching the fantastic
        <i>Children of Men</i>
        , which, sadly,
        <a href="http://www.boxofficemojo.com/movies/?id=childrenofmen.htm" shape="rect">doesn't seem to have even made back its $76 million budget.</a>
        <br clear="none"></br>
        <br clear="none"></br>
        It's unfortunate that bigger does so often mean better in Hollywood. Transformers 2, costing $200 million,
        <a href="http://www.boxofficemojo.com/movies/?id=transformers2.htm" shape="rect">has grossed over $825 million in less than 9 weeks.</a>
        That makes me really, really,
        <i>really</i>
        sad. I bet the investors love it, though.
        <br clear="none"></br>
        <br clear="none"></br>
        Spoilers ahead (sort of):
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://www.metafilter.com/84384/Cat-food#2707416" shape="rect">schoolgirl report</a>
        : I'm pretty sure the Tetra Vaal reference towards the end was on one of the doors or a wall as Wikus and Christopher were entering (or exiting?) the lab where the tests had been performed.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33917" shape="rect">malthas</a>
          at
          <a target="_self" href="/84384/Cat-food#2707641" shape="rect">10:22 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707649" shape="rect"></a>
      <div class="comments">
        The movie it most reminded me of was Dead/Alive (Braindead) to be honest, at least in the way it was structured.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29475" shape="rect">empath</a>
          at
          <a target="_self" href="/84384/Cat-food#2707649" shape="rect">10:32 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707653" shape="rect"></a>
      <div class="comments">
        <a title="malthas wrote in comment #2707641" href="http://www.metafilter.com/84384/Cat-food#2707641" shape="rect">&gt;</a>
        <i> The last time I remember feeling that way about a sci-fi movie was when I was watching the fantastic Children of Men, which, sadly, doesn't seem to have even made back its $76 million budget.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        If it's any condolences, D9 was made for $30 million, and made
        <a href="http://www.rottentomatoes.com/m/district_9/" shape="rect">$73 million</a>
        so far, and that is with it being in theaters for a week. If it makes more than 120 million in 9 weeks, it would have a higher return on investment than Transformers 2 did.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2707653" shape="rect">10:38 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707662" shape="rect"></a>
      <div class="comments">
        I didn't know much about the movie before going in, other than it was supposed to be AMAZING, genre re-defining, thoughtful, intelligent sci-fi. I was somewhat disappointed. I'm an unabashed sci-fi fan in the big geeky way that
        <a href="http://www.theonion.com/content/video/trekkies_bash_new_star_trek_film" shape="rect">The Onion parodied.</a>
        ( &quot;Trekkies Bash New Star Trek Film As 'Fun, Watchable' &quot;) I was glad sci-fi could be returning to what it does best, delivering &quot;heavy handed morals&quot;. Sure District 9 did that but it honestly seems like it was toned down. The giant evil NGO seemed to replace the bad-guy, instead of humans and racism.
        <br clear="none"></br>
        <br clear="none"></br>
        Also I'm going to pick nits, but I thought the story telling format was weak. Using a fake documentary style seems to be a crutch for this director, and it bugged me how inconstantly this style was applied. If the story was strong enough, it could have been told in a skillful way without the pretense. Even having this idea of someone sitting behind the camera asking questions adds another character into the movie, one that is both limited and omnipresent and we are supposed to believe, without motive or bias?
        <br clear="none"></br>
        <br clear="none"></br>
        What could have been better was a documentarian with a mainline view point, that is anti-alien and anti- van der Merwe, but let the &quot;human&quot; qualities of Christopher and van der Merwe shine through creating complicated characters and further exploring the apartheid mindset while simultaneously attacking it.
        <br clear="none"></br>
        <br clear="none"></br>
        At least, thats how I would have made the movie, if anyone wants to give me $30 million...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/77967" shape="rect">fontophilic</a>
          at
          <a target="_self" href="/84384/Cat-food#2707662" shape="rect">10:45 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707667" shape="rect"></a>
      <div class="comments">
        If only aliens could fire the weapons, why didn't the humans use the aliens to fire them? They could have enticed the aliens with luxuries (e.g. cat food). &quot;Fire at our enemies and we'll give you each ten cans of cat food.&quot; They could have tortured the aliens until they agreed to become soldiers, etc. I don't remember anyone even mentioning trying this. It really bothered me. It seemed like such an obvious thing for the humans to at least try.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
          at
          <a target="_self" href="/84384/Cat-food#2707667" shape="rect">10:52 AM</a>
          on August 23, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707667" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707669" shape="rect"></a>
      <div class="comments">
        Strangely for me,
        <i>D9</i>
        reminded me the most of
        <i>Evil Dead II</i>
        , but with social commentary and a nebbishy, Steve Coogan-esque leading man.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11321" shape="rect">pxe2000</a>
          at
          <a target="_self" href="/84384/Cat-food#2707669" shape="rect">10:54 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707674" shape="rect"></a>
      <div class="comments">
        <em>Also I'm going to pick nits, but I thought the story telling format was weak. Using a fake documentary style seems to be a crutch for this director, and it bugged me how inconstantly this style was applied.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        The beginning made me think the whole film would be in documentary style. After the first five minutes, I was totally buying it. Then, when they suddenly cut to the aliens talking amongst themselves -- inside one of their shanties -- I was totally befuddled. I didn't understand how the documentary film crew could have stuck cameras and mics in there without the aliens knowing about it. I quickly figured out that the movie had switched styles, but the experience was deeply jarring.
        <br clear="none"></br>
        <br clear="none"></br>
        I've seen a mix of documentary and standard-fiction style work in the past. The trick is to START with the standard style, not the documentary style. The &quot;Citizen Kane&quot; approach works well, too: explicitly end the documentary and then loudly switch styles. The D9 approach was too subtle. I didn't know what was going on.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
          at
          <a target="_self" href="/84384/Cat-food#2707674" shape="rect">10:58 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707674" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707678" shape="rect"></a>
      <div class="comments">
        What I liked best about the movie was the leading actor. I thought his performance was phenomenal. It seemed to be a caricature at first, but it gradually become more and more layered.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
          at
          <a target="_self" href="/84384/Cat-food#2707678" shape="rect">10:59 AM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707678" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707692" shape="rect"></a>
      <div class="comments">
        <em>I wouldn't be surprised if this is the test movie for Blomkamp to prove that he can make a movie on a budget</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I agree, mrzarquon. It also makes me think that his next movie will end up being closer to a more formulaic blockbuster, since the movie studio will want to have more control over a much more expensive investment.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/86278" shape="rect">orme</a>
          at
          <a target="_self" href="/84384/Cat-food#2707692" shape="rect">11:16 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707697" shape="rect"></a>
      <div class="comments">
        <a title="grumblebee wrote in comment #2707667" href="http://www.metafilter.com/84384/Cat-food#2707667" shape="rect">&gt;</a>
        <i>
          If only aliens could fire the weapons, why didn't the humans use the aliens to fire them? They could have enticed the aliens with luxuries (e.g. cat food). &quot;Fire at our enemies and we'll give you each ten cans of cat food.&quot; They could have tortured the aliens until they agreed to become soldiers, etc. I don't remember anyone even mentioning trying this. It really bothered me. It seemed like such an obvious thing for the humans to at least try.
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        But the aliens couldn't be trusted / enslaved / coerced. They believe them less than human, so why entrust such an advanced piece of weaponry to what were obviously the lowest caste of an inferior species? And for MNU's goals, they couldn't sell and transport the aliens as easy as they could the weapons, and what I am guessing they would be hoping for, a short acting alien enabler that would give soldiers a 4 week functional period where they could use the weapons. They weren't looking at a way to make an undefeatable army, they were looking for a way to make a profit.
        <br clear="none"></br>
        <br clear="none"></br>
        <br clear="none"></br>
        <a title="grumblebee wrote in comment #2707678" href="http://www.metafilter.com/84384/Cat-food#2707678" shape="rect">&gt;</a>
        <i>What I liked best about the movie was the leading actor. I thought his performance was phenomenal. It seemed to be a caricature at first, but it gradually become more and more layered.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        The weapons testing scene was just brutal to watch, in a way forcing him through the microcosm of everything MNU had be doing for the last 20 years. Along with the last shot with the flower, just really good all around. I think it actually has a lot of depth to it, if you want to dig, but it has the veneer of a scifi alien action film for those who don't.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2707697" shape="rect">11:24 AM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707697" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707710" shape="rect"></a>
      <div class="comments">
        <a title="orme wrote in comment #2707692" href="http://www.metafilter.com/84384/Cat-food#2707692" shape="rect">&gt;</a>
        <i>since the movie studio will want to have more control over a much more expensive investment.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        I don't know about that. In fact, I believe part of the reason why the deals fell apart for the Halo movie was Microsoft / Bungie wouldn't let them their property be shaped into some sort of standard Blockbuster formula, and the bigger studios wouldn't spend the money needed to produce a movie that would be true to the Halo universe since it wouldn't fit their formula that a $200 million film needs to do X,Y,Z to in order to provide a profitable return on investment.
        <br clear="none"></br>
        <br clear="none"></br>
        And D9 is making a ton of money for Wingnut and the associated production groups that bankrolled it, so those guys may end up with enough cash on hand to bankroll their own Halo movie, especially with some more money from Microsoft and Bungie, now that they've shown there is a market for the style of movie that Bungie and Neill and Jackson want to make out of Halo.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2707710" shape="rect">11:38 AM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707752" shape="rect"></a>
      <div class="comments">
        *SPOILER*
        <br clear="none"></br>
        I thought the apartheid angle was a ploy to setup the twist that Christopher was hoping to leave Earth, and, I imagine, take a bunch of workers, if not all of them, with him (rather than fight for humane conditions and integration). If the eviction plan had been delayed by just a day or so, they'd have left and everyone but MNU and their ilk would have been satisfied. So the prejudice of the general population and power lust of MNU prevented the most satisfactory resolution and in the end they are left with the same problem only without the mothership hovering overhead and no chance at all of getting rid of them (as far as the humans knew).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19621" shape="rect">effwerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2707752" shape="rect">12:10 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707756" shape="rect"></a>
      <div class="comments">
        My feelings about the movie can be summed up in the comparison of the two trailers.  When the teaser came out D9 looked to be a documentary-style sci-fi film that would explore apartheid, xenophobia, corporate control and so many other interesting things.  I almost couldn't wait to see the film.  And then the theatrical trailer came out.  Gone was the subtle documentary feel.  It was instead replaced by explosions and exoskeletons.  Was this really the same movie?  Could they keep the documentary style while still adding a few action sequences?  Nope.
        <br clear="none"></br>
        <br clear="none"></br>
        I knew the movie was in trouble when about 15 or 20 minutes in they shifted the style from documentary to standard movie.  It happened when the camera appeared inside Christopher's shack.  How did the documentary cameras get in there?  Why were they allowed to film this totally secret meeting.  Did they just cut from a master shot to an over the shoulder shot in the documentary?  What's going on?
        <br clear="none"></br>
        <br clear="none"></br>
        From then on it played out like a standard summer action movie.  The evil corporate baddies wanted the weapons technology from the harmless alien race and a former member of the corporate baddies came to the realization that these alien people aren't so bad after all.  But before that happens let's blow some people to bits.
        <br clear="none"></br>
        <br clear="none"></br>
        It's as if Blomkamp was allowed to tell the story the way he wanted for the opening act and then Peter Jackson stepped in and changed the entire direction of the movie.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37985" shape="rect">Sandor Clegane</a>
          at
          <a target="_self" href="/84384/Cat-food#2707756" shape="rect">12:12 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707760" shape="rect"></a>
      <div class="comments">
        On preview, what grumblebee said.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37985" shape="rect">Sandor Clegane</a>
          at
          <a target="_self" href="/84384/Cat-food#2707760" shape="rect">12:14 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707769" shape="rect"></a>
      <div class="comments">
        <i>Also, the portrayal of Nigerian gangsters in the movie is straight-up, uncritically xenophobic. </i>
        <br clear="none"></br>
        <br clear="none"></br>
        You're underthinking this plate of beans.  The Nigerians are the mirror image of MNU.  The experiences of the aliens  and van der Merwe's experience at their hands mirror one another; the differences are ones of detail; the biotech labs vs the religious rituals; collecting weapons for catfood vs taking them under the guise of paternalistic protection.  MNU stands for the evils of white colonialism in Africa, while the Nigerians stand for black regimes that have failed Africa (Rwanda, Mugabe, et al).
        <br clear="none"></br>
        <br clear="none"></br>
        If your problem with that is that you uncrtitically accept portraits of whites as evil psycopaths or sociopaths (the Colonel and the MNU directors and scientists), but get hinky about the same portraits applied to black Africans you should maybe think more about your own attitudes, rather than ascribing xenophobia to the film.
        <br clear="none"></br>
        <br clear="none"></br>
        More broadly: my wife described it as &quot;The Fly meets Die Hard&quot;, which is a pretty fair summary, which probably accounts for the gear grinding of a lot of folks who found the action sequences dissapointing.  I'd compare it to Aliens, and suggest the same applies to people who love Alien but find Aliens a huge dissapointment.
        <br clear="none"></br>
        <br clear="none"></br>
        One thing I did dislike heartily, though: women.  It's pretty much all guys all the time.  I don't know if that's deliberate, or just thoughtless.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2707769" shape="rect">12:21 PM</a>
          on August 23, 2009 [
          <a title="17 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707769" shape="rect">17 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707772" shape="rect"></a>
      <div class="comments">
        <i>What I liked best about the movie was the leading actor. I thought his performance was phenomenal. It seemed to be a caricature at first, but it gradually become more and more layered.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        I went in having avoided interviews and whatnot about it.  I was blown away when I read he hadn't acted before, and that large chunks of his dialogue were improved.  That's pretty incredible.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2707772" shape="rect">12:24 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707774" shape="rect"></a>
      <div class="comments">
        Also, the worker caste being helpless without direction - that was pretty much spelled out in the film.  The idea that Chris was an emergent intelligence from the hive, a la bees replacing their queen, was spelled out explicitly in the AV Club interview, but I thought that it was pretty much obvious that he must either be a surviving high-caste or somesuch from the expert interview segments.
        <br clear="none"></br>
        <br clear="none"></br>
        I didn't like the shot of prawn van der Merwe making the rose at the end - I would far preferred if it had ended with the wife's comments about where her flower came from, rather than ramming it home that way.
        <br clear="none"></br>
        <br clear="none"></br>
        Also, how dumb are humans that their response to the craft leaving isn't to start treating the aliens a damn sight better until we find out whether an invasion fleet is coming back or not?  Which dovetails, I guess, with Bomkamf's generally negative view of human behaviour.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2707774" shape="rect">12:28 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707774" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707777" shape="rect"></a>
      <div class="comments">
        I thoroughly enjoyed the film.  It had several interwoven themes but a primary one was about a man who does not discover his humanity until he stops being a human.  I find it amazing how many people do not seem to understand that.  My roomie came back and tole me that the movie had a sad ending.  Me, I found it uplifting because the anti-protagonist , by the end of the movie had finally discovered his humanity and through it all , his love had survived.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/77939" shape="rect">Poet_Lariat</a>
          at
          <a target="_self" href="/84384/Cat-food#2707777" shape="rect">12:34 PM</a>
          on August 23, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707777" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707798" shape="rect"></a>
      <div class="comments">
        <i>I greatly enjoyed it. Though, one shouldn't address or examine it too deeply. It's a fantastic popcorn movie, as octothorpe noted, and sometimes that's all a good movie needs to be.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Then what was all the apartheid stuff for? The movie set itself up as a  serious exploration of ethnic conflicts and refugee issues, and then quickly descends into a mindless shoot 'em up. They were just teasing with the apartheid parallels?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18184" shape="rect">chrchr</a>
          at
          <a target="_self" href="/84384/Cat-food#2707798" shape="rect">12:49 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707809" shape="rect"></a>
      <div class="comments">
        In the middle of work unfortunately (actually writing about race, art and politics in SA coincidentally), but to quickly respond to rodgerd's points.
        <br clear="none"></br>
        <br clear="none"></br>
        I absolutely do make a distinction between a caricature of corporations  as evil, violent etc and an ethnocentric, xenophobic portrait of nigerians.  And I don't think the movie prtrays whites in any kind of general sense as evil, the caricature is of corporations and their participants.  It is perhaps a predictable one, but given the incredible power of corporate capital in the contemporary world - a pretty benign one as well.  The prtrayal of the Nigerian warlord is point for point a xenophobic stereotype and at no point is it critiqued or ironized.
        <br clear="none"></br>
        <br clear="none"></br>
        Second, like I said before, I don't care what the plot justification for the praun being directionless is - I agree there is one.  The question is why did a film the is self-evidently trying to function as an analogy choose to portray those who are oppressed as directionless, without community, without politics.  And like I said it is symptomatic of a certain understanding of impoverished, oppressed communities around the world.
        <br clear="none"></br>
        <br clear="none"></br>
        (sorry for typos, iPhone)
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2707809" shape="rect">1:02 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707885" shape="rect"></a>
      <div class="comments">
        <em>Also, the portrayal of Nigerian gangsters in the movie is straight-up, uncritically xenophobic. </em>
        <br clear="none"></br>
        <br clear="none"></br>
        I kept waiting for the Nigerians to send around a circular to the aliens:  &quot;Dear Sir:  A man near Lagos, Nigeria recently died with vouchers worth 1,000,000 cans of cat food.  We propose to put you forward as the legal heir, but require you to...&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        <em>If only aliens could fire the weapons, why didn't the humans use the aliens to fire them?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Because that seems like such a phenomenal recipe for disaster?  In short because it was neither possible nor desirable.  With the exception of Christopher and his offspring, it doesn't really seem like the humans have any capacity whatsoever for the command &amp; control necessary to build an effective force of mercs wielding alien-tech.  Controlling a relatively small army of aliens with advanced weapons also seems far less lucrative than being able to mass-produce human-usable models and selling them to both sides.  War-profiteering is oh-so-much better than owning your own alien-backed Xe would be.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/68908" shape="rect">Hylas</a>
          at
          <a target="_self" href="/84384/Cat-food#2707885" shape="rect">2:37 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707885" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707887" shape="rect"></a>
      <div class="comments">
        <i>And I don't think the movie prtrays whites in any kind of general sense as evil, the caricature is of corporations and their participants.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        ...which happen to be every white character in the movie -- did you think that was an accident?
        <br clear="none"></br>
        <br clear="none"></br>
        I thought they did a very good job of making it clear that
        <i>all</i>
        the whites (including the doctor in the hospital, the bystanders while Wikus is running away, all his &quot;friends&quot; in the party scene, everyone watching television, etc) were part of The System, here. That's reinforced when you get to the end and see that everybody has unquestioningly bought MNU's version of the story, despite the fact that it's kind of nonsensical. Even the people who knew Wikus personally bought it hook, line, and sinker. And if I remember correctly, the one guy at the end who was interested in looking further was black, right?
        <br clear="none"></br>
        <br clear="none"></br>
        <i>
          Second, like I said before, I don't care what the plot justification for the praun being directionless is - I agree there is one. The question is why did a film the is self-evidently trying to function as an analogy choose to portray those who are oppressed as directionless, without community, without politics. And like I said it is symptomatic of a certain understanding of impoverished, oppressed communities around the world.
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        Except that they
        <i>did</i>
        have direction, community, and politics in Christopher's movement. He and his friends were working quietly for 20 years to save their people, in the face of widespread apathy and hopelessness -- how is that a poor analogy for how &quot;impoverished, oppressed communities around the world&quot; actually work? Not
        <i>everybody</i>
        in communities like that is political. I'd say most people are just trying to survive, just like anywhere else... and that's where the prawns did have some direction and community (for instance, how long did they work to get that mech suit, and how many of them had to help? You really think they wanted &quot;a hundred thousand cans of cat food&quot; just for those two prawns? Or was that their attempt to get out from under their oppressors and break the monopoly -- &quot;no more slaving, cat food for everybody&quot;?)
        <br clear="none"></br>
        <br clear="none"></br>
        At any rate, I thought it was a great movie. As the ship was taking off at the end, I had a very visceral reaction:
        <i>
          good, that's good! Oh, I hope they come back someday... I hope they come back
          <b>and nuke us all!</b>
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        Any movie which can evoke that reaction is a good one, if you ask me.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15136" shape="rect">vorfeed</a>
          at
          <a target="_self" href="/84384/Cat-food#2707887" shape="rect">2:38 PM</a>
          on August 23, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707887" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707889" shape="rect"></a>
      <div class="comments">
        Well, I thought the light matching, practical light and compositing were the best I've ever seen.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17345" shape="rect">bz</a>
          at
          <a target="_self" href="/84384/Cat-food#2707889" shape="rect">2:40 PM</a>
          on August 23, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707889" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707919" shape="rect"></a>
      <div class="comments">
        SPOILERS: I actually liked that Wikus didn't really become much of a good-guy in contrast to just about every other buddy-action movie out there in which the male bonding over the events of the movies lead to a change of heart and everyone becoming best friends. The next-to-last scene of him, broken and begging for his life struck me as a good moment of writing.
        <br clear="none"></br>
        <br clear="none"></br>
        Another thing I liked about it was that it felt there was some thought put into actually looking at the biology of the Prawn and how that might play out, as opposed to Alien Nation which gave us that the Newcomers like soap and sour milk, and dissolve in salt water.
        <br clear="none"></br>
        <br clear="none"></br>
        And I must admit that I don't agree with all of the politics as presented in the film. But I do have to give it credit for there being something to think about there. If anything, I think the film was muddled between two opposing needs: using the aliens as a metaphor for human poverty and exploitation, while keeping the aliens as alien in their social caste structure and nutritional needs.
        <br clear="none"></br>
        <br clear="none"></br>
        The cat food thing struck me right off because canned catfood is heavily supplemented with
        <a href="http://en.wikipedia.org/wiki/Taurine#Taurine_and_cats" shape="rect">taurine</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10608" shape="rect">KirkJobSluder</a>
          at
          <a target="_self" href="/84384/Cat-food#2707919" shape="rect">3:10 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707928" shape="rect"></a>
      <div class="comments">
        I was saw this film introduced by Peter Jackson in Wellington (where a lot of the interiors were filmed).
        <br clear="none"></br>
        <br clear="none"></br>
        <em>Finally, the actor who portrays Wikus Van De Merwe (Sharlto Copley) appears very briefly in Alive in Joburg, but, more interestingly, is listed as a producer of the same film.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Jackson explained that Copley isn't an actor but an old school-friend of Blomkamp's who has been his producer for a while. Blomkamp put him forward to play Wikus and ran it past the producers who saw his audition pieces and were really happy with his performance.
        <br clear="none"></br>
        <br clear="none"></br>
        Bloody good on him, since his performance really anchors the film and is better than anything Shia the Beef could crank out.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/13196" shape="rect">John Shaft</a>
          at
          <a target="_self" href="/84384/Cat-food#2707928" shape="rect">3:25 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707943" shape="rect"></a>
      <div class="comments">
        <b>Meatbomb</b>
        <i>I found Wikus van der Merwe to be a very likeable character.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Then you're not granting the aliens their status as persons. The &quot;popcorn abortion&quot; scene, the &quot;counts as a signature&quot; when the alien strikes the clipboard, the &quot;child services ... one-by-one metre box&quot; speech, his violent reaction to &quot;three years&quot; ... he, like every other human in the movie, is a thoroughly horrible and sadistic monster who deserves to burn in cleansing fire. He manages to rise a little tiny way above selfishness at the end of the fight scene, but it's only after he's given up the hope of solving his own problem (and to hell with the aliens and their problems).
        <br clear="none"></br>
        <br clear="none"></br>
        Hyperblue's comparison to &quot;Children of Men&quot; is a good one - there are only a few characters in that movie worth the air they breathe, but the rest are irredeemable savages who, presented with a ray of hope or an opportunity to rise above cruel stupidity, will laugh maniacally as they pull its legs off just to watch it wiggle.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11128" shape="rect">aeschenkarnos</a>
          at
          <a target="_self" href="/84384/Cat-food#2707943" shape="rect">3:48 PM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707943" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707945" shape="rect"></a>
      <div class="comments">
        <i>Another thing I liked about it was that it felt there was some thought put into actually looking at the biology of the Prawn and how that might play out, as opposed to Alien Nation which gave us that the Newcomers like soap and sour milk, and dissolve in salt water.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Ironically, I thought the opposite was true, though, of course, I am mefi's resident
        <i>Alien Nation</i>
        nerd. In
        <i>Alien Nation</i>
        , we get all sorts of bits of interesting alien culture (which was not a monoculture, at least not religiously) and biology (particularly reproductive biology), even if visually they were more-or-less humans with spots. My biggest beef with
        <i>District 9</i>
        was probably how poorly developed the aliens were beyond the visual--no culture to speak of (not even a monoculture) and a really unclear social structure. Interviews with Blomkamp where he discusses how the aliens were some sort of hive or collective mind or how maybe Christopher Johnson is the just-evolved new queen--which seems to contradict some of the content of the actual movie, like how CJ affirms that he's been hiding the command module for the past twenty years--really just confirmed for me that the background of the aliens wasn't terribly important to those behind the movie; instead, the aliens were supposed to be a typical Metaphor For Oppressed Minority #1, which is a shame because I think they could have done a lot more there. The alien development seemed pretty promising in the ARG material, too, but the actual movie was so focused on Wikus that I really thought an opportunity was lost.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>The cat food thing struck me right off because canned catfood is heavily supplemented with taurine.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        My thinking was along the same lines--that either because of taurine or the high amount of protein, catfood fulfilled some sort of biologically necessary food need of theirs. The moment Wikus' transformation starts, he begins pigging out. Most other viewers seemed to view the catfood as a simple drug, though, so I think, if that was intended, it was lost on most of the audience.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2707945" shape="rect">3:51 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707945" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707947" shape="rect"></a>
      <div class="comments">
        <i>
          Then you're not granting the aliens their status as persons. The &quot;popcorn abortion&quot; scene, the &quot;counts as a signature&quot; when the alien strikes the clipboard, the &quot;child services ... one-by-one metre box&quot; speech, his violent reaction to &quot;three years&quot; ... he, like every other human in the movie, is a thoroughly horrible and sadistic monster who deserves to burn in cleansing fire. He manages to rise a little tiny way above selfishness at the end of the fight scene, but it's only after he's given up the hope of solving his own problem (and to hell with the aliens and their problems).
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        I found those scenes incredibly difficult to watch, particularly the abortion scene. I'm surprised that anyone could muster any empathy for Wikus after that--and especially after he later tries to abandon Christopher.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2707947" shape="rect">3:53 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707947" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707949" shape="rect"></a>
      <div class="comments">
        <i>Except that they did have direction, community, and politics in Christopher's movement. He and his friends were working quietly for 20 years to save their people, in the face of widespread apathy and hopelessness</i>
        <br clear="none"></br>
        <br clear="none"></br>
        That was really only true for Christopher and his son. His &quot;friend&quot; quickly showed himself to be just as helpless/hopeless as the rest of the aliens--I mean, look at his reaction to the suggestion that he &quot;be polite&quot; to the MNU guys.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2707949" shape="rect">3:55 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707970" shape="rect"></a>
      <div class="comments">
        I went on a &quot;date&quot; (well, not really a date) to see
        <em>District 9 </em>
        with a girl who I haven't really talked to since fifth grade.
        <br clear="none"></br>
        <br clear="none"></br>
        During the movie, she asked me if this was real. I had to explain to her that yes, it does look like a documentary but no, there really were not aliens in Johannesburg. I did explain to her after the movie that this is very similar to what they did to blacks in South Africa during apartheid and she asked &quot;You mean treat them like aliens?&quot; and I said &quot;Well, they segregated them and all that.&quot; She said &quot;This must have happened in like, the Medieval times, right?&quot; and I told her &quot;No, only twenty years ago or so.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        I really wish she was joking but given the fact that before we went to the movie, she told me how she seriously concerned about the world ending in 2012 (and she was expecting the world to end in 2000) and that vampires and werewolves do exist and are very real (&quot;They have to be real, I mean, how can you can't make that stuff up?&quot;), I don't think she was.
        <br clear="none"></br>
        <br clear="none"></br>
        I don't plan on meeting up with her again.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/45388" shape="rect">champthom</a>
          at
          <a target="_self" href="/84384/Cat-food#2707970" shape="rect">4:27 PM</a>
          on August 23, 2009 [
          <a title="12 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707970" shape="rect">12 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2707975" shape="rect"></a>
      <div class="comments">
        I was going to followup, but fundamentally what vorfeed said.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>I'm surprised that anyone could muster any empathy for Wikus after that</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Certainly Wikus' fate to spend a good 3 years as an alien seems pretty just in light of the things he did wrong.  It's one of the things that saves the film from having the &quot;benevolent white guy come in and fix things for the blacks^H^H^H^H^H^Haliens&quot; trope that would (rightly) get backs up.  He's actually the one responsible, in large part, for fucking up Chris' plans to save his people, and his intervention really amounts to nothing more than undoing the damage he's done, and he continues to be compromised throughout, especially by stealing the ship.
        <br clear="none"></br>
        <br clear="none"></br>
        (A move which pretty much rams home how dumb and panicked he is - what, he's going to steal the ship and... figure out how to work the transformation tools?)
        <br clear="none"></br>
        <br clear="none"></br>
        That said, a lot of his behaviour cited (the signature and the threat of child services) are more the &quot;banality of evil&quot;.  Threatening to take your kid away because you won't play ball with some dubious document?  How often do you reckon that scene is played out all over the world; black, white, yellow, communist, capitalist, whatever.  He's not a psychopath like the Colonel, or a monster like his father in law, he's just this guy doing his job without thinking about it hard enough.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2707975" shape="rect">4:37 PM</a>
          on August 23, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707975" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708027" shape="rect"></a>
      <div class="comments">
        <em>
          I'm surprised that anyone could muster any empathy for Wikus after that
          <br clear="none"></br>
          <br clear="none"></br>
          He's not a psychopath like the Colonel, or a monster like his father in law, he's just this guy doing his job without thinking about it hard enough.
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        See, that's why I found him so likable.  He wasn't a bad man, he was just a very small and not very intelligent man, put into a very difficult situation that in the end he could not resolve.  I would say it wasn't that he wasn't thinking enough, he seemed to small to be capable of the thought needed. You don't usually get an action hero like that.
        <br clear="none"></br>
        <br clear="none"></br>
        Maybe better to say &quot;I really enjoyed his character&quot;, because it was more sympathetic pathos than admiration.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17588" shape="rect">Meatbomb</a>
          at
          <a target="_self" href="/84384/Cat-food#2708027" shape="rect">5:39 PM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708027" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708038" shape="rect"></a>
      <div class="comments">
        <em>That said, a lot of his behaviour cited (the signature and the threat of child services) are more the &quot;banality of evil&quot;. Threatening to take your kid away because you won't play ball with some dubious document?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        No question, those two things are the banality of evil. But the abortion scene (&quot;It sounds like popcorn&quot;) is something altogether much worse. It made the character completely unsympathetic.
        <br clear="none"></br>
        <br clear="none"></br>
        Now that didn't mean I was applauding when he was later being tortured in MNU's underground labs; I felt physically ill when they were forcing him to test the alien weapons on pig carcasses and then a live alien.
        <br clear="none"></br>
        <br clear="none"></br>
        But once you see a guy gleeful in the way exploding fetuses sound, he's certainly slipped more into evil than banal.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/84384/Cat-food#2708038" shape="rect">5:47 PM</a>
          on August 23, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708038" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708061" shape="rect"></a>
      <div class="comments">
        <i>Maybe better to say &quot;I really enjoyed his character&quot;, because it was more sympathetic pathos than admiration.</i>
        <br clear="none"></br>
        I agree that the character was well-realized, and very well acted - a great performance, and it was a very, very worth-watching movie.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>I would say it wasn't that he wasn't thinking enough, he seemed to small to be capable of the thought needed.</i>
        <br clear="none"></br>
        That's a very low bar to jump, though. I feel pain when X, if I do X to you it is reasonable to infer that you will feel pain. The threat of taking the child away, for instance, requires the capacity to infer that the adult will feel fear and distress at the prospect.
        <br clear="none"></br>
        <br clear="none"></br>
        Whether Wikus is a bad man, and how bad a man he is, is a judgment that depends on what degree of prejudice one expects a human being neither good nor bad to display, and how that prejudice should motivate the person's behavior. IMO some prejudice is acceptable in a normal person, even in a good person. Some prejudices (for example, the narrative of the &quot;white man's burden&quot;, the actions of many religious charities, or the prejudice of believers in permanent and everlasting affirmative action policies) will even motivate the holder of the prejudice to act more kindly towards those whom he/she feels are inferior; while the prejudice is still
        <i>wrong</i>
        , it's hard to justify the effort of arguing with it, and it could even be counterproductive to do so. By nature most people are quite prejudiced and will seek the company of those like themselves and avoid the company of those unlike themselves as long as it's not inconvenient to do so - that's an animal instinct.
        <br clear="none"></br>
        <br clear="none"></br>
        But the point at which prejudice turns into an active desire to harm is where, to me, it becomes evil; and Wikus is well into that area. As the movie begins he is a hateful man, who has been given some power over the targets of his hate, and he exercises that power to harm them.
        <br clear="none"></br>
        <br clear="none"></br>
        People like him are common, for sure. They flock to anywhere that they can exercise authority without oversight or worse, with approval of their actions by their overseers. They become prison guards, teachers, police officers, security guards, bureaucrats of various kinds. Generally they get away with their corruption because sadistic pleasure isn't as traceable as money or goods, but it is no less corruption for that.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11128" shape="rect">aeschenkarnos</a>
          at
          <a target="_self" href="/84384/Cat-food#2708061" shape="rect">6:15 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708061" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708103" shape="rect"></a>
      <div class="comments">
        <em>Then what was all the apartheid stuff for? The movie set itself up as a serious exploration of ethnic conflicts and refugee issues, and then quickly descends into a mindless shoot 'em up. They were just teasing with the apartheid parallels?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        As the thread has shown, it seems a number of people have become dissatisfied with the movie after thinking too deeply about things.
        <br clear="none"></br>
        <br clear="none"></br>
        More to the point, I think the apartheid parallels were in part to simply set the atmosphere and setting of the movie.  Somewhat in how Wall-e had a polluted world and a human civilization based on over consumption and laziness.  The movie wasn't specifically about those subjects, but they were blatantly part of the representation.  The specific stories of District 9 was Wilkus, Christopher, and his Son.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/26998" shape="rect">Atreides</a>
          at
          <a target="_self" href="/84384/Cat-food#2708103" shape="rect">6:53 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708103" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708120" shape="rect"></a>
      <div class="comments">
        <i>You don't usually get an action hero like that.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        I don't really see him as the hero - if anything, Chris is the hero, and we're seeing the film from the POV of the bumbling sidekick of the action movie.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>As the thread has shown, it seems a number of people have become dissatisfied with the movie after thinking too deeply about things.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Most of the people who are dissatisfied don't seem to be thinking enough, in my opinion, but I suspect we'll differ there.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>More to the point, I think the apartheid parallels were in part to simply set the atmosphere and setting of the movie.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        You should probably read the
        <a href="http://www.avclub.com/articles/district-9-director-neill-blomkamp,31606/" shape="rect">AV Club interview</a>
        with Bomkamp if you think that's the case.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2708120" shape="rect">7:11 PM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708120" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708130" shape="rect"></a>
      <div class="comments">
        Jesus, Champthom.  That musta sucked.  I hope you at least got a . . . little something for your time.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18529" shape="rect">John of Michigan</a>
          at
          <a target="_self" href="/84384/Cat-food#2708130" shape="rect">7:23 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708142" shape="rect"></a>
      <div class="comments">
        Read the interview.  Not really sure where Bomkamp says anything that contradicts what I thought.  I didn't say that the apartheid atmosphere was supposed to be completely  relegated to the background, but it did serve as a background to an extent.  The director states that he chose the city because he thought it was a good setting for the future.   Please feel free to point out the quotations which state that apartheid was the crucial message of the movie.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/26998" shape="rect">Atreides</a>
          at
          <a target="_self" href="/84384/Cat-food#2708142" shape="rect">7:38 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708172" shape="rect"></a>
      <div class="comments">
        On the subject of South African (human racial) apartheid, it's an interesting assumption that a variety of SF and alternate history authors have made, that the presence of a genuine external alien threat would cause us as humans to look to other humans of different races and think that in comparison to the New Other, we're not so different after all. In District 9 it seems reasonable to assume that the landing of the aliens in 1982 would have ended apartheid early, and certainly in the context of the movie black and white South Africans (though not Nigerians) are seen working and socializing as equals.
        <br clear="none"></br>
        <br clear="none"></br>
        (Incidentally did it occur to anyone else that the alien &quot;boat people&quot; backstory in District 9 is pretty the same story as the arrival and history of Zoidberg's species on Earth in Futurama? :) )
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11128" shape="rect">aeschenkarnos</a>
          at
          <a target="_self" href="/84384/Cat-food#2708172" shape="rect">8:09 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708211" shape="rect"></a>
      <div class="comments">
        Futurama has three or four different meta histories for zoidberg's race, the decapodeans.  But then I haven't seen the movies.
        <br clear="none"></br>
        <br clear="none"></br>
        But I digress.  I had a slightly different take on wikus, and the abortion scene in particular.  Near the beginning of the movie you see Wikus trying to talk to the &quot;cowboys&quot; the paramilitary forces that MNU has.  I see his reaction in the first third of the movie, including the abortion scene as him being a spineless worm who wants to seem macho to his assistant.  I recall him saying, &quot;You don't need a facemask, masks are for pussies,&quot; or something during the scene.
        <br clear="none"></br>
        <br clear="none"></br>
        To me Wikus isn't evil.  The culture is sick. Hell even the protesters outside District 9 had &quot;we &lt;3 prawns&quot; signs, when prawns is treated as a racial slur.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27005" shape="rect">gryftir</a>
          at
          <a target="_self" href="/84384/Cat-food#2708211" shape="rect">8:55 PM</a>
          on August 23, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708211" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708214" shape="rect"></a>
      <div class="comments">
        I enjoyed the movie for simple reasons: originality and quality. But it does repay more complex thinking. How evil (or what type of evil) is Wikus? did he have a change of heart at the end, or did he merely give up hope for his own survival? what do the Nigerians have in common with MNU? what do MNU and the Nigerians have in common with us?
        <br clear="none"></br>
        <br clear="none"></br>
        And this discussion has brought up another series of questions for me: how quick are we to look down upon people who aren't doing what we think they should in order to better themselves? why do we assume they've got the same resources/skills/support that we do? If we don't know someone's situation, as the movie restricts us from knowing with the prawns, how can we really judge their actions? And do we always ask that of people in trouble in our own lives?
        <br clear="none"></br>
        <br clear="none"></br>
        And there's no indication that the aliens wouldn't have been equally horrible to us, if their ship hadn't stalled with a bunch of them stuck in the hold. The short at least indicates that they were going to suck the planet dry of water and electricity.
        <br clear="none"></br>
        <br clear="none"></br>
        I think it's a deeply pessimistic movie.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2708214" shape="rect">8:58 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708237" shape="rect"></a>
      <div class="comments">
        <em>Most of the people who are dissatisfied don't seem to be thinking enough, in my opinion</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Agreed!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/47831" shape="rect">taliaferro</a>
          at
          <a target="_self" href="/84384/Cat-food#2708237" shape="rect">9:16 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708266" shape="rect"></a>
      <div class="comments">
        I read the abortion thing as just gallows humor. Also I think he thought of them as animals, by that point. If he had been making jokes about an omelette being a chicken abortion would that make him a bad person?  What if the aliens were animal like and barely posessed higher brain function?  If there was no Christopher among the aliens, would they have gotten your sympathy?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29475" shape="rect">empath</a>
          at
          <a target="_self" href="/84384/Cat-food#2708266" shape="rect">9:53 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708274" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/84384/Cat-food#2707885" shape="rect">Hylas</a>
        :I kept waiting for the Nigerians to send around a circular to the aliens:  &quot;Dear Sir:  A man near Lagos, Nigeria recently died with vouchers worth 1,000,000 cans of cat food.  We propose to put you forward as the legal heir, but require you to...&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        OMG, I almost forgot! I got a CALL on my CELL yesterday which was literally a straight-up 419! Some dude was all, &quot;I am calling you from Nigeria and I will tell you my name,&quot; and it was hard to understand because of a hinky connection and his accent. Once he repeated it a couple times, i understood what he was saying but was puzzled as hell. Then he started his spiel, about the missing money or whatever, and I BURST OUT LAUGHING! Inventiveness!
        <br clear="none"></br>
        <br clear="none"></br>
        Anyway, and also: huffa, keep kickin' down!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2708274" shape="rect">10:03 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708277" shape="rect"></a>
      <div class="comments">
        Oh, there's one other plot thing: The film makes it clear that the aliens in the ship were rescued from starvation by the government of South Africa. While the consequences of the act in the film are complicated and not pretty it undercuts the analysis of the film which posits that the viewpoint of the filmmakers is purely misanthropic.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2708277" shape="rect">10:10 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708285" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/84384/Cat-food#2707928" shape="rect">John Shaft</a>
        : &quot;
        <i>Jackson explained that Copley isn't an actor but an old school-friend of Blomkamp's who has been his producer for a while. Blomkamp put him forward to play Wikus and ran it past the producers who saw his audition pieces and were really happy with his performance. </i>
        &quot;
        <br clear="none"></br>
        <br clear="none"></br>
        As well he should have been, the guy was fucking great. I mean, really great. I was hoping he had point on the release since he did on the original. He might, even: Jackson has an earned rep for fair dealing. For all my wigshifting and pondering on the content of the film, I delighted at it's success precisely because it's got me reseating my DeKalb hat repeatedly.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2708285" shape="rect">10:18 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708291" shape="rect"></a>
      <div class="comments">
        mrwhybark, your satire reminds me of the rather sad story of the guy who flew to Nigeria to sort out an email scammer and turned up dead, because he failed to understand that &quot;Nigerian criminal gangs&quot; are no more to be taken lightly than, say the Yakuza or Mafia.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2708291" shape="rect">10:21 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708294" shape="rect"></a>
      <div class="comments">
        <em>why did a film the is self-evidently trying to function as an analogy choose to portray those who are oppressed as directionless, without community, without politics</em>
        <br clear="none"></br>
        <br clear="none"></br>
        The prawns had managed to find the most awesome tech they could, and were trying to trade it for ten thousand cans of cat food - as mentioned earlier, that was an attempt to feed a large group using what they had available. But the oppressors kicked them while they were down, stole their tech, and shot the representative prawn for even trying. They weren't directionless, without community or without politics - it's that the oppressors are too racist to see those good qualities even when it's right in their faces, and we're seeing things solely from the oppressors point of view until we get to know Christopher better. Blomkamp invites us to see things as they really are, even as the documentary footage feeds us the corporate line.
        <br clear="none"></br>
        <br clear="none"></br>
        Blomkamp is trying to show the ugliness and pervasiveness of institutionalised racism without tugging on the heartstrings in a cheesy way. He puts us in the oppressors shoes, and shows us that it's not that different from things we already know.
        <br clear="none"></br>
        <br clear="none"></br>
        He could have gone the Hollywood route, and had Wikus and Christopher triumphantly rescue all the prawns, while Wikus gets returned to &quot;normal&quot; in 3 minutes inside the ship while making a speech about how awesome being different is, and the corporation gets exposed for it's evil ways and the gangs are arrested. But it wouldn't be a realistic analogy that way, and it would focus on the actions of individuals instead of how we're all complicit in maintaining these systems through weakness (Wikus and the other staff) and greed (MNU and the gang).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2708294" shape="rect">10:29 PM</a>
          on August 23, 2009 [
          <a title="9 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708294" shape="rect">9 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708305" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/84384/Cat-food#2708291" shape="rect">rodgerd</a>
        : &quot;
        <i>mwhybark, your satire...</i>
        &quot;
        <br clear="none"></br>
        <br clear="none"></br>
        It's not a joke, dude. It really happened. The originating number was 2347034290558.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17447" shape="rect">mwhybark</a>
          at
          <a target="_self" href="/84384/Cat-food#2708305" shape="rect">10:43 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708311" shape="rect"></a>
      <div class="comments">
        <em>I read the abortion thing as just gallows humor. Also I think he thought of them as animals, by that point. If he had been making jokes about an omelette being a chicken abortion would that make him a bad person?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Okay, so he thought of them as animals - does that make it right? There was clearly some subtext about how we treat animals in this film, since there is a lot of animal slaughter and animal carcasses throughout. Are we to think his gallows humour is okay because he's equating the aliens with, say, the pigs we see a lot of during the film?
        <br clear="none"></br>
        <br clear="none"></br>
        <em>What if the aliens were animal like and barely posessed higher brain function? If there was no Christopher among the aliens, would they have gotten your sympathy?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Well IF they were animal like and IF they barely possessed higher brain function, it would be a whole different movie. And, of course, Christopher is there for us to gain our sympathies. Although, to be honest, even before Christopher and his son appeared in the film, it was clear to see that no matter what the brain function of the aliens, the human population of South Africa was generally treating them pretty badly.
        <br clear="none"></br>
        <br clear="none"></br>
        Had they been actually analogous to animals, the film would be more a criticism of factory farming. As it is, that subtext is still there in a lot of ways.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/84384/Cat-food#2708311" shape="rect">10:55 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708317" shape="rect"></a>
      <div class="comments">
        a lot of interesting points about the film.  i really agree with mwhybark's point about peter jackson productions in general being very much about a kind of colonial experience of the Other.  of course, told from the perspective of the colonizer.  district 9, king kong and lotr all do this to a degree.  and they are fascinating, complex, thought-provoking films precisely because they occupy this standpoint so deeply.  at the same time, they DO occupy the standpoint of the settler/colonial/firstworldmiddleclass, and they are told (often uncritically) from this standpoint.  (in the case of lotr and king kong, they are adaptations of stories that are already symptomatic of a colonial worldview, that don't so much criticize this as take it on fully.)
        <br clear="none"></br>
        <br clear="none"></br>
        there have been a few points raised about the actions taken by christopher in the film, and the trading a tech to feed a large group of people.  as regards the first point, I don't see christopher's actions as indicative of the presence of a political community, but instead the presence of a few unique, exceptional individuals within a community that is by and large portrayed as dissolute and depoliticized. honestly, I would have to go back and watch the scene where there is a trade of tech for food - I don't clearly remember who is involved here - is this something else christopher does?
        <br clear="none"></br>
        <br clear="none"></br>
        I certainly am not advocating a feel good ending, or any particular ending.  and, moreover, I appreciate the portrayal of Merwe as a kind of Eichmann-via-Arendt, banality of evil type character who is never really redeemed even at the very end.  And I appreciate that the world is not simply saved at the end of the film with the praun achieving some happy life on Earth or elsewhere.  And, once again, I agree with all those who have said that it is an innovative, surprising, worthwhile film in many respects, one of the most interesting films of the year.
        <br clear="none"></br>
        <br clear="none"></br>
        None of this makes me any less convinced that this film is symptomatic of a view of oppressed groups around the world as without community and politics.  Here is one way to think about:  There are two possible groups that this film could, in part, be equating the praun with.  On the one hand, black Africans under apartheid.  On the other hand, the contemporary poor of South Africa.  In both cases, there are/were strong MASS movements that spanned the entire country of South Africa that were grounded in these groups.  Under apartheid, as is well known, there were all the various anti-apartheid movements - UDF, ANC, PAC, SACP, etc, etc. - and innumerable community based organizations, smaller organizations, etc, etc.  Associated with these movements were mass marches and political rallies of thousands upon thousands, nationwide boycotts, and general strikes.  In the contemporary moment, there are movements like the Anti-Eviction Campaign and Abahlali baseMjondolo who have brought together shackdwellers across the country, marched on the city halls of every major city in the country, and brought cases to the constitutional court.  There is not a single shot of an organized mass protest, not a single piece of evidence of a movement or an organization in the entirety of District 9.  The community is portrayed in such a way as to make that almost unthinkable.  Instead, we have shots of belligerent drunks, random violence, aliens swarming upon humans and food alike.  At best, there are a few individuals who appear as a kind of underground insurgency building, literally, IED's.  The tradition of mass politics so important to the resistance to apartheid and its legacy is simply erased in this film.
        <em>From any perspective other than that of a distant middle-class observer such an erasure appears as not only politically suspect but actually stretching the limits of plausibility.</em>
        It is simply bizarre to imagine the history of the past 20 years in SA without mass politics.  Therefore, this film is told from just such a distant, middle-class perspective.  It is deeply, complexly, invested in this perspective.  This makes it a very, very interesting film - but still a film symptomatic of a kind of neo-colonialism.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2708317" shape="rect">11:11 PM</a>
          on August 23, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708317" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708349" shape="rect"></a>
      <div class="comments">
        <a title="huffa wrote in comment #2708317" href="http://www.metafilter.com/84384/Cat-food#2708317" shape="rect">&gt;</a>
        <i>There is not a single shot of an organized mass protest, not a single piece of evidence of a movement or an organization in the entirety of District 9.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Actually, there was footage of the mass protests and efforts against the eviction process in the film, usually clips of newsreel footage leading up to the caravan scenes.
        <br clear="none"></br>
        <br clear="none"></br>
        And I realize it must be bizarre for someone who has much more intimate knowledge about the political movements in SA to see an alternative history be placed there, but then it also has aliens and a gun that shoots pigs.
        <br clear="none"></br>
        <br clear="none"></br>
        I think the distinction could in fact be intentional, that even in a place such as SA, where one would assume the populace would be the most adept and understanding at dealing with such systemic levels of prejudice and institutionalized racism, that these aliens are so radically non human and insect like that even there, they are segregated.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2708349" shape="rect">11:45 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708355" shape="rect"></a>
      <div class="comments">
        Actually, to add, I don't want to come off defensive about the film. I am very much one with the distant middle class perspective of the apartheid, being something I have not studied in depth, and I see your points in regards to colonialism and neo-colonialism. However I feel that is not the only lens available with which to view the movie.
        <br clear="none"></br>
        <br clear="none"></br>
        And that is in part why I enjoy it so much, it does have many intentional, and unintentional, layers to it. Especially when considered with it's immediate relatives of the alien movie genre.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/84384/Cat-food#2708355" shape="rect">11:52 PM</a>
          on August 23, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708386" shape="rect"></a>
      <div class="comments">
        <em>There are two possible groups that this film could, in part, be equating the praun with.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I took it less as the prawns being representative of a particular group, and more about how they could be *any* group that's different from the majority/rich. Maybe that's why it had to be aliens - if he picked blacks, Asians, gays, women, transgendered, nerds, old people, whatever, we'd only see that the Moral Of The Story is &quot;straight white men with money should be nicer to [insert group here], they're people same as you&quot;. Aliens makes it about humans and our shitty behaviour in general, not about why a specific group should be allowed to join in the privilege this time.
        <br clear="none"></br>
        <br clear="none"></br>
        Humans all over the world are currently happy to demonise the Other - we don't want to admit the intelligence, agency, emotions or culture of anyone not like us. I think District 9 is Blomkamp's fear of what the future will be like if we can't get over that, rather than a definite commentary on a specific political situation.
        <br clear="none"></br>
        <br clear="none"></br>
        I'm not really disagreeing with you, as such, more just saying where I was coming from when I saw the movie. I've got a bit more time on my hands than usual today. It's nice to have an accessible movie about a complex subject to discuss with MeFi.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2708386" shape="rect">12:58 AM</a>
          on August 24, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708386" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708541" shape="rect"></a>
      <div class="comments">
        You all must have seen a different movie than I did.
        <br clear="none"></br>
        <br clear="none"></br>
        I went in looking for a subtle science fiction flick with truly alien aliens and an overarching subtext of apartheid in a novel context.
        <br clear="none"></br>
        <br clear="none"></br>
        Instead I got Signs 2: Prawn Boogaloo
        <br clear="none"></br>
        <br clear="none"></br>
        The inconsistent documentary style, the complete absence of culture (or thought or novelty or intelligence or...) in the aliens, the caricatured evil of the MMU
        <i>and</i>
        the Nigerians (squick), the utter failure of Wikus' wife, friends and family to notice that he was profoundly ill at his party, the again
        <i>profoundly</i>
        clichÃ©'d Machiavellianism of the father in law and the 0-dimensional gun-toting rambo/Blackwater dude. All while the background screamed &quot;SEE THE VIOLENCE INHERENT IN THE SYSTEM!&quot; over and over.  And over.
        <br clear="none"></br>
        <br clear="none"></br>
        Wikus' performance was stellar, I agree but the surrounding universe was so unbelievable I couldn't enjoy it at all.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15797" shape="rect">Skorgu</a>
          at
          <a target="_self" href="/84384/Cat-food#2708541" shape="rect">6:41 AM</a>
          on August 24, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708541" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708601" shape="rect"></a>
      <div class="comments">
        <em>More to the point, I think the apartheid parallels were in part to simply set the atmosphere and setting of the movie.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I chalk some of this up to the fact that this is a movie steeped in South African culture, and there are resonances lost on a North American audience.  I have travelled a fair bit in my life and probably know a teensy bit more about South Africa than the average guy in the street here.  I almost certainly know more South Africans personally.  Even so, I knew I was watching allusions that a South African audience would get that would pass me by totally.  I gather District 9 is an allusion to the historical District 6 in Cape Town; I know that van der Merwe is the stock name for a doofus character in jokes; and I know that Wikus is an Afrikaans South African and his wife and in-laws are more English culture South Africans with all the tensions that implies, but the nuances are lost on me (and I suspect, almost everyone reading this). And I suspect that for every reference I got, I missed ten. (What would a Johannesburg audience make of
        <em>Bon Cop, Bad Cop</em>
        ?)
        <br clear="none"></br>
        <br clear="none"></br>
        I enjoyed the unfamiliarity of the idiom.  As the movie admits in a sort of po-mo moment early on, you expect that the ship would wind up over New York or Washington; likewise, we have come to expect the same tired-ass Noo Yawk characters (the cranky Brooklyn cabbie, the sassy no-nonsense black woman, the simpering and corrupt guy in a tie).  It was nice to give those folks the week off.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78804" shape="rect">ricochet biscuit</a>
          at
          <a target="_self" href="/84384/Cat-food#2708601" shape="rect">7:53 AM</a>
          on August 24, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708601" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708615" shape="rect"></a>
      <div class="comments">
        <em>The Nigerians are the mirror image of MNU. The experiences of the aliens and van der Merwe's experience at their hands mirror one another; the differences are ones of detail; the biotech labs vs the religious rituals</em>
        <br clear="none"></br>
        <br clear="none"></br>
        The portrayal of the biotech industry in D-9 is pure, unadulterated horseshit.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/48745" shape="rect">KokuRyu</a>
          at
          <a target="_self" href="/84384/Cat-food#2708615" shape="rect">8:09 AM</a>
          on August 24, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708615" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708642" shape="rect"></a>
      <div class="comments">
        <em>Nothing that happens in the second half of the film is as compelling as the first forty minutes, or even close, and by the end all pretense of higher thematic interest is lost in the usual mess of shouting and explosions.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        People complained about Shaun of the Dead for the same reason.  And while I can empathize, I don't sympathize.  At some point the director *has* to make the switch to a more classic narrative style or they'll end up with a strictly arthouse flick.  Even Memento, which kept the backwards structure throughout the whole movie, felt fairly traditional in the second and third acts.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33578" shape="rect">bpm140</a>
          at
          <a target="_self" href="/84384/Cat-food#2708642" shape="rect">8:31 AM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708648" shape="rect"></a>
      <div class="comments">
        <a href="http://www.madamandeve.co.za/cartoons/me004427.jpg" shape="rect">District 419</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/646" shape="rect">RakDaddy</a>
          at
          <a target="_self" href="/84384/Cat-food#2708648" shape="rect">8:37 AM</a>
          on August 24, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708648" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2708700" shape="rect"></a>
      <div class="comments">
        <i>You all must have seen a different movie than I did. </i>
        <br clear="none"></br>
        <br clear="none"></br>
        Such is the triumph and tragedy of subjective literary interpretation.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10608" shape="rect">KirkJobSluder</a>
          at
          <a target="_self" href="/84384/Cat-food#2708700" shape="rect">9:09 AM</a>
          on August 24, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708700" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709004" shape="rect"></a>
      <div class="comments">
        I really appreciated the lack of gender markers for the prawns. Usually when a film features non-human characters, the females (female animals, aliens, rocks, whatever) get fuller pink lips and fuller heaving bosoms than do the males. As if male bears are attracted to lipstick and cleavage. D9 had none of this.
        <br clear="none"></br>
        <br clear="none"></br>
        The lack of gender markers combined with the constant use of male pronouns and names left my partner and I wondering if there are two sexes in the Prawn species but females were conveniently left out of the plot, or if maybe Prawns don't have sexes, but since English relies on gendered pronouns the translation relied on the universal &quot;him&quot; and &quot;he.&quot; Chris described as the child's father, and the child as his son, but there was no mention of a missing or dead wife (
        <a href="http://tvtropes.org/pmwiki/pmwiki.php/Main/MissingMom" shape="rect">a movie staple</a>
        ), or of females at all, really.
        <br clear="none"></br>
        <br clear="none"></br>
        The lack of female prawns was conspicuous enough to seem intentional, which led me to wonder if this is a non sex-differentiated species whose words, when translated into English,  are replaced with the universal male versions. I hope so, because I really liked the movie, and the alternative explanation (females just aren't important enough to warrant mention in the movie except for as a male's love interest) is awful.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23174" shape="rect">arcticwoman</a>
          at
          <a target="_self" href="/84384/Cat-food#2709004" shape="rect">12:38 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709030" shape="rect"></a>
      <div class="comments">
        Well, there's lots of speculation above and elsewhere that what we are looking at is a stranded ship full of low-caste labourers. What is true for this group may not be true for the species. That would seem to hold to the hive/drone analogy, too.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/68399" shape="rect">Durn Bronzefist</a>
          at
          <a target="_self" href="/84384/Cat-food#2709030" shape="rect">12:48 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709042" shape="rect"></a>
      <div class="comments">
        I hated how cartoonishly evil the big corporation was.  &quot;Yes, we wont even bother exploring them as a species, just try to fire those weapons.&quot; Where's the international outrage, humantarian groups, research scientists, etc? Its all seemed so &quot;good guy vs bad guy&quot; that I couldnt get into it.  Then it became a Transformers-like action movie.
        <br clear="none"></br>
        <br clear="none"></br>
        The premise was purposely oblique. Did they need fuel? If they did then why were they able to get some from debris? Why are some smart and others dumb? Is this a hive mind? Instead, they side-step the interesting questions and basic context to bring us &quot;guy in mech suit throwing pig at guy with m60.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        Still well-done, but its a comic-book melodrama at best.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/41990" shape="rect">damn dirty ape</a>
          at
          <a target="_self" href="/84384/Cat-food#2709042" shape="rect">12:55 PM</a>
          on August 24, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2709042" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709127" shape="rect"></a>
      <div class="comments">
        To me, it seems that some of that obliqueness was intentional. It felt to me that the prawn were set up to be viscerally disgusting to human beings, and therefore, no one really bothered to figure out what was wrong with them or how their culture and biology really worked. The narrative breaks away from the view of Wikers only to make key transitions, and perhaps it should have explored the alien point of view more clearly.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10608" shape="rect">KirkJobSluder</a>
          at
          <a target="_self" href="/84384/Cat-food#2709127" shape="rect">2:03 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709180" shape="rect"></a>
      <div class="comments">
        arcticwoman - the aliens a hermaphrodites, and carry both male and female organs for reproduction.
        <a href="http://www.traileraddict.com/trailer/district-9/psa-alien-reproduction" shape="rect">As seen in this lovely PSA</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        They didn't portray females because they're aren't any.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18795" shape="rect">daq</a>
          at
          <a target="_self" href="/84384/Cat-food#2709180" shape="rect">2:43 PM</a>
          on August 24, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2709180" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709311" shape="rect"></a>
      <div class="comments">
        <em>The lack of female prawns was conspicuous enough to seem intentional</em>
        <br clear="none"></br>
        <br clear="none"></br>
        The &quot;prawns&quot; are also supposed to be an insectoid hive collective with a queen, and on Earth, the workers and drones in these societies are typically female.
        <br clear="none"></br>
        <br clear="none"></br>
        So maybe all of the prawns are female.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/48745" shape="rect">KokuRyu</a>
          at
          <a target="_self" href="/84384/Cat-food#2709311" shape="rect">4:13 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709475" shape="rect"></a>
      <div class="comments">
        It seems like a lot of the criticisms are about stuff that was left out of the movie - but you can't have an exploration of alien culture and biology, plus an analogy about racism and the future of humanity, plus taking the time to make the characters three-dimensional, plus a nuanced view of big corporations, plus a critique of current SA politics, plus some action so that people don't complain that &quot;it's too talky, when are they going to put this knowledge to use?&quot;, in just a couple of hours. Unless you want to make a Lord of the Rings length feature.
        <br clear="none"></br>
        <br clear="none"></br>
        Sometimes a movie can only cover one aspect of a story. Charles Dickens wasn't famous for his well-rounded character development, yet people still read his books because they enjoy the plot. Alien wasn't an analogy for anything at all, but it's a classic sci-fi/horror film. 2001 didn't tell you jack about the Starchild, but it's considered a masterful artistic achievement.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2709475" shape="rect">6:45 PM</a>
          on August 24, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2709475" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709480" shape="rect"></a>
      <div class="comments">
        I'm still working my way through this idea: maybe showing us how awesome the prawns really are in great detail would detract from the racism analogy? We should treat all creatures and people with dignity, not because they're nice or cool or have stuff in common with us, but because it's just the right thing to do.
        <br clear="none"></br>
        <br clear="none"></br>
        We keep saying &quot;oh, that group over there are savages, you can't trust them&quot; - then we're proved wrong, and so we include them in the new, expanded group of people worthy of being treated properly. And then we see a new group, decide they're savages, are proven wrong, include them in the group... etc etc. It's a cycle repeated through history, and if Blomkamp's right, into the future as well.
        <br clear="none"></br>
        <br clear="none"></br>
        We shouldn't be waiting for evidence that people deserve dignity. We should just see that the prawns are living beings with capacity for pain, for love, for culture in general, and treat them right even if we think they're squicky.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2709480" shape="rect">6:53 PM</a>
          on August 24, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2709480" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709482" shape="rect"></a>
      <div class="comments">
        Maybe I'm overthinking a plate of
        <strike>prawns</strike>
        beans.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2709482" shape="rect">6:57 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709519" shape="rect"></a>
      <div class="comments">
        mrzarquon - just wanted to reply to your comment.  first, as I recall the, and as you suggest, the shots of protest are shots of humans protesting on behalf of the aliens - a very different thing than the aliens protesting themselves.  second, my problem with the presentation of the aliens in the film isn't inaccuracy but rather the political implications of the fiction it spins.  when I say that this portrayal stretches the limits of plausibility - I am trying to make clear how stark the erasure of political action is within the film given that it is explicitly situated within the history of South Africa.  however, the film could have fictionalized that history and changed it in all sorts of ways - in principle there's nothing wrong with that.  however, the particular way it did chose to fictionalize this history - produced an alternative in which the central oppressed group had no real politics.  (it's interesting too, btw, that the aliens land in the 80's at what was the height of apartheid of violence in the 'real' SA.  going into the film, was sure they would have them land after 1994, and postulate a kind of second apartheid.  instead, they sort of substitute the late apartheid era for the landing of the aliens.  i'm not criticizing this choice - but i find it interesting.)
        <br clear="none"></br>
        <br clear="none"></br>
        harriet vane - I don't disagree with the idea that Blomkamp could be talking more generally about the oppressed, exiled, dislplaced, impoverished of the world.  in fact, I think you are right that that is part of the analogy being made.  so in that sense, I probably overstated my point about the possible groups that the praun could be standing in for.  however, I do maintain that the film is, at least, in part, making reference to both of those groups - contemporary poor South Africans and non-white or black South Africans under apartheid.  also, even if it is a more general analogy to oppressed peoples worldwide, I still have just as much a problem with its denial of political organization on the part of the oppressed.  and it is, in this way, still just as symptomatic of a view of third world populations as objects of assistance and aid, not political subjects in their own right.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2709519" shape="rect">7:52 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709586" shape="rect"></a>
      <div class="comments">
        I think the movie had a lot of flaws, but think the portrayal of Wilkus alone was enough to save it and make it an interesting movie. I don't think I've seen such a fascinating film protagonist recently.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73858" shape="rect">Solon and Thanks</a>
          at
          <a target="_self" href="/84384/Cat-food#2709586" shape="rect">9:35 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709606" shape="rect"></a>
      <div class="comments">
        huffa - fair enough. I still wouldn't say that the movie itself denies them political agency, but that it portrays characters who have a denial/wilful ignorance of same - which is a fine distinction to draw for sure.
        <br clear="none"></br>
        <br clear="none"></br>
        I wish I had your background knowledge of the specific situation in South Africa, it's not something that gets a lot of coverage in the mainstream news. I'd be fascinated by an FPP about it if you wanted to pull one together sometime.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2709606" shape="rect">10:11 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709644" shape="rect"></a>
      <div class="comments">
        <i>Alien wasn't an analogy for anything at all,</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Um what?  Helllllloooooooooo pregnancy fears!
        <br clear="none"></br>
        <br clear="none"></br>
        <i>
          We keep saying &quot;oh, that group over there are savages, you can't trust them&quot; - then we're proved wrong, and so we include them in the new, expanded group of people worthy of being treated properly. And then we see a new group, decide they're savages, are proven wrong, include them in the group... etc etc. It's a cycle repeated through history, and if Blomkamp's right, into the future as well.
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        That's where he's drawing on the status of e.g. Zimbabweans in modern South Africa, for example.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2709644" shape="rect">11:32 PM</a>
          on August 24, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709792" shape="rect"></a>
      <div class="comments">
        Someone suggested that Blomkamp got much of his dialog for the &quot;candid&quot; interviews about the aliens by interviewing people on the street about immigrant groups. And parts of District 9 were filmed on location in an immigrant slum, which puts the arguments about exaggerated rhetoric and the absence of sheetrock in a different context.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10608" shape="rect">KirkJobSluder</a>
          at
          <a target="_self" href="/84384/Cat-food#2709792" shape="rect">4:51 AM</a>
          on August 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2709932" shape="rect"></a>
      <div class="comments">
        <i>arcticwoman - the aliens a hermaphrodites, and carry both male and female organs for reproduction. As seen in this lovely PSA.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Man, why couldn't they include this information in the actual movie? Without it, it seems either like all of the prawns are apparently male due to either bad film-making (not bothering to include alien female characters) or bad sci-fi species building. I hate that film makers assume that audiences will be bored by details that create a richer, more holistic universe--and assume that the only people who would be interested are, say, the nerds who are into ARGs.
        <br clear="none"></br>
        <br clear="none"></br>
        (I am a nerd who is into ARGs, so no offense intended there!)
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2709932" shape="rect">7:57 AM</a>
          on August 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2710043" shape="rect"></a>
      <div class="comments">
        My main complaint with the premise of District 9 was that in the case of apartheid, the oppressors came to the oppressed, not the other way around.
        <br clear="none"></br>
        <br clear="none"></br>
        I thought the talk of a sequel was a joke, until I read the AV Club interview. Then it was like &quot;Ha ha ha ha ha ha... oh wait, he's serious.&quot; What would a District 10 look like? Blomkamp seems smart enough to avoid an &quot;aliens return and wage war&quot; shoot-em-up (though I wouldn't put any money on it), so hopefully we'd get another allegory. But a different one. The return of Christopher has obvious parallels with the second coming of Jesus (starting with his 'name,' for one). Three years have come and gone, and there is no return. The hive once again starts selecting a queen from the herd, who attempts to organize the poleepkwa in a scenario that mirrors the formation of the early Christian church. In this case, the humans become the Roman Empire. This is just the first scenario that comes to mind. Blomkamp, my e-mail's in my profile.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20821" shape="rect">Eideteker</a>
          at
          <a target="_self" href="/84384/Cat-food#2710043" shape="rect">8:52 AM</a>
          on August 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2710074" shape="rect"></a>
      <div class="comments">
        <i>My main complaint with the premise of District 9 was that in the case of apartheid, the oppressors came to the oppressed, not the other way around.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        So?  I'm not sure the point of the movie was to create a point for point allegory for apartheid.  If you're going to do that, why not just make a movie about apartheid?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29475" shape="rect">empath</a>
          at
          <a target="_self" href="/84384/Cat-food#2710074" shape="rect">9:11 AM</a>
          on August 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2710074" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2710182" shape="rect"></a>
      <div class="comments">
        Well, &quot;they came to us and now we have to take care of them&quot; is a different situation than &quot;we took everything they had and now they're dependent on us to take care of them.&quot; And that was my impression going into the movie; it didn't have as much of an effect on the picture as I'd thought.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20821" shape="rect">Eideteker</a>
          at
          <a target="_self" href="/84384/Cat-food#2710182" shape="rect">9:47 AM</a>
          on August 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2710435" shape="rect"></a>
      <div class="comments">
        My idea for a sequel has the prawns worshiping Wikus as some kind of prophet, which he finds completely appalling and wants no part of.  He does, however accidentally begin spouting off a completely hackneyed 'philosophy' which is just a mish-mash of christianity, new age pablum and corporate slogans that the Aliens take as their gospel.
        <br clear="none"></br>
        <br clear="none"></br>
        By the time that Christopher returns, the prawns have begun to express a yearning for individuality and 'freedom' and decide that they don't actually want to go back to become slaves to the hive mind again.
        <br clear="none"></br>
        <br clear="none"></br>
        At the same time, there's a sub-plot of a Sinn-Fein/IRA-esque group of prawns that are running terrorist operations, and kind of pretend to pay fealty to Wikus while really plotting to have him killed and make him a martyr.
        <br clear="none"></br>
        <br clear="none"></br>
        And of course MNU is still around, etc...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29475" shape="rect">empath</a>
          at
          <a target="_self" href="/84384/Cat-food#2710435" shape="rect">11:15 AM</a>
          on August 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2711950" shape="rect"></a>
      <div class="comments">
        <i>Man, why couldn't they include this information in the actual movie? Without it, it seems either like all of the prawns are apparently male due to either bad film-making (not bothering to include alien female characters) or bad sci-fi species building.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Well, intentionally or otherwise, it's awfully telling about us, is it not, that we translate the prawn non-gendered terms for parent and child as father and son in the movie, no?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73284" shape="rect">rodgerd</a>
          at
          <a target="_self" href="/84384/Cat-food#2711950" shape="rect">2:07 AM</a>
          on August 26, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2711950" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2711967" shape="rect"></a>
      <div class="comments">
        Well, since the character of the &quot;father&quot; was named Christopher, is it really surprising we refer to him as father? And since his &quot;son&quot; was CJ - Christopher Junior, why would we call him anything but son?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/84384/Cat-food#2711967" shape="rect">3:13 AM</a>
          on August 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2712031" shape="rect"></a>
      <div class="comments">
        <i>Well, since the character of the &quot;father&quot; was named Christopher, is it really surprising we refer to him as father? And since his &quot;son&quot; was CJ - Christopher Junior, why would we call him anything but son?</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Not to mention that they're referred to as &quot;father&quot; and &quot;son&quot; in the movie.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2712031" shape="rect">4:46 AM</a>
          on August 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2712039" shape="rect"></a>
      <div class="comments">
        Sorry, shouldn't comment as soon as I wake up. I see what you're saying,
        <b>rogerd</b>
        , but non-gendered pronouns (and names)
        <i>do</i>
        exist in English. I think most of the audience is going to take names and gendered referrants as fact rather than as example of the bone-headedness of humans, particularly if the movie doesn't give us any reason to read it that way.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
          at
          <a target="_self" href="/84384/Cat-food#2712039" shape="rect">4:50 AM</a>
          on August 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2712967" shape="rect"></a>
      <div class="comments">
        <em>Well, since the character of the &quot;father&quot; was named Christopher, is it really surprising we refer to him as father? And since his &quot;son&quot; was CJ - Christopher Junior, why would we call him anything but son?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I somehow think the name Christopher was not self-applied.  Did you not detect at least some of the theme of humans being clueless with regard to the aliens?
        <br clear="none"></br>
        <br clear="none"></br>
        And the little one is not named anywhere in the movie, but is in fact adressed as &quot;little one&quot; the first time he is seen on screen.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78804" shape="rect">ricochet biscuit</a>
          at
          <a target="_self" href="/84384/Cat-food#2712967" shape="rect">12:39 PM</a>
          on August 26, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2712967" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2713446" shape="rect"></a>
      <div class="comments">
        <em>I somehow think the name Christopher was not self-applied. Did you not detect at least some of the theme of humans being clueless with regard to the aliens?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Well, there's nothing to indicate these aliens didn't give themselves human names just as some Asian people give themselves Anglo names when they emigrate to English-speaking countries. Regardless, the reason we are discussing the father and son was because the film indicated that, not because the people in this thread have some kind of instant bias for male characters. That said, the film clearly does.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/84384/Cat-food#2713446" shape="rect">4:32 PM</a>
          on August 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2713717" shape="rect"></a>
      <div class="comments">
        thanks harriet vane.  i did a post on xenophobic violence a while back, maybe i'll try to get another together.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27704" shape="rect">huffa</a>
          at
          <a target="_self" href="/84384/Cat-food#2713717" shape="rect">7:16 PM</a>
          on August 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2714121" shape="rect"></a>
      <div class="comments">
        Cool, I'll go back and check your previous post out (I was going to say &quot;yay!&quot; but then realised how weird that sounds: &quot;xenophobic violence? yay!&quot;).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76925" shape="rect">harriet vane</a>
          at
          <a target="_self" href="/84384/Cat-food#2714121" shape="rect">4:07 AM</a>
          on August 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2714811" shape="rect"></a>
      <div class="comments">
        <em>
          That said, a lot of his behaviour cited (the signature and the threat of child services) are more the &quot;banality of evil&quot;. Threatening to take your kid away because you won't play ball with some dubious document? How often do you reckon that scene is played out all over the world; black, white, yellow, communist, capitalist, whatever. He's not a psychopath like the Colonel, or a monster like his father in law, he's just this guy doing his job without thinking about it hard enough.
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        <br clear="none"></br>
        JUST saw it and this as the most appealing part D9 for me.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/80649" shape="rect">The Whelk</a>
          at
          <a target="_self" href="/84384/Cat-food#2714811" shape="rect">12:05 PM</a>
          on August 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2716562" shape="rect"></a>
      <div class="comments">
        I haven't seen this movie yet, so I didn't read the thread.
        <br clear="none"></br>
        <br clear="none"></br>
        Since when do aliens speak in
        <a href="http://en.wikipedia.org/wiki/Chicago_(typeface)" shape="rect">iPod</a>
        ?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/93525" shape="rect">at the crossroads</a>
          at
          <a target="_self" href="/84384/Cat-food#2716562" shape="rect">11:42 AM</a>
          on August 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2721007" shape="rect"></a>
      <div class="comments">
        I really liked the Nigerians. I thought their presence was really useful and made things more complex. Maybe I'm giving the filmmakers too much credit, but I thought it was great that everyone in the theater was all like &quot;Aww, poor aliens; mistreated so simply because of a personal characteristic&quot; and then were like &quot;Boo! Evil Nigerians!&quot; To me it was a statement that people are always capable of finding at least one group to hate and fear -- heck, more than one, even! -- and a reminder that we shouldn't get all up on our high horse about the mistreatment of one highly visible group when we accept the same attitudes about less visible/popular groups.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78799" shape="rect">staggering termagant</a>
          at
          <a target="_self" href="/84384/Cat-food#2721007" shape="rect">9:29 AM</a>
          on September 1, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2721007" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2721151" shape="rect"></a>
      <div class="comments">
        I thought the cannibalism of the Nigerians was meant to be a reflection of what MNU was doing with their genetic research.  Same thing, functionally.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29475" shape="rect">empath</a>
          at
          <a target="_self" href="/84384/Cat-food#2721151" shape="rect">10:31 AM</a>
          on September 1, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2721255" shape="rect"></a>
      <div class="comments">
        Yeah, that's another useful comparison. Sure, the big evil white corporate guys were overblown and caricatured, as were the small evil black renegade guys. But maybe the movie was trying to illustrate that the two groups, because of their lust for power, were pretty much the same.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78799" shape="rect">staggering termagant</a>
          at
          <a target="_self" href="/84384/Cat-food#2721255" shape="rect">11:04 AM</a>
          on September 1, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2729771" shape="rect"></a>
      <div class="comments">
        nuts - I am way late to this discussion, but I only saw it yesterday, so I waited to read this thread until just now
        <br clear="none"></br>
        <em>
          <br clear="none"></br>
          As the thread has shown, it seems a number of people have become dissatisfied with the movie after thinking too deeply about things.
          <br clear="none"></br>
          <br clear="none"></br>
          Most of the people who are dissatisfied don't seem to be thinking enough
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        I think you could probably predict whether a person enjoys this film or not by asking &quot;do you find fight scenes entertaining?&quot;  There's a lot of interesting ideas started off in the beginning of the film, but then it gets lost in showers of gunfire.  While that is happening, the plot grinds to a halt until the fight is resolved and we see who wins.  Personally I found the last half dull - I was wanting to know more about the aliens, more about the way they had been rescued, how did communications develop between the species... but what I was getting was &quot;hey that guy in the robot suit shot a guy with a pig&quot;  I know that there are lots of people who will have fun watching that, but for me it just raises more unanswered questions, so it's unsatisfying.  How the hell did he fit in to the robot suit without it breaking his legs?  his joints are in the wrong place.  How does he know how to operate it? grrr
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/81377" shape="rect">5_13_23_42_69_666</a>
          at
          <a target="_self" href="/84384/Cat-food#2729771" shape="rect">1:21 PM</a>
          on September 7, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/84383/One-in-8-Million" shape="rect">« Older</a>
        One in 8 Million...  |  Just in case you were wonderin...
        <a target="_self" href="/84385/Alekpehanhou-and-the-funky-moves-he-inspires" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/88046/I-dont-want-to-do-highbudget-films" shape="rect">'I don't want to do high-budget films'</a>
        <span class="smallcopy">January 6, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/84648/District-9-Now-Playing-in-South-Africa" shape="rect">District 9 Now Playing in South Africa</a>
        <span class="smallcopy">August 31, 2009</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/80031/Contracting-SyFyllis" shape="rect">Contracting SyFyllis</a>
        <span class="smallcopy">March 16, 2009</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/30746/Latro-Cerebrus-Suns-New-Long-and-Short-Gene-Wolfe" shape="rect">Latro, Cerebrus, Suns New, Long and Short - Gene...</a>
        <span class="smallcopy">January 15, 2004</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/16234/A-Few-Words-About-Jack-Vance" shape="rect">A Few Words About Jack Vance</a>
        <span class="smallcopy">April 10, 2002</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    film   /C     allegory   /�     Blomkamp   -�     August   ,�     feature   /     food   ,a     Director   -�     were  V9     	examining   /�     South   0�         9http://en.wikipedia.org/wiki/South_Africa_under_apartheid    	Apartheid   0
     �to District 9. Director Neill Blomkamp turns his sci-fi short "Alive in Joburg" into a full-length feature film - examining xenophobia in an allegory of    �, set in a slum recalling District 6 of Cape Town in South Africa. posted by crossoverman (135 comments total) 11 users marked this as    	Apartheid      9202a8c04000641f800000001f44b369     4http://en.wikipedia.org/wiki/District_Six,_Cape_Town    	Cape Town   0�     �"Alive in Joburg" into a full-length feature film - examining xenophobia in an allegory of Apartheid , set in a slum recalling District 6 of    �in South Africa. posted by crossoverman (135 comments total) 11 users marked this as a favorite Previously and previouslier . posted by effbot at 3:31    	Cape Town      9202a8c04000641f800000000051d3ad    >��    Dhttp://www.metafilter.com/84389/Debt-slavery-and-violence-in-history   _�<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Debt, slavery, and violence in history | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history/rss" title="Comments on: Debt, slavery, and violence in history" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/history" shape="rect">history</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/debt" shape="rect">debt</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/credit" shape="rect">credit</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/money" shape="rect">money</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/slavery" shape="rect">slavery</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/violence" shape="rect">violence</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Graeber" shape="rect">Graeber</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Debt%2C%20slavery%2C%20and%20violence%20in%20history%20http%3A%2F%2Fmefi%2Eus%2Fw%2F84389" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Debt, slavery, and violence in history
        <br clear="none"></br>
        <span class="smallcopy">
          August 23, 2009 7:31 AM  
          <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://www.eurozine.com/articles/2009-08-20-graeber-en.html" shape="rect">Debt: The first five thousand years.</a>
        Anarchist anthropologist
        <a href="http://en.wikipedia.org/wiki/David_Graeber" shape="rect">David Graeber</a>
        (
        <a href="http://www.metafilter.com/52233/Class-Dismissed" shape="rect">previously</a>
        ) writes about &quot;debt and debt money in human history&quot; in
        <em>Eurozine</em>
        .  Lots of thought-provoking stuff here; I'll put a sample in the extended description. (Via
        <a href="http://web.ncf.ca/ek867/wood_s_lot.html" shape="rect">wood s lot</a>
        .)
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <blockquote>
          Commodity money, particularly in the form of gold and silver, is distinguished from credit money most of all by one spectacular feature: it can be stolen. Since an ingot of gold or silver is an object without a pedigree, throughout much of history bullion has served the same role as the contemporary drug dealer's suitcase full of dollar bills, as an object without a history that will be accepted in exchange for other valuables just about anywhere, with no questions asked. As a result, one can see the last 5 000 years of human history as the history of a kind of alternation. Credit systems seem to arise, and to become dominant, in periods of relative social peace, across networks of trust, whether created by states or, in most periods, transnational institutions, whilst precious metals replace them in periods characterised by widespread plunder. Predatory lending systems certainly exist at every period, but they seem to have had the most damaging effects in periods when money was most easily convertible into cash.
        </blockquote>
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14752" shape="rect">languagehat</a>
        (44 comments total)
        <span id="favcnt184389">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/84389" shape="rect">90 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2707460" shape="rect"></a>
    <div class="comments">
      This looks great! Thanks languagehat.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/36760" shape="rect">anotherpanacea</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707460" shape="rect">7:37 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707467" shape="rect"></a>
    <div class="comments">
      On a related note,
      <a href="http://www.npr.org/blogs/money/2009/08/who_needs_cash_when_you_have_p.html" shape="rect">NPR money</a>
      reports that
      <em>Gianni Zonin, an Italian bank chairman and wine producer, is proposing that banks accept expensive wines and legs of prosciutto as collateral on loans to producers.</em>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/67185" shape="rect">lahersedor</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707467" shape="rect">7:44 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707467" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707505" shape="rect"></a>
    <div class="comments">
      &quot;Now we see the violence inherent in the system!&quot;
      <br clear="none"></br>
      Cheers lh, good solid reading.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47127" shape="rect">Abiezer</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707505" shape="rect">8:25 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707505" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707507" shape="rect"></a>
    <div class="comments">
      Taking this with me to a long, boring sit-around job this afternoon.  I'll be looking especially for any discussion on something I've been wondering about lately, namely, why do we put up with the payment of interest?  Credit I get, but how did we come to accept the idea that it's SOP to buy something on credit and pay a non-commodity-related premium, namely interest, that doesn't necessarily go to the seller, but to an unrelated third party?  Why not just pay the buyer, over time, without credit? (Late night carpeting companies sell stuff all the time on no-credit deals, for instance.)  I await enlightenment and the pointing out of both my naivete and my questionable (*cough*communist*cough*) tendencies.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50284" shape="rect">nax</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707507" shape="rect">8:27 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707513" shape="rect"></a>
    <div class="comments">
      <em>why do we put up with the payment of interest? Credit I get, but how did we come to accept the idea that it's SOP to buy something on credit and pay a non-commodity-related premium, namely interest, that doesn't necessarily go to the seller, but to an unrelated third party?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Because it's what the market will bear. Sometimes a merchant will want to sell badly enough that they will be willing to add a sweetener to the credit part of the transaction, either reducing interest rates or eliminating them entirely (&quot;0% interest for 12 months!&quot;). But this costs the merchant money, so if they can make the sale without doing so, why wouldn't they?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17563" shape="rect">grouse</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707513" shape="rect">8:32 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707516" shape="rect"></a>
    <div class="comments">
      Oh I'll see your first 5,000 years and raise it to
      <a href="http://www.amazon.com/exec/obidos/ASIN/0813522889/metafilter-20/ref=nosim/" shape="rect">A History of Interest Rates</a>
      by Sidney Homer and Richard Sylla. Coming from Wiley Finance it is not exactly coming from an anarchist perspective and takes on sort of a just-the-facts-ma'am perspective, but I enjoyed it nonetheless.   It took a similar view that currency arose naturally as a result of the complexity of debt repayment, but not making the military origins of the article. In fact I think the inference the article tries to make is jumping to conclusions based on what little evidence we have from the era and our application of modern credit terms to ancient loans, from the aforementioned book:
      <blockquote>
        These scraps of primitive interest rates are in fact all a part of modern history, not of ancient history or of the prehistory of credit. Inferences from them should be made with caution. They do, however, serve to illustrate the actual operation of primitive credit in kind and in very general terms show the type and magnitude of return the creditor often expected. In most cases per annum rates were not conventional and our translation into modern credit terms is forced. The term was the natural term of the transaction: from seed time to harvest, for example. But since such a seed loan can often be made only once a year, it might have been a matter of indifference to both debtor and creditor whether the term was six months or twelve months
      </blockquote>
      It seems that going into near ancient times, from Sumerian and beyond, interest rates were regulated more on how well a central authority could enforce such regulations (which would follow the assertion that in peaceful times loan sharks less common). The stability of credit itself was actually a long, slow evolution as various terms were agreed upon. Penalty for payment? Penalty for non-payment? Rates of return? Rates at temples reflected such uncertainty the Temple of Arbela charged 25% ~732BC and in 608 BC Suka borrowed 3 mina of silver at an incredible 40% interest. This was not interest rate as we would think of them, but rather penalty for non-payment with non-payment expected, otherwise why would you be borrowing, if that makes any sort of sense. One more thing, since the article seems to address Alexandra the Great's conquest of Persia as a sort of pivotal moment, here's what the book says about that:
      <blockquote>
        The end of the classical period of Greek history and the beginning of the Hellenistic period is usually dated from the conquests of Alexander, circa 325 B.C. These wars had revolutionary economic effects, two of which should be mentioned here. Alexander seized and distributed a vast hoard of Persian gold and silver. Much of it was subsequently coined, and it is said that the money stock of the Mediterranean world was multiplied several-fold in a few years. Prices rose and interest rates declined. Also, the opening of the East and of Africa and the unifying of the known world created a much wider trading area. This vastly increased the demand for, and supply of, goods and expanded trade.
      </blockquote>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/10331" shape="rect">geoff.</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707516" shape="rect">8:34 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707516" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707517" shape="rect"></a>
    <div class="comments">
      <em>...I've been wondering about lately, namely, why do we put up with the payment of interest?</em>
      <br clear="none"></br>
      Well...
      <em>simple</em>
      interest I can accept. I can't begrudge a lender making a bit of profit for taking a risk on my behalf.
      <em>Compound</em>
      and
      <em>variable-rate</em>
      interest, though, I have a much, much harder acceptance of. It seems that those two developments, especially when applied in-tandem (as Visa, Mastercard, etc. do), are a good reason why credit has come to be seen as a predatory business.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/20558" shape="rect">Thorzdad</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707517" shape="rect">8:35 AM</a>
        on August 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707517" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707524" shape="rect"></a>
    <div class="comments">
      If you're up for 5 hours of Margaret Atwood, she's done some CBC Massey Lectures on
      <a href="http://www.cbc.ca/ideas/massey/massey2008.html" shape="rect">&quot;Debt and the shadow side of wealth&quot;</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18970" shape="rect">anthill</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707524" shape="rect">8:44 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707524" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707528" shape="rect"></a>
    <div class="comments">
      Excellent article. The nation state is slavery - free men rise up!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17588" shape="rect">Meatbomb</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707528" shape="rect">8:48 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707539" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history#2707513" shape="rect">grouse</a>
      : (nax)&quot;
      <i>
        <em>why do we put up with the payment of interest? Credit I get, but how did we come to accept the idea that it's SOP to buy something on credit and pay a non-commodity-related premium, namely interest, that doesn't necessarily go to the seller, but to an unrelated third party?</em>
        &quot;
        <br clear="none"></br>
        <br clear="none"></br>
        Because it's what the market will bear. Sometimes a merchant will want to sell badly enough that they will be willing to add a sweetener to the credit part of the transaction, either reducing interest rates or eliminating them entirely (&quot;0% interest for 12 months!&quot;). But this costs the merchant money, so if they can make the sale without doing so, why wouldn't they?
      </i>
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;What the market will bear.&quot;  i.e. We're all a bunch of suckers who bear a lot of shit they shove at us unnecessarily...
      <br clear="none"></br>
      <br clear="none"></br>
      That is: &quot;Why are you hitting me?&quot;  Well, you're not fighting back?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19789" shape="rect">symbioid</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707539" shape="rect">9:00 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707539" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707546" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history#2707513" shape="rect">&gt;</a>
      <em>this costs the merchant money</em>
      <br clear="none"></br>
      <br clear="none"></br>
      How does selling something to me without interest cost the merchant money?  If they are paying interest to someone else, wouldn't simply working that cost into my transaction cover that?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50284" shape="rect">nax</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707546" shape="rect">9:08 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707548" shape="rect"></a>
    <div class="comments">
      Since he's looking at ancient origins, probably as good a place to post this as any:
      <blockquote>
        From 7000 to 4000 B.C. there existed an egalitarian society in Anatolia and the Balkan region with gender equality and where wars were unknown. Its high living standard for everyone was only achieved again millenniums later.
        <br clear="none"></br>
        <br clear="none"></br>
        In the settlement of Ã‡atalhÃ¶yÃŒk, up to ten thousand people lived together for more than one thousand years. From the archaeological findings, not only the egalitarian structure of society can be deduced but also insights can be gained into the cultural achievements of a free society.
      </blockquote>
      <a href="http://www.urkommunismus.de/catalhueyuek_en.html" shape="rect">Emergence and development of an egalitarian society - ancient communism in Turkey</a>
      . We've had a post about Ã‡atalhÃ¶yÃŒk before IIRC, but closed to new posts now.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47127" shape="rect">Abiezer</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707548" shape="rect">9:10 AM</a>
        on August 23, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707548" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707549" shape="rect"></a>
    <div class="comments">
      So, per
      <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history#2707516" shape="rect">geoff</a>
      's quote, interest could be seen as a hedge against default?  That would make some sort of sense to me.
      <br clear="none"></br>
      <br clear="none"></br>
      <small> Sorrty, should have read comments first, then I wouldn't be doubling.</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50284" shape="rect">nax</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707549" shape="rect">9:11 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707554" shape="rect"></a>
    <div class="comments">
      If we see interest as a way to &quot;mitigate risk&quot; but also take a less predatory approach(HA!) -- what if we did &quot;innocent until proven guilty&quot;  No interest to start, but once you fuck up, adjust interest a little bit  The more you fuck up, the more interest becomes prohibitive (and reported to a credit rating agency).  This then doesn't punish people right off the bat, but then does establish a scheme to help reduce losses through poor money management.
      <br clear="none"></br>
      <br clear="none"></br>
      This assumes they're not just rapacious assholes, which, I believe, is the actual case.
      <br clear="none"></br>
      <br clear="none"></br>
      I think I read of interest as the idea of wealth generation.  That is -- you want a sheep?  Well, sheep breed, increasing profit to you through time.  What if only productive loans required interest?  Of course, that would seem to reward non-productive borrowing, which is of course antithetical to the very foundations of this producer culture.
      <br clear="none"></br>
      <br clear="none"></br>
      There are so many alternatives to the current system, it's pathetic how easy it is to let them just pop off the top of your head.
      <br clear="none"></br>
      <br clear="none"></br>
      That said, I  guess it's time I start to actually READ the article!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19789" shape="rect">symbioid</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707554" shape="rect">9:16 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707558" shape="rect"></a>
    <div class="comments">
      <em>How does selling something to me without interest cost the merchant money? If they are paying interest to someone else, wouldn't simply working that cost into my transaction cover that?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      They could increase the price for everyone to make up their costs in granting credit, but that would put them at a competitive disadvantage relative to people who would not. Let's say that at Matthew Haughey's Country Flea Market, jessamyn will sell you a widget for $25, and you optionally have six months to pay her back. Cortex won't give you interest-free credit, but he will sell it to you for $20, same as in town. If you have the cash today, who are you going to buy from?
      <br clear="none"></br>
      <br clear="none"></br>
      The merchant incurs actual costs in the administration of your credit transaction at the very least, and will have to pay interest if they have to borrow to allow the credit transaction. And of course there is the risk of default, which if you're loaning to enough people, will definitely be a cost. As for the capital, if they happen to be sitting on an enormous pile of cash, they won't have to pay interest but they will incur an opportunity cost of foregoing the interest they could have easily made by loaning the money to someone else.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17563" shape="rect">grouse</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707558" shape="rect">9:20 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707559" shape="rect"></a>
    <div class="comments">
      <i>...I've been wondering about lately, namely, why do we put up with the payment of interest?</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Because we have central banks (the fed) which have monopoly control over money supply (interest). The solution is to get rid of money entirely. This book
      <a href="http://www.amazon.com/exec/obidos/ASIN/1603580786/metafilter-20/ref=nosim/" shape="rect">
        <i>The End of Money and the Future of Civilization</i>
      </a>
      is well worth reading - it shows the problems with the current system (including the problem of interest as you rightly point out) and an alternative system that is more egalitarian and &quot;open source&quot; so to speak. Sort of what Wikipedia did to knowledge, get rid of the monopoly gatekeepers and open it up to full transparency and egalitarian control. It would eliminate the need for interest.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/1915" shape="rect">stbalbach</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707559" shape="rect">9:22 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707561" shape="rect"></a>
    <div class="comments">
      <em>the state monopoly on violence</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I have seen statements like this many times in anarchist writings, and I wonder, does that imply a preference for a free market of violence with fair violent competition? I guess that does describe what actually happens in places without governments, but it doesn't describe what anarchist say
      <em>should</em>
      happen in the
      <em>right kind</em>
      of absence of government.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/81087" shape="rect">idiopath</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707561" shape="rect">9:24 AM</a>
        on August 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707561" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707580" shape="rect"></a>
    <div class="comments">
      <i>Because we have central banks (the fed) which have monopoly control over money supply (interest).</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Whoa, no. We've had interest rates before we had currency, civilizations or anything resembling a bank. In fact, historically, interest rates have been lower when citizens have access to credit though means other than loan sharks and through strong central institutions. Even the temples of Greece had lower rates than personal loans. Secured debt is cheaper still and with a strong judicial system, secured debt loans become basically free if the security is strong.
      <blockquote>
        Credit was in general use in ancient and in medieval times. Credit long antedated industry, banking, and even coinage; it probably antedated primitive forms of money. Loans at interest may be said to have begun when the Neolithic farmer made a loan of seed to a cousin and expected more back at harvest time. Be this as it may, we know that the recorded legal history of several great civilizations started with elaborate regulation of credit.
        <br clear="none"></br>
        For example, about 1800 B.C., Hammurabi, a king of the first dynasty of ancient Babylonia, gave his people their earliest known formal code of laws. A number of the chief provisions of this code regulated the relation of debtor to creditor. The maximum rate of interest was set at 33 1â�„3% per annum for loans of grain, repayable in kind, and at 20% per annum for loans of silver by weight. All loans had to be accompanied by written contracts witnessed before officials. If a higher than legal interest rate was collected by subterfuge, the principal of the debt was canceled. Land and movables could be pledged for debt, as could the person of the creditor, his wife, concubine, children, or slaves. Personal slavery for debt, however, was limited to three years.
      </blockquote>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/10331" shape="rect">geoff.</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707580" shape="rect">9:37 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707583" shape="rect"></a>
    <div class="comments">
      Eurozine is consistently excellent.  If you're looking for viewpoints on Europe and society outside the halls of Paris, London, and Brussels, there are few better places to look.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/26924" shape="rect">mdonley</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707583" shape="rect">9:39 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707619" shape="rect"></a>
    <div class="comments">
      <em>
        To put the matter somewhat crudely: if one relegates a certain social space simply to the selfish acquisition of material things, it is almost inevitable that soon someone else will come to set aside another domain in which to preach that, from the perspective of ultimate values, material things are unimportant, and selfishness â€“ or even the self â€“ illusory.
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      [sigh]
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21032" shape="rect">Brian B.</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707619" shape="rect">10:05 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707621" shape="rect"></a>
    <div class="comments">
      It's funny how we draw lines in the sand and use hypothetical constructs and then chains ourselves to it as if they were natural laws. Debts and economic recessions/depressions are a prime example of this -- when you think about it, neither should exist in a world of 6 billion people -- we don't need to eat? We don't need clothes, shelter, tools, antidotes, solutions? We talk ourselves into these messes, but we have a harder time collectively talking ourselves *out* of them. There is always a demand for things -- but we allow other people to trip us and stand in our way with rules that have no evidence of being productive or effective.  Commerce is ruled by unproven folksy logic -- and then we wonder why people choke in debt and the world is terrorized into thinking there is a recession -- there is no recession -- we just have people standing in the way of progress because they think they know what's best...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/60524" shape="rect">Alexandra Kitty</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707621" shape="rect">10:08 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707621" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707629" shape="rect"></a>
    <div class="comments">
      haven't even finished it yet, but wanted to interrupt myself to say thanks for this...really solid read and oodles of interesting insights.
      <br clear="none"></br>
      <br clear="none"></br>
      Great post!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/62231" shape="rect">Lutoslawski</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707629" shape="rect">10:13 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707646" shape="rect"></a>
    <div class="comments">
      <em>...why do we put up with the payment of interest?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Credit allows for time-shifting the availability of money. Interest is the price you pay for that time shifting. You're basically renting someone else's money so you can do something with it now that you wouldn't have been able to do if you didn't have that sum of money up front. Maybe that's buying something that you want to have and use now rather than waiting until you've saved up the money. Or maybe, as described above, you're using the money to do something productive - you have a way to use the money to create more money, which will be sufficient to pay the interest. Either way, there's no particular reason for someone to hand you their money now and give up the use of it themselves unless they're getting something in return.
      <br clear="none"></br>
      <br clear="none"></br>
      Sorry, feel like I'm contributing to a bit of a derail here - will read the full article with interest. (oops, pun)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/53196" shape="rect">yarrow</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707646" shape="rect">10:30 AM</a>
        on August 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707646" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707650" shape="rect"></a>
    <div class="comments">
      &quot;
      <a href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history#2707516" shape="rect">Alexandra the Great's conquest of Persia...</a>
      &quot;  now that's the start of an awesome alternative history.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50202" shape="rect">geos</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707650" shape="rect">10:34 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707650" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707651" shape="rect"></a>
    <div class="comments">
      You're paying the lender for the lost opportunity cost. If the money was not lent to you it could be placed into productive use, like buying grain and growing crops, or whatever hypo you want to use. Your hypo that credit does not cost anything to the lender ignores the fact that the funds could be placed in alternate use rather than sitting quietly somewhere.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18761" shape="rect">miss tea</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707651" shape="rect">10:34 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707651" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707676" shape="rect"></a>
    <div class="comments">
      I'm not really following the violence argument in this article - the general thesis being that there are periods in history which are characterized by more violence and more reliance on commodity money and periods that are characterized by less violence and therefore more trust and the institutional support required for greater use of credit. I guess I see the logical tie between the concepts, I'm not sure what kind of evidence I'd need to buy that either facet was &quot;dominant&quot; in any given historical period.
      <br clear="none"></br>
      <br clear="none"></br>
      In any case, either either type of &quot;money&quot; requires trust - for commodity money (which he's using to mean things like gold or silver), you have to trust that others will continue to value the commodity you have stockpiled, since it really is just a collective agreement that gives those things value. For credit obligations you have a more directed personal form of trust between the debtor and the creditor, but these have to exist within a set of institutional supports that allow for such trust. If the argument is that such trust exists only in the relative absence of violence... not sure I'm buying that. Or understanding it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/53196" shape="rect">yarrow</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707676" shape="rect">10:59 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707676" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707689" shape="rect"></a>
    <div class="comments">
      <i>
        thinking about debt outside the twin intellectual straitjackets of state and market opens up exciting possibilities. For instance,
        <a href="http://www.edrants.com/wtv/" shape="rect">we can ask</a>
        :
        <a href="http://www.marginalrevolution.com/marginalrevolution/2009/07/imperial-by-william-vollmann.html" shape="rect">in a society</a>
        in which that
        <a href="http://andrewsullivan.theatlantic.com/the_daily_dish/2009/08/battering-around-the-world.html" shape="rect">foundation of violence</a>
        had finally been yanked away,
        <a title="Why Women's Rights Are the Cause of Our Time" href="http://www.nytimes.com/2009/08/23/magazine/23Women-t.html?pagewanted=all" shape="rect">what exactly would free men and women owe each other?</a>
        What sort of promises and commitments should they make to each other?
      </i>
      <br clear="none"></br>
      <br clear="none"></br>
      money as credit, or social debt, is interesting to me, but i like to think of it more properly conceived as
      <a href="http://www.metafilter.com/77801/The-Real-Price-of-Gold#2392834" shape="rect">social memory</a>
      (or information systems wrt trust and reputation), which, like graeber sez, means it doesn't have to be this way -- that we
      <a href="http://www.metafilter.com/80101/DIE#2493308" shape="rect">cycle continually</a>
      thru specie and credit as forms of money, while historically and politically (behaviourally?) contingent perhaps, may ultimately be a failure of the (collective) imagination -- and, that understood, opens up the possibility for
      <a href="http://www.metafilter.com/83808/Berkshares" shape="rect">alternatives</a>
      (principally, when the economic problem revolves around either scarcity or surplus...), e.g.
      <a href="http://www.metafilter.com/84305/A-New-Approach-to-Aid#2704886" shape="rect">transfers</a>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      also btw, re:
      <a href="http://www.metafilter.com/79390/The-Axis-of-Upheaval#2462464" shape="rect">political dimensions</a>
      (coercion), i think
      <a href="http://www.skidelskyr.com/site/article/fictional-sovereignties/" shape="rect">there too</a>
      a
      <a href="http://www.lse.ac.uk/collections/gellner/gellner12.html" shape="rect">new chapter</a>
      [
      <a href="http://www.cscs.umich.edu/~crshalizi/reviews/nations-and-nationalism/" shape="rect">review</a>
      ] is
      <a href="http://www.metafilter.com/83240/growth-theory" shape="rect">being written</a>
      :P
      <br clear="none"></br>
      <br clear="none"></br>
      cheers!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/3217" shape="rect">kliuless</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707689" shape="rect">11:12 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707689" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707691" shape="rect"></a>
    <div class="comments">
      <em>
        I have seen statements like this many times in anarchist writings, and I wonder, does that imply a preference for a free market of violence with fair violent competition? I guess that does describe what actually happens in places without governments, but it doesn't describe what anarchist say should happen in the right kind of absence of government.
      </em>
      <br clear="none"></br>
      In one sense you could say answering this question has been at the core of of the social anarchist (as opposed to individualist) tradition and was one of the things that distinguished them from the statist communists ended up attempting to usher in utopia by engineering violent revolutionary coups. Certainly there's reams of theory on the topic if you are interested - to name just one example, I particularly like the work of the libertarian communist
      <a href="http://libcom.org/tags/maurice-brinton?page=1" shape="rect">Maurice Brinton</a>
      (pen name of
      <a href="http://ukpmc.ac.uk/articlerender.cgi?artid=1404005" shape="rect">Chris Pallis who was also a noted neurologist</a>
      ); his writing is a clear as his thinking and he addresses the issue, if not directly in the terms you've framed it then certainly to my mind in his discussion of self-management.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47127" shape="rect">Abiezer</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707691" shape="rect">11:14 AM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707691" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707705" shape="rect"></a>
    <div class="comments">
      <em>...why do we put up with the payment of interest?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Interest was banned in Christianity and Islam, and Jews could not charge it to each other. The post-slavery question is, what is allowed to be used for collateral? Homes? Human organs? I think that the concept of inalienable human rights is a very powerful stabilizer for allowing things like interest to take place, in order to fill the economic demand for well-placed loans to innovators and service competitors. However, it is politically dangerous because human rights also reduce the need for corrupt but preachy social institutions such as religion, which exist to ideologically maintain submissive obedience to traditional abusive power (and not just to any one person, which helped to make it a constant in human history). In other words, human rights are dangerous because the logical basis of these stabilizing non-transferable rights is the concept of equality itself, which strike most people, in one way or another, as heretical to their childhood notion of an absolute moral authority.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21032" shape="rect">Brian B.</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707705" shape="rect">11:32 AM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707780" shape="rect"></a>
    <div class="comments">
      <i>I can't begrudge a lender making a bit of profit for taking a risk on my behalf.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      It's not just about risk.  Even if there were
      <b>zero</b>
      risk in lending you money, a lender would still want to be paid for the time value of that money, because to lend you money the lender has to forgo the opportunity to use that money for other things.
      <br clear="none"></br>
      <br clear="none"></br>
      <i>Compound and variable-rate interest, though, I have a much, much harder acceptance of.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Compound interest is just math.  (Or is that a defense here?  A couple recent threads proved that game theorists will be first against the wall when the Metafilter revolution comes...)
      <br clear="none"></br>
      <br clear="none"></br>
      Suppose I assess the opportunity cost of my money and the risk of your borrowing such that I don't want to loan you $1000 for a year without receiving $100 in return.  Then by the same token I probably don't want to loan you $500 for a year without receiving $50 in return, or loan you $1100.00 for a year without receiving $110.00 in return.
      <br clear="none"></br>
      <br clear="none"></br>
      But if $100 is what it's worth to me to loan you $1000 for a year, and if $110.00 is what it's worth for me to loan you $1100 for a year, what should it be worth to me to loan you $1000 for two years?  The answer is just arithmetic: I loan you $1000 for a year, you pay me $1000+$100, then I loan you $1100 for the second year, and you pay me $1100+$110.  Compound interest just skips the part where you scrounge up $1100 to hand to me in the middle of the loan so that I can hand it right back.
      <br clear="none"></br>
      <br clear="none"></br>
      Variable rate interest refers to a few different concepts, is trickier to explain, and the explanation of why it's sometimes sensible would be derailed by the explanation of political and market failures that make it more common than is sensible.  If your difficulty accepting it has steered you away from non-fixed-rate loans, though, congrats; a lot of Americans now wish they had your instincts.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/67388" shape="rect">roystgnr</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707780" shape="rect">12:36 PM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707780" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707832" shape="rect"></a>
    <div class="comments">
      Also in PDF from :
      <a href="http://www.metamute.org/en/html2pdf/view/12121" shape="rect">Mute</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/33937" shape="rect">RoseyD</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707832" shape="rect">1:32 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707872" shape="rect"></a>
    <div class="comments">
      <i>Credit I get, but how did we come to accept the idea that it's SOP to buy something on credit and pay a non-commodity-related premium, namely interest, that doesn't necessarily go to the seller, but to an unrelated third party? Why not just pay the buyer, over time, without credit?</i>
      <br clear="none"></br>
      <br clear="none"></br>
      1.  The merchant needs the money now.  They generally don't have a big pool of cash sitting around, and they have a lot of regular costs that they need to pay.  Payroll is the most important, but they also have things like rent, utilities, and buying an item from their supplier to replace the one you just bought.  When your purchase is financed through a bank, the merchant gets the money right away and can meet their obligations.
      <br clear="none"></br>
      <br clear="none"></br>
      2.  Many small business owners already wear too many hats.  They have to manage people, logistics, marketing, accounting, etc.  By going through a bank for your loan, they are essentially outsourcing the job of evaluating your creditworthiness and making sure you pay to an expert.  They're also kind of insuring the transaction by making the bank take the risk.  If the merchant extends you credit and you default, they take a loss.  If a bank extends you credit and you default, the bank takes the loss and the merchant still gets paid.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17487" shape="rect">TungstenChef</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707872" shape="rect">2:17 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707882" shape="rect"></a>
    <div class="comments">
      I love it when authors are able to take a subject that would normally confuse me (economics) and turn it into something utterly fascinating. Great find!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707882" shape="rect">2:32 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707942" shape="rect"></a>
    <div class="comments">
      <blockquote>
        why do we put up with the payment of interest? Credit I get, but how did we come to accept the idea that it's SOP to buy something on credit and pay a non-commodity-related premium, namely interest, that doesn't necessarily go to the seller, but to an unrelated third party? Why not just pay the buyer, over time, without credit?
      </blockquote>
      Because, if I am a seller, it is my job to sell things, not lend money to people. Now, if I open a business that sells things, I
      <i>could</i>
      start extending credit to my customers to make it easier for them to buy my things, but I'd just as soon have my customers find someone
      <i>else</i>
      to lend them money to buy my things rather than doing it myself, which distracts me from my core business (selling things). Extending credit means that I have to deal with a whole other set  of functions, like evaluating credit-worthiness, documenting open credit accounts, and creating mechanisms of dealing with those who fail to pay and possibly repossessing the goods. If I were really good at all of that, I would have opened a bank, rather than a store to sell things.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16459" shape="rect">deanc</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707942" shape="rect">3:46 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707958" shape="rect"></a>
    <div class="comments">
      Thanks all who answered my question, and for taking it so seriously, apologies to languagehat for getting his thread started off on a total derail, and thanks mods for letting me do it.
      <br clear="none"></br>
      <br clear="none"></br>
      Only got partway through the article (who was I kidding thinking I could slip it in at work) and right off the bat, the fairly mind-blowing idea that debt was invented
      <blockquote>
        &quot;to produce what we like to call the market: an arena where anything can be bought and sold,
        <em>because all objects are disembedded from their former social relations and exist only in relation to money.</em>
      </blockquote>
      As someone who's worked in the arts my whole life, this is a concept I struggle with daily-- the struggle between the soul's need for art and society's desire to commoditize everything.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50284" shape="rect">nax</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707958" shape="rect">4:03 PM</a>
        on August 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2707958" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707979" shape="rect"></a>
    <div class="comments">
      <i>society's desire to commoditize everything</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Debt is not an instrument to &quot;commoditize&quot; anything. Society still plays an instrumental role in
      <b>valuation</b>
      , which has nothing to do with debt. Money and price are simply the lowest common denominator in the quest for value, and valuation. The fact that art is given a dollar value is simply a function of trying to exchange that good for other goods (food and shelter, for instance). The price put on art (low or high) has no relation to the theory of money or debt. That process of valuation is based on the set of societal constructs at any given time, and is subject to change based on society's whims.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14254" shape="rect">SeizeTheDay</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707979" shape="rect">4:40 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2707989" shape="rect"></a>
    <div class="comments">
      <a title="nax wrote in comment #2707958" href="http://www.metafilter.com/84389/Debt-slavery-and-violence-in-history#2707958" shape="rect">&gt;</a>
      <i>apologies to languagehat for getting his thread started off on a total derail</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Are you kidding? There are derails and there are derails, and this was a
      <em>terrific </em>
      derail, especially compared to some we've seen around here lately.  You asked an interesting question on a related topic and got great answers.  Would that every thread had derails like that!
      <br clear="none"></br>
      <br clear="none"></br>
      Glad people are enjoying the piece; I really think Graeber is one of the unheralded thinkers of our day.  I hope he winds up getting the kind of attention someone like Amartya Sen does.
      <small>(Just because I'm languagehat and this is how I geek out: Amartya Sen is pronounced AW-mortto SHAYN, more or less, in Bengali.)</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14752" shape="rect">languagehat</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2707989" shape="rect">5:04 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708015" shape="rect"></a>
    <div class="comments">
      <blockquote>
        <blockquote>&quot;to produce what we like to call the market: an arena where anything can be bought and sold, because all objects are disembedded from their former social relations and exist only in relation to money.</blockquote>
        As someone who's worked in the arts my whole life, this is a concept I struggle with daily-- the struggle between the soul's need for art and society's desire to commoditize everything.
      </blockquote>
      That was actually the weakest part of the essay. It wasn't that the &quot;social relations&quot; of objects are disembedded and exist &quot;only in relation to money.&quot; It's that the laws surrounding the recovery of debts hadn't yet defined a &quot;maximum limit&quot; (what we know as bankruptcy) that would prevent the borrower in default from becoming property of the lender.
      <br clear="none"></br>
      <br clear="none"></br>
      Money and prices are simply ways of managing scarcity. I don't have an infinite amount of time. We don't have an infinite amount of raw materials. There isn't an infinite amount of food. The soul might have a desire for art, but the body has a desire for food and clothes. You can take some cloth and make it into clothes, or you can make it into a nice tapestry to hang on your wall. You might
      <i>really</i>
      want that tapestry on your wall, but so does everyone else, and the tapestry-maker only has a limited amount of time on his hands to make them and likely wants clothes, food, and a car that doesn't constantly break down for himself, so how do we manage the finite number of artistic items that exist and divide them up between people who want them? We allow people to determine how much they
      <i>really</i>
      want one item as opposed to others by putting a price on them. Since people generally have different personal values for different items, the priority someone is going to put on owning (or creating) a certain item is going to be different than someone else's, and market prices put a number on the priority individuals have for certain items.
      <br clear="none"></br>
      <br clear="none"></br>
      The other things about debt is that I think in this era of consumer debt and credit cards we forget that debt was originally
      <i>for</i>
      : a means of getting the capital for businesses that provide money, which you can use to pay off the debt. If someone is selling a restaurant for $1 million that makes $100,000/yr in profit, that's great for you if you have $1 million lying around. If you don't, however, you can
      <i>borrow</i>
      $1 million from the bank at 5% interest, buy the restaurant, and give $60,000/yr of the profits to the bank until it's paid off. The restaurant owner could simply sell the restaurant on the installment plan to a new owner, but the original owner probably just wants all the money right away. The bank might consider getting a 10% return on its investment by buying the restaurant itself, rather than a 5% return from lending out the money, but the bank would rather lend money than get into the restaurant business (that's why they chose to be bankers instead of restauranteurs). It doesn't have to be a restaurant, of course, it could be anything: a farm that produces food which is sold, or a machine that takes milk, sugar, and ice and creates ice cream. If you have $1 million lying around, your choice is going to be either to buy one of those value-creating items or lending the money out to someone
      <i>else</i>
      to buy one of those things.
      <br clear="none"></br>
      <br clear="none"></br>
      What was interesting about the essay was that it makes an argument that, counter to modern concepts about money, gold and silver aren't &quot;real money&quot;-- they were only a medium of exchange under certain circumstances at certain times. The idea of money as a metaphor for exchange is actually the
      <i>earlier</i>
      concept and the &quot;gold standard&quot; the more recent one.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16459" shape="rect">deanc</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708015" shape="rect">5:29 PM</a>
        on August 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708015" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708275" shape="rect"></a>
    <div class="comments">
      It strikes me as worrisome that all the art and anthro majors in this thread are going, &quot;wow, what a fascinating and insightful article,&quot; and all the good-with-numbers people are going &quot;Meh. Yeah I thought that bit was pretty flawed...&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92928" shape="rect">Diablevert</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708275" shape="rect">10:04 PM</a>
        on August 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708275" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708329" shape="rect"></a>
    <div class="comments">
      Yep, when are these mathematicians going to realise that's the least significant aspect of economics? :p
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47127" shape="rect">Abiezer</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708329" shape="rect">11:20 PM</a>
        on August 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708384" shape="rect"></a>
    <div class="comments">
      I'm a dilettante when it comes to macroeconomics, but I think the original post is way too general in its claim that physical coinage is correlated with exploitation.
      <br clear="none"></br>
      <br clear="none"></br>
      I may be a bit jaded because I've read too many
      <a href="http://www.gold-eagle.com/editorials_99/mbutler120299d.html" shape="rect">possibly wackjob attempts at correlating ancient and modern history with a single principle</a>
      .  (It's interesting to see where the dates given in the previous link and the original post overlap, though.)
      <br clear="none"></br>
      <br clear="none"></br>
      Anyway, the original post gives 1971 as the end of a long era where precious metals ruled.  But
      <a href="http://caps.fool.com/Blogs/ViewPost.aspx?bpid=49586&amp;t=01004553487438585767" shape="rect">the U.S. (and most other countries) went off the gold standard in the early 1930s</a>
      .  So in practical terms, most people weren't &quot;gold slaves&quot; in 1971 or for decades before then, and it's not clear to me why 1971 is an important turning point in any way.
      <br clear="none"></br>
      <br clear="none"></br>
      I guess my biggest problem with the article is that it tries to correlate coinage with exploitation, but I'm not seeing that correlation.
      <a href="http://www.brycchancarey.com/slavery/chrono2.htm" shape="rect">Slavery existed in most of Europe (and all over Islamic countries) between 600 and 1500 AD</a>
      , when the claim in the article is that the credit-based societies in place during that time were somehow more advanced socially.
      <br clear="none"></br>
      <br clear="none"></br>
      I think it would be worthwhile to settle on terms that correspond to things we think it's good that humanity has achieved, and then figure out what things, historically, have correlated with those terms.  One such attempt at this is William Bernstein's excellent
      <a href="http://www.efficientfrontier.com/ef/404/CH1.HTM" shape="rect">Birth of Plenty</a>
      , which mostly tries to correlate economic growth with a few specific causes, but also discusses what seems to make us happy in general.  For a lot of people, having more money increases their happiness, but it's certainly not the only thing that affects our well-being, and that's clear from many surveys that have been done in many countries.
      <br clear="none"></br>
      <br clear="none"></br>
      Anyway, maybe the article is describing some well-defined features of a better society that we should be progressing towards, but it isn't doing so in a clear enough way for me to understand.  I'd love to know what I'm missing.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19068" shape="rect">A dead Quaker</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708384" shape="rect">12:49 AM</a>
        on August 24, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2708384" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708706" shape="rect"></a>
    <div class="comments">
      This looks great.q
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/69606" shape="rect">fantabulous timewaster</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708706" shape="rect">9:11 AM</a>
        on August 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2708823" shape="rect"></a>
    <div class="comments">
      <a href="http://www.youtube.com/watch?v=cUou51iI4vw" shape="rect">http://www.youtube.com/watch?v=cUou51iI4vw</a>
      <br clear="none"></br>
      <br clear="none"></br>
      <br clear="none"></br>
      Money As Debt II: Promises Unleashed
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15493" shape="rect">rough ashlar</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2708823" shape="rect">11:00 AM</a>
        on August 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2747453" shape="rect"></a>
    <div class="comments">
      to me, thinking about it some more, central banks (and central banking) in general look to be in self-preservation mode; they're having to rethink the very
      <i>concept</i>
      of money and debt/credit creation and its relationship to growth/output (and how it's measured/priced), i.e. they have no
      <i>idea</i>
      (perhaps an inkling they might know much less than they thought) and that getting back to the way it was might not be such a great idea if the only thing left to inflate is your currency, so that leaves the ugly business of governing (and government), who to placate, and figuring out again the best way to bridge the uneasy relationship between power and production.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/3217" shape="rect">kliuless</a>
        at
        <a target="_self" href="/84389/Debt-slavery-and-violence-in-history#2747453" shape="rect">6:54 AM</a>
        on September 19, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/84388/Mexico-grows-up" shape="rect">« Older</a>
      Just as quietly as when they first voted on this, ...  |  In a press statement released ...
      <a target="_self" href="/84390/SIGG-admits-to-BPA" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/116772/sovereignty-and-taxation" shape="rect">sovereignty and taxation</a>
      <span class="smallcopy">June 8, 2012</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/107029/Everyone-has-pain-Its-your-job-to-find-it" shape="rect">&quot;Everyone has pain. It's your job to find it.&quot;</a>
      <span class="smallcopy">August 31, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/106920/you-owe-me-but-Ill-cut-you-a-break-for-now" shape="rect">you owe me, but Iâ€™ll cut you a break for now</a>
      <span class="smallcopy">August 28, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/89679/Be-it-resolved-that-financial-innovation-does-not-boost-economic-growth" shape="rect">Be it resolved that financial 'innovation' does...</a>
      <span class="smallcopy">March 2, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/81774/You-have-to-be-rich-to-be-poor" shape="rect">You have to be rich to be poor</a>
      <span class="smallcopy">May 19, 2009</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    David   +r     institutions   0     press   �     ll   ,L     much   .     stolen   -�     s   ,�     them   0=     served   .     role   .-         *http://en.wikipedia.org/wiki/David_Graeber    David Graeber   +r     �Graeber Share: Twitter Facebook Debt, slavery, and violence in history August 23, 2009 7:31 AM   Subscribe Debt: The first five thousand years. Anarchist anthropologist    �( previously ) writes about "debt and debt money in human history" in Eurozine . Lots of thought-provoking stuff here; I'll put a sample in    David Graeber      9202a8c04000641f80000000004b4ca4  