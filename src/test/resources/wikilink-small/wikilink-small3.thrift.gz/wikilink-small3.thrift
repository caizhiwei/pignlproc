  >��    .http://www.metafilter.com/81990/IANA-be-a-hero    ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>IANA be a hero | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/81990/IANA-be-a-hero" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/81990/IANA-be-a-hero/rss" title="Comments on: IANA be a hero" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/arin" shape="rect">arin</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/ipv4" shape="rect">ipv4</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/superhero" shape="rect">superhero</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/comics" shape="rect">comics</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/education" shape="rect">education</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20IANA%20be%20a%20hero%20http%3A%2F%2Fmefi%2Eus%2Fw%2F81990" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/81990/IANA-be-a-hero" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        IANA be a hero
        <br clear="none"></br>
        <span class="smallcopy">
          May 27, 2009 7:02 PM  
          <a href="http://www.metafilter.com/81990/IANA-be-a-hero/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/81990/IANA-be-a-hero/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        In this issue: The floating head of
        <a href="http://en.wikipedia.org/wiki/Jon_Postel" shape="rect">Jon Postel</a>
        endows four lucky grad students with superpowers. They form Team ARIN
        <a href="https://www.arin.net/knowledge/comic.html" shape="rect">to promote the Internet way</a>
        . Together, they facilitate transparent development processes, battle misinformation about IPv4 number space depletion, and help us all transition to IPv6!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/45017" shape="rect">ardgedee</a>
          (18 comments total)
          <span id="favcnt181990">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/81990" shape="rect">5 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2580913" shape="rect"></a>
      <div class="comments">
        They must be
        <a href="http://www.iana.org/assignments/ipv4-address-space/" shape="rect">really</a>
        <a href="http://en.wikipedia.org/wiki/IPv4_address_exhaustion" shape="rect">getting</a>
        desperate - 2011 appears to be the end of the line.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/1915" shape="rect">stbalbach</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580913" shape="rect">7:10 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580919" shape="rect"></a>
      <div class="comments">
        <blockquote>
          <i>Team ARIN is not a typical group of superheroes -- they do not battle a literal enemy directly. Instead they use their powers to educate the public and facilitate community participation in the existing open, transparent, bottom-up policy process.</i>
        </blockquote>
        Oh, this is going to be good.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/36800" shape="rect">Kadin2048</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580919" shape="rect">7:13 PM</a>
          on May 27, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2580919" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580920" shape="rect"></a>
      <div class="comments">
        Does every computer genius have a beard?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17655" shape="rect">zorro astor</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580920" shape="rect">7:14 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580924" shape="rect"></a>
      <div class="comments">
        Thank you, I didn't know they made sequels!  Every new tech support rep that I take under my wing
        <strike>has</strike>
        gets to read volume 1 of this comic.  They will be absolutely delighted tomorrow!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/40905" shape="rect">effigy</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580924" shape="rect">7:16 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580937" shape="rect"></a>
      <div class="comments">
        I can't wait until TWC starts charging me for my IPv4 address because &quot;there's only so many of them left.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        Can't you run IPv4 over a IPv6 network? For adoption wouldn't we just need the new addresses to be IPv6? It seems like this will not be such a big deal outside of network providers, where this
        <i>might</i>
        be a large budget increase for a lucky project manager. Am I missing something?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10331" shape="rect">geoff.</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580937" shape="rect">7:28 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580961" shape="rect"></a>
      <div class="comments">
        You can check to see if you have an IPv6 enabled connection by going to
        <a href="http://whatismyipv6address.com/" shape="rect">whatismyipv6address.com</a>
        and clicking 'IPv6 only Test.'  If you have a home router it probably won't work.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27428" shape="rect">jedicus</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580961" shape="rect">7:49 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580964" shape="rect"></a>
      <div class="comments">
        I _think_ there's a fair amount of content out there in IPv6 space already, but there's no guarantee you can resolve it or even get to it through your provider.  It's sort of a chicken and the egg problem - nobody wants to go to the trouble of upgrading their network if there isn't any content for users to reach with it, and nobody wants to provide content without certain access from users.  I _think_ every step of the chain from me to my provider is IPv6 compatible (OS, Router, etc), if I were to get an IPv6 address from them.  Conversely, in a few cases where this has happened, the IPv6 compatible nature has gone on to play hell with poor inadvertent beta-testers when google decides to fiddle with their IPv6 site and people who don't know better are hitting the new site and oy.
        <br clear="none"></br>
        <br clear="none"></br>
        And, frankly, I've been hearing from ARIN that IPv4 is going to be exhausted
        <i>n</i>
        +2 years away since at least 2000.  It'll happen I'm sure, eventually, but 2011?  Color me skeptical.  Have they started making aggressive noises about reclaiming some of the early &quot;permanent&quot; allocations, like the classic /8's?  Or did that happen back when CIDR rolled out (into wide use, anyway) and the allocations weren't quite so permanently routed?  (I'm more systems these days, I haven't really been a core routing nerd in more than 7 years now, so my knowledge could be dated, I'll admit.)
        <br clear="none"></br>
        <br clear="none"></br>
        Anyway, on the comic: I got the first issue in the mail at the office last year.  Color me surprised to discover there's a _series_.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38400" shape="rect">Kyol</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580964" shape="rect">7:55 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580982" shape="rect"></a>
      <div class="comments">
        <em>Have they started making aggressive noises about reclaiming some of the early &quot;permanent&quot; allocations, like the classic /8's?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        They have not.  Some of the original Class A or /8 holders have voluntarily relinquished some of their numbers, but
        <a href="http://en.wikipedia.org/wiki/List_of_assigned_/8_IP_address_blocks" shape="rect">quite a few questionable (i.e., non-ISP) cases remain</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        I can't even really see IBM actually needing all 16.7 million addresses in its network, for instance, and Apple definitely doesn't.  HP now actually has two /8s on account of the Compaq merger, which is ridiculous.  Xerox PARC's /8 is now owned by PARC, which was spun off from Xerox, so it surely doesn't need a /8.
        <br clear="none"></br>
        <br clear="none"></br>
        The DoD has
        <em>10</em>
        /8s, which is absurd, but good luck prying them from the military's hands.  Also, I love amateur radio as much as the next guy, but there are only about 3 million hams worldwide, which makes the AMPRNet /8 kind of excessive.
        <br clear="none"></br>
        <br clear="none"></br>
        So, anyway, yeah, there are tons of numbers left to be reclaimed, but I don't know if the 2011 estimate takes that into account or not.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27428" shape="rect">jedicus</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580982" shape="rect">8:11 PM</a>
          on May 27, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2580982" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2580997" shape="rect"></a>
      <div class="comments">
        Ah, thanks.  At one point I knew the holders of those classic /8's, but since routing is more of a LAN-level concern for me these days, it faded.  And even beyond the _big_ /8's, there are reasonably large chunks of 90's ISP &quot;permanent&quot; allocations going basically disused as various shell companies acquired assets they don't know about slash can't use.  (I can think of 3, and can probably scrounge up the ASNs for 2 off the top of my head.)  Better we try to implement IPv6 than the political suicide of asking the major players and various AS's to clean up their shit a bit, though.  *shrug*  We live in interesting times.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38400" shape="rect">Kyol</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2580997" shape="rect">8:27 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581034" shape="rect"></a>
      <div class="comments">
        And, to be fair, ultimately I don't know what the transitional concerns for going from IPv4 to IPv6 are like these days.  I get the impression it's little bit of ISP's upgrading (in this economic climate?  shyeah right) and a little bit consumers upgrading.  Ultimately I think we're going to see developing nations jump to IPv6 out of necessity, and a bunch of tunneling networks spring up to reach them until hardware is relatively ubiquitous, but even still, I don't know that we'll ever see 100% IPv6 compatible hardware, and I don't see anything in the transition discussion relating to what to do with those islands.  Permanent ::ffff:192.168.0.1-type addressing, and do the IPv6-&gt;IPv4 transition layer at something upstream that's smarter?  guh.  Or will the NAT ghettos just get even more all-encompassing from the current ranges to include all of 0.0.0.0/0?
        <br clear="none"></br>
        <br clear="none"></br>
        And background to why the date has been continually pushed back: NAT has helped tons - you don't have to assign a (reasonably) wasteful CIDR allocation to every tom dick and harry who wants multiple computers on their internet connection.  And virtual webhosting, so every podunk little website on the internet doesn't need a unique address.  I don't know if there are any other major address saving techniques of that sort on the horizon, though.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38400" shape="rect">Kyol</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581034" shape="rect">8:59 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581094" shape="rect"></a>
      <div class="comments">
        I've had v6 connectivity from my home network for a few years now, using one of Hurricane Electric's tunnelbroker tunnels. Works fine, and there does seem to be a slowly, slowly increasing number of sites I connect to via v6 instead of v4. (It's perfectly transparent; I only notice if I check for it.)
        <br clear="none"></br>
        <br clear="none"></br>
        On the other hand, every time I talk to an ISP about getting a &quot;real&quot; v6 connection (as opposed to bouncing all my traffic off a server in California like it was 1992) the response is that they simply don't have enough interest from customers to be willing to do it.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15818" shape="rect">hattifattener</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581094" shape="rect">10:08 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581096" shape="rect"></a>
      <div class="comments">
        The idea of clawing back some of the /8s comes up in every IPv6 discussion, but it's not really worth the trouble.  It would take a lot of political and social capital to pressure the current users to give them up (and it's an open question whether they can be legally compelled to anyway; the allocation agreements used back then aren't the same as are used now), and there are technical hurdles on their networks to doing it that somebody would have to pay for.
        <br clear="none"></br>
        <br clear="none"></br>
        It may be unfair that Ford/IBM/DoD/HP gets an entire /8 (or two), but at this point who's going to pay to move Ford/IBM/DoD/HP off?  They're not going to; that's for sure.  There's nothing in it for them but a major PITA.  A lot of statically-configured equipment would have to be updated, or more likely replaced, routes and rules that assume anything in the /8 is intranet traffic would have to change ... there could be some serious software archeology involved.  I don't see them just doing that as some sort of public service to their own detriment.
        <br clear="none"></br>
        <br clear="none"></br>
        Rather than spending the time and money on clawbacks, which at best would get us a few extra years and then put us right back where we are today, it's a lot better to just start working on the IPv6 transition.
        <br clear="none"></br>
        <br clear="none"></br>
        IPv6 is a permanent solution, at least to the number-scarcity issue; the /8s are at best an expensive stopgap.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/36800" shape="rect">Kadin2048</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581096" shape="rect">10:12 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581113" shape="rect"></a>
      <div class="comments">
        I've setup IPv6 with Hurricane Electric as well, as it's fairly easy.
        <br clear="none"></br>
        <br clear="none"></br>
        I setup AAAA records so people could actually reach hosts on the IPv6 address, but I found that traffic from one host to another over the IPv6 tunnel had a good amount of packet loss and jitter. Good for testing, but nothing I'd actually want normal users hitting.
        <br clear="none"></br>
        <br clear="none"></br>
        Kyol, probably the next big conservation technique will be
        <a href="http://en.wikipedia.org/wiki/Server_Name_Indication" shape="rect">Server Name Indication</a>
        , so SSL hosts can finally be virtually based and not require one IP per domain.
        <br clear="none"></br>
        <br clear="none"></br>
        Firefox 2.0, IE on Vista or modern Mac browsers all support this, so it's really the major servers that are lagging.
        <br clear="none"></br>
        <br clear="none"></br>
        Apache just
        <a href="https://issues.apache.org/bugzilla/show_bug.cgi?id=34607" shape="rect">backported SNI support</a>
        to the current 2.2 release. No idea when Microsoft will add it to IIS, unfortunately.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14551" shape="rect">dragoon</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581113" shape="rect">10:47 PM</a>
          on May 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581144" shape="rect"></a>
      <div class="comments">
        Yeah, and I'm not saying we ought delay the IPv6 transition in the long term anyway really, but it just sort of feels (again, judging by the wiki page, so the usual caveats apply) that there's this degree of &quot;oh well, guess you're screwed&quot; attitude applied to all of the hardware that's currently out there that will need to be replaced.  (before 2011!)  But I could be mistaking how IPv4/IPv6 BGP-like announcements will work.  I just see a huge headache trying to update all the embedded/ancient/non-updatable servers out there with incompatible stacks*, but if their ASN will still advertise via the ::ffff:old.dotted.quad.scheme over IPv6 borders and their gateways will manage the translations, eh, whatevs, let's do this.  C'mon transit providers, go for the gusto.
        <br clear="none"></br>
        <br clear="none"></br>
        dragoon: ah, I had a suspicion it would be something to do with SSL, I had forgotten they couldn't be virtualized yet due to the cert requirements.
        <br clear="none"></br>
        <br clear="none"></br>
        Anyway, it's nice to talk shop again.  I'm sort of locked in the basement Milton-style at my current gig.
        <br clear="none"></br>
        <br clear="none"></br>
        * Which is, I guess the same problem as IBM et al face cleaning up their /8s, but applied to the entire IPv4 world, isn't it?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38400" shape="rect">Kyol</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581144" shape="rect">12:16 AM</a>
          on May 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581276" shape="rect"></a>
      <div class="comments">
        <a href="http://www.metafilter.com/81990/IANA-be-a-hero#2580920" shape="rect">zorro astor</a>
        :
        <i>Does every computer genius have a beard?</i>
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://en.wikipedia.org/wiki/Grace_Hopper" shape="rect">No.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15637" shape="rect">atbash</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581276" shape="rect">6:59 AM</a>
          on May 28, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2581276" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581288" shape="rect"></a>
      <div class="comments">
        I think one of the things that is holding things back is that NAT is so friggen easy and (largely) it just works.  It makes segmenting networks a breeze - and you get a (sorta) firewall out of the deal just for playing.  I'm not saying NAT is awesome - it's a hack, sure.  But if it's stupid and it works, it's not stupid.
        <br clear="none"></br>
        <br clear="none"></br>
        The removes a great deal of the pressure that ISPs would be feeling from the smaller consumers, especially the small/mid businesses who can get along just fine with a few Internet addresses, and a huge NAT space behind them.
        <br clear="none"></br>
        <br clear="none"></br>
        I also tend to think that there are a lot of network admins at that level who don't understand how to do things that NAT provides in an IPv6 world that some sort of NAT similar hack will need to be developed to make those things easy again.  I would even wager that these admins don't want every IP address they manage to be internet routable.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/51218" shape="rect">Pogo_Fuzzybutt</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581288" shape="rect">7:14 AM</a>
          on May 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581742" shape="rect"></a>
      <div class="comments">
        I detest the design decision not to have embedded IPv4 in IPv6.  I know there are good technical reasons, but imagine if the bottom 127 characters of UTF-8 weren't the same as ASCII: *nobody at all* would be using Unicode. Because implementing it would mean breaking everyone, everywhere, all at once.
        <br clear="none"></br>
        <br clear="none"></br>
        I predict that IPv4 will never die, even when it's really a horrible pain, because of IPv6's irresponsible decision not to embed the previous namespace in their own.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/92157" shape="rect">Fraxas</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581742" shape="rect">12:15 PM</a>
          on May 28, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2581742" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2581993" shape="rect"></a>
      <div class="comments">
        Fraxas, there
        <a href="http://tools.ietf.org/html/rfc2373#section-2.5.4" shape="rect">is actually such an embedding</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        The problem is that even though every v4 address has a corresponding v6 address (::ffff:XXXX), not every v6 address has a v4 address (duh), so a v4 host can't communicate with a v6 host without some sort of
        <a href="http://www.ietf.org/proceedings/99mar/I-D/draft-ietf-ngtrans-translator-01.txt" shape="rect">NATlike technology</a>
        in between. This is inherent to the fact that there are more v6 addresses than v4 addresses.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15818" shape="rect">hattifattener</a>
          at
          <a target="_self" href="/81990/IANA-be-a-hero#2581993" shape="rect">2:38 PM</a>
          on May 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/81989/Cant-touch-this" shape="rect">« Older</a>
        Prince Marcus Von Anhalt (painting with nudity, nu...  |  Photos of various insects mati...
        <a target="_self" href="/81991/Insex" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/115330/Wonder-Woman-means-so-much-more-to-me-than-Hera-or-Aphrodite" shape="rect">Wonder Woman means so much more to me than Hera or...</a>
        <span class="smallcopy">April 26, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/112419/NERD-RAGE-GOES-TO-11" shape="rect">NERD RAGE GOES TO 11</a>
        <span class="smallcopy">February 4, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/107704/We-get-a-very-clear-and-detailed-shot-of-her-butt-in-black-latex-before-we-ever-see-what-her-face-looks-like" shape="rect">&quot;We get a very clear and detailed shot of her butt...</a>
        <span class="smallcopy">September 22, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/106462/Ill-be-right-with-you-guys" shape="rect">&quot;I'll be right with you guys!&quot;</a>
        <span class="smallcopy">August 12, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/98036/The-Keene-Act-And-You" shape="rect">The Keene Act And You</a>
        <span class="smallcopy">November 30, 2010</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    IPv6   *P     hero   '�     They   )S     four   )(     Photos   sF     number   *     floating   (�     nu   s(     mati   s`     Anhalt   s
         'http://en.wikipedia.org/wiki/Jon_Postel    
Jon Postel   )     �ipv4 superhero comics education Share: Twitter Facebook IANA be a hero May 27, 2009 7:02 PM   Subscribe In this issue: The floating head of    �endows four lucky grad students with superpowers. They form Team ARIN to promote the Internet way . Together, they facilitate transparent development processes, battle misinformation    
Jon Postel      9202a8c04000641f80000000000200fd    >��    Dhttp://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination    �<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>A Place of Discovery and Imagination.... | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination/rss" title="Comments on: A Place of Discovery and Imagination...." type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a title="adventuresinodyssey" rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/adventuresinodyssey" shape="rect">adventuresinody</a>
              ...
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/focusonthefamily" shape="rect">focusonthefamily</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/dobson" shape="rect">dobson</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/radio" shape="rect">radio</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20A%20Place%20of%20Discovery%20and%20Imagination%2E%2E%2E%2E%20http%3A%2F%2Fmefi%2Eus%2Fw%2F82221" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        A Place of Discovery and Imagination....
        <br clear="none"></br>
        <span class="smallcopy">
          June 5, 2009 11:19 AM  
          <a href="http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://en.wikipedia.org/wiki/Adventures_in_Odyssey" shape="rect">Adventures in Odyssey</a>
        is a twenty-year-old children's radio series out of
        <a href="http://www.focusonthefamily.com/" shape="rect">Focus on the Family</a>
        <em>&quot;The series centers on the fictional town of Odyssey, and in particular, an ice cream emporium named 'Whit's End', and its proprietor, John Avery Whittaker.&quot;</em>
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        At the
        <a href="http://www.whitsend.org/" shape="rect">official website</a>
        , you can listen to
        <a href="http://www.whitsend.org/radio/" shape="rect">select shows</a>
        and
        <a href="http://www.whitsend.org/podcast/" shape="rect">podcasts</a>
        , as well as find other interactive material.  There is also a complete
        <a href="http://www.aiohq.com/aiohq.htm" shape="rect">repository of all-things-Odyssey</a>
        available for your enjoyment, and if you happen to be in Colorado Springs, you can actually
        <a href="http://www.aiohq.com/whitsend.htm" shape="rect">visit</a>
        Whit's End.
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92240" shape="rect">litterateur</a>
        (44 comments total)
        <span id="favcnt182221">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/82221" shape="rect">5 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2594000" shape="rect"></a>
    <div class="comments">
      &quot;This week in Oddssey, Janie and Scotty learn to hate teh gheys.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/52373" shape="rect">Cool Papa Bell</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594000" shape="rect">11:24 AM</a>
        on June 5, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594000" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594007" shape="rect"></a>
    <div class="comments">
      I visited the Focus on the Family compound in Colorado Springs once. At the time I wasn't anti-FotF (because I was about 13) but I still have a distinct sense of being incredibly creeped out by how meticulous and sterile the facilities were, everything maintained within a centimeter of its life. It wasn't until I saw
      <em>The Stepford Wives</em>
      that I was actually able to place the sensation the FotF place gave me.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/37801" shape="rect">shakespeherian</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594007" shape="rect">11:28 AM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594011" shape="rect"></a>
    <div class="comments">
      Man, I loved this stuff when I was a kid. The best bit to me was the
      <a href="http://www.whitsend.org/vault/A000000767.cfm" shape="rect">Darkness Before Dawn</a>
      series; everything else after that felt kind of lackluster, so I dropped it soon after. That may have had more to do with me getting older rather than any actual drop in quality though.
      <br clear="none"></br>
      <br clear="none"></br>
      I also remember that Chick-fil-A used to give away Adventures in Odyssey tapes instead of toys with their kids meals.
      <br clear="none"></br>
      <br clear="none"></br>
      On preview: Yeah, this comment thread is already starting to turn out about like I expected it would. There was definitely a lot of Christian proselytizing in the stories (although, since it's a kids show, there isn't any mention of gay marriage. At least, there wasn't as of the time I quit listening.) But there's also just basic morality stuff in there too, teaching kids to be nice to each other and whatnot.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/42583" shape="rect">JDHarper</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594011" shape="rect">11:33 AM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594011" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594012" shape="rect"></a>
    <div class="comments">
      It's sad, too, because when I was a kid my sisters and I listened to AIO on a regular basis. It was pretty inoffensive, typical sunday-school-type stuff. It's only in the last, oh, fifteen years or so that Dobson became hellbent on converting a fairly influential but relatively harmless ministry into a fucking nightmare of a bully pulpit that won't stop until it's infected every aspect of our national politics with its narrow-minded, misogynist, gay-hating ideas.
      <br clear="none"></br>
      <br clear="none"></br>
      Fuck that guy, fuck FOTF, and fuck every last thing that comes out of that hypocritical institution.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594012" shape="rect">11:34 AM</a>
        on June 5, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594012" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594014" shape="rect"></a>
    <div class="comments">
      I'm from Colorado Springs and remember receiving a cassette tape of this program out trick-or-treating one year when I was maybe nine.  I was totally incensed, like they were disparaging the spirit of
      <i>my</i>
      holiday.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71943" shape="rect">7segment</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594014" shape="rect">11:35 AM</a>
        on June 5, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594014" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594016" shape="rect"></a>
    <div class="comments">
      <em>The goal of the Odyssey staff was to create a &quot;values based&quot; radio show with production values comparable with or surpassing most mainstream audio dramas.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      1. Are there still
      <em>mainstream </em>
      audio dramas?
      <br clear="none"></br>
      <br clear="none"></br>
      2. &quot;We need to reach the kids! Speak to the youth of america! What do kids love? I know! Radio plays! It's the next big thing!&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17897" shape="rect">brundlefly</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594016" shape="rect">11:36 AM</a>
        on June 5, 2009 [
        <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594016" shape="rect">8 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594020" shape="rect"></a>
    <div class="comments">
      Oh, and incidentally: The video series of Adventures in Odyssey bears only a passing resemblance to the radio series. The radio series has some grounding in reality; the video series has Whit flying a combination sailboat/hot air balloon.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/42583" shape="rect">JDHarper</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594020" shape="rect">11:38 AM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594022" shape="rect"></a>
    <div class="comments">
      Sorry, I misspoke -- according to
      <a href="http://www.slate.com/id/2109621/" shape="rect">this excellent Slate article</a>
      that discusses the transformation of Dobson from genial conservative family therapist to the figurehead of the religious right movement in politics, Dobson established the Family Research Council in 1983, which means his political aspirations are more than 25 years old.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594022" shape="rect">11:39 AM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594024" shape="rect"></a>
    <div class="comments">
      Christians proselytize via awkward entertainment. Film coming up after this episode of
      <i>Adventures in Odyssey</i>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/26572" shape="rect">GuyZero</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594024" shape="rect">11:39 AM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594057" shape="rect"></a>
    <div class="comments">
      I like the episode where Penelope is all &quot;Can you help me move this bed over here&quot; and Odysseus is all &quot;LOL NO&quot;.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19016" shape="rect">everichon</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594057" shape="rect">11:58 AM</a>
        on June 5, 2009 [
        <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594057" shape="rect">7 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594061" shape="rect"></a>
    <div class="comments">
      You know who else
      <a href="http://pbskids.org/rogers/" shape="rect">
        taught kids to be nice to each other and whatnot?
        <br clear="none"></br>
      </a>
      <br clear="none"></br>
      <br clear="none"></br>
      And, oddly enough, didn't feel the need to branch out into the hate business on the side.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66724" shape="rect">Halloween Jack</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594061" shape="rect">12:00 PM</a>
        on June 5, 2009 [
        <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594061" shape="rect">5 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594066" shape="rect"></a>
    <div class="comments">
      This thread certainly doesn't need to be pure haterade. I didn't mean it with my
      <em>Stepford</em>
      comment. It's the only Focus on the Family experience I've had, and I never much listened to Adventures in Odyssey but have several friends who did.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/37801" shape="rect">shakespeherian</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594066" shape="rect">12:03 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594083" shape="rect"></a>
    <div class="comments">
      There is absolutely no reason to drag the gay marriage debate into a thread about a children's radio show.
      <br clear="none"></br>
      ...or I guess there is, but I humbly decline to get into that hornet's nest.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/83298" shape="rect">St. Alia of the Bunnies</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594083" shape="rect">12:16 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594084" shape="rect"></a>
    <div class="comments">
      Ps-I never listened nor had my kids listen. Mostly because I can't stand cheeze, which I assumed this was full to the brim of.
      <br clear="none"></br>
      <br clear="none"></br>
      Now, otoh, I can definitely groove with some Veggie Tales.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/83298" shape="rect">St. Alia of the Bunnies</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594084" shape="rect">12:17 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594092" shape="rect"></a>
    <div class="comments">
      I get where you're coming from, shakespeherian, but as someone who grew up steeped in FOTF before Dobson became the Christian equivalent of Emperor Palpatine, it's hard not to hate them.
      <br clear="none"></br>
      <br clear="none"></br>
      Halloween Jack's comment above isn't far off -- imagine if sweet old Fred Rogers had decided that cardigan-wearing and shoe-tossing wasn't enough, that it was his divine mission to make sure that the entire population of the US
      <a href="http://www2.focusonthefamily.com/aboutus/A000000408.cfm" shape="rect">found Jesus,</a>
      <a shape="rect"> </a>
      <a href="http://www.focusonthefamily.com/socialissues/sexual_identity/progay_revisionist_theology/our_position.aspx" shape="rect">gave up teh gay,</a>
      <a href="http://www.focusonthefamily.com/socialissues/sanctity_of_life/abortion/talking_points.aspx" shape="rect">outlawed abortion,</a>
      and made sure that
      <a href="http://www.focusonthefamily.com/socialissues/marriage_and_family/marriage/talking_points.aspx" shape="rect">
        women knew their rightful place in this world
        <sup>1</sup>
      </a>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      You'd be pretty pissed off too, you know?
      <br clear="none"></br>
      <br clear="none"></br>
      <small>
        1 - &quot;Without a social norm of monogamy, women become commodities to be used and discarded.&quot; &quot; A society's most serious problem is the unattached male, and marriage links men to women who help channel male sexuality and aggression in socially productive ways. Marriage and parenthood socialize men to care for and respect their wives, other women and children&quot; Gag me.
      </small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594092" shape="rect">12:23 PM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594092" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594110" shape="rect"></a>
    <div class="comments">
      This program was a mainstay in my family, especially on vacations.  We would listen to hours of it in the car from cassettes we checked out from our church library.
      <br clear="none"></br>
      <br clear="none"></br>
      We too visited the focus on the family compound in Colorado, famous for their Whit's End Chocolate Soda.
      <br clear="none"></br>
      <br clear="none"></br>
      But yes, it's totally creepy.  Thanks for posting!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/62231" shape="rect">Lutoslawski</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594110" shape="rect">12:29 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594113" shape="rect"></a>
    <div class="comments">
      oh, man, I LOVED this stuff!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/91588" shape="rect">callmejordan</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594113" shape="rect">12:33 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594135" shape="rect"></a>
    <div class="comments">
      <a href="http://kids.tate.org.uk/" shape="rect">Here is something else</a>
      that kids can get into... from the
      <a href="http://www.tate.org.uk/" shape="rect">Tate Foundation</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/951" shape="rect">netbros</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594135" shape="rect">12:43 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594141" shape="rect"></a>
    <div class="comments">
      <em>You'd be pretty pissed off too, you know? </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Oh, no, I totally understand, I just think that narrowing our scope to focus (heh) on this one aspect of FotF-- namely, AIO-- would be okay just this once, and no one would have to be confused and think that we didn't hate Dobson's political shenanigans.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/37801" shape="rect">shakespeherian</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594141" shape="rect">12:46 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594171" shape="rect"></a>
    <div class="comments">
      <a href="http://en.wikipedia.org/wiki/Heroin" shape="rect">Here's something else kids can get into!</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16634" shape="rect">lumpenprole</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594171" shape="rect">12:59 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594225" shape="rect"></a>
    <div class="comments">
      Mostly I remember hearing this every now and then passing through radio stations, and then later seeing some of the videos on the shelf at my home-schooled step-cousins' house, and just being confused as all get-out about what the heck was going on because the radio show was mildly entertaining radio-drama pablum while the videos appeared to have a
      <i>freaking zeppelin</i>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      Zeppelins are awesome, is pretty much what I'm trying to say here.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/84450" shape="rect">Scattercat</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594225" shape="rect">1:39 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594234" shape="rect"></a>
    <div class="comments">
      Incidentally, I did not intend to spark a debate about Dobson or his organization, though I suppose I have little control over this.
      <br clear="none"></br>
      <br clear="none"></br>
      I just wanted to share a piece of my childhood.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92240" shape="rect">litterateur</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594234" shape="rect">1:47 PM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594234" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594244" shape="rect"></a>
    <div class="comments">
      Ah, yes, I remember listening to this series as a kid.  Now, I'll have to go and forget its existence yet again.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19346" shape="rect">The Great Big Mulp</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594244" shape="rect">1:53 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594248" shape="rect"></a>
    <div class="comments">
      Evolution Control Committee's &quot;
      <a href="http://evolution-control.com/index.php/discography/past-releases/37-past-releases/65-gunderphonics-cassette-self-released" shape="rect">The Acid Family</a>
      &quot;, pieced together from an Adventures in Odyssey episode.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/56506" shape="rect">anazgnos</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594248" shape="rect">1:55 PM</a>
        on June 5, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594248" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594251" shape="rect"></a>
    <div class="comments">
      <em>Now, otoh, I can definitely groove with some Veggie Tales.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Aaaaaand now I've got the Bunny Song in my head again. Thanks.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/48930" shape="rect">Lentrohamsanin</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594251" shape="rect">1:58 PM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594251" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594293" shape="rect"></a>
    <div class="comments">
      Oh, who would think that an all white evangelical propaganda fest aimed at kids would be controversial?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/46650" shape="rect">GavinR</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594293" shape="rect">2:28 PM</a>
        on June 5, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594293" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594294" shape="rect"></a>
    <div class="comments">
      Yeah, I'm sorry, I didn't mean to sort-of derail with my anti-Dobson screed. My comments came out of my own bitterness and disillusion over something I used to love a lot as a kid having been permanently tarnished by something I so despise as an adult. It was never my intention to crap on anyone's memories here.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594294" shape="rect">2:31 PM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594294" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594305" shape="rect"></a>
    <div class="comments">
      I have a lot of fond childhood memories of the Cub Scouts too, but if I made a post discussing them I don't think it would be out of line to bring up the anti-gay bigotry of the parent organization.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17563" shape="rect">grouse</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594305" shape="rect">2:38 PM</a>
        on June 5, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594305" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594306" shape="rect"></a>
    <div class="comments">
      shiu mai baby - gosh and here I was just going to co-sign your &quot;bitter&quot; comment, cause I'm with you.
      <br clear="none"></br>
      <br clear="none"></br>
      Fuck Dobson, Fuck FOF and FOF the entire conservative christian movement.  It has no place in government, by law - ours - and has just made life utterly miserable for Americans who don't fit their idea of How Things Must Be.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/88195" shape="rect">Tena</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594306" shape="rect">2:38 PM</a>
        on June 5, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594306" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594316" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/82221/A-Place-of-Discovery-and-Imagination#2594092" shape="rect">shiu mai baby</a>
      : It's hard to imagine Mister Rogers telling everyone it was necessary to routinely
      <a href="http://family.custhelp.com/cgi-bin/family.cfg/php/enduser/std_adp.php?p_faqid=770" shape="rect">use corporal punishment on toddlers</a>
      either.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/22916" shape="rect">zachlipton</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594316" shape="rect">2:47 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594375" shape="rect"></a>
    <div class="comments">
      The big crack in AIO's armor during my listening as a kid was when they explored the evils of Dungeons and Dragons.
      <br clear="none"></br>
      <br clear="none"></br>
      I was forbidden to play D&amp;D by my mother under the guise of its dangerous demonism and slaughter of the innocents. In retrospect, I think it was more an attempt to avoid my becoming a total nerd--my mom admitted at a good friend's wedding that she was convinced the two of us would never have girlfriends because we played a substantial amount of Nintendo. Anyway, even if I never played and wasn't dying to play, I loved the concept of the game and would sit in the public library reading issues of Dragon and delighting at mathy breakdowns of horse travel, epic discussions of epic monsters, and hot chix in chain mail.
      <br clear="none"></br>
      <br clear="none"></br>
      So I knew a lot about it... and remember listening to that episode of AIO and thinking... this is an awesome story, what with demon summoning and everything, but it's kind of a bullshit message... is all of this a bullshit message?
      <br clear="none"></br>
      <br clear="none"></br>
      While I've learned to separate the bullshit from the better shit, it's this type of thing that is still a struggle in my Christian faith. Trying to identify in faith with a community of fellow believers who let nonsensical zealotry command their spiritual identity is a tough balancing act. And I've definitely fallen in the wrong on both sides from time to time.
      <br clear="none"></br>
      <br clear="none"></br>
      Anyway.
      <br clear="none"></br>
      <br clear="none"></br>
      FWIW, voice actress Katie Leigh played the prominent character Connie in AIO and was also a principle in the Dungeons and Dragons animated series
      <small>which IMHO if there was a giant concrete donkey cock, would suck it</small>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      She was also Baby Rowlf in Muppet Babies.
      <br clear="none"></br>
      <br clear="none"></br>
      ---
      <br clear="none"></br>
      <br clear="none"></br>
      P.S.
      <br clear="none"></br>
      The ebb and flow of this thread--beginning with hatred and ending with a hug
      <small>except for teh gheys</small>
      --is classic Adventures in Odyssey.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/34987" shape="rect">pokermonk</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594375" shape="rect">3:43 PM</a>
        on June 5, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594375" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594382" shape="rect"></a>
    <div class="comments">
      Wait, who here is not hugging teh gays? I will personally hug any gay who feels unhugged.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594382" shape="rect">3:50 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594383" shape="rect"></a>
    <div class="comments">
      James Dobson.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17563" shape="rect">grouse</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594383" shape="rect">3:53 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594417" shape="rect"></a>
    <div class="comments">
      Pretty sure Dobson isn't here, though, unless he has a sockpuppet account. Which, given the commenting history of some members, wouldn't come as that great a surprise, frankly. Heh.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44217" shape="rect">shiu mai baby</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594417" shape="rect">4:21 PM</a>
        on June 5, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594417" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594498" shape="rect"></a>
    <div class="comments">
      If only you'd gotten yourself laid, pokermonk,
      <i>just once</i>
      , your mom would probably have been so delighted and surprised that she'd have let you do most anything geeky you cared to do.
      <br clear="none"></br>
      <br clear="none"></br>
      But of course, what geek would ever realize it at the time?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/13258" shape="rect">five fresh fish</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594498" shape="rect">6:06 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594523" shape="rect"></a>
    <div class="comments">
      <em>is all of this a bullshit message?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      <small>PROTIP: Yes</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66958" shape="rect">DecemberBoy</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594523" shape="rect">6:37 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594627" shape="rect"></a>
    <div class="comments">
      <i>Are there still mainstream audio dramas?</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Yes. Garrison Keillor's
      <i>A Prairie Home Companion</i>
      , which offers wit, absurdist humor, moral lessons gently taught, a wide range of musical guests, and has been family-friendly from its inception. It is, by definition, more wholesome than anything FotF can put out, because Keillor actually focuses on family and community, and not reactionary talking points that obsess over sex and reproductive issues.
      <br clear="none"></br>
      <br clear="none"></br>
      Lake Woebegone, where all the women are strong, all the men are good looking, and all the children are above average...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50104" shape="rect">Slap*Happy</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594627" shape="rect">8:46 PM</a>
        on June 5, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2594627" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594637" shape="rect"></a>
    <div class="comments">
      Or if you don't like Garrison, try CBC's
      <a href="http://www.cbc.ca/vinylcafe/" shape="rect">Stuart McLean</a>
      , provided he's still employed.  I believe he's a university professor, author-storyteller, and radio/live theatre storyteller.  Looks like he's got podcasts and stuff.  Hope they're free, 'cause my tax dollars are funding them to large part.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/13258" shape="rect">five fresh fish</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594637" shape="rect">9:01 PM</a>
        on June 5, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594826" shape="rect"></a>
    <div class="comments">
      <a href="http://www.cbc.ca/wiretap/" shape="rect">Wiretap </a>
      has a radio sitcom feel in many of its segments (especially anything involving Howard Chackowicz and his hilarious manchild persona).
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/48930" shape="rect">Lentrohamsanin</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594826" shape="rect">4:44 AM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594830" shape="rect"></a>
    <div class="comments">
      Stuart McLean is
      <i>not</i>
      a university professor. He's just an asshole who tells repetitive, folksy stories on the radio. My brother-in-law had to pick him up from the airport once to transport him to a reading he was giving, with my CBC obsessed sister in the passenger seat. McLean quickly discovered that my brother-in-law had no clue who he was, and he immediately began treating brother-in-law like shit, acting like the stuck-up asshole he is. My sister, fully aware of who was in the car with them, just watched it happen in horror.
      <br clear="none"></br>
      <br clear="none"></br>
      No one is an asshole to my sweet, gentle brother-in-law and retains any respect from me.
      <br clear="none"></br>
      <br clear="none"></br>
      The Vinyl Cafe is one big ego-fest for Stuart McLean, who tries to be edgy like Wiretap by calling random people and asking, &quot;Do you know who this is? Do you listen to the CBC? Have you heard of the Vinyl Cafe? No? Oh.&quot; Yawn.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/10462" shape="rect">Hildegarde</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594830" shape="rect">5:09 AM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594848" shape="rect"></a>
    <div class="comments">
      I cant wait for the Veggie Tales FPP
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23533" shape="rect">wheelieman</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594848" shape="rect">6:20 AM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2594938" shape="rect"></a>
    <div class="comments">
      Correction, then: he
      <i>was</i>
      a university professor.  I'm sorry to hear he was an asshole to your sweet, gentle bro-in-law.  Nonetheless, I love to hear his stories about the hapless Dave and his family.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/13258" shape="rect">five fresh fish</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2594938" shape="rect">9:19 AM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2595295" shape="rect"></a>
    <div class="comments">
      So there are no episodes past Spring 2007?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30104" shape="rect">A189Nut</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2595295" shape="rect">4:50 PM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2595388" shape="rect"></a>
    <div class="comments">
      <em>
        Are there still mainstream audio dramas?
        <br clear="none"></br>
        <br clear="none"></br>
        Yes. Garrison Keillor's A Prairie Home Companion
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Hmm, I've always considered Prairie Home Companion to be more of a radio variety show, featuring skits that riff on old radio dramas rather than being a radio drama in itself.
      <br clear="none"></br>
      <br clear="none"></br>
      <em>It is, by definition, more wholesome than anything FotF can put out, because Keillor actually focuses on family and community, and not reactionary talking points that obsess over sex and reproductive issues.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Word.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17897" shape="rect">brundlefly</a>
        at
        <a target="_self" href="/82221/A-Place-of-Discovery-and-Imagination#2595388" shape="rect">6:50 PM</a>
        on June 6, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/82220/Adventures-in-Excrement" shape="rect">« Older</a>
      Friday Flash Fun: Who Pooped? [NSFLunch, autoplays...  |  Is salvaging sunken treasure a...
      <a target="_self" href="/82222/found-keys-to-davy-jones-locker" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/119027/August-2012-shooting-at-Family-Research-Council" shape="rect">August 2012 shooting at Family Research Council</a>
      <span class="smallcopy">August 17, 2012</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/88682/Ad-Vocal-on-My-Ass-WTF" shape="rect">Ad Vocal on My Ass! WTF?</a>
      <span class="smallcopy">January 27, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/80126/Hobsons-choice-Dobsons-choice-whats-the-difference" shape="rect">Hobson's choice, Dobson's choice... what's the...</a>
      <span class="smallcopy">March 19, 2009</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/54859/General-themes-are-hard-to-make-out-but-isolated-lines-prove-problematic" shape="rect">General themes are hard to make out, but isolated...</a>
      <span class="smallcopy">September 18, 2006</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/44170/Gay-Child-Quiz" shape="rect">Gay Child Quiz</a>
      <span class="smallcopy">August 10, 2005</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    	enjoyment   ,�     
proprietor   *�     material   ,     things   ,j     treasure   ��     year   )�     website   +S     Friday   �|     happen   ,�     There   ,         2http://en.wikipedia.org/wiki/Adventures_in_Odyssey    Adventures in Odyssey   )�     �Login New User Tags: adventuresinody ... focusonthefamily dobson radio Share: Twitter Facebook A Place of Discovery and Imagination.... June 5, 2009 11:19 AM   Subscribe    �is a twenty-year-old children's radio series out of Focus on the Family "The series centers on the fictional town of Odyssey, and in particular, an    Adventures in Odyssey      9202a8c04000641f8000000000415ca8    >��    Whttp://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu    ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Beautiful music by Romanian composer Ciprian Porumbescu | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu/rss" title="Comments on: Beautiful music by Romanian composer Ciprian Porumbescu" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/music" shape="rect">music</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Romania" shape="rect">Romania</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Beautiful%20music%20by%20Romanian%20composer%20Ciprian%20Porumbescu%20http%3A%2F%2Fmefi%2Eus%2Fw%2F82446" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Beautiful music by Romanian composer Ciprian Porumbescu
        <br clear="none"></br>
        <span class="smallcopy">
          June 13, 2009 12:12 PM  
          <a href="http://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        The fiddle is usually associated with the hillbilly mania of people like
        <a href="http://www.youtube.com/watch?v=TOUGBf8IK20" shape="rect">Michael Cleveland</a>
        (the nerdiest master ever to wield a bow), or the can't-get-it-out-of-your-head knees up party sound of
        <a href="http://www.youtube.com/watch?v=l9fF0Dn8F_o" shape="rect">celtic music</a>
        .  The violin, on the other hand, is associated with the elegance of
        <a href="http://www.youtube.com/watch?v=u06Nq4xtx_M&amp;feature=PlayList&amp;p=4938399EF5968DB3&amp;playnext=1&amp;playnext_from=PL&amp;index=14" shape="rect">orchestral music</a>
        .  They're actually one and the same instrument, applied to different sounds.  And nobody wrote for this instrument more movingly than the Romanian composer
        <a href="http://en.wikipedia.org/wiki/Ciprian_Porumbescu" shape="rect">Ciprian Porumbescu</a>
        (1853-1883).  Listen to his
        <a href="http://www.youtube.com/watch?v=Qth2-64Z2_Q" shape="rect">Ballad for Violin and Orchestra</a>
        with your eyes closed, and weep for the suffering of the world.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73486" shape="rect">crazylegs</a>
          (23 comments total)
          <span id="favcnt182446">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/82446" shape="rect">27 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2605270" shape="rect"></a>
      <div class="comments">
        Looks for all the world like Bubbles playing the fiddle in the first video.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16907" shape="rect">Space Coyote</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605270" shape="rect">1:30 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605272" shape="rect"></a>
      <div class="comments">
        That instrument can also be used to good effect in jazz/rock fusion, as demonstrated
        <a href="http://www.youtube.com/watch?v=VohubM8Hls4&amp;feature=related" shape="rect">here</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14688" shape="rect">TedW</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605272" shape="rect">1:32 PM</a>
          on June 13, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605272" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605273" shape="rect"></a>
      <div class="comments">
        Never heard of Porumbescu before.  Nice piece.  Closing your eyes is good advice, because if you watch the photos accompanying the music, you will certainly weep for the suffering of the world, and not in a good way, either.
        <br clear="none"></br>
        <br clear="none"></br>
        I'm sure you'll get lots of comments from others with other favorite violin moments, so let me just throw in my two cents: (OK, not a violin concerto, but still)  Beethoven's late string quartets!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/3843" shape="rect">kozad</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605273" shape="rect">1:32 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605277" shape="rect"></a>
      <div class="comments">
        I'm always moved by Bartok's Sixth String Quartet:
        <br clear="none"></br>
        <a title="String Quartet No. 6, Op. 7 (1909)/I. Mesto; Vivace - Guarneri Quartet, BÃ©la BartÃ³k" href="http://www.lala.com/song/504966147171248823" shape="rect">String Quartet No. 6, Op. 7 (1...</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14822" shape="rect">twsf</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605277" shape="rect">1:45 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605278" shape="rect"></a>
      <div class="comments">
        Slightly different instrument, but the
        <a href="" shape="rect">electric violin</a>
        is pretty cool as well.
        <br clear="none"></br>
        <br clear="none"></br>
        This is a nice piece, I haven't heard of it or the composer before.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/59892" shape="rect">Autarky</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605278" shape="rect">1:47 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605279" shape="rect"></a>
      <div class="comments">
        Why does the description of the ballad say &quot;a painful cry to god? Is it actually religious?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42631" shape="rect">thylacine</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605279" shape="rect">1:54 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605283" shape="rect"></a>
      <div class="comments">
        The fiddle is also associated with
        <a href="http://www.youtube.com/watch?v=wo4A9mBJM8I" shape="rect">traditional</a>
        (and
        <a href="http://www.youtube.com/watch?v=mY5c5e9q0m8" shape="rect">not-so-traditional</a>
        ) Cajun music.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/78796" shape="rect">manguero</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605283" shape="rect">2:01 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605289" shape="rect"></a>
      <div class="comments">
        If you watch that video, don't do it at work unless naked boobs are a-okay for your work place.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/83298" shape="rect">St. Alia of the Bunnies</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605289" shape="rect">2:07 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605314" shape="rect"></a>
      <div class="comments">
        I'm thinking that
        <a href="http://en.wikipedia.org/wiki/Gypsy_music" shape="rect">Romani</a>
        music has influenced most of these different styles, including Cajun. According to some digging and reading between the lines, it seems that a lot of the Cajuns and Acadians in Quebec came from a part of France where the folk music was heavily influenced by the Romani. (It also included a couple of instruments resembling the oboe and bagpipe. I guess not all the traditions made it over the water.) I can't tell if Celtic music was also influenced by Romani music (or could it be the other way around?), but Celtic music is a major influence on
        <a href="http://www.scottishbluegrass.com/history.htm" shape="rect">bluegrass</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Nice post, crazylegs! I could be googling this stuff all afternoon. And I had never heard of Porumbescu, so great introduction.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/85543" shape="rect">zinfandel</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605314" shape="rect">2:53 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605320" shape="rect"></a>
      <div class="comments">
        <em>If you watch that video, don't do it at work unless naked boobs are a-okay for your work place.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Yeah, and don't look at pictures of Michelangelo's
        <em>David</em>
        or
        <em>The Creation of Adam</em>
        either, there are
        <small>
          <em>penises</em>
        </small>
        showing!
        <br clear="none"></br>
        <br clear="none"></br>
        For fuck's sake. I would think most employers would be able to distinguish between fine art and pornography, and if they can't, it's not everyone else's responsibility to help you comply with their insane ultrapuritan whims*. Also, if that were the case, you'd probably be happier working for someone who isn't insane anyway.
        <br clear="none"></br>
        <br clear="none"></br>
        <small>* I happen to be of the opinion that it's not everyone else's responsibility to enable people to dick around on the Internet at work anyway, however, &quot;NSFW&quot; tags are a reasonable compromise that hurt no one. Unless you get snippy about it.</small>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66958" shape="rect">DecemberBoy</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605320" shape="rect">2:56 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605321" shape="rect"></a>
      <div class="comments">
        I hadn't actually looked at the pictures before posting, only listened to the music.  Boobs or no boobs, they're pretty cheesy.  Like I said, close your eyes.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73486" shape="rect">crazylegs</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605321" shape="rect">3:01 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605326" shape="rect"></a>
      <div class="comments">
        The difference between the two is that you can't spill beer on a violin.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/41445" shape="rect">MNDZ</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605326" shape="rect">3:11 PM</a>
          on June 13, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605326" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605338" shape="rect"></a>
      <div class="comments">
        Leonid Kogan performing on
        <a href="http://www.youtube.com/watch?v=QNrOKzcDDJ4" shape="rect">Paganini's</a>
        violin.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/56932" shape="rect">francesca too</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605338" shape="rect">3:22 PM</a>
          on June 13, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605338" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605343" shape="rect"></a>
      <div class="comments">
        Hey!  A musician joke I haven't heard!  (By the way, in my very first real pro piano job - in Uppsala, Sweden, 1973 - some drunk came up on spilled beer on the shitty piano I had to work with.  I lived every musician cliche in the next couple of decades.)
        <br clear="none"></br>
        <br clear="none"></br>
        Most musician jokes are interchangeable (banjos, accordians, especially), but there are a few special jokes for oboists...and especially, violists.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/3843" shape="rect">kozad</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605343" shape="rect">3:27 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605400" shape="rect"></a>
      <div class="comments">
        <em>For fuck's sake. I would think most employers would be able to distinguish between fine art and pornography.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        In St Alia's defense, not all the boobies were of the fine-art variety.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18553" shape="rect">Ritchie</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605400" shape="rect">4:59 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605440" shape="rect"></a>
      <div class="comments">
        I went to art school and I know the difference between fine art boobage and OMG BOOBIES boobage. This was definitely the latter variety I was talking of. And I am of the opinion that people have the right to know if a link they click has something they might not choose to view -or at least choose to view at home and not at work.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/83298" shape="rect">St. Alia of the Bunnies</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605440" shape="rect">5:55 PM</a>
          on June 13, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605440" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605505" shape="rect"></a>
      <div class="comments">
        Retroactively:
        <br clear="none"></br>
        <br clear="none"></br>
        Beautiful music by Romanian composer Ciprian Porumbescu.  WARNING: TITS!!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/73486" shape="rect">crazylegs</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605505" shape="rect">6:52 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605506" shape="rect"></a>
      <div class="comments">
        The best ever
        <a href="http://www.youtube.com/watch?v=fPb--BzlEc0" shape="rect">duet for guitar, voice, violin, and alarm clock.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/81087" shape="rect">idiopath</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605506" shape="rect">6:54 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605554" shape="rect"></a>
      <div class="comments">
        &quot;...Cajuns and
        <a href="http://en.wikipedia.org/wiki/Acadians" shape="rect">Acadians </a>
        in Quebec&quot;.  That's just silly.  You know about Wikipedia, right?
        <br clear="none"></br>
        <br clear="none"></br>
        It's well established that Rom travelling people in Ireland had/have an influence on traditional Irish music, and it seems likely that that would be the case on the continent as well.
        <br clear="none"></br>
        <br clear="none"></br>
        <small>PS: there's no such thing as &quot;Celtic&quot; music, unless you're referring to the commercial genre created by record companies to sell Enya disks - which has never heard of Gypsy music.</small>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19352" shape="rect">sneebler</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605554" shape="rect">7:54 PM</a>
          on June 13, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605574" shape="rect"></a>
      <div class="comments">
        I'd never heard of Porumbescu. The Ballad is lovely. I've passed it along to my husband's string quartet, suggesting to them that an arrangement for quartet would work well.
        <br clear="none"></br>
        <br clear="none"></br>
        Along with Cajun and Acadian fiddle music, there's also
        <a href="http://www.youtube.com/watch?v=NGtckNUY7b8" shape="rect">MÃ©tis fiddling</a>
        . See/hear more of MÃ©tis fiddler
        <a href="http://www.youtube.com/watch?v=bDqzHFjeH4Q&amp;feature=related" shape="rect">Sierra Noble</a>
        . She also plays from traditions other than MÃ©tis in the linked clip.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/74932" shape="rect">angiep</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605574" shape="rect">8:41 PM</a>
          on June 13, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605574" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605738" shape="rect"></a>
      <div class="comments">
        Cajun music is great, but no, there is probably no Roma influence on it at all - that clip of Michael Doucet laying a
        <a href="http://en.wikipedia.org/wiki/Dennis_McGee" shape="rect"> Dennis McGee </a>
        tune is great, but Dennis was half Seminole Indian, and his music was an older repetoire that he learned from his Grandfather. The rythyms in Cajun owe more to
        <a href="http://en.wikipedia.org/wiki/Am%C3%A9d%C3%A9_Ardoin" shape="rect">African/Creole </a>
        influences than to any imagined Gypsy influence. French folk music - like most West Europe music traditions - didn't have a strong Musician Gypsy participation until relatively recently (a century or so.)
        <br clear="none"></br>
        <br clear="none"></br>
        Although it is considered PC to use the term Roma to refer to all &quot;Gypsy&quot; people, most east European musicians who are Gypsy don't usually identify themselves by the term &quot;Roma&quot; unless speaking in Romani language. They usually use the local terms for themselves&quot; Å£igan&quot; &quot;cigÃ¡ny&quot; &quot;yifti&quot;. Those groups (
        <em>Ä†aÄ‡e Roma</em>
        ) who do speak Romani rarely work as professional musicians. It gets a bit more mixed up in
        <a href="http://www.youtube.com/watch?v=XGi4xKzbXb4" shape="rect">Romania</a>
        <a href="http://www.youtube.com/watch?v=5-4AMiBMcno&amp;feature=related" shape="rect">Nicolae Guta </a>
        , where everybody is into the
        <a href="http://www.youtube.com/watch?v=eVvzF4l38Jo&amp;feature=related" shape="rect">manele </a>
        sound. Nicolae Guta is my favorite, but he actually has always used a
        <a href="http://www.youtube.com/watch?v=pNtQDEEDvBE" shape="rect">non-Gypsy fiddler </a>
        in his band (Ion Trifoi, who learned from the same old
        <a href="http://www.youtube.com/watch?v=vvSrmIOtCpc&amp;feature=related" shape="rect">Maramures </a>
        fiddler as me.)
        <br clear="none"></br>
        <br clear="none"></br>
        A lot of Romanians are going to hate me for even bringing up manele in a discussion of Porumbescu. I actually prefer the more
        <a href="http://www.youtube.com/watch?v=gP8J0X6XoE4" shape="rect">traditional </a>
        <a href="http://www.youtube.com/watch?v=C_KwDPou4pE" shape="rect">Romanian </a>
        <a href="http://www.youtube.com/watch?v=qKYWUNn07R0" shape="rect">fiddle </a>
        <a href="http://www.youtube.com/watch?v=A5Sd6WqctWk&amp;feature=related" shape="rect">music</a>
        . And some
        <a href="http://www.youtube.com/watch?v=dZwdROgml6U" shape="rect">modern stuff.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15157" shape="rect">zaelic</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605738" shape="rect">3:55 AM</a>
          on June 14, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2605738" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605777" shape="rect"></a>
      <div class="comments">
        I don't think everyone has a
        <strong>responsibility </strong>
        to label stuff as NSFW, but they definitely have the
        <strong>right</strong>
        to label it that way if they want to.  So St Alia volunteered the fact that this might be NSFW for some workplaces.  It wasn't a complaint or a demand, just providing some info that a small segment of MeFi might find valuable.  So, relax, DecemberBoy.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17611" shape="rect">Bugbread</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605777" shape="rect">6:02 AM</a>
          on June 14, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2605865" shape="rect"></a>
      <div class="comments">
        /me shrugs and shuffles on to the next post, but not before noting:
        <br clear="none"></br>
        <br clear="none"></br>
        &quot;
        <a href="http://en.wikipedia.org/wiki/Ciprian_Porumbescu" shape="rect">full of poetry and bitter nostalgia, with light and shade, a mixture of &quot;doina&quot;, old dance and song, everything in the environment of serene melancholy</a>
        &quot; ... nice to find this; the 10:51 on the YT clip was a pleasant soundtrack, but frankly (and I'll probably catch some flack here), I don't think this even begins to compare to the Mendolsohn or Tchaikovsky concertos which, in the hands of the right violinist, will take  your breath away.
        <br clear="none"></br>
        <br clear="none"></br>
        I'm just saying that, while I appreciate discovering Porumbescu, I think some of the praise being heaped out here (and on that awful YT page) is a bit too effusive. I suspect that the &quot;patriotic&quot; aspect of Porumbescu'sbody of work may be one of the reasons for this.
        <br clear="none"></br>
        <br clear="none"></br>
        Good stuff, but again, no Mendolsohn ... and that's not a negative criticism ... just a call for some perspective.
        <br clear="none"></br>
        <br clear="none"></br>
        (A further note: I am always amazed/baffled/intrigued/annoyed by our desires to infliuct images on the sounds that get created ... people often ask me what I am seeing when i perform and I think it disillusions them to know that I am NOT seeing beautiful horizons, running streams, etc., but rather am focusing on the sounds as they are being created. And yet, I am as gullty when listening to others music! Go figure ... )
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20784" shape="rect">aldus_manutius</a>
          at
          <a target="_self" href="/82446/Beautiful-music-by-Romanian-composer-Ciprian-Porumbescu#2605865" shape="rect">9:14 AM</a>
          on June 14, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/82445/Kinda-like-fez-No-not-really-Still-kinda-neat-though" shape="rect">« Older</a>
        Somnia...  |  Curious about the health of yo...
        <a target="_self" href="/82447/BankTracker" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/112185/78-78s" shape="rect">78 78s</a>
        <span class="smallcopy">January 29, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/108033/EM-Cioran" shape="rect">E.M. Cioran</a>
        <span class="smallcopy">October 4, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/98183/a-longlasting-lunch-break" shape="rect">a long-lasting lunch break</a>
        <span class="smallcopy">December 4, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/94285/95" shape="rect">95</a>
        <span class="smallcopy">July 31, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/86172/1989-revolution-in-Eastern-Europe" shape="rect">1989, revolution in Eastern Europe</a>
        <span class="smallcopy">October 27, 2009</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    
orchestral   *�     knees   )e     Ballad   +�     sounds   *�     same   *�     re   *�     t   )K     up   )k     They   *�     Listen   +�         /http://en.wikipedia.org/wiki/Ciprian_Porumbescu    Ciprian Porumbescu   +p     �music . They're actually one and the same instrument, applied to different sounds. And nobody wrote for this instrument more movingly than the Romanian composer    �(1853-1883). Listen to his Ballad for Violin and Orchestra with your eyes closed, and weep for the suffering of the world. posted by crazylegs (23    Ciprian Porumbescu      9202a8c04000641f8000000000187495    >��    Whttp://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac   ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>&quot;We just wanted to tell him, â€˜Shut up and take your Prozac.'&quot; | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac/rss" title="Comments on: 'We just wanted to tell him, â€˜Shut up and take your Prozac.''" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/holdencaulfield" shape="rect">holdencaulfield</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/plagiarism" shape="rect">plagiarism</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/jdsalinger" shape="rect">jdsalinger</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20%27We%20just%20wanted%20to%20tell%20him%2C%20%E2%80%98Shut%20up%20and%20take%20your%20Prozac%2E%27%27%20http%3A%2F%2Fmefi%2Eus%2Fw%2F82639" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        &quot;We just wanted to tell him, â€˜Shut up and take your Prozac.'&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          June 21, 2009 11:52 AM  
          <a href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        In light of J.D. Salingerâ€™s
        <a href="http://www.nytimes.com/2009/06/18/nyregion/18salinger.html?fta=y" shape="rect">successful injunction </a>
        against the publication of the subtly-nom-de-plumed J.D. Californiaâ€™s
        <i>Catcher in the Rye</i>
        followup, the NYTimesâ€™s Jennifer Schuessler asks:
        <a href="http://www.nytimes.com/2009/06/21/weekinreview/21schuessler.html?hpw" shape="rect">How relevant is Holden Caulfieldâ€™s defiant disillusionism to the lives and tastes of modern adolescents</a>
        ?
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        So, Holden may have reached his obsolescence. Was the shady Swedish Mr. California (né Fredrik Colting), then, doing us all a favor by trying to breathe new life into an aging text, à la Jean Rhysâ€™s
        <a href="http://en.wikipedia.org/wiki/Wide_Sargasso_Sea" shape="rect">Wide Sargasso Sea</a>
        and Seth Grahame-Smithâ€™s more recent
        <a href="http://www.npr.org/templates/story/story.php?storyId=102485068" shape="rect">Pride and Prejudice and Zombies</a>
        ? More likely heâ€™s just a
        <a href="http://www.huffingtonpost.com/teddy-wayne/jd-california-is-a-goddam_b_217734.html" shape="rect">crummy phony</a>
        .
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92854" shape="rect">oinopaponton</a>
        (66 comments total)
        <span id="favcnt182639">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/82639" shape="rect">9 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2615504" shape="rect"></a>
    <div class="comments">
      Ok. jump on me and denounce. The book is dated ...give Holden some Ritalin. prep school? Hew is as phony as the rest of us...pur your hat on the right way unless you are still in high school or are a real catcher.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/2290" shape="rect">Postroad</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615504" shape="rect">11:58 AM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615505" shape="rect"></a>
    <div class="comments">
      <i>â€œIn general, they do not have much sympathy for alienated antiheroes; they are more focused on distinguishing themselves in society as it is presently constituted than in trying to change it.â€�</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Tell that to the Jonas Brothers.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50346" shape="rect">l33tpolicywonk</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615505" shape="rect">11:59 AM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615511" shape="rect"></a>
    <div class="comments">
      The book is indeed dated, but I doubt that immersion in current &quot;teen culture&quot; provides any richer insights on life. I may be antiquated, but I'll take Holden Caulfield over Spencer Pratt any day. That doesn't mean I won't try to wrap my head around what Spencer Pratt means, but inevitably, I don't know that I'll succeed all that well.) Saying that Holden Caulfield is dated is like saying that Huckleberry Finn is dated: true, but what replaces them?
      <br clear="none"></br>
      <br clear="none"></br>
      That said, I think J.D. Salinger (or his handlers, more likely) trying to clutch tightly to the embers of his crumbling novels by suing people in court who are trying to bring new life to them is sadly absurd as well.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15019" shape="rect">blucevalo</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615511" shape="rect">12:03 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615511" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615514" shape="rect"></a>
    <div class="comments">
      Holden Caulfield himself would answer this, but Sunday is his day to hang out with Raskolnikov and Bazarov and denounce things.  Besides, he probably wouldn't have much to say to us, because let's face it, we're all a bunch of phonies.
      <br clear="none"></br>
      <br clear="none"></br>
      Some of us are even over 30.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/30541" shape="rect">Afroblanco</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615514" shape="rect">12:06 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615514" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615515" shape="rect"></a>
    <div class="comments">
      The writer seems to have skipped over the fact that Gen X tried the whole disaffection thing. It's not cool to be uninterested anymore. Calling that immersion in competitive conformity is inane. It's not just &quot;fuck the world, and my life&quot; on one hand and &quot;i shall serve our mass-media overlords&quot; on the other.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/59430" shape="rect">Non Prosequitur</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615515" shape="rect">12:07 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615515" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615519" shape="rect"></a>
    <div class="comments">
      How fucking shallow are people today, adults and teenagers alike? You're
      <em>supposed </em>
      to find Holden Caulfield whiny and annoying and half formed. He
      <em>is </em>
      those things. He's confused and unsure of himself and stumbling towards an illumination that never really comes. He's a bright, insightful and hypocritical teenager whose life goes off the rails. He's not supposed to be a role model.
      <br clear="none"></br>
      <br clear="none"></br>
      . for our doomed and millimeter deep 21st century readership.
      <br clear="none"></br>
      <br clear="none"></br>
      <small>p.s. i too am a phony</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/20224" shape="rect">fleetmouse</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615519" shape="rect">12:08 PM</a>
        on June 21, 2009 [
        <a title="22 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615519" shape="rect">22 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615520" shape="rect"></a>
    <div class="comments">
      I'm just sorry that Jerry Lewis never got his chance to make the film version.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/84281" shape="rect">Joe Beese</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615520" shape="rect">12:09 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615520" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615526" shape="rect"></a>
    <div class="comments">
      fleetmouse, doesn't that also indict the people who read the book and took him on as a role model (or accepted his worldview), as many of the nostalgics quoted within the piece did?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/59430" shape="rect">Non Prosequitur</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615526" shape="rect">12:11 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615531" shape="rect"></a>
    <div class="comments">
      Considering Holden is a borderline sociopath who is spinning his story in the best light possible, I hope not very.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/80649" shape="rect">The Whelk</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615531" shape="rect">12:12 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615531" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615535" shape="rect"></a>
    <div class="comments">
      Worth noting:  This is only a 10-day temporary injunction, and my understanding of copyright is that it has about zero percent chance of standing.  It is a long-standing tenet of copyright that you can't copyright an idea, only the
      <i>expression</i>
      of an idea.  Thus you cannot copyright a character, only a story about that character.   If the work takes the teenaged character, ages him 60 years, and tells a totally new story based on an angle Salinger obviously didn't consider or care to follow, then I'd say the new author is in a pretty strong position.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14935" shape="rect">localroger</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615535" shape="rect">12:14 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615536" shape="rect"></a>
    <div class="comments">
      <em>
        Julie Johnson, who taught Mr. Salingerâ€™s novel over three decades at New Trier High School in Winnetka, Ill., cited similar reactions. â€œHoldenâ€™s passivity is especially galling and perplexing to many present-day students,â€� she wrote in an e-mail message. â€œIn general, they do not have much sympathy for alienated antiheroes; they are more focused on distinguishing themselves in society as it is presently constituted than in trying to change it.â€�
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Ack.  Just what I didn't want to read -- an entire generation is growing up not questioning the status quo, but instead seeks to participate in it as fully as possible.  Suddenly my hope for the future is diminished.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615536" shape="rect">12:15 PM</a>
        on June 21, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615536" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615539" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615504" shape="rect">Postroad</a>
      :
      <em>prep school? Hew is as phony as the rest of us.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Wow, congratulations on discovering subtext.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/37801" shape="rect">shakespeherian</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615539" shape="rect">12:19 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615539" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615542" shape="rect"></a>
    <div class="comments">
      <em>
        How fucking shallow are people today, adults and teenagers alike? You're supposed to find Holden Caulfield whiny and annoying and half formed. He is those things. He's confused and unsure of himself and stumbling towards an illumination that never really comes. He's a bright, insightful and hypocritical teenager whose life goes off the rails. He's not supposed to be a role model.
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Yes, but here's the thing:
      <em>The Catcher in the Rye</em>
      is forced onto teenagers, most of whom fit that same description.  All that time and effort could be saved by having North America's high school English teachers simply read aloud to their students a certain two words of the book.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66149" shape="rect">Sys Rq</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615542" shape="rect">12:21 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615542" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615544" shape="rect"></a>
    <div class="comments">
      My father had that very edition of the paperback, which I snuck out and read.  I first read &quot;Catcher in the Rye&quot; ca. 1973, when we were all supposed to be anti-establishment, so his aversion to phonies didn't strike me as unusual.  What struck me about the book, besides its portrait of new York City in the 50s, which I still treasure, is that Holden's future seemed so bleak.  Coming off all the usual kid's books I was reading, I was shocked that there was no implied happy ending- the author was daring me to calculate the odds that Holden would a) grow out of it and thus become a phony b) not grow out of it and be a crazy failure (but not a phony) c) figure out some way to survive and not be a phony.  As a teenager, I really worried about him, and by extension, myself.  Growing up, I discovered that it's not all that hard to not be a phony, but it really struck a chord at the time.
      <br clear="none"></br>
      <br clear="none"></br>
      Today's kids may have it harder, because it's harder to spot the phonies.  Richard Nixon was pretty easy to spot, I have to admit.  Today's world is so post-post-meta-meta that you could get away with posing as a phony to show how phony that is, or make a living writing books about how there is no such thing as phoniness, or have a phony.com website.  Holden's simple black-and-white understanding of phoniness was believable for a 16-yr-old.  I have no idea what would be believable now.  Indifference? Boredom?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/79768" shape="rect">acrasis</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615544" shape="rect">12:22 PM</a>
        on June 21, 2009 [
        <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615544" shape="rect">8 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615548" shape="rect"></a>
    <div class="comments">
      hippybear, I'll think take today's status quo over previous status quos any day.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/40206" shape="rect">infinitewindow</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615548" shape="rect">12:23 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615549" shape="rect"></a>
    <div class="comments">
      My students have mixed reactions to the book, as they do to Catch-22.  Both books had a greater impact fifty years ago than they do now, for obvious reasons.  I don't know anything about prep-school students, but the average student today is still pretty disaffected, as far as I can tell.  I wouldn't worry about that.  Between adolescence and school, which is still not much fun, kids can often relate to Holden.  His locutions, which now appear a little dated, can be a problem.  But the more bookish students still love the book.
      <br clear="none"></br>
      <br clear="none"></br>
      The trope of the not-very-expressive protagonist is still a good one.  Since I teach in an arts school, I isolated five sections in which the narrator talks about the arts (the lounge pianist, for example), and he says some pretty profound things in his dumbed-down language.
      <br clear="none"></br>
      <br clear="none"></br>
      Kids still like Kurt Vonnegut, though.  One kid, a dirt-biker, said
      <em> Cat's Cradle</em>
      was the first book he read that he liked!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/3843" shape="rect">kozad</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615549" shape="rect">12:28 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615549" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615551" shape="rect"></a>
    <div class="comments">
      I had to read it thirty years ago in high school and hated it then.  But that had as much to do with the fact that I was a poor kid growing up in a rich school district than any merits of the book.  At the time I really wasn't in the mood to sympathize with the plight of a whiny self-important rich kid since I was surrounded by those assholes.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18117" shape="rect">octothorpe</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615551" shape="rect">12:29 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615556" shape="rect"></a>
    <div class="comments">
      On preview:  Reading the book again when in my 20's, I was struck by what an obnoxious whiner Holden was and how I totally didn't catch that when I was 13.  But that didn't diminish my appreciation for the book.  It's astounding how few books about kids realistically portray what kids are like.  I just read &quot;The Elegance of the Hedgehog&quot; and was apalled at the unbelievability of that 12-year old.  The whole book was a waste of my time because it wasn't portraying the real problem of how bright but inexperienced and unformed kids figure out how to grow up.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/79768" shape="rect">acrasis</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615556" shape="rect">12:33 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615561" shape="rect"></a>
    <div class="comments">
      <em>
        Julie Johnson, who taught Mr. Salingerâ€™s novel over three decades at New Trier High School in
        <strong>Winnetka, Ill.</strong>
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Fear not, hippybear, I don't think this is indicative of greater social trends as Winnetka is one of the wealthiest suburbs of Chicago.  Of course they're focused on distinguishing themselves in society as it is presently constituted, they're all going to elite schools and getting cushy jobs through their parent's connections.  Society as it is presently constituted is treating them
      <em>great</em>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21894" shape="rect">Ndwright</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615561" shape="rect">12:38 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615561" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615563" shape="rect"></a>
    <div class="comments">
      <em>In general, they do not have much sympathy for alienated antiheroes</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I would say, rather, that the zeitgeist of recent days is that, there are
      <strong>plenty </strong>
      of alienated antiheroes, they're just not pansies like Holden Caulfield.
      <br clear="none"></br>
      <br clear="none"></br>
      Using movies as an example, the most popular movie last year,
      <em>The Dark Knight</em>
      , was entirely an exploration of alienated antiheroics. The most popular movie this year,
      <em>Star Trek</em>
      , features two characters that start out as alienated antiheroes, but ones who grow up on screen. Coming in at No. 4 is
      <em>Wolverine</em>
      , who takes the cake as the most popular antihero of the last 30 years. Down around No. 12, we find Rorschach from
      <em>Watchmen</em>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      When Holden Caulfield is confused, he takes a day off and wanders New York. When our antiheroes are confused, they go out and pimp-slap the real bad guys.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/52373" shape="rect">Cool Papa Bell</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615563" shape="rect">12:42 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615563" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615564" shape="rect"></a>
    <div class="comments">
      Did it ever occur these people that there may be
      <i>more then one type of teenager</i>
      ?  Do they really believe that &quot;today's teenagers&quot; are all the same and share the same interests? Teenagers who are interested in aspirational consumerism, in fitting in and gaining status in the existing culture are the catalyst for those who are disaffected. The ratios may ebb and flow but the idea that one would totally go away is absurd.
      <br clear="none"></br>
      <br clear="none"></br>
      And more then that, the vast majority of people might think of themselves differently then other people might place them.  So a teen might listen to the Jonas brothers and still think of themselves as being somewhat alienated and disaffected.  Plus how many kids like bands like
      <a href="http://en.wikipedia.org/wiki/Good_Charlotte" shape="rect">Good Charlotte</a>
      .  They probably think they're all hard core like Marylin Manson fans when I was in HS.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/10539" shape="rect">delmoi</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615564" shape="rect">12:42 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615564" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615565" shape="rect"></a>
    <div class="comments">
      I'm afraid I'm stuck on the title:
      <em>Coming Through the Rye</em>
      , because it sounds to me like a slash fic mashup of of John Rechy's
      <em>Numbers</em>
      , in which our protagonist becomes a hard bodied hustler. Thrust into the seedy underbelly of Los Angeles in 1974, we follow his anonymous encounters in the stuffy balconies of downtown grindhouses and the twisted green grottos of Griffith Park.
      <br clear="none"></br>
      <br clear="none"></br>
      I'd probably read it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/40978" shape="rect">Tube</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615565" shape="rect">12:44 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615569" shape="rect"></a>
    <div class="comments">
      <em>Do they really believe that &quot;today's teenagers&quot; are all the same and share the same interests?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Yes.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15019" shape="rect">blucevalo</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615569" shape="rect">12:50 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615570" shape="rect"></a>
    <div class="comments">
      <em>The most popular movie this year, Star Trek, features two characters that start out as alienated antiheroes, but ones who grow up on screen</em>
      <br clear="none"></br>
      <br clear="none"></br>
      That's just amazing to me that anyone would consider that movie to have had &quot;characters&quot; in any meaningful sense, much less try to analyze the half-assed, first-draft-typed-between bong-hits hackery that the absolutely talentless bros who also &quot;wrote&quot; &quot;Tranformers&quot; called a script.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/36675" shape="rect">drjimmy11</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615570" shape="rect">12:51 PM</a>
        on June 21, 2009 [
        <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615570" shape="rect">8 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615572" shape="rect"></a>
    <div class="comments">
      delmoi, like all NYT trend stories, it needs just three examples to universalize human experience. The writer got TONS of interview material and whittled it down to a couple things that supported her take. What can ya do.
      <br clear="none"></br>
      <br clear="none"></br>
      Also, I don't get this idea that reflexive anti-status-quo thinking is an unrivaled virtue. That kinda sentiment would run straight into a Burkean meat-grinder of criticism. The Taliban are anti-establishment!!
      <br clear="none"></br>
      <br clear="none"></br>
      The truth of the matter is that half the people dismayed that kids aren't interested in breaking the structures of contemporary society would rather see kids get the A's and the good job and the social charm etc. to change things instead of watch them fall out and become heroin junkies or whatever. That's not gonna change the world now is it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/59430" shape="rect">Non Prosequitur</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615572" shape="rect">12:53 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615572" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615573" shape="rect"></a>
    <div class="comments">
      <em>Thrust into the seedy underbelly of Los Angeles in 1974, we follow his anonymous encounters in the stuffy balconies of downtown grindhouses and the twisted green grottos of Griffith Park.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Except in Rechy's case his hustlers now live in &quot;neat, attractive&quot; apartments in &quot;a court of well-kept units surrounding a pool&quot; on a street lined with pines, ficus, and palm trees in West Hollywood. (I'm not kidding.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15019" shape="rect">blucevalo</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615573" shape="rect">12:54 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615577" shape="rect"></a>
    <div class="comments">
      re: &quot;Catcher in the Rye.&quot; It's a really good book. I liked, and like Holden. He's funny, insightful,  and has his heart in the right place. He's flawed, but if he wasn't basically likable the book would have been forgotten a long time ago.
      <br clear="none"></br>
      <br clear="none"></br>
      I'll never forget being in 9th grade English at the horrific private school my parents inexplicably sent me to after 7 perfectly happy years in public school, and at which I lasted one year. The teacher asked, &quot;Can anyone understand how Holden feels?&quot; No one raised their hand. Finally someone said, &quot;No, I think he's just a stupid baby,&quot; or something like that.
      <br clear="none"></br>
      <br clear="none"></br>
      I wanted to raise my hand SO BAD. Because every other kid in the class was those awful spoiled Pency Prep kids. Exactly. And they couldn't see it. So maybe most teenagers don't identify with Holden, because most teenagers are more like the thieves or the bullies that made Castle jump out the window. Maybe most adults too.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/36675" shape="rect">drjimmy11</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615577" shape="rect">12:57 PM</a>
        on June 21, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615577" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615582" shape="rect"></a>
    <div class="comments">
      I loved the book when I read it as a teenager (for myself -- I never went to a school that assigned any books as remotely controversial as
      <em>Catcher in the Rye</em>
      ). But sure, Holden is whiny, and he probably could have used some Prozac. I don't teach in a high school, but I'd be surprised if it wasn't still possible to teach
      <em>Catcher in the Rye</em>
      . I mean, they are still teaching
      <strong>Dickens</strong>
      , for goodness sake.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47706" shape="rect">Forktine</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615582" shape="rect">1:02 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615585" shape="rect"></a>
    <div class="comments">
      Achilles, whiny warrior.  Yossarian, whiny pilot. Winston Smith, whiny proletariat. Why can't all those bastards just conform? The Wall Street Journal, now there's literature.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/65212" shape="rect">CheeseDigestsAll</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615585" shape="rect">1:04 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615585" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615589" shape="rect"></a>
    <div class="comments">
      Most of these comments are confirming what I found to be the case reading
      <em>Catcher in the Rye</em>
      for the first time at 14. I was attending a wealthy private school where I didn't much like any of my classmates, getting mediocre grades because I just didn't care. Basically, I was at the perfect place and time to read the book-- and I loved it. Most of my classmates hated it. I can't imagine that Ms. Feinburg's 15-year-old example didn't have some classmates who found the book to be a total lifesaver.
      <br clear="none"></br>
      <br clear="none"></br>
      But, as Cool Papa Bell points out, there seems to be a new model for unhappy youth, something very different from Holden's inaction and the glorification of the slacker in the 1990s. I mean, would Obama have been elected if thousands of young people hadn't worked their asses off for the idea of change?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/92854" shape="rect">oinopaponton</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615589" shape="rect">1:07 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615607" shape="rect"></a>
    <div class="comments">
      I'd have to agree with delmoi that Youth is not some uniform hivemind who either all love Catcher in the Rye or don't &quot;get it&quot;. Fifferent books speak to different readers in different ways, surprise!
      <br clear="none"></br>
      <br clear="none"></br>
      The scene in the book when he watches his little sister on the carousel, totally happy and carefree, and he just starts crying? That still gets to me, and I think it's the defining moment of the book - take a good long look at the carefreeness you pissed away and will never get back. You're on your way into Grownupland whether you like it or not. Yes, he has disdain for pretty much everyone, he complains and &quot;whines&quot;. But Holden was clearly an unreliable narrator from Page One. And all his swagger and disaffectedness comes to an end at that carousel. That's what I took away from it, anyway.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615607" shape="rect">1:26 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615607" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615615" shape="rect"></a>
    <div class="comments">
      <em>Considering Holden is a borderline sociopath</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Examples of how he is a sociopath? Because he was written an extremely sensitive teenager, moreso than his peers. I don't recall anything sociopathic at all from the book (though it has been a few years--they put it on this reading list for those of us who were bound for US universities, something like &quot;must read&quot; books about American culture before we left India).
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/83977" shape="rect">anniecat</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615615" shape="rect">1:33 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615618" shape="rect"></a>
    <div class="comments">
      <small>(That's right, &quot;fifferent&quot;. It's a real word, meaning &quot;different as pertains to books&quot;. Look it up if you don't believe me.)</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615618" shape="rect">1:36 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615618" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615622" shape="rect"></a>
    <div class="comments">
      Yeah, echoing what
      <a href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615519" shape="rect">leetmouse </a>
      said.  The book has been woefully misread (and mistaught) for ages.  If your recollection of
      <i>Catcher</i>
      comes from reading it as a fifteen-year-old, you owe it to yourself to take a day to reread it.  To think that the primary question of
      <i>Catcher</i>
      is whether Holden's anti-status-quo/everyone's-a-phony take on life is legitimate or not is to just totally miss out on Salinger's incredible 3D character-rendering.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/59489" shape="rect">NolanRyanHatesMatches</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615622" shape="rect">1:39 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615651" shape="rect"></a>
    <div class="comments">
      While I love
      <u>Catcher in the Rye</u>
      with all my heart, it's still my least favorite Salinger. Rereading
      <u>Raise High The Roofbeams, Carpenters</u>
      or
      <u>Franny and Zooey</u>
      , I can't help but wonder, why the slathering over Holden Caufield, when the Glass family is more on so many levels.
      <br clear="none"></br>
      <br clear="none"></br>
      But yes, after 3 hours of having to explain to my slacker, stoner friend who thought the book was stupid why it's OK if Holden is a phoney himself, I'm sure there are still lots of clueless kids lacking empathy or self-examination who think the book's a waste.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21609" shape="rect">Gucky</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615651" shape="rect">2:09 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615675" shape="rect"></a>
    <div class="comments">
      <em>Disillusionism</em>
      ?  What happened to
      <a href="http://www.google.ca/search?hl=en&amp;q=define%3A+disillusion&amp;btnG=Google+Search&amp;meta=" shape="rect">disillusion</a>
      ?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18901" shape="rect">weapons-grade pandemonium</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615675" shape="rect">2:36 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615688" shape="rect"></a>
    <div class="comments">
      I loved it at twelve, and by fifteen I was rolling my eyes at it.  I was also an insufferable pity princess of an alienated teenager, and I was lucky to go to a school where I could hang out with many of the same.  I can't recall anyone who didn't think Holden was pathetic.  We had the added perspective of knowing that
      <em>Catcher </em>
      was a favorite book of Mark David Chapman and other famous psychotic murderers.
      <br clear="none"></br>
      <br clear="none"></br>
      It's not that These Kids Today are too spoiled and conformist for Holden's noble truths.  It's that they have more cultural and technological power than he ever did, and it causes him to read as passive and grating.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/63748" shape="rect">Countess Elena</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615688" shape="rect">2:54 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615699" shape="rect"></a>
    <div class="comments">
      I'm with
      <a href="http://www.newyorker.com/archive/2001/10/01/011001fa_FACT3?currentPage=all" shape="rect">Louis Menand</a>
      on this one:
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;That it might end up on the syllabus for ninth-grade English was probably close to the last thing Salinger had in mind when he wrote the book. He wasnâ€™t trying to expose the spiritual poverty of a conformist culture; he was writing a story about a boy whose little brother has died. Holden, after all, isnâ€™t unhappy because he sees that people are phonies; he sees that people are phonies because he is unhappy.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      It's amazing how many people who first read the book as teenagers fail to remember the fact of his brother's death, or fail to recognize it as a crucial piece of information. How did Holden Caulfield, a protagonist gripped by legitimate grief, come to be seen as a poster-child for mere adolescent broodiness? A mystery.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/37455" shape="rect">Powerful Religious Baby</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615699" shape="rect">3:03 PM</a>
        on June 21, 2009 [
        <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615699" shape="rect">7 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615705" shape="rect"></a>
    <div class="comments">
      <blockquote>
        <i>
          Julie Johnson, who taught Mr. Salingerâ€™s novel over three decades at New Trier High School in Winnetka, Ill., cited similar reactions. ...  â€œIn general, they do not have much sympathy for alienated antiheroes; they are more focused on distinguishing themselves in society as it is presently constituted than in trying to change it.â€�
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        Ack. Just what I didn't want to read -- an entire generation is growing up not questioning the status quo, but instead seeks to participate in it as fully as possible. Suddenly my hope for the future is diminished.
      </blockquote>
      Blah. Boomer teachers have been saying this about teenagers since they left their teen years and instead started teaching to them. Echoing
      <a href="http://www.metafilter.com/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615519" shape="rect">leetmouse</a>
      again, boomer teachers have turned Holden from a study of a grief-stricken, broken character that's interesting to examine and understand into the &quot;voice of a generation.&quot;
      <blockquote>why the slathering over Holden Caufield, when the Glass family is more on so many levels.</blockquote>
      Quoted for truth.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16459" shape="rect">deanc</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615705" shape="rect">3:10 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615705" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615710" shape="rect"></a>
    <div class="comments">
      Compared to almost everything else I had to read in high school english, Catcher in the Rye stands out as a book I still care to own a copy of.
      <br clear="none"></br>
      <br clear="none"></br>
      And honestly, when has contemporary relevance stopped people from teaching works of literature before?  Salinger is part of the western literary canon, and is pretty much assured of being read in schools (save ones particularly snooty about swear words and sexual situations, even if they just talk) until euro-american society society and culture fade and are replaced by something even more bizarre and inexplicable.  That's the power of getting to decide what is &quot;literature&quot;--you can putter about talking about relevance all you want, but doesn't calling something literature remove it from this being a real issue?
      <br clear="none"></br>
      <br clear="none"></br>
      As people have said before, we're still teaching Huckleberry Finn and numerous, odious, boring, dreadful, unreadable Charles Dickens works (sorry I hate Dickens a lot) and nobody cares that they're relevant to teenagers.  Maybe all the fuss is that this book, in particular, was one thing that was both literature *and* happened to be relevant to teenagers, and now it might just be one of those things.  Maybe.  FWIW I love it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18419" shape="rect">Tesseractive</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615710" shape="rect">3:14 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615710" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615712" shape="rect"></a>
    <div class="comments">
      <i>While I love Catcher in the Rye with all my heart, it's still my least favorite Salinger. Rereading Raise High The Roofbeams, Carpenters or Franny and Zooey, I can't help but wonder, why the slathering over Holden Caufield, when the Glass family is more on so many levels.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      I agree with almost all of this, except that my least favorite Salinger is
      <i>Seymour: An Introduction</i>
      , and would encourage anyone who loves the Glass family not to read it, even if it means ripping the apart from
      <i>Raise High the Roofbeam, Carpenters</i>
      and chucking it out a window.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/44886" shape="rect">naoko</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615712" shape="rect">3:14 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615724" shape="rect"></a>
    <div class="comments">
      I have to reread the book, because I was pretty much the only person in my high school class (late 1980's) who absolutely hated it.  Lots of my friends, whose tastes I generally respected, loved it, but Holden seemed like an illogical self-centered wanker.  Which, I guess, is fine for a main character in the service of an interesting plot, but since he didn't really
      <i>do</i>
      so much, and it was more an exploration of his feelings, the book seemed really pointless, because there are illogical self-centered wankers
      <i>all over the goddamn place</i>
      .  It was like asking every broody kid in the school to just talk randomly for a few hours about how deep they were.
      <br clear="none"></br>
      <br clear="none"></br>
      It was like reading a goth/emo livejournal.
      <br clear="none"></br>
      <br clear="none"></br>
      I'm sure it
      <i>wasn't</i>
      that, and there was
      <i>something</i>
      pretty good in the book, because it wouldn't have so many fans.  So I'm curious what it was (but have trepidation about rereading it, because right now I can say &quot;I'm sure it was good, I just read it a long time ago, and I didn't like it back then&quot;, but if I reread and dislike it now, I'm stuck with &quot;hated it then, still do&quot;)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17611" shape="rect">Bugbread</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615724" shape="rect">3:43 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615726" shape="rect"></a>
    <div class="comments">
      <em>
        I don't think this is indicative of greater social trends as Winnetka is one of the wealthiest suburbs of Chicago. Of course they're focused on distinguishing themselves in society as it is presently constituted, they're all going to elite schools and getting cushy jobs through their parent's connections. Society as it is presently constituted is treating them great.
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      Yes.
      <br clear="none"></br>
      <br clear="none"></br>
      Funny they picked someone from hilltop, crenelated New Trier to opine on Caulfield's dwindling relevance.  More likely, the annoyance of that school's privileged darlings speaks to
      <em>Catcher</em>
      's continuing importance.  In fact, it's probably no coincidence that New Trier inspired Liz Phair's
      <a href="http://en.wikipedia.org/wiki/Exile_in_Guyville" shape="rect">Exile in Guyville</a>
      --surely one of the most Caulfield-esque documents of the late twentieth century.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23894" shape="rect">washburn</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615726" shape="rect">3:45 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615727" shape="rect"></a>
    <div class="comments">
      <em>It was like reading a goth/emo livejournal.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Oh, now THERE is a recasting / retelling I'd love to see.  Similar to the twitter streams of characters from The Stand which emerged when bacon lung was announced in Mexico.  Could be brilliant if done correctly.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615727" shape="rect">3:49 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615736" shape="rect"></a>
    <div class="comments">
      Also, I should point out that not liking Catcher in the Rye is not synonymous with being conformist or supportive of modern society.  I was a nonconformist, anti-authority kid.  The problem I always had with him was just his massive internal confliction.  I understand about being conflicted about a thing or two, but (my memory) was that he was conflicted about
      <i>everything</i>
      .  If you're an introspective, insightful person, you eventually come to conclusions.  Those conclusions may change over time, but to be perpetually conclusionless about your own personality is to have a lack of insight.
      <br clear="none"></br>
      <br clear="none"></br>
      Again, I may be wrong, and he may be a great character that just rubbed me wrong.  My main point is just that finding his conflict to be annoying is in no way simultaneous with worshiping the status quo.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17611" shape="rect">Bugbread</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615736" shape="rect">4:01 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615752" shape="rect"></a>
    <div class="comments">
      <em>Ok. jump on me and denounce. The book is dated ...give Holden some Ritalin.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I don't understand how a work of fiction can be dated. I really don't. I guess if I thought of fiction as a form of non-fiction, then I'd understand. Non-fiction
      <em>can</em>
      be dated, because it can be an attempt to explain an idea that has been discredited since the book has come out. I'd call a non-fiction book dated if it was a tome about Phrenology. Non-fiction can also be dated if it's about obscure historical issues that most people no-longer care about -- issues that are no longer relevant.
      <br clear="none"></br>
      <br clear="none"></br>
      So I guess if you think about &quot;Richard III&quot; as a play about &quot;The War of the Roses,&quot; you might say, &quot;It's dated, because that war ended years ago.&quot; Or you could say, &quot;Oedipus is dated, because people are more sexually liberated now, and while sleeping with your mom is gross, it's over-the-top to blind yourself because you did it.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      You COULD say those things, but I wouldn't, because I see Richard as a sociopath who is willing to do anything to seize power. I've met people like that, alas, and so the play is completely relevant to my life. Also, I sometimes fantasize about engaging in immoral power plays myself, so &quot;Richard III&quot; is also relevant to me as a wicked (harmless) fantasy.
      <br clear="none"></br>
      <br clear="none"></br>
      Oedipus is a man caught in a trap. The gods have completely undone him. He's like a pinball in some sick game they are playing. I'm an atheist -- and if I wasn't, I probably wouldn't be a polytheist -- but I often FEEL like my life is not under my control, as if I'm fated for something terrible. On days like that, I am grateful to Sophocles for giving me such a clear example to commiserate with.
      <br clear="none"></br>
      <br clear="none"></br>
      Who hasn't had a job (or been in a family situation) in which all the people in the room seem like shallow hypocrites? No, of course they're not REALLY all empty suits. They have rich inner lives. But sometimes it FEELS like they are all phonies. &quot;Catcher in the Rye&quot; explores that feeling. It will be dated when people no longer feel that way.
      <br clear="none"></br>
      <br clear="none"></br>
      Fiction is best when it makes you wonder what is going to happen next; when it makes you worry about what is going to happen to the hero; when it makes you angry at the hero; when it makes you have that shock of recognition -- the shock of a familiar feeling. That sort of stuff can't be dated, because even back in the caves, people got jealous, angry, joyful and afraid. Even back in the caves, there were phonies -- or at least it FELT like there were. And that's good enough, because in the case of fiction, material truth matters less than emotional truth.
      <br clear="none"></br>
      <br clear="none"></br>
      If you happen to find &quot;Catcher&quot; boring, ill-constructed, or unappealing, that's fair enough. But it's not dated.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615752" shape="rect">4:21 PM</a>
        on June 21, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615752" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615753" shape="rect"></a>
    <div class="comments">
      Following bugbread, I should note similarly that of course I don't mean to suggest that disliking
      <em>Catcher</em>
      makes one a prep-school bully, or even a little bit mean.   And I should also note with some shame that, contrary to my comment above,
      <a href="http://farm3.static.flickr.com/2138/2514972043_8c393ea49d.jpg" shape="rect">crennelation</a>
      , it
      <a href="http://www.glazeware.com/images/wooden-04-NewTrier.gif" shape="rect">seems</a>
      , cannot be counted among New Trier's sins.
      <br clear="none"></br>
      <br clear="none"></br>
      <small>(New Trier *is* however blamable for Don Rumsfeld *and* John Stossel, despite its nice, harmless-looking roof-lines ...).</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23894" shape="rect">washburn</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615753" shape="rect">4:22 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615774" shape="rect"></a>
    <div class="comments">
      The idea that we need to &quot;breathe new life&quot; into works that are very much of their time is ludicrous.
      <i>Wide Sargasso Sea</i>
      ,
      <i>March</i>
      , and the like were not written to pad the reputation of their (often much better) predecessors; they were written because of the reaction they elicited, often hundreds of years later, in their authors.
      <br clear="none"></br>
      <br clear="none"></br>
      If the ability to inspire discussion and reactions years after publication isn't longevity, I don't know what is.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/63002" shape="rect">mynameisluka</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615774" shape="rect">4:52 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615774" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615775" shape="rect"></a>
    <div class="comments">
      Holden didn't even tweet or have cell! loser!!! He can not bwe my FaceBook friend.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/2290" shape="rect">Postroad</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615775" shape="rect">4:52 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615778" shape="rect"></a>
    <div class="comments">
      Holden is totally the kind of person who would have been on twitter.
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;I went to the coffee shop.  I hate it, it's so phony.  My usual seat was taken.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17611" shape="rect">Bugbread</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615778" shape="rect">4:56 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615778" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615785" shape="rect"></a>
    <div class="comments">
      <em>&quot;The mark of a immature man is that he will die nobly for a cause. The mark of a mature man is that he will live humbly for the same cause</em>
      ---Thurber, the teacher at Holden's last prep school.
      <br clear="none"></br>
      <br clear="none"></br>
      Thats what I took the most from the book.
      <br clear="none"></br>
      <br clear="none"></br>
      After many readings, I
      <em> pity </em>
      Holden.
      <br clear="none"></br>
      <br clear="none"></br>
      If I recall, Holden ends up in a mental hospital.  His hunting cap?  That's a people hunting cap.  When he is buying drinks for those ladies in the hotel?  He is lying to them.  When he hires the prostitute and the pimp roughs him up?  That too was a lying spree. In fact, the only real form of communication in the book for Holden is the communication he has with Phoebe.  She is the only person he feels he can trust. Yes, indeed Holden is grasping for the golden ring of adulthood; the metaphor used as the kids whiz past a real golden ring, and he ends up crying in the rain.  He spends so much time setting his sights on the phonies, that he overlooks himself.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/77913" shape="rect">captainsohler</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615785" shape="rect">5:05 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615785" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615786" shape="rect"></a>
    <div class="comments">
      Oh, and if I came up with a definitive character and idea, I would be pissed if someone tried to cash in on it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/77913" shape="rect">captainsohler</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615786" shape="rect">5:05 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615796" shape="rect"></a>
    <div class="comments">
      You know what's dated? Moby Dick. I mean -- killing whales??? WTF??? Douches!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/24516" shape="rect">potsmokinghippieoverlord</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615796" shape="rect">5:29 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615809" shape="rect"></a>
    <div class="comments">
      <em>Oh, and if I came up with a definitive character and idea, I would be pissed if someone tried to cash in on it.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Yeah, I know that if I had written the
      <a href="http://en.wikipedia.org/wiki/Gesta_Danorum" shape="rect">Gesta Danorum</a>
      , I'd have been pissed when some
      <a href="http://www.shakespeare-online.com/sources/hamletsources.html" shape="rect">crappy English poet</a>
      came along and stole my characters. Did he really think that changing Amleth to Hamlet was going to fool anyone. There definitly should've been an injunction against that one.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17357" shape="rect">bashos_frog</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615809" shape="rect">5:48 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615812" shape="rect"></a>
    <div class="comments">
      Hey, why all the angst about a &quot;goddamn book&quot;?  (Which is the funniest two-word reply in the history of literature, courtesy of Holden Caulfield.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19708" shape="rect">zardoz</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615812" shape="rect">5:51 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615815" shape="rect"></a>
    <div class="comments">
      <em>
        <br clear="none"></br>
        Considering Holden is a borderline sociopath
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      I should probably respond to my provocative statements.  It was based on a few readings I had from age 18-22, that Holden is trying to convince the reader he's totally right and totally justified but it never quite sticks cause he doesn't treat people (aside from Phoebe, who he kinda idealizes) with any kind of empathy. So my orginal statement is what I came away with, but I don't have the book in front of me and I haven't read it in a while and so I shouldn't  talk about it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/80649" shape="rect">The Whelk</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615815" shape="rect">5:58 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615821" shape="rect"></a>
    <div class="comments">
      To me, a work becomes &quot;dated&quot; when the distance in time becomes visible to the reader, to the point where it requires some effort AND when the work is not deemed worthy of the effort.
      <br clear="none"></br>
      <br clear="none"></br>
      Today's English reader have to make a substantial effort to understand Shakespeare's language. But they're willing to do so (or their teachers are willing to force them to), because it's Shakespeare, who won't be dated for the forseeable future.
      <br clear="none"></br>
      <br clear="none"></br>
      But all the forgotten writers of old, and all the forgotten, unread works of famous authors (that may have been a great source of fame during their lives, like Voltaire's tragedies); these works are dated: of their time, and not worth the effort for all but specialists of literature.
      <br clear="none"></br>
      <br clear="none"></br>
      <i>Catcher</i>
      seems to be in a weird place: a true
      <i>classic</i>
      , in a way, because it is taught all over the place, but a book that may be chosen more for its relevance to teenagedom than for its intrinsic qualities; if teenagedom changes, and
      <i>Catcher</i>
      becomes hard to understand for the class, will the teachers be willing to force their pupils to make the effort, or will they drop it?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/79354" shape="rect">Monday, stony Monday</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615821" shape="rect">6:04 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615852" shape="rect"></a>
    <div class="comments">
      With all the time I've spent downloading and saving web clips of random interest to my music folder, I frequently forget the identity of tracks on my iPod.  Not long ago, I had hit &quot;shuffle&quot; to see what came up, and the screen was hidden away in my pocket somewhere.
      <br clear="none"></br>
      <br clear="none"></br>
      I heard a plummy, elderly lady's voice recite: &quot;Men.  They hail you as their morning star / Because you are the way you are.  If you return the sentiment / They'll try to make you different . . .&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      <em>Huh,</em>
      I thought,
      <em>who's this old woman. Sounds so pleased with herself but it's not much of a poem. Where did I get this, again?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      It was a recording of a reading by Dorothy Parker.
      <br clear="none"></br>
      <br clear="none"></br>
      I loved Dorothy Parker in high school.
      <em>Loved </em>
      her.  Went everywhere with a copy of her
      <em>Portable</em>
      , the one with her painted portrait on the cover, looking just about ready for another suicide attempt.  I'd still go to the wall for her short stories.  She is the pioneer and first lady of women's snark.
      <br clear="none"></br>
      <br clear="none"></br>
      Just because she was the first, though, and just because she founded a tradition, doesn't mean that she's the best, or that she speaks to all thinking persons at all times.  A work can be important without being the last word in its genre.  That, on reflection, is pretty much how I feel about
      <em>Catcher in the Rye. </em>
      There had to be a Holden first.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/63748" shape="rect">Countess Elena</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615852" shape="rect">6:24 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615860" shape="rect"></a>
    <div class="comments">
      I first read the book when I was sixteen. I was an incredibly shy teenager, particularly when it came to boys. I saw something of myself in Holden's thoughts about Jane Gallagher--he thinks about her throughout the book, he considers calling her, he plans on calling her, he doesn't. Nothing ever happened between them, really, except that they played checkers and he watched her cry once.
      <br clear="none"></br>
      <br clear="none"></br>
      More importantly, I could see what was wrong with that.
      <b>bugbread</b>
      is right--Holden was a character of inaction, someone lacking conclusions. He was a smart kid, saw all of these problems with society, but was totally incapable of doing anything about it.
      <br clear="none"></br>
      <br clear="none"></br>
      We read
      <i>The Stranger</i>
      the same year. Both books were incredibly affecting for me, because every fiber of myself just sort of screamed at the main characters to
      <i>do something</i>
      . And then I realized that I should have been shouting the same thing at myself.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/78000" shape="rect">PhoBWanKenobi</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615860" shape="rect">6:29 PM</a>
        on June 21, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615860" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615910" shape="rect"></a>
    <div class="comments">
      <em>
        To me, a work becomes &quot;dated&quot; when the distance in time becomes visible to the reader, to the point where it requires some effort AND when the work is not deemed worthy of the effort.
        <br clear="none"></br>
        <br clear="none"></br>
        Today's English reader have to make a substantial effort to understand Shakespeare's language. But they're willing to do so (or their teachers are willing to force them to), because it's Shakespeare, who won't be dated for the forseeable future.
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      I don't really get what you're saying. Shakespeare takes work because it's written in a foreign language (Elizabethan English as opposed to contemporary English.) If you happen to speak that language -- as I do -- it doesn't require effort.
      <br clear="none"></br>
      <br clear="none"></br>
      Via your argument, any book written in French is dated, unless you happen to be a French speaker. Yes, I had to work to become comfortable with Elizabethan English. I'd have to work even harder to learn French. But I'd never claim that French is dated.
      <br clear="none"></br>
      <br clear="none"></br>
      Surely, whether or not something is dated has little to do with the effort required to read it. There are PLENTY of contemporary books that require great effort to parse. A work is dated when it is no longer relevant to most contemporary people even IF they put in the effort to understand what the words mean.
      <br clear="none"></br>
      <br clear="none"></br>
      For instance, if I spent a year trying to understand a medieval book about curing diseases, I would find, at the end of the year, that I'd wasted my time on something dated (assuming my goal was to learn how to cure diseases). On the other hand, if I spent a year trying to understand &quot;King Lear,&quot; I would realize, at the end, that I had spent my time on something about various timeless aspects of the human condition.
      <br clear="none"></br>
      <br clear="none"></br>
      The argument about whether or not &quot;Catcher&quot; should be forced on teenagers is stupid, at least in my view. NO work of literature should be forced on teenagers. Forcing a tried a true way of making kids hate reading.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615910" shape="rect">7:01 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615953" shape="rect"></a>
    <div class="comments">
      It's fascinating to me that many people read &quot;Catcher&quot; and hate Holden -- or, worse, see him as a sociopath! -- because he's a snob.
      <br clear="none"></br>
      <br clear="none"></br>
      It's not that I think these readers are wrong. He IS a snob. But I suspect that readers who CHIEFLY view Holden that way weren't outcasts as teenagers. (If they were, their outcast experience was radically different from mine.)
      <br clear="none"></br>
      <br clear="none"></br>
      (Pardon me for MY moment of snobbishness, but if you considered yourself an outcast because you and your geeky friends weren't part of the popular set, you weren't &quot;real&quot; outcasts. Why not? Because you HAD friends.)
      <br clear="none"></br>
      <br clear="none"></br>
      I gradually became popular in high school, but in junior high I was picked on by almost the entire school -- and by many teachers. I've written about that experience elsewhere, so I won't go into it here. But I spent three years being bullied, mocked and despised.
      <br clear="none"></br>
      <br clear="none"></br>
      Some kids in my shoes dealt with similar treatment by working extra hard to conform. I don't blame them, but that wasn't my road. First of all, I wouldn't have known how; second, I was way too stubborn. Why would I want to conform to a group of people who picked on me?
      <br clear="none"></br>
      <br clear="none"></br>
      Added to this, I was an intellectual kid. I was reading Shakespeare while other kids were disco dancing and talking about &quot;Dynasty.&quot; My interests may have been elitist, but they weren't feigned. I read what I wanted to read, what I really enjoyed reading. And though I now listen to (and enjoy) ABBA, I genuinely hated it back then. Sure, it was because I didn't give it a chance. But I didn't understand that.
      <br clear="none"></br>
      <br clear="none"></br>
      So I found myself alone, with totally different interests from my peers. And my peers didn't leave me alone to enjoy my interests in peace. No, they picked on me and teased me.
      <br clear="none"></br>
      <br clear="none"></br>
      So -- yes -- I became a snob. Everyone around me seemed mean, superficial or both. As an adult, I understand that they had rich inner lives, and that many of the meanest ones had miserable home lives. I no longer turn up my nose at popular culture (I'm a fan of &quot;Lost&quot; and &quot;Seinfeld&quot;), but I understand why that younger me saw mass entertainment as being beneath contempt. It was what the the stuff the mean kids liked!
      <br clear="none"></br>
      <br clear="none"></br>
      Which is all to say that though I'm an empathic person -- and definitely not a sociopath -- I spent a few years as a Holden. And though I outgrew that juvenile skin, I can still connect to it. I remember how it felt. And I'm sure anyone else who had that sort of childhood reads &quot;Catcher&quot; without thinking Holden is evil or strange. His stance is one of self-preservation.
      <br clear="none"></br>
      <br clear="none"></br>
      From some people's reactions, I can only assume they've never felt like everyone else comes from a different planet. They only way they can understand such a feeling is that it must come from sociopath!
      <br clear="none"></br>
      <br clear="none"></br>
      Also: the world IS full of phonies. By which I mean that it's rife with hypocrisy and cow-towing to shallow idols. As an adult, most of us come to think of that is &quot;just the way things are,&quot; and most of us also kind of get into the game. For instance, I am capable of politely pretending to like a friend's dreadful poetry without feeling I've sold my soul to the devil.
      <br clear="none"></br>
      <br clear="none"></br>
      Many kids are also not bothered by phoniness. They are either not very attentive to it or they are too caught up with the party of childhood to care about it. And the more popular a kid is, the more chances he has to learn the natural &quot;phoniness&quot; of complex human interaction -- the white lies we have to tell and the politics we have to play in order to get along. As a loner, it took me a while to grasp the social utility of this stuff. I didn't need &quot;phoniness&quot; for social lubrication, because I wasn't social!
      <br clear="none"></br>
      <br clear="none"></br>
      Dating was a huge challenge. I remember railing against &quot;dishonesty&quot; such as &quot;playing hard to get.&quot; What others thought of as fun flirting, I thought of as lying.
      <br clear="none"></br>
      <br clear="none"></br>
      IF you're a kid who, from a young age, simply accepts things at face value, it's a HUGE bubble burst to learn that the world is full of people who don't mean what they say and people who are slaves to fashion.
      <br clear="none"></br>
      <br clear="none"></br>
      This is SO self-evident to most adults that it's hard for them to remember when they lost their innocence. And many kids lose theirs early, so they can't connect with it, either. Some kids are so canny that they seem to be born politicians. But there are sensitive kids out there who sadly default to a belief that people are always truthful and deep-thinking. Learning that this isn't the case is painful. And, once the bubble is burst, it's almost impossible not to swing to the other extreme -- to believe that if people sometimes lie, they always lie; if they sometimes follow trends, they always follow trends; if they sometimes turn their brains off, they don't have any brains in the first place.
      <br clear="none"></br>
      <br clear="none"></br>
      Hopefully, the adult Holden will learn to be gentler with people, more generous. Hopefully, he will learn that all those phonies were more like him than unlike him -- that their phoniness masked their humanity, their fears, their desires...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/923" shape="rect">grumblebee</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615953" shape="rect">7:33 PM</a>
        on June 21, 2009 [
        <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615953" shape="rect">7 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615961" shape="rect"></a>
    <div class="comments">
      <i>I don't really get what you're saying. Shakespeare takes work because it's written in a foreign language (Elizabethan English as opposed to contemporary English.) If you happen to speak that language -- as I do -- it doesn't require effort.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Yes, maybe Shakespeare isn't the best example -- but almost every English speaker is required to read a least some of his works in school, without taking &quot;Elizabethan English 101&quot;. But take Austen. Her language is a bit different from contemporary English, and her world requires a good deal of effort to understand (government bonds, marriage, property, etc.).
      <br clear="none"></br>
      <br clear="none"></br>
      I think it would be more clear if I used the term &quot;gap&quot;. There's a time gap between us and Austen. It's immediately visible. There's also a space gap, since we both live in North America.
      <br clear="none"></br>
      <br clear="none"></br>
      There's a language gap between you and French works, and probably between us both and Russian works (and it's hard to surmount, except through translation -- a big can of worms to open).
      <br clear="none"></br>
      <br clear="none"></br>
      What I mean is that there wasn't a time gap between
      <i>Catcher</i>
      and its readers when it was first published, but now there is one: the language has changed, New York has changed, teenagers (or, at least, the experience of being a teenager) have changed.
      <br clear="none"></br>
      <br clear="none"></br>
      In most education systems, books are assigned to student. You don't write the report, you don't get the grade. So the sad reality is that teachers force their students to read books that may or may not seem quite foreign to them. As the 1950s become more and more distant, a question appears: did we assign
      <i>Catcher</i>
      because (1) it spoke to (some, and less and less of them) students, or did we assign it because (2) it is a Great Work of Literature?
      <br clear="none"></br>
      <br clear="none"></br>
      If we answer 1, and we say it doesn't speak to teenagers these days and that it isn't that great, actually, it's dated. If we answer 2, it's not.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/79354" shape="rect">Monday, stony Monday</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615961" shape="rect">7:39 PM</a>
        on June 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2615968" shape="rect"></a>
    <div class="comments">
      <i>I don't understand how a work of fiction can be dated.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      i think what might date catcher is that holden's hatred of phoniness and ironic alienation from everything were shocking then and now, it's pretty much old hat - in other words, the emotions and consciousness that a book expresses can be outdated - david copperfield by dickens, frankenstein by mary shelley both have a romantic sensibility and expression of sentimentality that we find awkward - edgar allen poe's shrill invocation of terror and horror can seem overdone to us - and yet, mark twain's huckleberry finn seems contemporary to us in the way it presents its characters as believable people with believable passions
      <br clear="none"></br>
      <br clear="none"></br>
      i'd have to read catcher again to decide, but yeah, the &quot;things are phony, phony, phony&quot; mentality belongs to a time when rebellion meant a little more than it did now - even if it wasn't effective or sincere rebellion, which i'm sure salinger knew
      <br clear="none"></br>
      <br clear="none"></br>
      i will say this - looking through stuff like ellen hopkins' godawful poems about teen addicts and listing to bands piss and moan about suicide, rage and angst, as many bands do these days, holden complaining of &quot;phoniness&quot; seems pretty quaint - holden was an antihero for a generation that had plenty of heroes to look up to - now, he's a wimpy boogerflicker in a land of self-cutters who rummage through their parents' medicine cabinet to get loaded, don't think that much about getting knocked up, pretend to practice black magick, and listen to bands that equate god with smack and enlightenment with torture
      <br clear="none"></br>
      <br clear="none"></br>
      yeah, i guess he is a bit dated
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16417" shape="rect">pyramid termite</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2615968" shape="rect">7:47 PM</a>
        on June 21, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2615968" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2616032" shape="rect"></a>
    <div class="comments">
      <i>So -- yes -- I became a snob. Everyone around me seemed mean, superficial or both.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Here's the thing-- the sort of adolescent snobbery you describe has a
      <i>very</i>
      short half-life for most people who live it, and after that brief moment, it becomes clearly and transparently revealed for what it is -- a self-conscious pose borne of insecurity (and a few people never outgrow it, in which it's an even worse manifestation). That's why
      <i>Catcher</i>
      is literature-- Salinger captures that sort of character very well. However, you can only really identify with Holden within a very brief interval of adolescent development... and in any case
      <i>you're not supposed to identify with Holden</i>
      , and the major error in teaching
      <i>Catcher</i>
      is that teachers tend not to realize this. They're hoping for a classroom full of Holdens.
      <br clear="none"></br>
      <br clear="none"></br>
      A lot of moments in Salinger's
      <i>Nine Stories</i>
      are things that come back to me and that I think about from time to time.
      <i>Catcher</i>
      , on the other hand, is something I left behind a while ago. It
      <i>a</i>
      depiction of adolescence. Unfortunately it's been held up by a generation of teachers as the
      <i>definitive</i>
      one, and along with that we have a group of students who mistakenly believe them.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16459" shape="rect">deanc</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2616032" shape="rect">8:34 PM</a>
        on June 21, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2616032" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2616347" shape="rect"></a>
    <div class="comments">
      <i>
        &quot;Here's the thing-- the sort of adolescent snobbery you describe has a very short half-life for most people who live it, and after that brief moment, it becomes clearly and transparently revealed for what it is -- a self-conscious pose borne of insecurity (and a few people never outgrow it, in which it's an even worse manifestation). That's why Catcher is literature-- Salinger captures that sort of character very well.&quot;
      </i>
      <br clear="none"></br>
      <br clear="none"></br>
      I think this pretty much nails the problem I had with it, and yet also shows why I had a problem conceiving of it as great literature.  By the time I read it (high school), I had already outgrown the whole &quot;indier than thou&quot; thing.  That doesn't mean that I took to worshipping to gods of conformity, but that I understood that sometimes people's internal beliefs matched their external manifestations, and sometimes they didn't, and there is a spectrum of reasons for that, from very good reasons to very bad reasons.  The problem I had with Holden wasn't that he found people/things phony, but that the idea was still new enough to him that he just kept ruminating about it at length.
      <br clear="none"></br>
      <br clear="none"></br>
      Remember back when it first occurred to you that it's possible that the world was just created 10 seconds ago, and you just have memories that it existed before then?  At the time, it was probably pretty interesting and profound.  Now, it probably wouldn't hold your interest for more than a few seconds unless some additional exploration of the idea happened.  When I read Catcher in the Rye, it was like reading a few hundred pages of just the basic idea of the 10 second universe repeated over and over.  If it went on to probe new ideas that came from that, it would be interesting, but it was just that first conceit repeated.
      <br clear="none"></br>
      <br clear="none"></br>
      The problem I have is that Holden's ideas, from what I can tell, are something that have occurred to
      <i>everyone</i>
      .  So he doesn't bring anything new to the table.  And he may be an extremely well written character, but that's because of a certain universality.  A well written character isn't enough to be literature, unless either there is something
      <i>interesting</i>
      about that well written character, or unless that well written character
      <i>does something</i>
      interesting.  Or both.  But for a character to be well written but neither interesting nor involved in anything interesting doesn't seem like literature.
      <br clear="none"></br>
      <br clear="none"></br>
      And, again, big caveats: I'm talking about a book I haven't read in over 2 decades.  There may be a lot I'm misremembering, or that I missed, or, hell, maybe I
      <i>was</i>
      still &quot;indier-than-thou&quot; and my mind is playing tricks on me, and I actually disliked Holden for being too normal and straight-laced.  Memory is a tricky thing, and how well you
      <i>think</i>
      you remember something has been proven scientifically to have almost no relation to how well you actually
      <i>do</i>
      remember something.  The biggest argument in defense of the book to me is that a lot of people around me whose tastes I trusted liked the book a lot.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17611" shape="rect">Bugbread</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2616347" shape="rect">5:40 AM</a>
        on June 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2617220" shape="rect"></a>
    <div class="comments">
      Perhaps
      <i>Catcher</i>
      should be taught as a manifesto of hate.
      <blockquote>
        PAUL: Well...a substitute teacher out on Long Island was dropped from his job for fighting with a student. A few weeks later, the teacher returned to the classroom, shot the student unsuccessfully, held the class hostage and then shot himself: successfully. This fact caught my eye: last sentence, Times. A neighbor described him as a nice boy: always reading Catcher in the Rye.
        <br clear="none"></br>
        The nitwit -- Chapman -- who shot John Lennon said he did it because he wanted to draw the attention of the world to The Catcher in the Rye and the reading of the book would be his defense. And young Hinckley, the whiz kid who shot Reagan and his press secretary, said if you want my defense, all you have to do is read: Catcher in the Rye. It seemed to be time to read it again.
        <br clear="none"></br>
        FLAN: I haven't read it in years.
        <br clear="none"></br>
        <br clear="none"></br>
        (OUISA shushes him.)
        <br clear="none"></br>
        <br clear="none"></br>
        PAUL: I borrowed a copy from a young friend of mine because I wanted to see what she had underlined and I read this book to find out why this touching, beautiful, sensitive story published in July 1951 had turned into this manifesto of hate.
        <br clear="none"></br>
        <br clear="none"></br>
        I started reading. It's exactly as I remembered. Everybody's a phony. Page two: &quot;My brother's in Hollywood being a prostitute.&quot; Page three: &quot;What a phony his father was.&quot; Page nine: &quot;People never notice anything.&quot; Then on page 22 my hair stood up. Remember Holden Caulfield -- the definitive sensitive youth -- wearing his red hunter's cap. &quot;A deer hunter hat? Like hell it is. I sort of closed one eye like I was taking aim at it. This is a people-shooting hat. I shoot people in this hat.&quot;
        <br clear="none"></br>
        Hmmm, I said. This book is preparing people for bigger moments in their lives than I ever dreamed of. Then on page 89: &quot;I'd rather push a guy out the window or chop his head off with an ax than sock him in the jaw...I hate fist fights...what scares me most is the other guy's face...&quot;
        <br clear="none"></br>
        I finished the book. It's a touching story, comic because the boy wants to do so much and can't do anything. Hates all phoniness and only lies to others. Wants everyone to like him, is only hateful, and he is completely self-involved. In other words, a pretty accurate picture of a male adolescent. And what alarms me about the book -- not the book so much as the aura about it -- is this: the book is primarily about paralysis. The boy can't function. And at the end, before he can run away and start a new life, it starts to rain and he folds. Now there's nothing wrong in writing about emotional and intellectual paralysis. It may indeed, thanks to Chekhov and Samuel Beckett, be the great modern theme.
        <br clear="none"></br>
        The extraordinary last lines of Waiting For Godot -- &quot;Let's go.&quot; &quot;Yes, let's go.&quot; Stage directions: they do not move.
        <br clear="none"></br>
        But the aura around this book of Salinger's -- which perhaps should be read by everyone but young men -- is this: it mirrors like a fun house mirror and amplifies like a distorted speaker one of the great tragedies of our times -- the death of the imagination.
        <br clear="none"></br>
        Because what else is paralysis?
        <br clear="none"></br>
        The imagination has been so debased that imagination -- being imaginative -- rather than being the lynchpin of our existence now stands as a synonym for something outside ourselves like science fiction or some new use for tangerine slices on raw pork chops -- what an imaginative summer recipe -- and Star Wars! So imaginative! And Star Trek -- so imaginative! And Lord of the Rings -- all those dwarves -- so imaginative -- The imagination has moved out of the realm of being our link, our most personal link, with our inner lives and the world outside that world -- this world we share. What is schizophrenia but a horrifying state where what's in here doesn't match up with what's out there?
        <br clear="none"></br>
        Why has imagination become a synonym for style?
        <br clear="none"></br>
        I believe that the imagination is the passport we create to take us into the real world. I believe the imagination is another phrase for what is most uniquely us.
        <br clear="none"></br>
        Jung says the greatest sin is to be unconscious.
        <br clear="none"></br>
        Our boy Holden says &quot;What scares me most is the other guy's face -- it wouldn't be so bad if you could both be blindfolded -- most of the time the faces we face are not the other guys' but our own faces. And it's the worst kind of yellowness to be so scared of yourself you put blindfolds on rather than deal with yourself...&quot; To face ourselves.
        <br clear="none"></br>
        That's the hard thing.
        <br clear="none"></br>
        The imagination.
        <br clear="none"></br>
        That's God's gift to make the act of self-examination bearable.
      </blockquote>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/38835" shape="rect">CCBC</a>
        at
        <a target="_self" href="/82639/We-just-wanted-to-tell-him-Shut-up-and-take-your-Prozac#2617220" shape="rect">2:01 PM</a>
        on June 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/82638/The-mysterious-death-of-a-young-hotel-chef-in-China-mobilizes-thousands" shape="rect">« Older</a>
      &quot;At 1am on June 19, police and funeral cars arrive...  |  In Buffy Vs. Edward (Twilight ...
      <a target="_self" href="/82640/Youre-like-my-personal-brand-of-herion-My-god-are-you-twelve" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/110882/Free-Cabin-Porn" shape="rect">Free! Cabin! Porn!</a>
      <span class="smallcopy">December 22, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/107029/Everyone-has-pain-Its-your-job-to-find-it" shape="rect">&quot;Everyone has pain. It's your job to find it.&quot;</a>
      <span class="smallcopy">August 31, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/10005/A-man-checks-out-copies-of-Catcher-in-the-Rye" shape="rect">A man checks out copies of &quot;Catcher in the Rye&quot; </a>
      <span class="smallcopy">September 10, 2001</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/9049/Happy-birthday-Holden" shape="rect">Happy birthday, Holden.</a>
      <span class="smallcopy">July 16, 2001</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/5301/Holden-Caulfield-expelled" shape="rect">Holden Caulfield expelled.</a>
      <span class="smallcopy">January 16, 2001</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    phony   -�     Catcher   *<     Caulfield's   *�     more   ,�     Wide   ,�     lives   +     cars  k@     Jennifer   *m     Rye   *K     Swedish   +�         .http://en.wikipedia.org/wiki/Wide_Sargasso_Sea    Wide Sargasso Sea   ,�     �Mr. California (né Fredrik Colting), then, doing us all a favor by trying to breathe new life into an aging text, à la Jean Rhysâ€™s    �and Seth Grahame-Smithâ€™s more recent Pride and Prejudice and Zombies ? More likely heâ€™s just a crummy phony . posted by oinopaponton (66 comments total)    Wide Sargasso Sea      9202a8c04000641f800000000037baf5    >��    Thttp://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story    �<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Film Noir: Flip Side of the All-American Success Story | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story/rss" title="Comments on: Film Noir: Flip Side of the All-American Success Story" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/FilmNoir" shape="rect">FilmNoir</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Noir" shape="rect">Noir</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/NoirOfTheWeek" shape="rect">NoirOfTheWeek</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/MovieReviews" shape="rect">MovieReviews</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Movies" shape="rect">Movies</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Films" shape="rect">Films</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/NinoFrank" shape="rect">NinoFrank</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/MalteseFalcon" shape="rect">MalteseFalcon</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/DashiellHammett" shape="rect">DashiellHammett</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Maltese" shape="rect">Maltese</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Hammett" shape="rect">Hammett</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Film%20Noir%3A%20Flip%20Side%20of%20the%20All%2DAmerican%20Success%20Story%20http%3A%2F%2Fmefi%2Eus%2Fw%2F82906" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Film Noir: Flip Side of the All-American Success Story
        <br clear="none"></br>
        <span class="smallcopy">
          June 30, 2009 1:07 PM  
          <a href="http://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        Maybe you already know about
        <a href="http://www.greencine.com/static/primers/noir.jsp" shape="rect">film noir</a>
        , how Italian-born French film critic
        <a href="http://en.wikipedia.org/wiki/Nino_Frank" shape="rect">Nino Frank</a>
        coined the term in 1946, and that
        <a href="http://www.pbs.org/wnet/americanmasters/database/hammett_d.html" shape="rect">Dashiell Hammett</a>
        's book
        <a href="http://en.wikipedia.org/wiki/The_Maltese_Falcon_(novel)#Adaptations" shape="rect">
          <em>The Maltese Falcon</em>
          was adapted for film
        </a>
        3 times in 10 years. Or perhaps you've just browsed through
        <a href="http://en.wikipedia.org/wiki/Film_noir" shape="rect">the detailed Wikipedia page</a>
        , and found the
        <a href="http://en.wikipedia.org/wiki/List_of_film_noir" shape="rect">list of film noir series and films</a>
        to be daunting, and
        <a href="http://www.imdb.com/find?s=kw&amp;q=noir&amp;x=0&amp;y=0" shape="rect">IMDB search</a>
        provides a list that is lacking. Either way,
        <a href="http://www.noiroftheweek.com/" shape="rect">Noir of the Week</a>
        has a wealth of information if you crave more details, but focuses on one film per week if long lists are daunting. Not interested in this week's film? They have
        <a href="http://www.noiroftheweek.com/2005/01/noir-of-week-list.html" shape="rect">over 240 movies covered to date</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/81610" shape="rect">filthy light thief</a>
          (20 comments total)
          <span id="favcnt182906">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/82906" shape="rect">55 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2630132" shape="rect"></a>
      <div class="comments">
        Thank you! There is much to come back and savor in this post.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15019" shape="rect">blucevalo</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630132" shape="rect">1:09 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630164" shape="rect"></a>
      <div class="comments">
        Great post. Thanks.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17702" shape="rect">foxy_hedgehog</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630164" shape="rect">1:24 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630165" shape="rect"></a>
      <div class="comments">
        Augh! This is going to make me late for work! I'll have to come back later. Great post!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/69120" shape="rect">Kimothy</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630165" shape="rect">1:24 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630183" shape="rect"></a>
      <div class="comments">
        I have to say that wikipedia entry is pretty loose with the noir titles. Many are not technically noir.
        <br clear="none"></br>
        Any study of noir [in English] starts with Paul Schrader's
        <a href="http://www.paulschrader.org/writings.html" shape="rect">seminal essay</a>
        . [Look under 1971]
        <br clear="none"></br>
        But
        <a href="http://library.calumet.purdue.edu/nitesoul.htm" shape="rect">others </a>
        are just as good at narrowing down what is essential to noir and where there is critical disagreement.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20199" shape="rect">Rashomon</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630183" shape="rect">1:31 PM</a>
          on June 30, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630183" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630188" shape="rect"></a>
      <div class="comments">
        filthy light thief, this is amazing timing. I re-watched the Maltese Falcon last night, and wasted a good chunk of my morning reading reviews of the 1931 movie to see if it was worth renting (verdict: probably not) and trying to figure out who was and wasn't a queer (verdict: every male but Bogart was gay).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23098" shape="rect">kanewai</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630188" shape="rect">1:32 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630194" shape="rect"></a>
      <div class="comments">
        Noir of the Week is a great blog, and
        <em>Night of the Hunter</em>
        , which they're featuring this week, is a great film. Davis Grubb, the guy who wrote the book upon which it is based, is probably post worthy. Also, The Murder City Devil's song &quot;
        <a href="http://www.youtube.com/watch?v=G8SkxpBUO8Q" shape="rect">Left Hand, Right Hand&quot;</a>
        was inspired by Night of the Hunter (Youtube link to loud music).
        <br clear="none"></br>
        <br clear="none"></br>
        I think my favorite film noir would have to be Billy Wilder's
        <em>Ace in the Hole</em>
        , which is covered on Noir of the Week in
        <a href="http://www.noiroftheweek.com/2009/03/ace-in-hole-1951-part-1.html" shape="rect">two</a>
        <a href="http://www.noiroftheweek.com/2009/03/ace-in-hole-1951-part-2.html" shape="rect">parts.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/93644" shape="rect">dortmunder</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630194" shape="rect">1:35 PM</a>
          on June 30, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630194" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630200" shape="rect"></a>
      <div class="comments">
        Thank you, filthy light thief!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17897" shape="rect">brundlefly</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630200" shape="rect">1:37 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630215" shape="rect"></a>
      <div class="comments">
        eponysterical FPP.  You heard it here first, folks.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38322" shape="rect">Navelgazer</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630215" shape="rect">1:43 PM</a>
          on June 30, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630215" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630257" shape="rect"></a>
      <div class="comments">
        Odd timing! Kanewai, FLT: I ALSO re-watched the Bogart/Astor one last night! For reals.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23431" shape="rect">dirtdirt</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630257" shape="rect">1:59 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630379" shape="rect"></a>
      <div class="comments">
        Splendid!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/41173" shape="rect">No Robots</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630379" shape="rect">3:02 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630381" shape="rect"></a>
      <div class="comments">
        And I just watched most of The Big Sleep for the first time last night. Spooky.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/61224" shape="rect">gofargogo</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630381" shape="rect">3:04 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630407" shape="rect"></a>
      <div class="comments">
        Awesome set of links!
        <br clear="none"></br>
        <br clear="none"></br>
        The 1931
        <i>Maltese Falcon</i>
        was merely OK, but looks and seems worse in comparison with the Bogart/Astor
        <em>Maltese Falcon</em>
        , which is just tremendously good. I've heard the radio versions of The Maltese Falcon with Bogart and Astor and Greenstreet et al, and they really highlight how well the movie was shot and framed, and how important the visuals were to the movie.
        <br clear="none"></br>
        <br clear="none"></br>
        Mitchum is fantastic in
        <em>Night of the Hunter</em>
        , just so malevolent and focused, but my favorite on that list is Hitchcock's
        <em>Shadow of a Doubt</em>
        , which frames the noir in the all-American bright-and-sunny picture-perfect world. It's a bit of a precursor to full-fledged noir, but is insidious. Joseph Cotton and Teresa Wright are just so good in it.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/534" shape="rect">julen</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630407" shape="rect">3:28 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630454" shape="rect"></a>
      <div class="comments">
        I forgot to check Archive.org for any handy catch-all page or link. Lo and behold, they have
        <a href="http://www.archive.org/details/Film_Noir" shape="rect">a Film Noir collection</a>
        . There are only
        <a href="http://www.archive.org/search.php?query=collection%3AFilm_Noir&amp;sort=-publicdate" shape="rect">46 items listed currently</a>
        , though I'm not sure if they're all properly sorted or tagged.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/81610" shape="rect">filthy light thief</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630454" shape="rect">3:49 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630463" shape="rect"></a>
      <div class="comments">
        <em>
          filthy light thief, this is amazing timing. I re-watched the Maltese Falcon last night, and wasted a good chunk of my morning reading reviews of the 1931 movie to see if it was worth renting (verdict: probably not) and trying to figure out who was and wasn't a queer (verdict: every male but Bogart was gay).
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        The 1931 version is worth watching, if just for the fact that it is pre-code, and rather explicit for it's time.  Also, I think it kind of sheds some light on Spade's character. Pay attention to the scene at the beginning where Spade speaks Chinese. It will eventually put his actions in a different light. You can make an argument that Bogart's Spade is some sort of existential hero. You can't say the same thing about Spade in the first film.  I think the first film gets closer to Hammett's spade than Huston's does.
        <br clear="none"></br>
        <br clear="none"></br>
        Also, Archer's not gay. It would be a very different story if he were.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/93644" shape="rect">dortmunder</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630463" shape="rect">3:52 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630509" shape="rect"></a>
      <div class="comments">
        I watched
        <a href="http://www.noiroftheweek.com/2007/08/detour-1945.html" shape="rect"> Dead End</a>
        the other night. A very good -&amp; short- film.
        <br clear="none"></br>
        I'd never even heard of it until it was recommended by Errol Morris as one of his
        <a href="http://current.com/items/90177660_five-favorite-films-with-errol-morris.htm" shape="rect">'5 Favorite Films'</a>
        . He calls it 'The Greatest American Movie'!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37049" shape="rect">Flashman</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630509" shape="rect">4:18 PM</a>
          on June 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630713" shape="rect"></a>
      <div class="comments">
        Film noir movies always have the best lamps. Have you ever noticed that? The lamps in the rooms of film noir movies are the most awesome lamps in movies.
        <br clear="none"></br>
        <br clear="none"></br>
        Great post. Whenever there's a classic dark film I want to learn more about, Noir of the Week is my go-to site. One of the best they've turned me on to is 1948's
        <em>
          <a href="http://www.noiroftheweek.com/2007/02/big-clock-1948.html" shape="rect">The Big Clock</a>
        </em>
        , which I recommend highly as a fantastic, suspenseful and
        <a href="http://allmovie.com/work/the-big-clock-84976/review" shape="rect">visually stylish little thriller</a>
        . It has great acting from Ray Milland, Charles Laughton and Elsa Lanchester (Bride of Frankenstein) in a great comic role as a ditzy artist, plus a young Harry Morgan (Colonel Potter from M*A*S*H) as a mute thug. It takes place over the course of one day mainly in the art deco office building of a murder magazine, which adds to the atmosphere beautifully. It was remade in 1987 as &quot;No Way Out&quot; with Kevin Costner and Gene Hackman, but don't hold that against it. And lookee here; someone's
        <a href="http://www.youtube.com/view_play_list?p=3A5BCA1A53421515" shape="rect">posted it in 11 parts</a>
        to YouTube.
        <br clear="none"></br>
        <br clear="none"></br>
        Watch for the lamps.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/12847" shape="rect">mediareport</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630713" shape="rect">7:06 PM</a>
          on June 30, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630713" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630723" shape="rect"></a>
      <div class="comments">
        Oh, and
        <a href="http://www.detnovel.com/" shape="rect">detnovel.com</a>
        is a
        <a href="http://www.detnovel.com/FilmNoir.html" shape="rect">marvelously informative</a>
        site with
        <a href="http://www.detnovel.com/FemmeFatale.html" shape="rect">tons of great info</a>
        about the books many of these films came from.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/12847" shape="rect">mediareport</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630723" shape="rect">7:10 PM</a>
          on June 30, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630723" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2630894" shape="rect"></a>
      <div class="comments">
        <a href="http://www.youtube.com/watch?v=3cVzHeJ0Z3I" shape="rect">Brick</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42489" shape="rect">now i'm piste</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2630894" shape="rect">10:42 PM</a>
          on June 30, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2630894" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2631067" shape="rect"></a>
      <div class="comments">
        <em>Detour</em>
        is okay, but for my money the best noir are
        <em>
          <a href="http://www.imdb.com/title/tt0048261/" shape="rect">Kiss Me Deadly</a>
        </em>
        ,
        <em>
          <a href="http://www.imdb.com/title/tt0040723/" shape="rect">Raw Deal</a>
        </em>
        ,
        <em>
          <a href="http://www.imdb.com/title/tt0038669/" shape="rect">The Killers</a>
        </em>
        , and of course
        <em>
          <a href="http://www.imdb.com/title/tt0036775/" shape="rect">Double Indemnity</a>
        </em>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        What was most startling to me about
        <em>Satan Met a Lady</em>
        (the middle, comedic adaptation of Maltese Falcon) was how very similar it was to the other two films, while having a totally different effect due to its tone. I liked
        <a href="http://www.imdb.com/name/nm0933810/" shape="rect">Marie Wilson</a>
        's performance more than her analogues in the other versions.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/32714" shape="rect">beerbajay</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2631067" shape="rect">5:25 AM</a>
          on July 1, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2632055" shape="rect"></a>
      <div class="comments">
        <a href="#2630894" shape="rect">now i'm piste</a>
        : I just watched Brick, thanks for the suggestion. Pretty good. Maybe a bit too much &quot;tying up all the loose ends&quot; but stylish, convoluted and fun.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/32714" shape="rect">beerbajay</a>
          at
          <a target="_self" href="/82906/Film-Noir-Flip-Side-of-the-AllAmerican-Success-Story#2632055" shape="rect">4:48 PM</a>
          on July 1, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/82905/Threatening-the-mercs-way-of-life" shape="rect">« Older</a>
        Debate over government-funded services heats up. [...  |  Canning makes a comeback. Is i...
        <a target="_self" href="/82907/Back-to-the-future-of-food" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/111275/Comin-at-you-like-schools-out" shape="rect">Comin' at you like school's out.</a>
        <span class="smallcopy">January 4, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/94922/She-cant-be-all-bad-No-one-is-Well-she-comes-the-closest" shape="rect">&quot;She can't be all bad. No one is.&quot; &quot;Well, she...</a>
        <span class="smallcopy">August 19, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/84628/The-Maltese-Falcon-Take-1" shape="rect">The Maltese Falcon: Take 1</a>
        <span class="smallcopy">August 31, 2009</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/75141/In-everything-that-can-be-called-art-there-is-a-quality-of-redemption" shape="rect">In everything that can be called art there is a...</a>
        <span class="smallcopy">September 24, 2008</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/55247/The-shooting-script-and-original-novella-for-the-film-Brick" shape="rect">The shooting script and original novella for the...</a>
        <span class="smallcopy">October 2, 2006</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    book   /     Frank   .�     French   .?     Nino   .�     Debate   k�     wealth   1e     information   1o     more   1�     long   1�     born   .:         'http://en.wikipedia.org/wiki/Nino_Frank    
Nino Frank   .�     �of the All-American Success Story June 30, 2009 1:07 PM   Subscribe Maybe you already know about film noir , how Italian-born French film critic    �coined the term in 1946, and that Dashiell Hammett 's book The Maltese Falcon was adapted for film 3 times in 10 years. Or perhaps    
Nino Frank      9202a8c04000641f80000000046df262     Chttp://en.wikipedia.org/wiki/The_Maltese_Falcon_(novel)#Adaptations    'The Maltese Falcon was adapted for film   /m     �you already know about film noir , how Italian-born French film critic Nino Frank coined the term in 1946, and that Dashiell Hammett 's book    �3 times in 10 years. Or perhaps you've just browsed through the detailed Wikipedia page , and found the list of film noir series and    'The Maltese Falcon was adapted for film      .http://en.wikipedia.org/wiki/List_of_film_noir    "list of film noir series and films   0s     �Maltese Falcon was adapted for film 3 times in 10 years. Or perhaps you've just browsed through the detailed Wikipedia page , and found the    �to be daunting, and IMDB search provides a list that is lacking. Either way, Noir of the Week has a wealth of information if you    "list of film noir series and films   