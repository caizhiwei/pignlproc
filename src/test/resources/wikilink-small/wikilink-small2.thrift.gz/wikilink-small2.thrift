  >��    /http://www.metafilter.com/80925/Man-Gets-On-Bus    ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Man Gets On Bus | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/80925/Man-Gets-On-Bus" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/80925/Man-Gets-On-Bus/rss" title="Comments on: Man Gets On Bus" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Frank" shape="rect">Frank</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Bainimarama" shape="rect">Bainimarama</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Fiji" shape="rect">Fiji</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Junta" shape="rect">Junta</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Despot" shape="rect">Despot</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Coup" shape="rect">Coup</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Dictator" shape="rect">Dictator</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Man%20Gets%20On%20Bus%20http%3A%2F%2Fmefi%2Eus%2Fw%2F80925" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/80925/Man-Gets-On-Bus" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Man Gets On Bus
        <br clear="none"></br>
        <span class="smallcopy">
          April 16, 2009 5:35 PM  
          <a href="http://www.metafilter.com/80925/Man-Gets-On-Bus/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/80925/Man-Gets-On-Bus/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://en.wikipedia.org/wiki/Frank_Bainimarama" shape="rect">Commodore Frank Bainimarama</a>
        has engineered a coup on top of a coup in
        <a href="http://www.theaustralian.news.com.au/story/0,25197,25319368-2703,00.html" shape="rect">sacking the judiciary</a>
        ,
        <a href="http://www.economist.com/world/asia/displaystory.cfm?story_id=13496478" shape="rect">suspending the constitution</a>
        ,
        <a href="http://www.abc.net.au/news/stories/2009/04/12/2541235.htm" shape="rect">controlling the press</a>
        ,
        <a href="http://www.upi.com/Top_News/2009/04/13/Fiji-military-given-OK-to-shoot-civilians/UPI-77221239654619/" shape="rect">quashing dissent</a>
        and taking over the
        <a href="http://www.theage.com.au/world/fijian-troops-occupy-central-bank-20090414-a6ai.html" shape="rect">central bank</a>
        <a href="http://www.reservebank.gov.fj/?Page=newsRoom&amp;newsId=339" shape="rect">pdf press release</a>
        .
        <a href="http://www.3news.co.nz/Fiji-newspaper-digs-at-interim-govt-with-lead-story-Man-gets-on-bus/tabid/209/articleID/100012/cat/525/Default.aspx" shape="rect">With no reportage of the takeover or criticism of the junta allowed</a>
        , and with local journalists arrested and
        <a href="http://www.stuff.co.nz/national/2334098/Deported-TV3-crew-arrive-home" shape="rect">foreign</a>
        <a href="http://www.abc.net.au/news/stories/2009/04/13/2541478.htm?site=local" shape="rect">correspondents</a>
        <a href="http://www.fijidailypost.com/news.php?section=1&amp;fijidailynews=23115" shape="rect">expelled</a>
        , how is the Fijiâ€™s story being told?
        <a href="http://wwwfijicoup2006.blogspot.com/" shape="rect">Bloggers</a>
        have
        <a href="http://intelligentsiya.blogspot.com/" shape="rect">taken to the task</a>
        ,
        <a href="http://www.abc.net.au/pm/content/2008/s2545020.htm" shape="rect"> but are undertaking huge risks</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33757" shape="rect">mattoxic</a>
          (27 comments total)
          <span id="favcnt180925">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/80925" shape="rect">4 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2531320" shape="rect"></a>
      <div class="comments">
        Frank
        <a href="http://en.wikipedia.org/wiki/Bananarama" shape="rect">Bananarama?</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16521" shape="rect">ZenMasterThis</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531320" shape="rect">5:40 PM</a>
          on April 16, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531320" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531328" shape="rect"></a>
      <div class="comments">
        It's gonna be a cruel, cruel summer.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/83047" shape="rect">mattdidthat</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531328" shape="rect">5:44 PM</a>
          on April 16, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531328" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531363" shape="rect"></a>
      <div class="comments">
        God damn you both.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531363" shape="rect">6:24 PM</a>
          on April 16, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531363" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531364" shape="rect"></a>
      <div class="comments">
        Alright, someone at least parodize this guy into the lyrics for &quot;Venus&quot;.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531364" shape="rect">6:25 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531364" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531390" shape="rect"></a>
      <div class="comments">
        Ah, you all beat me to it.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49218" shape="rect">cmgonzalez</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531390" shape="rect">6:40 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531393" shape="rect"></a>
      <div class="comments">
        Surely there's still a Commodore joke to be made.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17573" shape="rect">box</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531393" shape="rect">6:42 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531393" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531396" shape="rect"></a>
      <div class="comments">
        Dammit. I provided the setup, and
        <b>mattdidthat</b>
        gets all the favorites.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16521" shape="rect">ZenMasterThis</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531396" shape="rect">6:44 PM</a>
          on April 16, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531396" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531399" shape="rect"></a>
      <div class="comments">
        Yeah, you know how it is for a straight man on Metafilter.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17573" shape="rect">box</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531399" shape="rect">6:45 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531399" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531401" shape="rect"></a>
      <div class="comments">
        <em>Surely there's still a Commodore joke to be made.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I wonder if Mr. Bananrama is planning on building any brick houses.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49218" shape="rect">cmgonzalez</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531401" shape="rect">6:48 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531401" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531407" shape="rect"></a>
      <div class="comments">
        Also, holy crap. Fiji's been in a perpetual state of coup since as long as I can remember.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531407" shape="rect">6:53 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531410" shape="rect"></a>
      <div class="comments">
        Thank god the guy has a slightly comedic name, otherwise it would be a total downer.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33757" shape="rect">mattoxic</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531410" shape="rect">6:56 PM</a>
          on April 16, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531410" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531417" shape="rect"></a>
      <div class="comments">
        Hey guys, that commodore's last name is wacky!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19375" shape="rect">TwelveTwo</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531417" shape="rect">7:01 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531417" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531419" shape="rect"></a>
      <div class="comments">
        <small>
          <strong>posted by Marisa Stole the Precious Thing</strong>
          <em>Alright, someone at least parodize this guy into the lyrics for &quot;Venus&quot;.</em>
        </small>
        <br clear="none"></br>
        <br clear="none"></br>
        Dictator on the mountaintop
        <br clear="none"></br>
        Hatin' the human rights game
        <br clear="none"></br>
        Silencin' all his opponents
        <br clear="none"></br>
        And Frankie was his name
        <br clear="none"></br>
        <br clear="none"></br>
        We blogged it
        <br clear="none"></br>
        Yeah baby, we blogged it
        <br clear="none"></br>
        I'm on Twitter, I'm on Blogspot
        <br clear="none"></br>
        Don't get caught
        <br clear="none"></br>
        Well, I'm on Twitter, I'm on Blogspot
        <br clear="none"></br>
        Don't get caught
        <br clear="none"></br>
        <br clear="none"></br>
        He controlled all the newspapers
        <br clear="none"></br>
        And then he took over the bank
        <br clear="none"></br>
        Then he fired all the judges
        <br clear="none"></br>
        Bloggers wrote WTF FRANK?!
        <br clear="none"></br>
        Wow!
        <br clear="none"></br>
        <br clear="none"></br>
        We blogged it
        <br clear="none"></br>
        Yeah baby, we blogged it
        <br clear="none"></br>
        I'm on Twitter, I'm on Blogspot
        <br clear="none"></br>
        Don't get caught
        <br clear="none"></br>
        Well, I'm on Twitter, I'm on Blogspot
        <br clear="none"></br>
        Don't get caught
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/83047" shape="rect">mattdidthat</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531419" shape="rect">7:03 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531419" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531432" shape="rect"></a>
      <div class="comments">
        Since it's independence since 1970, Fiji has had
        <a href="https://www.cia.gov/library/publications/the-world-factbook/geos/fj.html" shape="rect">four previous coups</a>
        . Reading about the 2006 coup alone is like something out of Cardinal Guzman. The EU has stopped sending aid and tourism is dying there, but where can it go from here? I don't hear a lot about what's going on in the South Pacific. But it would seem the internet traffic would be a relatively easy thing for the military their to monitor. They've already disconnected a lot of phone lines and are probably tapping more of them.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531432" shape="rect">7:21 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531460" shape="rect"></a>
      <div class="comments">
        Coup in Fiji, attempted coup in Thailand...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/76681" shape="rect">mark242</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531460" shape="rect">7:57 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531475" shape="rect"></a>
      <div class="comments">
        Wait till the Fijians learn about Twitter and Facebook.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/48745" shape="rect">KokuRyu</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531475" shape="rect">8:09 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531496" shape="rect"></a>
      <div class="comments">
        I guess I'm
        <i>not</i>
        going to buy meself a little farm on Fiji.
        <br clear="none"></br>
        <br clear="none"></br>
        I suppose that's okay: I couldn't manage to fit waterwings on my sheep.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/13258" shape="rect">five fresh fish</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531496" shape="rect">8:30 PM</a>
          on April 16, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531496" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531510" shape="rect"></a>
      <div class="comments">
        Excellent post.
        <br clear="none"></br>
        <br clear="none"></br>
        Disappointing thread.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20011" shape="rect">merelyglib</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531510" shape="rect">8:51 PM</a>
          on April 16, 2009 [
          <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531510" shape="rect">6 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531524" shape="rect"></a>
      <div class="comments">
        Terrible, but at least the
        <a href="http://www.fijidailypost.com/news.php?section=1&amp;fijidailynews=23076" shape="rect">paint is dry</a>
        ,
        <a href="http://www.fijidailypost.com/news.php?section=1&amp;fijidailynews=23110" shape="rect">a man went out</a>
        and
        <a href="http://www.fijidailypost.com/news.php?section=1&amp;fijidailynews=23106" shape="rect">someone cleaned their teeth</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/29141" shape="rect">scodger</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531524" shape="rect">9:12 PM</a>
          on April 16, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531524" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531526" shape="rect"></a>
      <div class="comments">
        Here's another blog -
        <a href="http://discombobulatedbubu.blogspot.com/" shape="rect">discombobulated</a>
        . Thanks for posting this mattoxic.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19387" shape="rect">tellurian</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531526" shape="rect">9:16 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531531" shape="rect"></a>
      <div class="comments">
        <em>Terrible, but at least the paint is dry, a man went out and someone cleaned their teeth.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Well, it's more useful than what the NYT was printing in the run-up to the Iraq war. I smell Pulitzer!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/36675" shape="rect">drjimmy11</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531531" shape="rect">9:26 PM</a>
          on April 16, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531725" shape="rect"></a>
      <div class="comments">
        Would it be bad if I said...
        <br clear="none"></br>
        <br clear="none"></br>
        LOAD &quot;COUP&quot;,8,1
        <br clear="none"></br>
        <br clear="none"></br>
        ?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/12985" shape="rect">Samizdata</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531725" shape="rect">3:23 AM</a>
          on April 17, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531725" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2531902" shape="rect"></a>
      <div class="comments">
        Great post, mattoxic, I've been following the Fiji coup news somewhat closely (
        <small>
          <small>I do research in the area and have some Fijian ex-pat friends who are keeping me posted</small>
        </small>
        ) and your links directed me to some new stuff.  If anyone is more interested in further Fiji news and blog links rather than just HURF DURF FUNNY NAMES, here are a few I would recommend:
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://www.discombobulatedbubu.blogspot.com/" shape="rect">discombobulated bubu</a>
        <br clear="none"></br>
        <a href="http://talkingfiji.wordpress.com/" shape="rect">Talking Fiji</a>
        <br clear="none"></br>
        <a href="http://www.fijifreespeech.info/" shape="rect">FijiFreeSpeech</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/32016" shape="rect">barnacles</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2531902" shape="rect">7:00 AM</a>
          on April 17, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2531902" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2532040" shape="rect"></a>
      <div class="comments">
        <i>
          Would it be bad if I said...
          <br clear="none"></br>
          <br clear="none"></br>
          LOAD &quot;COUP&quot;,8,1
          <br clear="none"></br>
          <br clear="none"></br>
          ?
          <br clear="none"></br>
        </i>
        It wouldn't be bad, but it would mean fuck all.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19387" shape="rect">tellurian</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2532040" shape="rect">8:46 AM</a>
          on April 17, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2532053" shape="rect"></a>
      <div class="comments">
        Thanks, mattoxic and others, for all those links. It's a grim time for Fiji.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/971" shape="rect">rory</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2532053" shape="rect">8:58 AM</a>
          on April 17, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2532632" shape="rect"></a>
      <div class="comments">
        It's such a disaster, Fiji's economy is fragile anyway, with the country relying on the garment trade, sugar and tourism. The world bank is going to withdraw support for new sugar refining infrastructure, the GFC has pretty much decimated the garment industry and tourism, Fiji will have precious else. The junta desperate for cash will sell Fiji's forests to logging companies at bargain prices.
        <br clear="none"></br>
        <br clear="none"></br>
        I'm not much of a believer in interventions, but Australia and New Zealand should act before its too late. Bainimarama should be in a cell in the Hague.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33757" shape="rect">mattoxic</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2532632" shape="rect">5:44 PM</a>
          on April 17, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2533315" shape="rect"></a>
      <div class="comments">
        <em>
          Excellent post.
          <br clear="none"></br>
          <br clear="none"></br>
          Disappointing thread.
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        You must become the change you seek.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/48745" shape="rect">KokuRyu</a>
          at
          <a target="_self" href="/80925/Man-Gets-On-Bus#2533315" shape="rect">10:38 PM</a>
          on April 18, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/80924/Deaths-of-Children-and-Noncombatants-in-Iraq-20032008" shape="rect">« Older</a>
        Iraq air raids hit mostly women and children....  |  The Brick Testament (previousl...
        <a target="_self" href="/80926/Apocalypse-Now" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/111130/An-unusual-coup-detat" shape="rect">An unusual coup d'etat</a>
        <span class="smallcopy">December 31, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/96099/The-Gangster-Prince-of-Liberia" shape="rect">The Gangster Prince of Liberia</a>
        <span class="smallcopy">September 27, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/56734/Ai-tei-vovo-tei-vovo-veico-veico-veico" shape="rect">Ai tei vovo, tei vovo, veico, veico, veico</a>
        <span class="smallcopy">December 4, 2006</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/8231/Echelon-rumored-to-be-used-in-NZ-spying-on-Fiji" shape="rect">
          Echelon rumored to be used in NZ spying on Fiji
          <br clear="none"></br>
        </a>
        <span class="smallcopy">June 11, 2001</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/2248/Deal-Announced-To-End-Hostage-Standoff-in-Fiji" shape="rect">Deal Announced To End Hostage Standoff in Fiji</a>
        <span class="smallcopy">June 23, 2000</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    risks   0.     taking   ,/     story   /?     top   *W     expelled   /     pdf   ,�     local   -�     but   0     task   /�     	reportage   -�         .http://en.wikipedia.org/wiki/Frank_Bainimarama    Commodore Frank Bainimarama   *     �Login New User Tags: Frank Bainimarama Fiji Junta Despot Coup Dictator Share: Twitter Facebook Man Gets On Bus April 16, 2009 5:35 PM   Subscribe    �has engineered a coup on top of a coup in sacking the judiciary , suspending the constitution , controlling the press , quashing dissent and    Commodore Frank Bainimarama      9202a8c04000641f8000000000294d7b    >��    Xhttp://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/    ��<html lang="en-US" dir="ltr">
  <head profile="http://gmpg.org/xfn/11">
    <meta content="text/html; charset=UTF-8" http-equiv="Content-Type"></meta>
    <title>NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED | LUXURYBLURB</title>
    <meta content="text/html; charset=utf-8" http-equiv="content-type"></meta>
    <meta content="real, estate, new, york, manhattan, loft, luxury, condo, condominium, greenwich, village, soho, tribeca, chelsea, wall, street, brooklyn, dumbo, development, buy, sell, broker, nyc, ny, realty" name="keywords"></meta>
    <meta content="Real Estate: see us to rent, buy or sell a loft in Manhattan, New York City. We offer Manhattan, New York City, real estate. We deal Manhattan, New York City, real estate: luxury loft apartments." name="description"></meta>
    <meta content="all" name="robots"></meta>
    <meta content="General" name="rating"></meta>
    <meta content="30 days" name="revisit-after"></meta>
    <meta content="Real Estate: See Us To Rent, Buy Or Sell A Loft In Manhattan, New York City." name="VW96.objecttype"></meta>
    <meta content="Real Estate: See Us To Rent, Buy Or Sell A Loft In Manhattan, New York City." name="DC.title"></meta>
    <meta content="Real Estate: see us to rent, buy or sell a loft in Manhattan, New York City. We offer Manhattan, New York City, real estate. We deal Manhattan, New York City, real estate: luxury loft apartments." name="DC.subject"></meta>
    <meta content="Real Estate: see us to rent, buy or sell a loft in Manhattan, New York City. We offer Manhattan, New York City, real estate. We deal Manhattan, New York City, real estate: luxury loft apartments." name="DC.description"></meta>
    <meta content="EN" scheme="RFC1766" name="DC.Language"></meta>
    <meta content="Global" name="DC.Coverage.PlaceName"></meta>
    <link href="mailto:ls@luxuryloft.com" title="LuxuryLoft.com" rev="made"></link>
    <link href="images/favicon.ico" rel="shortcut icon"></link>
    <link href="/css/print.css" media="print" type="text/css" rel="stylesheet"></link>
    <script src="/js/jquery-1.3.2.min.js" type="text/javascript"></script>
    <script src="/js/library.js" type="text/javascript"></script>
    <script src="/js/forms.js" type="text/javascript"></script>
    <link media="screen" type="text/css" href="http://www.luxuryloft.com/blog/wp-content/themes/default/style.css" rel="stylesheet"></link>
    <link href="http://www.luxuryloft.com/blog/xmlrpc.php" rel="pingback"></link>
    <style media="screen" type="text/css"> #page { background: url(&quot;http://www.luxuryloft.com/blog/wp-content/themes/default/images/kubrickbgwide.jpg&quot;) repeat-y top; border: none; } </style>
    <link href="http://www.luxuryloft.com/blog/feed/" title="LUXURYBLURB » Feed" type="application/rss+xml" rel="alternate"></link>
    <link href="http://www.luxuryloft.com/blog/comments/feed/" title="LUXURYBLURB » Comments Feed" type="application/rss+xml" rel="alternate"></link>
    <link href="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/feed/" title="LUXURYBLURB » NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED Comments Feed" type="application/rss+xml" rel="alternate"></link>
    <link media="all" type="text/css" href="http://www.luxuryloft.com/blog/wp-content/plugins/add-link-to-facebook/add-link-to-facebook.css?ver=3.4.1" rel="stylesheet" id="al2fb_style-css"></link>
    <script src="http://www.luxuryloft.com/blog/wp-includes/js/comment-reply.js?ver=3.4.1" type="text/javascript"></script>
    <link href="http://www.luxuryloft.com/blog/xmlrpc.php?rsd" title="RSD" type="application/rsd+xml" rel="EditURI"></link>
    <link href="http://www.luxuryloft.com/blog/wp-includes/wlwmanifest.xml" type="application/wlwmanifest+xml" rel="wlwmanifest"></link>
    <link href="http://www.luxuryloft.com/blog/2011/05/no-one-is-building-studios/" title="NO ONE IS BUILDING STUDIOS…" rel="prev"></link>
    <link href="http://www.luxuryloft.com/blog/2011/05/greenwich-connecticut-super-luxe-market-stalled/" title="GREENWICH CONNECTICUT SUPER-LUXE MARKET STALLED" rel="next"></link>
    <meta content="WordPress 3.4.1" name="generator"></meta>
    <link href="http://www.luxuryloft.com/blog/?p=1022" rel="shortlink"></link>
    <meta content="Posted by Leonard Steinberg on May 28th, 2011 One of the worst forms of pollution in a city like Manhattan is noise pollution: Because of the very nature of" name="description"></meta>
    <meta content="311,city noise,city ordinance,hearing loss,hypertension,law,leonard steinberg,manhattan noise,new york noise,noise pollution,quality of life,real estate valuations,sleep disturbance,stress,tinnitus" name="keywords"></meta>
    <link href="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/" rel="canonical"></link>
    <link href="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/style.css" media="all" type="text/css" rel="stylesheet"></link>
    <meta content="article" property="og:type"></meta>
    <meta content="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/" property="og:url"></meta>
    <meta content="NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" property="og:title"></meta>
    <meta content="http://www.luxuryloft.com/blog/wp-content/uploads/2011/05/noise-400x400.jpg" property="og:image"></meta>
    <meta content="LUXURYBLURB" property="og:site_name"></meta>
    <meta content="102759403176968" property="fb:app_id"></meta>
    <meta 
    content="Posted by Leonard Steinberg on May 28th, 2011 One of the worst forms of pollution in a city like Manhattan is noise pollution: Because of the very nature of the city, noise affects individuals more acutely than in other parts of the country where noise can..." property="og:description">
</meta>
    <meta content="en_US" property="og:locale"></meta>
  </head>
  <body class="single single-post postid-1022 single-format-standard">
    <div id="page">
      <a name="top" shape="rect"></a>
      <div id="ll_header">
        <img height="105" width="818" alt="LuxuryLoft.com" src="/images/header.gif"></img>
      </div>
      <table border="0" cellspacing="0" cellpadding="0" id="table_content">
        <tr>
          <td id="menu" valign="top" rowspan="1" colspan="1">
            <a href="/" shape="rect">Home</a>
            <br clear="none"></br>
            <a href="/buying.php" shape="rect">Available Listings</a>
            <a href="/wishlist.php?search" shape="rect">Custom Search</a>
            <br clear="none"></br>
            <a href="/buying.php?buying_menu" shape="rect">Buying?</a>
            <ul class="submenu">
              <li>
                <a href="/buying.php?buying_menu" shape="rect">Luxuryloft listings</a>
              </li>
              <li>
                <a href="/neighborhoods.php" shape="rect">Neighourhoods</a>
              </li>
              <li>
                <a href="/wishlist.php" shape="rect">Wishlist</a>
              </li>
              <li>
                <a href="/timing_for_buying.php" shape="rect">Timing for buying</a>
              </li>
              <li>
                <a href="/what_is_a_luxuryloft.php" shape="rect">What is a Luxury Loft?</a>
              </li>
              <li>
                <a href="/closing_costs.php" shape="rect">Closing costs</a>
              </li>
              <li>
                <a href="/purchase_cost_analysis.php" shape="rect">Purchase cost analysis</a>
              </li>
              <li>
                <a href="/decision_tools.php" shape="rect">Decision tools</a>
              </li>
            </ul>
            <a href="/selling.php" shape="rect">Selling?</a>
            <ul class="submenu">
              <li>
                <a href="/what_is_my_home_worth.php?selling" shape="rect">What's My Home Worth?</a>
              </li>
              <li>
                <a href="/the_selling_process.php" shape="rect">The Process</a>
              </li>
              <li>
                <a href="/enhance_your_property.php" shape="rect">Enhance Your Property</a>
              </li>
              <li>
                <a href="/closing_costs_seller.php" shape="rect">Closing Costs</a>
              </li>
            </ul>
            <br clear="none"></br>
            <a href="/best_downtown_condos.php" shape="rect">Downtown Condolofts</a>
            <a href="/best_developments.php" shape="rect">New Developments</a>
            <a href="/services.php" shape="rect">Services</a>
            <ul class="submenu">
              <li>
                <a href="/what_is_my_home_worth.php?appraisal" shape="rect">Appraisal</a>
              </li>
              <li>
                <a href="/concierge.php" shape="rect">Concierge</a>
              </li>
              <li>
                <a href="/virtual_broker.php" shape="rect">Virtual Broker</a>
              </li>
            </ul>
            <a href="/ideas.php" shape="rect">Ideas</a>
            <a href="/picks.php" shape="rect">NYC Picks</a>
            <a href="/ask_a_broker.php" shape="rect">Ask-a-broker</a>
            <a href="/links.php" shape="rect">Luxuryconnect</a>
            <ul class="submenu"></ul>
            <a href="/financing.php" shape="rect">Financing</a>
            <a href="/market_report.php" shape="rect">Market Report</a>
            <br clear="none"></br>
            <a href="/shop.php" shape="rect">Shop</a>
            <br clear="none"></br>
            <a href="/blog/index.php" class="orange" shape="rect">LUXURYBLURB</a>
            <br clear="none"></br>
            <a href="/luxuryletter.php" class="orange" shape="rect">LUXURYLETTER</a>
            <ul class="submenu">
              <li>
                <a href="/subscribe.php?ll" shape="rect">Subscribe</a>
              </li>
            </ul>
            <br clear="none"></br>
            <a href="/about_us.php" shape="rect">About Us</a>
            <a href="/press.php" shape="rect">Press</a>
            <a href="/ask_a_broker.php?contact" shape="rect">Contact Us</a>
            <a href="/languages.php" shape="rect">Other Languages</a>
            <a href="/external_links.php" shape="rect">Links</a>
          </td>
          <td id="right_hand_div" valign="top" rowspan="1" colspan="1">
            <div role="main" id="content" class="narrowcolumn">
              <h1>LuxuryBlurb</h1>
              <div class="navigation">
                <div class="alignleft">
                  <span class="orange">
                    <b>
                      «
                      <a rel="prev" href="http://www.luxuryloft.com/blog/2011/05/no-one-is-building-studios/" shape="rect">NO ONE IS BUILDING STUDIOS…</a>
                    </b>
                  </span>
                </div>
                <b> </b>
                <div class="alignright">
                  <b>
                    <a rel="next" href="http://www.luxuryloft.com/blog/2011/05/greenwich-connecticut-super-luxe-market-stalled/" shape="rect">GREENWICH CONNECTICUT SUPER-LUXE MARKET STALLED</a>
                    <span class="orange">
                      <b>»</b>
                    </span>
                  </b>
                </div>
                <b>
                  <b> </b>
                </b>
              </div>
              <b>
                <b> </b>
              </b>
              <div 
              id="post-1022" class="post-1022 post type-post status-publish format-standard hentry category-real-estate tag-311 tag-city-noise tag-city-ordinance tag-hearing-loss tag-hypertension tag-law tag-leonard-steinberg tag-manhattan-noise tag-new-york-noise tag-noise-pollution tag-quality-of-life tag-real-estate-valuations tag-sleep-disturbance tag-stress tag-tinnitus">
                <b>
                  <b> </b>
                </b>
                <h2>
                  <b>
                    <b>NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED</b>
                  </b>
                </h2>
                <b>
                  <b> </b>
                </b>
                <div class="entry">
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <a href="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/noise-3/" rel="attachment wp-att-1023" shape="rect">
                          <img height="400" width="400" alt="" src="http://www.luxuryloft.com/blog/wp-content/uploads/2011/05/noise-400x400.jpg" class="aligncenter size-medium wp-image-1023"></img>
                        </a>
                        Posted by Leonard Steinberg on May 28th, 2011
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>One of the worst forms of pollution in a city like Manhattan is noise pollution: Because of the very nature of the city, noise affects individuals more acutely than in other parts of the country where noise can carry and be spread out more.</b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        It is time for Manhattan to institute new laws governing noise AND police/enforce these laws. Why does one individual have the ‘right’ to make a tremendous amount of noise at the expense of hundred of individuals. Not only is it unfair, it is completely ridiculous and absurd. The other day I witnessed a loud motorcycle roar past my apartment. One individual on a lousy bike, making the lives of HUNDREDS uncomfortable. Then there are those antiquated garbage trucks, busses, vans, AC equipment, etc. Not to mention construction crews out of control. If I were to sit in my apartment and make the exact same level of sound, I would probably be arrested and jailed. Why does the law not apply to all, equally?
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        I have heard that noise complaints are one of the primary issues reported on 311 calls: who is listening to this? In other civilized cities and towns, noise ordinances are enforced regularly. If Manhattan is seeking additional tax revenues, there are enough noise offenders that could probably LOWER our taxes…..surely that would be motivation for those questioning me?
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        Noise is also bad for your health in many ways, not only your ear drums.Â Noise pollution can cause annoyance and aggression,Â 
                        <a href="http://en.wikipedia.org/wiki/Hypertension" title="Hypertension" shape="rect">hypertension</a>
                        , high stress levels,Â 
                        <a href="http://en.wikipedia.org/wiki/Tinnitus" title="Tinnitus" shape="rect">tinnitus</a>
                        , hearing loss, sleep disturbances, and other harmful effects.
                        <span style="font-size: small">
                          <span style="font-size: 11px"> </span>
                        </span>
                        Furthermore, stress and hypertension are the leading causes to health problems, whereas tinnitus can lead to forgetfulness, severe depression and at times panic attacks. Surely it does not require a lawsuit to realize that a change in this arena is long overdue?
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>And by the way, cities and towns with strong noise ordinances offer a better quality of life for all and therefore produce better real estate valuations…..surely another motivator to make some changes?</b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>Something is wrong and it has to change. How much noise do I have to make to be heard on this subject?</b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <div class="WP-Social-Bookmarking">
                    <b>
                      <b>
                        <a title="Mega World News" target="_blank" href="http://www.megawn.com/?f=aHR0cDovL3d3dy5sdXh1cnlsb2Z0LmNvbS9ibG9nLzIwMTEvMDUvbmV3LW5vaXNlLXBvbGx1dGlvbi1sYXdzY2l0eS1vcmRpbmFuY2VzLXJlcXVpcmVkLw==&amp;l=en-US" shape="rect">
                          <img title="Mega World News" alt="Mega World News" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/onlinerel.png"></img>
                        </a>
                        <a title="Facebook" rel="nofollow" target="_blank" href="http://facebook.com/sharer.php?u=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;t=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Facebook" alt="Facebook" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/facebook.png"></img>
                        </a>
                        <g:plusone annotation="none"></g:plusone>
                        <a title="Twitter" rel="nofollow" target="_blank" href="http://twitter.com/home?status=http://www.luxuryloft.com/blog/?p=1022  NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Twitter" alt="Twitter" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/twitter.png"></img>
                        </a>
                        <a title="Myspace" rel="nofollow" target="_blank" href="http://www.myspace.com/Modules/PostTo/Pages/?c=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;t=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Myspace" alt="Myspace" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/myspace.png"></img>
                        </a>
                        <a title="Friendfeed" rel="nofollow" target="_blank" href="http://friendfeed.com/share?url=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;title=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Friendfeed" alt="Friendfeed" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/friendfeed.png"></img>
                        </a>
                        <a title="Technorati" rel="nofollow" target="_blank" href="http://www.technorati.com/faves?add=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/" shape="rect">
                          <img title="Technorati" alt="Technorati" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/technorati.png"></img>
                        </a>
                        <a title="del.icio.us" rel="nofollow" target="_blank" href="http://del.icio.us/post?url=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;title=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="del.icio.us" alt="del.icio.us" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/delicious.png"></img>
                        </a>
                        <a title="Digg" rel="nofollow" target="_blank" href="http://digg.com/submit?phase=2&amp;url=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;title=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Digg" alt="Digg" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/digg.png"></img>
                        </a>
                        <a title="Google" rel="nofollow" target="_blank" href="http://google.com/bookmarks/mark?op=add&amp;bkmk=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;title=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="Google" alt="Google" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/google.png"></img>
                        </a>
                        <a title="Yahoo Buzz" rel="nofollow" target="_blank" href="http://buzz.yahoo.com/submit?submitUrl=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED&amp;u=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/" shape="rect">
                          <img title="Yahoo Buzz" alt="Yahoo Buzz" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/yahoobuzz.png"></img>
                        </a>
                        <a 
                        title="StumbleUpon" rel="nofollow" target="_blank" href="http://stumbleupon.com/submit?url=http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/&amp;title=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED&amp;newcomment=NEW NOISE POLLUTION LAWS/CITY ORDINANCES REQUIRED" shape="rect">
                          <img title="StumbleUpon" alt="StumbleUpon" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/stumbleupon.png"></img>
</a>
                        <a title="Weekend Joy" target="_blank" href="http://www.weekendjoy.com/?f=aHR0cDovL3d3dy5sdXh1cnlsb2Z0LmNvbS9ibG9nLzIwMTEvMDUvbmV3LW5vaXNlLXBvbGx1dGlvbi1sYXdzY2l0eS1vcmRpbmFuY2VzLXJlcXVpcmVkLw==&amp;l=en-US" shape="rect">
                          <img title="Weekend Joy" alt="Weekend Joy" style="width:24px;height:24px;border:0px;" src="http://www.luxuryloft.com/blog/wp-content/plugins/wp-social-bookmarking/images/weekendjoy.png"></img>
                        </a>
                      </b>
                    </b>
                  </div>
                  <b>
                    <b>
                      <br clear="none"></br>
                      <script type="text/javascript"> (function() { var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true; po.src = 'https://apis.google.com/js/plusone.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s); })(); </script>
                    </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        Tags:
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/311/" shape="rect">311</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/city-noise/" shape="rect">city noise</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/city-ordinance/" shape="rect">city ordinance</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/hearing-loss/" shape="rect">hearing loss</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/hypertension/" shape="rect">hypertension</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/law/" shape="rect">law</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/leonard-steinberg/" shape="rect">Leonard Steinberg</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/manhattan-noise/" shape="rect">Manhattan noise</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/new-york-noise/" shape="rect">New York noise</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/noise-pollution/" shape="rect">noise pollution</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/quality-of-life/" shape="rect">quality of life</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/real-estate-valuations/" shape="rect">real estate valuations</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/sleep-disturbance/" shape="rect">sleep disturbance</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/stress/" shape="rect">stress</a>
                        ,
                        <a rel="tag" href="http://www.luxuryloft.com/blog/tag/tinnitus/" shape="rect">tinnitus</a>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p class="postmetadata alt">
                    <b>
                      <b>
                        <small>
                          This entry was posted
												on Saturday, May 28th, 2011 at 4:36 pm						and is filed under
                          <a rel="category tag" title="View all posts in Real Estate" href="http://www.luxuryloft.com/blog/category/real-estate/" shape="rect">Real Estate</a>
                          .
						You can follow any responses to this entry through the
                          <a href="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/feed/" shape="rect">RSS 2.0</a>
                          feed.

													You can
                          <a href="#respond" shape="rect">leave a response</a>
                          , or
                          <a rel="trackback" href="http://www.luxuryloft.com/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/trackback/" shape="rect">trackback</a>
                          from your own site.
                        </small>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                </div>
                <b>
                  <b> </b>
                </b>
</div>
              <b>
                <b> </b>
              </b>
              <div id="respond">
                <b>
                  <b> </b>
                </b>
                <h3>
                  <b>
                    <b>Leave a Reply</b>
                  </b>
                </h3>
                <b>
                  <b> </b>
                </b>
                <div class="cancel-comment-reply">
                  <b>
                    <b>
                      <small>
                        <a style="display:none;" href="/blog/2011/05/new-noise-pollution-lawscity-ordinances-required/#respond" rel="nofollow" id="cancel-comment-reply-link" shape="rect">Click here to cancel reply.</a>
                      </small>
                    </b>
                  </b>
                </div>
                <b>
                  <b> </b>
                </b>
                <form action="http://www.luxuryloft.com/blog/wp-comments-post.php" id="commentform" method="post" enctype="application/x-www-form-urlencoded">
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <input aria-required="true" size="22" value="" name="author" id="author" type="text" tabindex="1"></input>
                        <label for="author">
                          <small>Name (required)</small>
                        </label>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <input aria-required="true" size="22" value="" name="email" id="email" type="text" tabindex="2"></input>
                        <label for="email">
                          <small>Mail (will not be published) (required)</small>
                        </label>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <input size="22" value="" name="url" id="url" type="text" tabindex="3"></input>
                        <label for="url">
                          <small>Website</small>
                        </label>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <textarea name="comment" id="comment" tabindex="4" rows="10" cols="58"></textarea>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p>
                    <b>
                      <b>
                        <input value="Submit Comment" name="submit" id="submit" type="submit" tabindex="5"></input>
                        <input value="1022" name="comment_post_ID" id="comment_post_ID" type="hidden"></input>
                        <input value="0" name="comment_parent" id="comment_parent" type="hidden"></input>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b> </b>
                  </b>
                  <p style="display: none;">
                    <b>
                      <b>
                        <input value="056918835a" name="akismet_comment_nonce" id="akismet_comment_nonce" type="hidden"></input>
                      </b>
                    </b>
                  </p>
                  <b>
                    <b>
                      <script type="text/javascript"> var RecaptchaOptions = { theme : 'white', tabindex : 5 }; </script>
                      <script src="http://api.recaptcha.net/challenge?k=6Le8PgsAAAAAABpMEooPpe2b62DFD9qkUL_13N3B" type="text/javascript"></script>
                    </b>
                  </b>
                  <noscript>
                    <b>
                      <b>
                        <iframe width="500" height="300" src="http://api.recaptcha.net/noscript?k=6Le8PgsAAAAAABpMEooPpe2b62DFD9qkUL_13N3B" scrolling="auto" frameborder="0"></iframe>
                        <br clear="none"></br>
                        <textarea name="recaptcha_challenge_field" rows="3" cols="40"></textarea>
                        <input value="manual_challenge" name="recaptcha_response_field" type="hidden"></input>
                      </b>
                    </b>
                  </noscript>
                  <b>
                    <b> </b>
                  </b>
                  <div id="recaptcha-submit-btn-area">
                    <b>
                      <b></b>
                    </b>
                  </div>
                  <b>
                    <b>
                      <script type="text/javascript">
                        var sub = document.getElementById('submit');
			sub.parentNode.removeChild(sub);
			document.getElementById('recaptcha-submit-btn-area').appendChild (sub);
			document.getElementById('submit').tabIndex = 6;
			if ( typeof _recaptcha_wordpress_savedcomment != 'undefined') {
				document.getElementById('comment').value = _recaptcha_wordpress_savedcomment;
			}
                      </script>
                    </b>
                  </b>
                  <noscript>
                    <b>
                      <b>
                        <style type="text/css">#submit {display:none;}</style>
                        <input value="Submit Comment" name="submit" id="submit-alt" type="submit" tabindex="6"></input>
                      </b>
                    </b>
                  </noscript>
                  <b>
                    <b> </b>
                  </b>
                </form>
                <b>
                  <b> </b>
                </b>
              </div>
              <b>
                <b> </b>
              </b>
            </div>
            <b>
              <b> </b>
            </b>
            <div role="complementary" id="sidebar">
              <b>
                <b> </b>
              </b>
              <ul>
                <li>
                  <b>
                    <b> </b>
                  </b>
                </li>
                <li id="categories-3" class="widget widget_categories">
                  <b>
                    <b></b>
                  </b>
                  <h2 class="widgettitle">
                    <b>
                      <b>Categories</b>
                    </b>
                  </h2>
                  <b>
                    <b> </b>
                  </b>
                  <ul>
                    <li class="cat-item cat-item-4">
                      <b>
                        <b>
                          <a title="View all posts filed under Gossip" href="http://www.luxuryloft.com/blog/category/gossip/" shape="rect">Gossip</a>
                        </b>
                      </b>
                    </li>
                    <li class="cat-item cat-item-3">
                      <b>
                        <b>
                          <a title="View all posts filed under Real Estate" href="http://www.luxuryloft.com/blog/category/real-estate/" shape="rect">Real Estate</a>
                        </b>
                      </b>
                    </li>
                  </ul>
                  <b>
                    <b> </b>
                  </b>
                </li>
                <li id="archives-3" class="widget widget_archive">
                  <b>
                    <b></b>
                  </b>
                  <h2 class="widgettitle">
                    <b>
                      <b>Archives</b>
                    </b>
                  </h2>
                  <b>
                    <b> </b>
                  </b>
                  <ul>
                    <li>
                      <b>
                        <b>
                          <a title="October 2012" href="http://www.luxuryloft.com/blog/2012/10/" shape="rect">October 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="September 2012" href="http://www.luxuryloft.com/blog/2012/09/" shape="rect">September 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="August 2012" href="http://www.luxuryloft.com/blog/2012/08/" shape="rect">August 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="July 2012" href="http://www.luxuryloft.com/blog/2012/07/" shape="rect">July 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="June 2012" href="http://www.luxuryloft.com/blog/2012/06/" shape="rect">June 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="May 2012" href="http://www.luxuryloft.com/blog/2012/05/" shape="rect">May 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="April 2012" href="http://www.luxuryloft.com/blog/2012/04/" shape="rect">April 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="March 2012" href="http://www.luxuryloft.com/blog/2012/03/" shape="rect">March 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="February 2012" href="http://www.luxuryloft.com/blog/2012/02/" shape="rect">February 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="January 2012" href="http://www.luxuryloft.com/blog/2012/01/" shape="rect">January 2012</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="December 2011" href="http://www.luxuryloft.com/blog/2011/12/" shape="rect">December 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="November 2011" href="http://www.luxuryloft.com/blog/2011/11/" shape="rect">November 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="October 2011" href="http://www.luxuryloft.com/blog/2011/10/" shape="rect">October 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="September 2011" href="http://www.luxuryloft.com/blog/2011/09/" shape="rect">September 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="August 2011" href="http://www.luxuryloft.com/blog/2011/08/" shape="rect">August 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="July 2011" href="http://www.luxuryloft.com/blog/2011/07/" shape="rect">July 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="June 2011" href="http://www.luxuryloft.com/blog/2011/06/" shape="rect">June 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="May 2011" href="http://www.luxuryloft.com/blog/2011/05/" shape="rect">May 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="April 2011" href="http://www.luxuryloft.com/blog/2011/04/" shape="rect">April 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="March 2011" href="http://www.luxuryloft.com/blog/2011/03/" shape="rect">March 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="February 2011" href="http://www.luxuryloft.com/blog/2011/02/" shape="rect">February 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="January 2011" href="http://www.luxuryloft.com/blog/2011/01/" shape="rect">January 2011</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="December 2010" href="http://www.luxuryloft.com/blog/2010/12/" shape="rect">December 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="November 2010" href="http://www.luxuryloft.com/blog/2010/11/" shape="rect">November 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="October 2010" href="http://www.luxuryloft.com/blog/2010/10/" shape="rect">October 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="September 2010" href="http://www.luxuryloft.com/blog/2010/09/" shape="rect">September 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="August 2010" href="http://www.luxuryloft.com/blog/2010/08/" shape="rect">August 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="July 2010" href="http://www.luxuryloft.com/blog/2010/07/" shape="rect">July 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="June 2010" href="http://www.luxuryloft.com/blog/2010/06/" shape="rect">June 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="April 2010" href="http://www.luxuryloft.com/blog/2010/04/" shape="rect">April 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="March 2010" href="http://www.luxuryloft.com/blog/2010/03/" shape="rect">March 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="February 2010" href="http://www.luxuryloft.com/blog/2010/02/" shape="rect">February 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="January 2010" href="http://www.luxuryloft.com/blog/2010/01/" shape="rect">January 2010</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a title="December 2009" href="http://www.luxuryloft.com/blog/2009/12/" shape="rect">December 2009</a>
                        </b>
                      </b>
                    </li>
                  </ul>
                  <b>
                    <b> </b>
                  </b>
                </li>
                <li id="linkcat-2" class="widget widget_links">
                  <b>
                    <b></b>
                  </b>
                  <h2 class="widgettitle">
                    <b>
                      <b>Blogroll</b>
                    </b>
                  </h2>
                  <b>
                    <b> </b>
                  </b>
                  <ul class="xoxo blogroll">
                    <li>
                      <b>
                        <b>
                          <a target="_blank" title="Monthly Luxuryletter report" href="http://luxuryletter.com" shape="rect">Luxuryletter</a>
                        </b>
                      </b>
                    </li>
                  </ul>
                  <b>
                    <b> </b>
                  </b>
                </li>
                <li id="linkcat-54" class="widget widget_links">
                  <b>
                    <b></b>
                  </b>
                  <h2 class="widgettitle">
                    <b>
                      <b>Real Estate Links</b>
                    </b>
                  </h2>
                  <b>
                    <b> </b>
                  </b>
                  <ul class="xoxo blogroll">
                    <li>
                      <b>
                        <b>
                          <a target="_blank" href="http://www.curbed.com" shape="rect">Curbed</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a target="_blank" href="http://www.gawker.com" shape="rect">Gawker</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a target="_blank" title="Monthly Luxuryletter report" href="http://luxuryletter.com" shape="rect">Luxuryletter</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a target="_blank" href="http://www.nymag.com" shape="rect">New York Magazine</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a href="http://www.therealdeal.net" shape="rect">The Real Deal</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a target="_blank" href="http://www.triplemint.com" shape="rect">Triplemint</a>
                        </b>
                      </b>
                    </li>
                    <li>
                      <b>
                        <b>
                          <a target="_blank" href="http://www.urbandigs.com" shape="rect">Urbandigs</a>
                        </b>
                      </b>
                    </li>
                  </ul>
                  <b>
                    <b> </b>
                  </b>
                </li>
                <li id="search-3" class="widget widget_search">
                  <b>
                    <b></b>
                  </b>
                  <h2 class="widgettitle">
                    <b>
                      <b>Search Blog</b>
                    </b>
                  </h2>
                  <b>
                    <b></b>
                  </b>
                  <form action="http://www.luxuryloft.com/blog/" role="search" id="searchform" method="get" enctype="application/x-www-form-urlencoded">
                    <b>
                      <b> </b>
                    </b>
                    <div>
                      <b>
                        <b>
                          <label class="screen-reader-text" for="s">Search for:</label>
                          <input name="s" value="" id="s" type="text"></input>
                          <input value="Search" id="searchsubmit" type="submit"></input>
                        </b>
                      </b>
                    </div>
                    <b>
                      <b> </b>
                    </b>
                  </form>
                  <b>
                    <b></b>
                  </b>
                </li>
              </ul>
              <b>
                <b> </b>
              </b>
            </div>
            <b>
              <b> </b>
            </b>
          </td>
        </tr>
      </table>
      <b>
        <b> </b>
      </b>
      <div id="bg_shadow_feet">
        <b>
          <b></b>
        </b>
      </div>
      <b>
        <b> </b>
      </b>
      <div id="pde_logo_div">
        <b>
          <b>
            <img alt="Prudential Douglas Elliman" src="/images/pde_grey_logo.gif"></img>
          </b>
        </b>
      </div>
      <b>
        <b> </b>
      </b>
      <div id="disclaimer">
        <b>
          <b>
            All information regarding a property for sale, rental or financing is 
from sources deemed reliable. No representation is made as to the 
accuracy thereof, and such information is subject to errors, omission, 
change of price, rental, commission, prior sale, lease or financing, or 
withdrawal without notice. All square footage and dimensions are 
approximate. Exact dimensions can be obtained by retaining the services 
of a professional architect or engineer.
            <br clear="none"></br>
            <br clear="none"></br>
            Website design by
            <a target="_blank" href="http://www.versionindustries.com/" shape="rect">Version Industries</a>
            .
          </b>
        </b>
      </div>
      <b>
        <b> </b>
      </b>
      <div role="contentinfo" id="footer">
        <b>
          <b> </b>
        </b>
      </div>
      <b>
        <b> </b>
      </b>
    </div>
    <b>
      <b> </b>
    </b>
  </body>
</html>     
    reported   +|     bad   ,�     another   06     lead   .�     severe   .�     control   *�     
valuations   0     AC   *Q     new   (�     carry   (=         )http://en.wikipedia.org/wiki/Hypertension    hypertension   -�     �for those questioning me? Noise is also bad for your health in many ways, not only your ear drums.Â Noise pollution can cause annoyance and aggression,Â     �, high stress levels,Â  tinnitus , hearing loss, sleep disturbances, and other harmful effects. Furthermore, stress and hypertension are the leading causes to health problems,    hypertension      9202a8c04000641f800000000008a4af     %http://en.wikipedia.org/wiki/Tinnitus    tinnitus   -�     �is also bad for your health in many ways, not only your ear drums.Â Noise pollution can cause annoyance and aggression,Â  hypertension , high stress levels,Â     �, hearing loss, sleep disturbances, and other harmful effects. Furthermore, stress and hypertension are the leading causes to health problems, whereas tinnitus can lead to    tinnitus      9202a8c04000641f80000000000ae8dd    >��    Nhttp://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape    �><html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Intended Consequences: Rwanda's Children of Rape | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape/rss" title="Comments on: Intended Consequences: Rwanda's Children of Rape" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/rape" shape="rect">rape</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/genocide" shape="rect">genocide</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Rwanda" shape="rect">Rwanda</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Tutsi" shape="rect">Tutsi</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Hutu" shape="rect">Hutu</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Jonathan" shape="rect">Jonathan</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Torgovnik" shape="rect">Torgovnik</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/HIV" shape="rect">HIV</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/AIDS" shape="rect">AIDS</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/photography" shape="rect">photography</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Intended%20Consequences%3A%20Rwanda%27s%20Children%20of%20Rape%20http%3A%2F%2Fmefi%2Eus%2Fw%2F81016" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Intended Consequences: Rwanda's Children of Rape
        <br clear="none"></br>
        <span class="smallcopy">
          April 20, 2009 12:28 PM  
          <a href="http://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/81016/Intended-Consequences-Rwandas-Children-of-Rape/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://mediastorm.org/0024.htm" shape="rect">Intended Consequences.</a>
        It is estimated that 20,000 children were born as the result of rape during the 1994
        <a href="http://en.wikipedia.org/wiki/Rwandan_Genocide" shape="rect">Rwandan Genocide</a>
        that claimed the lives of over 800,000 Tutsis. Many of these women also contracted HIV/AIDS as a result. Not only do the mothers have to live with memories of this incredibly horrible event, but they along with their children are shunned by other Tutsi survivors.
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        Photographer
        <a href="http://www.torgovnik.com/" shape="rect">Jonathan Torgovnik</a>
        photographed and documented the stories of several of these women and their children in his new book Intended Consequences. He has also created
        <a href="http://www.foundationrwanda.org/" shape="rect">Foundation Rwanda</a>
        to help these families pay the $150 annual fee for their children's educations.
        <br clear="none"></br>
        <br clear="none"></br>
        <small>
          Disclaimer: The title of this post and some of the content is based on an article in the current issue of
          <a href="http://www.popphoto.com/" shape="rect">American Photo</a>
          which is currently only in print and not yet online.
        </small>
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/24066" shape="rect">itchylick</a>
        (22 comments total)
        <span id="favcnt181016">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/81016" shape="rect">9 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2534714" shape="rect"></a>
    <div class="comments">
      The scale and scope of this is really hard for me to comprehend and I don't know what to do other than give some money to the Foundation Rwanda.  Just...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/46088" shape="rect">Burhanistan</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534714" shape="rect">12:45 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534721" shape="rect"></a>
    <div class="comments">
      My god.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/73805" shape="rect">Flex1970</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534721" shape="rect">12:51 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534724" shape="rect"></a>
    <div class="comments">
      What is it about being poor that makes people flip out and mass rape/genocide other people? I guess I could see the evolutionary advantage of such.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66354" shape="rect">norabarnacl3</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534724" shape="rect">12:52 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534760" shape="rect"></a>
    <div class="comments">
      <em>What is it about being poor that makes people flip out and mass rape/genocide other people? I guess I could see the evolutionary advantage of such.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      What is it about spoiled office workers that cause them to make horribly flippant and ignorant comments?  I guess I can't really see the advantage of such.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/46088" shape="rect">Burhanistan</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534760" shape="rect">1:11 PM</a>
        on April 20, 2009 [
        <a title="11 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2534760" shape="rect">11 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534783" shape="rect"></a>
    <div class="comments">
      <a href="http://www.walrusmagazine.com/articles/2009.05-no-small-mercy-jina-moore-rwanda-genocide/" shape="rect">No Small Mercy: How a Rwandan genocide survivor made peace with the man who almost killed her</a>
      (Somewhat related)
      <br clear="none"></br>
      <br clear="none"></br>
      I had meant to make a post about this, but this is as good of a place as any.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15003" shape="rect">zabuni</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534783" shape="rect">1:24 PM</a>
        on April 20, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2534783" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534789" shape="rect"></a>
    <div class="comments">
      <em>What is it about being poor that makes people flip out and mass rape/genocide other people?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      If you're genuinely interested, and not just being making a hideously inappropriate glib comment, then I do recommend
      <a href="http://www.booknotes.org/Program/?ProgramID=1490" shape="rect">
        Philip Gourevitch's
        <em>We wish to inform you that tomorrow we will be killed with our families: Stories from Rwanda</em>
      </a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50911" shape="rect">liquidindian</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534789" shape="rect">1:25 PM</a>
        on April 20, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2534789" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534790" shape="rect"></a>
    <div class="comments">
      I would also that the article I mentioned is a good look into the mind of someone who actually commited these crimes.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15003" shape="rect">zabuni</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534790" shape="rect">1:25 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534795" shape="rect"></a>
    <div class="comments">
      Check out whose birthday it is; you don't need to be poor to genocide.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/40221" shape="rect">adipocere</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534795" shape="rect">1:26 PM</a>
        on April 20, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2534795" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534807" shape="rect"></a>
    <div class="comments">
      After seeing the main memorial and the mass graves which accompany it in Kigali, I never looked at the people again in the same way. My emotions were divided between compassion and contempt. Was I looking into the eyes of a victim, or a murderer? Or are they all victims?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/27288" shape="rect">gman</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534807" shape="rect">1:30 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534841" shape="rect"></a>
    <div class="comments">
      <em>Check out whose birthday it is</em>
      <br clear="none"></br>
      <br clear="none"></br>
      So it is.  Weird.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/46088" shape="rect">Burhanistan</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534841" shape="rect">1:40 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534843" shape="rect"></a>
    <div class="comments">
      <i>If you're genuinely interested, and not just being making a hideously inappropriate glib comment, then I do recommend Philip Gourevitch's We wish to inform you that tomorrow we will be killed with our families: Stories from Rwanda.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      I am genuinely curious. Care to summarize?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66354" shape="rect">norabarnacl3</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534843" shape="rect">1:41 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534849" shape="rect"></a>
    <div class="comments">
      <em>I would also that the article I mentioned is a good look into the mind of someone who actually commited these crimes.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      That article was hard to read. Jesus Christ.
      <br clear="none"></br>
      <br clear="none"></br>
      This is one of the most powerful things I've ever read, from Rebecca West. I think she's writing about the Balkans, but it applies here:
      <br clear="none"></br>
      <br clear="none"></br>
      <em>
        Only part of us is sane: only part of us loves pleasure and the longer day of happiness, wants to live to our nineties and die in peace, in a house that we built, that shall shelter those who come after us. The other half of us is nearly mad. It prefers the disagreeable to the agreeable, loves pain and its darker night despair, and wants to die in a catastrophe that will set back life to its beginnings and leave nothing of our house save its blackened foundations.
      </em>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/75964" shape="rect">A Terrible Llama</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534849" shape="rect">1:45 PM</a>
        on April 20, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2534849" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534877" shape="rect"></a>
    <div class="comments">
      <em>What is it about being poor that makes people flip out and mass rape/genocide other people?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      It's not a matter of being poor as such.
      <br clear="none"></br>
      <br clear="none"></br>
      I think the quote from Rebecca West that
      <strong>A Terrible Llama</strong>
      quotes above is partly right-- we all, rich
      <em>and</em>
      poor, want to live to our 90's, live in peace, seek happiness, and want to live in comfort.
      <br clear="none"></br>
      <br clear="none"></br>
      Attaining that is easier for some than it is for others.  There are many reasons why one may think this is so -- money is one.  Race is another.  Or nationality.  Or ethnicity.  Or...any number of things.  And some of these factors are true -- if you have money, it is easier for you to purchase the things you need for that life of comfort.  (Mind you, it's also easier for you to consider more things as being essential to that life of ease, but we'll set that aside for the moment...)
      <br clear="none"></br>
      <br clear="none"></br>
      And it's when you have trouble getting that kind of life that you may start wondering, well, why
      <em>don't</em>
      I get what I want?  I do all the right things, don't I?  I work, don't I?  I do all the things I'm supposed to do, and yet I'm still not as far ahead as I wanted.  What could be the reason for that?....some of the people who ask this question turn inward; they need a better job/better education/better conditions to live in, and they work to attain that.  Others, however, fall prey to blaming someone else for the reason they're a have-not; &quot;the reason I don't have a good job is because someone else took it.  If they weren't around,
      <em>I'd</em>
      be the one with that good job.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      Take that kind of thinking and escalate it through generations of conditioning, or desperation on your part, and eventually something explodes.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/73800" shape="rect">EmpressCallipygos</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534877" shape="rect">1:57 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2534905" shape="rect"></a>
    <div class="comments">
      Now that I've crawled back out of my dark corner and stopped rocking by myself after watching that video...
      <br clear="none"></br>
      <br clear="none"></br>
      It's stunning to me.  I cannot fathom what it must be like to have lived through something like this, let alone to have birthed a reminder.  The children who are not welcome because they are products of this horrible time, I weep for them.  I weep for the women who find the courage to talk, and even more for those who are broken beyond speech.
      <br clear="none"></br>
      <br clear="none"></br>
      Mostly, I'm really fucking pissed off that it was allowed to happen.  I really haven't thought through my opinions about my country interfering in the internal affairs of another, but Jebus!
      <br clear="none"></br>
      <br clear="none"></br>
      Is this similar to what we are allowing to happen in Darfur?
      <br clear="none"></br>
      <br clear="none"></br>
      I will probably wake up screaming having dreamt of that footage of a man hacking another person to death.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2534905" shape="rect">2:09 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535031" shape="rect"></a>
    <div class="comments">
      Also:
      <a href="http://www.nytimes.com/2002/09/15/magazine/a-woman-s-work.html?sec=&amp;spon=&amp;pagewanted=print" shape="rect">A womans work</a>
      , NYT 2002. It's just bloody horrible stuff:
      <br clear="none"></br>
      <br clear="none"></br>
      <em>
        In an interview at the State House in Kigali, Rwanda's president, Paul Kagame, talked about the mass rapes in measured, contemplative sentences, shaking his head, his emotions betraying him. &quot;We knew that the government was bringing AIDS patients out of the hospitals specifically to form battalions of rapists,&quot; he told me. He smiled ruefully, as if still astonished by the plan.
      </em>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/71291" shape="rect">monocultured</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535031" shape="rect">3:34 PM</a>
        on April 20, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2535031" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535061" shape="rect"></a>
    <div class="comments">
      <em>Is this similar to what we are allowing to happen in Darfur?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Unfortunately yes, and also in the DRC where estimates put the number of rapes at 42,000 in South Kivu and 45,000 in North Kivu respectively. Per year.
      <br clear="none"></br>
      <br clear="none"></br>
      In fact Major General
      <a href="http://en.wikipedia.org/wiki/Patrick_Cammaert" shape="rect">Patrick Cammaert</a>
      , the former UN Peacekeeping Operation commander in the DRC has said that it is now more dangerous to be a woman than to be a soldier in modern conflict.
      <br clear="none"></br>
      <br clear="none"></br>
      Rape is used as a weapon of war to humiliate, to terrorize, to divide (many women are rejected by their families and/or communities after being a victim of rape), and even to purposefully change the ethnic makeup of a given area.
      <br clear="none"></br>
      <br clear="none"></br>
      And sadly as this piece shows, there is still a long way to go before justice is served for the victims, and for their voices to be heard in the peace and reconciliation process.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/72979" shape="rect">vodkaboots</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535061" shape="rect">3:51 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535065" shape="rect"></a>
    <div class="comments">
      We also have to remember that this is ongoing in the Congo. This war never ended; it just moved to the Eastern DRC, where the same dynamics are in play have been for over a decade now, and the death toll, sexual violence, and HIV rates are staggering. In
      <a href="http://www.amazon.com/exec/obidos/ASIN/0061240478/metafilter-20/ref=nosim/" shape="rect">my work</a>
      I met many children who were forced, as soldiers, to commit countless rapes, who carry AIDS and are shunned as both perpetrators and as victims, and who, remarkably, find ways to get up in the morning, to survive, heal, and in some cases, to help others to heal. I met young survivors of rape who worked to try to remove the stigma surrounding them, and I met children who'd escaped the genocide in Rwanda, only to find the war in the Congo erupt around them, and who had, someone, kept hope for their future. They are remarkable people.
      <br clear="none"></br>
      <br clear="none"></br>
      Telling these stories is an essential step, so thank you for this post. Provoking the international political will to stop these atrocities in the Congo is the next step. Urge your government to support more resources for MONUC, the peacekeeping mission in the Congo, so that the perpetrators of these crimes can be caught or killed and the conflict can at last come to a close, and for
      <a href="http://www.refintl.org/policy/field-report/dr-congo-adapt-strategies-assist-vulnerable-people" shape="rect">NGOs working to mitigate the worst of the suffering</a>
      .
      <a href="http://www.enoughproject.org/conflict_areas/eastern_congo" shape="rect"> And Learn more. </a>
      There is a lot you can do, even just by how you shop. Read
      <a href="http://www.enoughproject.org/publications/can-you-hear-congo-now-cell-phones-conflict-minerals-and-worst-sexual-violence-world" shape="rect">Can You Hear Congo Now? Cell Phones, Conflict Minerals, and the Worst Sexual Violence in the World</a>
      for a look at how this conflict has continued since shifting from Rwanda to the Congo and how we might be complicit in it.
      <br clear="none"></br>
      <br clear="none"></br>
      Now I need a stiff drink...
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/42472" shape="rect">cal71</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535065" shape="rect">3:53 PM</a>
        on April 20, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2535065" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535093" shape="rect"></a>
    <div class="comments">
      <em>I am genuinely curious. Care to summarize?</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Summarize?  No.  I wouldn't dare.  Far too complex, and I read it too long ago for me to try without messing up.  The problem in understanding what happened, though, lies in our need for heroes and villians, victims and persecutors, and looking for a need for a simple narrative.  The problems go back to at least 1931, when Belgium issued identity cards that strictly divided the Hutus and Tutsis.  But before then the German colonialists began this process of division, so it goes back to 1900.
      <br clear="none"></br>
      <br clear="none"></br>
      The wikipedia entry
      <a href="http://en.wikipedia.org/wiki/History_of_Rwanda" shape="rect">here</a>
      gives an overview, but if you can read that and feel you have a full understanding of the causes of the genocide, you're a better person than me.  No doubt poverty played some part.  I wouldn't dare comment on the sociobiology side.  So you're not wrong as such, it's just much much more complex than that.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50911" shape="rect">liquidindian</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535093" shape="rect">4:17 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535120" shape="rect"></a>
    <div class="comments">
      <em>No doubt poverty played some part.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Not an argument with your point... I just don't see how we can watch this footage and classify these people as &quot;poor.&quot;  Assuredly, compared to even the poorest Americans, they appear impoverished.  But is that a fair rubric to use?  I see people with houses, who don't look underfed...
      <br clear="none"></br>
      <br clear="none"></br>
      I've never been to Africa, but recently have been watching The First Ladies Detective Agency on HBO, set in Botswana.  Some side reading I did about the production says that the series depicts a prosperous African country, and that it is set in its capital city.  The series was filmed on location, so I'm sure this isn't some false sense of how life is there.  But when I watch the series, my American eyes see people cooking over open fires, see unpaved roads more than pavement, see characters wearing the same clothes repeatedly, I assume because they own a limited supply.
      <br clear="none"></br>
      <br clear="none"></br>
      Yes, these are fictional characters, but my understanding is that the filmmakers went to lengths to reflect the true Botswana in their production.  Yet it looks poor to me.
      <br clear="none"></br>
      <br clear="none"></br>
      Sometimes poverty isn't what we think it is here in the land of too much.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535120" shape="rect">4:52 PM</a>
        on April 20, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535551" shape="rect"></a>
    <div class="comments">
      <em>
        Not an argument with your point... I just don't see how we can watch this footage and classify these people as &quot;poor.&quot; Assuredly, compared to even the poorest Americans, they appear impoverished. But is that a fair rubric to use? I see people with houses, who don't look underfed...
      </em>
      <br clear="none"></br>
      <br clear="none"></br>
      You're right, of course.  I think that part of the Hutu/Tutsi divide could be seen as a 'class' divide as well as an ethnic, with wealth inequally distributed, but that doesn't necessarily mean 'poverty'.  Again, I don't know enough.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50911" shape="rect">liquidindian</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535551" shape="rect">5:08 AM</a>
        on April 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2535939" shape="rect"></a>
    <div class="comments">
      <em>I don't know enough.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Ditto.  I'm extrapolating without real information.  (and trying to wake up my American mind to the fact that hardly anyone else in the world lives like we do.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2535939" shape="rect">12:04 PM</a>
        on April 21, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2536625" shape="rect"></a>
    <div class="comments">
      I've studied a bit about Rwanda, and there are some other factors to consider. One important one is how crowded the country was, and how much farmland there was per family - it was getting to where a well-off family would have, say, more than two acres on which to grow food to feed themselves. Most had less.
      <br clear="none"></br>
      Families in Rwanda typically have a lot of children, like 4-8. Inheritance of family farming land became hugely, hugely contentious. It used to be traditional to leave it all to the oldest son, but parents started dividing it up, partly because youngest sons traditionally would take care of the parents as they got old (so they wanted to make sure he had land to feed them with). So then the oldest son would get married and they would measure out and give him some land, and then the other kids would get angry - what if the family has to sell land? Then we won't get as much as he did - that sort of thing. And as these farms got smaller and smaller, that's what happened. Families would sell off land because they were having trouble feeding the family during a bad year. Better-off families who had two acres or more would have extra produce to sell, and then they could buy people's land adjacent to theirs when it became available.
      <br clear="none"></br>
      As this went along, it tore up families and pitted neighbor against neighbor. Hideous lawsuits brought by children against parents, nephews against aunts and uncles, filled up the courts and turned into family feuds. Envy of the family up the road who could afford shoes for their kids turned into hatred, coming from families whose kids were barefoot.
      <br clear="none"></br>
      The people who committed the murders during the genocide often knew their victims, and had long-standing grievances against them - real or perceived injustices, or just dire envy.
      <br clear="none"></br>
      And that's on
      <em>top</em>
      of the historical racial issues.
      <br clear="none"></br>
      <br clear="none"></br>
      As I recall,
      <a href="http://en.wikipedia.org/wiki/Rom%C3%A9o_Dallaire" shape="rect">RomÃ©o Dallaire</a>
      thought that with enough troops he could have stopped the genocide as it caught fire around him. But the more I've read about it, the less sure I am that it could have been stopped. Meaning no disrespect to him, mind you. He did an incredible job with what/who he had. It's just that it was everywhere all at once, practically.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/64237" shape="rect">ysabella</a>
        at
        <a target="_self" href="/81016/Intended-Consequences-Rwandas-Children-of-Rape#2536625" shape="rect">1:50 AM</a>
        on April 22, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/81015/Soldiers-Stress-What-Doctors-Get-Wrong-About-PTSD" shape="rect">« Older</a>
      Soldiers' Stress: What Doctors Get Wrong About PTS...  |  This is a fun little atheistic...
      <a target="_self" href="/81017/The-Blind-Watchmaker-applet" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/93503/Being-just-is-inhuman" shape="rect">&quot;Being just is inhuman.&quot;</a>
      <span class="smallcopy">July 6, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/89385/Luna-Commons" shape="rect">Luna Commons</a>
      <span class="smallcopy">February 20, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/83434/Forgiveness" shape="rect">Forgiveness</a>
      <span class="smallcopy">July 20, 2009</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/41307/Rwandan-Genocide" shape="rect">Rwandan Genocide</a>
      <span class="smallcopy">April 18, 2005</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/8387/catholic-priests-in-africa" shape="rect">catholic priests in africa</a>
      <span class="smallcopy">June 18, 2001</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    new   /�     annual   0:     Children   +h     born   --     lives   -�     book   /�     print   17     but   .d     were   -(     	Torgovnik   /7         -http://en.wikipedia.org/wiki/Rwandan_Genocide    Rwandan Genocide   -�     �April 20, 2009 12:28 PM   Subscribe Intended Consequences. It is estimated that 20,000 children were born as the result of rape during the 1994    �that claimed the lives of over 800,000 Tutsis. Many of these women also contracted HIV/AIDS as a result. Not only do the mothers have to    Rwandan Genocide      9202a8c04000641f800000000031088d    >��    =http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress   ^<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>The Earth is a Harsh Mistress | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress/rss" title="Comments on: The Earth is a Harsh Mistress" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/environment" shape="rect">environment</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/malthus" shape="rect">malthus</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/malthusianism" shape="rect">malthusianism</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/collapse" shape="rect">collapse</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/ecopocalypse" shape="rect">ecopocalypse</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20The%20Earth%20is%20a%20Harsh%20Mistress%20http%3A%2F%2Fmefi%2Eus%2Fw%2F81093" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        The Earth is a Harsh Mistress
        <br clear="none"></br>
        <span class="smallcopy">
          April 23, 2009 2:30 PM  
          <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://en.wikipedia.org/wiki/Lester_R._Brown" shape="rect">Lester R. Brown</a>
        , of
        <a href="http://en.wikipedia.org/wiki/Worldwatch_Institute" shape="rect">Worldwatch</a>
        and the
        <a href="http://en.wikipedia.org/wiki/Earth_Policy_Institute" shape="rect">Earth Policy Institute</a>
        , has an article in May's Scientific American magazine:
        <a href="http://www.sciam.com/article.cfm?id=civilization-food-shortages" shape="rect">&quot;Could Food Shortages Bring Down Civilization?&quot;</a>
        In the article he addresses three major food-security threats: increased demand, due to the
        <a href="http://www.csmonitor.com/2008/0421/p15s01-wmgn.html" shape="rect">burgeoning population</a>
        and diversion of staples for
        <a href="http://www.theoildrum.com/node/2615" shape="rect">energy production</a>
        ; water shortages due to
        <a href="http://www.eoearth.org/article/Aquifer_depletion" shape="rect">&quot;mining&quot; of fossil aquifers</a>
        ; and
        <a href="http://www.seattlepi.com/national/348200_dirt22.html?source=mypi" shape="rect">topsoil depletion</a>
        as a result of over-farming. The result? Civilization's demise, not through superpower conflict, but through chaos and
        <a href="http://www.fundforpeace.org/web/index.php?option=com_content&amp;task=view&amp;id=99&amp;Itemid=140" shape="rect">failed states</a>
        .
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        His preferred solution â€” which is also the title of an EPI
        <a href="http://www.earth-policy.org/Books/PB3/index.htm" shape="rect">book</a>
        (
        <a href="http://www.metafilter.com/72985/Lester-Browns-Plan-B-30" shape="rect">previously</a>
        on MeFi) â€” is a dramatic &quot;Plan B&quot; for civilization, involving population stabilization, poverty eradication, and water, soil and forest preservation.
        <br clear="none"></br>
        <br clear="none"></br>
        Both his conclusions and his plan are not without criticism.
        <a href="http://www.associatedcontent.com/article/738983/world_food_crisis_explained_in_one.html" shape="rect">Some question</a>
        what's behind the looming shortages in the first place, while others have faith that
        <a href="http://www.canadafreepress.com/index.php/article/3623" shape="rect">technology</a>
        <a href="http://www.americanchronicle.com/articles/printFriendly/92854" shape="rect">will provide the solutions</a>
        .
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/36800" shape="rect">Kadin2048</a>
        (42 comments total)
        <span id="favcnt181093">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/81093" shape="rect">10 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2538516" shape="rect"></a>
    <div class="comments">
      Well it will certainly be fun to watch and find out!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66354" shape="rect">norabarnacl3</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538516" shape="rect">2:45 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538521" shape="rect"></a>
    <div class="comments">
      Just stop having kids. That's one silver bullet solution to our environmental problems that the green movement doesn't mention.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18384" shape="rect">mullingitover</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538521" shape="rect">2:51 PM</a>
        on April 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538521" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538524" shape="rect"></a>
    <div class="comments">
      It would largely depend on how you define &quot;civilization.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/36398" shape="rect">lekvar</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538524" shape="rect">2:54 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538524" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538527" shape="rect"></a>
    <div class="comments">
      You know
      <a href="http://www.metafilter.com/81091/Achtung" shape="rect">who else</a>
      had a dramatic plan for civilization?
      <br clear="none"></br>
      <br clear="none"></br>
      But Mr. Brown and mullingitover are correct.
      <a href="http://en.wikipedia.org/wiki/The_Population_Bomb" shape="rect">The population bomb</a>
      is ticking away and there are no pleasant ways to defuse it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/84281" shape="rect">Joe Beese</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538527" shape="rect">2:57 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538527" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538529" shape="rect"></a>
    <div class="comments">
      <blockquote>Just stop having kids. That's one silver bullet solution to our environmental problems that the green movement doesn't mention.</blockquote>
      Some of them  do.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/87277" shape="rect">Electric Dragon</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538529" shape="rect">3:00 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538532" shape="rect"></a>
    <div class="comments">
      Ok, what happened to my link?
      <a href="http://women.timesonline.co.uk/tol/life_and_style/women/families/article5627634.ece" shape="rect">Here it is</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/87277" shape="rect">Electric Dragon</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538532" shape="rect">3:01 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538536" shape="rect"></a>
    <div class="comments">
      Population is a total red herring. You could stand 10 billion people in a 100 sq. km. area. The problem is one of production, distribution and disposal of all our stuff.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/41173" shape="rect">No Robots</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538536" shape="rect">3:03 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538536" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538546" shape="rect"></a>
    <div class="comments">
      <em>You could stand 10 billion people in a 100 sq. km. area.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      That is true but is not a serious argument. Clearly the &quot;population problem&quot; has nothing to do with standing room. A much more serious argument that has been advanced against the population problem is that well off populations tend to stabilize or even decline. While I'm not sure that the data we have so far on that is universally generalizable, it still merits consideration. However, it is subject to resource constraints, as there clearly is not enough &quot;stuff&quot; to go around right now to bring everyone in the world up to our standard of living. I have heard arguments that we are already in overshoot, and that nothing can stop an eventual collapse.
      <br clear="none"></br>
      <br clear="none"></br>
      Will we be able to get the majority of the global population to a stable point where population growth levels off while simultaneously keeping consumption to sustainable input flows? Only time will tell.
      <br clear="none"></br>
      <br clear="none"></br>
      I am, however, not all that hopeful.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66965" shape="rect">adamdschneider</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538546" shape="rect">3:11 PM</a>
        on April 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538546" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538547" shape="rect"></a>
    <div class="comments">
      Y'all oughta cheer up and show some
      <a href="http://www.urbandictionary.com/define.php?term=Malthusiasm" shape="rect">Malthusiasm</a>
      for a change.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/67334" shape="rect">mannequito</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538547" shape="rect">3:14 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538551" shape="rect"></a>
    <div class="comments">
      Look, Malthus has gotta go. Buckminster Fuller demonstrated in detail that resources are more than adequate to provide everyone with decent material conditions.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/41173" shape="rect">No Robots</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538551" shape="rect">3:16 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538555" shape="rect"></a>
    <div class="comments">
      What was the Easter Islander who cut down the last tree thinking?
      <br clear="none"></br>
      <br clear="none"></br>
      1. This tree is on MY land and the chiefs don't have any right to tell me what to do with MY tree.
      <br clear="none"></br>
      2. Science will find a replacement for trees.
      <br clear="none"></br>
      3. It is only a theory that this is the last tree, and the matter needs more research.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76921" shape="rect">benzenedream</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538555" shape="rect">3:20 PM</a>
        on April 23, 2009 [
        <a title="12 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538555" shape="rect">12 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538556" shape="rect"></a>
    <div class="comments">
      If there are any among the assembled company that have not read
      <a href="http://en.wikipedia.org/wiki/Stand_on_Zanzibar" shape="rect">
        <i>Stand on Zanzibar</i>
      </a>
      and
      <a href="http://en.wikipedia.org/wiki/The_Sheep_Look_Up" shape="rect">
        <i>The Sheep Look Up</i>
      </a>
      by
      <a href="http://en.wikipedia.org/wiki/John_Brunner_(novelist)" shape="rect">John Brunner</a>
      , I'd like to take this opportunity to recommend that you do so.
      <br clear="none"></br>
      <br clear="none"></br>
      For another interesting take on this same question try &quot;
      <a href="http://www.sciam.com/article.cfm?id=the-bottleneck" shape="rect">The Bottleneck</a>
      &quot; by Edward O. Wilson in
      <i>Scientific American</i>
      , February 2002.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76412" shape="rect">ob1quixote</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538556" shape="rect">3:24 PM</a>
        on April 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538556" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538557" shape="rect"></a>
    <div class="comments">
      <small>[Paraphrased from a radio interview with Jared Diamond]</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76921" shape="rect">benzenedream</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538557" shape="rect">3:25 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538591" shape="rect"></a>
    <div class="comments">
      You would be hard pressed to argue with just aout anything EO Wilson says, but I recall that in one of his books he notes that ur biggest threat would be the growing lack of drinkable water world-wide.
      <br clear="none"></br>
      <br clear="none"></br>
      Some guy recently suggested that the earth could renew itself, rather easily, if some 80% of the world's human population &quot;went away.&quot;  Science may provide food in various ways through uses of technology, but a huge expanding world population will use and destroy resources that are non-renewable and there is bound to be a massive increase in pollution, as, for example, the cars now being produced and bought in China and  India, added on to what the Western world consumes and pews out.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/2290" shape="rect">Postroad</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538591" shape="rect">4:05 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538600" shape="rect"></a>
    <div class="comments">
      I tend to take these kinds of apocalyptic predictions with a grain or two of salt, because I've been hearing them my entire adult life.
      <a href="http://urbin.net/blog/?p=196" shape="rect">For instance</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/85140" shape="rect">Chocolate Pickle</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538600" shape="rect">4:14 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538600" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538603" shape="rect"></a>
    <div class="comments">
      <em>Buckminster Fuller demonstrated in detail that resources are more than adequate to provide everyone with decent material conditions.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      This is true, but I doubt many would submit to allowing that to happen, especially here in the United States of Too Much.  In order to make such a thing work would require a restructuring of our society and expectations on a massive scale, and I don't think most who have become addicted to the teat of American consumerism will readily wean themselves.
      <br clear="none"></br>
      <br clear="none"></br>
      Not my personal viewpoint, but it's what I hear all around me these days.  I mean, what were all those
      <strike>ballsucking</strike>
      <strike>tea bagging</strike>
      tax day protest parties all about, if not protesting even the smallest measure of having a central authority suggest that we all might be better off if those who make a lot give up a little to share with those who have too little?
      <br clear="none"></br>
      <br clear="none"></br>
      <small>
        <small>
          <small>Yes, I know, most of it is right-wing pouting about having lost the election. But that doesn't support my point.</small>
        </small>
      </small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89363" shape="rect">hippybear</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538603" shape="rect">4:17 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538603" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538605" shape="rect"></a>
    <div class="comments">
      From
      <a href="https://listserv.umd.edu/cgi-bin/wa?A2=ind0812&amp;L=bobparks-whatsnew&amp;D=1&amp;H=1&amp;O=D&amp;T=0&amp;P=440" shape="rect">Bob Parks</a>
      (and if you don't subscribe, you should)
      <blockquote>
        Ehrlich thought a group of five metals would increase in price
        <br clear="none"></br>
        as they became scarce.  Simon thought the price would drop as new sources
        <br clear="none"></br>
        were found.  In a famous bet Simon won hands down and Ehrlich paid off.
        <br clear="none"></br>
        <br clear="none"></br>
        Simon once asked me why physicists never agree with him.  I said itâ€™s because they understand exponentials.
        <br clear="none"></br>
      </blockquote>
      As for how long it will take, here is a table:
      <br clear="none"></br>
      Yearly increase in population (percent)
      <br clear="none"></br>
      Years until the entire earth is covered with people (oceans included) (2 sq ft per person)
      <br clear="none"></br>
      Years until the entire volume of the earth is people (at 4 cubic feet per person)
      <pre> Pct Surface Volume 1% 1312 2827 2% 659 1420 3% 442 952 4% 333 717 5% 268 577 6% 224 483 7% 193 416 </pre>
      So ol' Bucky Fuller may not have been talking about
      <i>for all time</i>
      or maybe he had a secret plan.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/38917" shape="rect">hexatron</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538605" shape="rect">4:19 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538625" shape="rect"></a>
    <div class="comments">
      PEPOL HAV BEEN TALKING ABOUT RUNING OUT OF STUF AS RESENTLIY AS A FEW YEARS AGO AND WE ARENT AL DED YET SO THEY MUST BE RONG!!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19728" shape="rect">sourwookie</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538625" shape="rect">4:33 PM</a>
        on April 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538625" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538634" shape="rect"></a>
    <div class="comments">
      Fuller said quite plainly that we had only a short time to get our shit together, that there was a point of no return, and he said it a long time ago.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/82668" shape="rect">Restless Day</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538634" shape="rect">4:36 PM</a>
        on April 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538634" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538641" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress#2538521" shape="rect">mullingitover</a>
      : &quot;
      <i>Just stop having kids. That's one silver bullet solution to our environmental problems that the green movement doesn't mention.</i>
      &quot;
      <br clear="none"></br>
      <br clear="none"></br>
      Eh.. this doesn't add up. It's not the number of people so much as the lifestyle people choose to live. With the right techniques this planet could support many more people and still be healthy. We are just living in an environmental dark age still.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/1915" shape="rect">stbalbach</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538641" shape="rect">4:41 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538647" shape="rect"></a>
    <div class="comments">
      <i>You could stand 10 billion people in a 100 sq. km. area.</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Good God, can you imagine the decibel level from all their crappy music?  You'd be able to hear them
      <i>all at once</i>
      .  And their inappropriately loud ringtones, too!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76832" shape="rect">Michael Roberts</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538647" shape="rect">4:44 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538659" shape="rect"></a>
    <div class="comments">
      Funnily enough, I've just finished writing a long feature about urban farming, which involved some research of food security. We in the West can support ourselves far better than we do at the moment, taking some of the pressure off available land in the developing world. The downside is that this would reduce export earnings for some countries in the developing world, and they might be tempted to grow cash crops rather than feed their people. So the raw maths of food supply and demand only explains so much - what matters is reducing global inequality, and promoting social justice and democracy. (Democracies are less likely to use land for tobacco and carnations when people are starving.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/49890" shape="rect">WPW</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538659" shape="rect">4:49 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538659" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538669" shape="rect"></a>
    <div class="comments">
      which 80%?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/74856" shape="rect">double block and bleed</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538669" shape="rect">4:53 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538674" shape="rect"></a>
    <div class="comments">
      sorry, I'll try that again:
      <br clear="none"></br>
      <br clear="none"></br>
      <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress#2538591" shape="rect">Which 80%?</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/74856" shape="rect">double block and bleed</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538674" shape="rect">4:54 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538703" shape="rect"></a>
    <div class="comments">
      Um, doesn't the average number of children a family has decrease
      <strong>sharply</strong>
      once a certain level of development is reached?
      <br clear="none"></br>
      <br clear="none"></br>
      Aren't countries like Italy and Japan currently below the replacement level in new births?
      <br clear="none"></br>
      <br clear="none"></br>
      Isn't the population boom in part the crossover between:
      <br clear="none"></br>
      1. cultural norms encouraging lots of children with the assumption that a fair percentage will die
      <br clear="none"></br>
      2. improved public health saving those same children, resulting in larger average families.
      <br clear="none"></br>
      <br clear="none"></br>
      Isn't the concern in most of Western Europe more about a population leveling off, resulting in a disproportionate amount of old people?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16263" shape="rect">leotrotsky</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538703" shape="rect">5:16 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538711" shape="rect"></a>
    <div class="comments">
      Garrett Hardin was all over this back in 1968 with
      <em>
        <a href="http://en.wikipedia.org/wiki/Tragedy_of_the_commons" shape="rect">Tragedy of the Commons</a>
        ,
      </em>
      and was kind enough to
      <a href="http://en.wikipedia.org/wiki/Hemlock_Society" shape="rect">off himself</a>
      after he had finished just to prove his point.
      <br clear="none"></br>
      <br clear="none"></br>
      However, it's fairly likely that we'll soon have energy break-even with this latest generation of fusion reactors, meaning that large scale desalination/sanitation/whatever utilities will likely be a ubiquitous reality within a few generations (I'll ballpark it at 50-60 years, as the
      <a href="http://en.wikipedia.org/wiki/DEMO" shape="rect">DEMO tokamak</a>
      is set to be functional as of 2040 and it will take an additional 30 years to make its way to LDCs). To cover the gap in the meantime, someone should shut the Pope up and make a large investment in latex.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19185" shape="rect">The White Hat</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538711" shape="rect">5:24 PM</a>
        on April 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538711" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538715" shape="rect"></a>
    <div class="comments">
      Environmentalists like Lester Brown don't fear that the world will run out of food and that civilization will collapse, they
      <i>hope</i>
      that the world will run out of food and that civilization will collapse.  Obsessing about imaginary apocalypses reflects the bourgeoise wish for the annihilation of its own class -- or more personally, each individual bourgeoise wishes for the annihilation of his own &quot;self&quot;, with its burden of moral choice and onerous responsibility for creating an existence.  For such as these, the belief that the world is doomed is a comfort.  In asking us to picture an earth devoid of humanity, cracked, shriveled, and dry, they give us a snapshot of their own souls, poor bastards.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/10866" shape="rect">Faze</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538715" shape="rect">5:26 PM</a>
        on April 23, 2009 [
        <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538715" shape="rect">5 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538724" shape="rect"></a>
    <div class="comments">
      The White Hat:
      <em>&quot;To cover the gap in the meantime, someone should shut the Pope up and make a large investment in latex.&quot;</em>
      <br clear="none"></br>
      <br clear="none"></br>
      THIS
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18384" shape="rect">mullingitover</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538724" shape="rect">5:32 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538742" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress#2538703" shape="rect">leotrotsky's got it right.</a>
      <br clear="none"></br>
      <br clear="none"></br>
      Slowing population growth rates are a threat to developed and developing countries around the world. Not just in Europe. For example China is about to face the consequences of the 1 child policy as they're headed for a scenario where 1 working person's productivity has to potentially support up to 6 retired individuals (2 parents, 4 grandparents).
      <br clear="none"></br>
      The economies, political structures and social networks of almost all developed countries can only function if there's an ever increasing population so that retired and otherwise dependent individuals never outnumber the actively working.
      <br clear="none"></br>
      In Germany the retirement age has already been pushed back but that just takes away jobs from the next generation resulting in no net improvement.
      <br clear="none"></br>
      Cutting pensions, social services etc also doesn't help since it negatively impacts a population's buying power, which leads to shrinking profits and increasing unemployment negating any benefits almost immediately.
      <br clear="none"></br>
      I'm not sure if anything can be done to prevent further erosion of the systems in place other than pushing for continuing population growth which would of course amount to ecological suicide.
      <br clear="none"></br>
      <br clear="none"></br>
      I'm not a believer in doomsday scenarios but history teaches us that declines and erosion of structures can happen slowly. The roman empire didn't really end with a bang. Many aspects of life under the empire simply gradually vanished. Some probably so slowly that people barely notice within the course of a lifetime. What change one generation would notice would probably be laughed off by the next for whom the current situation is already normality. Of course things would not happen the same way for us. There is significantly more knowledge and know-how spread across a larger number of people today. So a path of decline today would probably look significantly different from anything that has occurred before.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/57144" shape="rect">Hairy Lobster</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538742" shape="rect">5:51 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538742" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538747" shape="rect"></a>
    <div class="comments">
      Faze, that seems like an uncharitable way of saying, &quot;Gosh, that's so gloomy.  They must be gloomy people.  I'm happy.  I believe in happy outcomes.&quot;  It doesn't actually prove anything one way or another.
      <br clear="none"></br>
      <br clear="none"></br>
      Either you think the Earth can support an infinite number of people, or you believe that only a finite amount (with varying lifestyles) may be sustainably supported.  Those who believe in the first case cannot be reasoned with; in the latter, it's just quibbling about the numbers.
      <br clear="none"></br>
      <br clear="none"></br>
      If you agree with the latter sentiment, then it comes down to realizing that, once that number is hit, the population growth must be zero.  If we are already above that number, then not only must population growth must be negative, but we must also check to make sure we have not acted too late and consumed too much, or our new carrying capacity will have dropped.
      <br clear="none"></br>
      <br clear="none"></br>
      Naturally, carrying capacity is about as useful as BMI is to weight loss.  It's a single number that isn't designed to be accurate so much as it is built to account for a number of factors and generally give you the idea that, yeah, at 350lb, &quot;big-boned&quot; does not cut it as an excuse anymore.  We can fudge it up and down from &quot;can everyone live like SUV-driving, steak-eating Americans?&quot; to &quot;we're wearing clothes made of corn shucks, living in a mud hut, and we're all on the edge of malnutrition.&quot;  You can get a lot more people if you go with the latter option.  Even as the birth rates in some countries drop as they reach levels of affluence, everyone in China suddenly wants a car, just like us.
      <br clear="none"></br>
      <br clear="none"></br>
      Sustainability isn't merely about trying to directly convert sunlight into food calories with as much efficiency as possible, it's about that fun chart a few days back showing how many years we could expect to still be able to mine, say, antimony.  It's about waiting for our aquifers to run dry.  This is not about a soft and fuzzy nature thing.  Screw the penguins.  It's about trying to run the planet like it was Biosphere 2, and finding our oxygen levels dropping.
      <br clear="none"></br>
      <br clear="none"></br>
      We have no new land to spread out into (and I've gone on enough about the utter non-solution of &quot;space, the final frontier&quot;).  We have nothing magical coming down the pipe.  Even if people would accept new food solutions from Monsanto, it's not enough.  We will have to turn back the population growth, smartly and with great alacrity, or we'll have some very hungry times.  Worse yet, we have to manage it while caring for our elderly, both physically and financially.
      <br clear="none"></br>
      <br clear="none"></br>
      Otherwise, the whole thing just starts to look like a Ponzi scheme written with &quot;be fruitful and multiply&quot; on the contract.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/40221" shape="rect">adipocere</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538747" shape="rect">5:54 PM</a>
        on April 23, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538747" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538753" shape="rect"></a>
    <div class="comments">
      <s>Environmentalists</s>
      Americans like
      <s>Lester Brown</s>
      Faze don't fear that the world will run out of food and that civilization will collapse, they
      <s>hope that the world will run out of food and that civilization will collapse </s>
      are willfully ignorant and refuse to look at reality.  Obsessing about
      <s>imaginary apocalypses</s>
      the psychological motivations of environmentalists reflects
      <s>the bourgeoise</s>
      their wish for the annihilation of
      <s>its own class</s>
      their own responsibility -- or more personally,
      <s>each individual bourgeoise wishes for the annihilation of his own &quot;self&quot;,</s>
      their own personal culpability in the current destructive world system, with
      <s>its</s>
      the attendant burden of moral choice and onerous responsibility for
      <s>creating</s>
      having contributed to an existence of poverty and misery for billions of people in the Third World. For such as these, the belief that the world is doomed is
      <s>a comfort</s>
      inconceivable, because they haven't opened their eyes. In
      <s>asking us to picture an earth devoid of humanity, cracked, shriveled, and dry,</s>
      their flippant rejection of the facts, they give us a snapshot of their own souls and mentality, poor bastards.
      <br clear="none"></br>
      <br clear="none"></br>
      There, fixed it for you.
      <br clear="none"></br>
      <br clear="none"></br>
      Seriously, Faze, you seem like a smart guy.  Why must you ignore/reject facts in favor of some kind of B.S. pop psychoanalysis or whatever this is?  Respond to the facts and the arguments, don't stoop to broad generalizations and nasty assertions.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/79493" shape="rect">natteringnabob</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538753" shape="rect">5:57 PM</a>
        on April 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2538753" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538757" shape="rect"></a>
    <div class="comments">
      Recent episode of NOW on PBS, on the
      <a href="http://www.pbs.org/now/shows/516/index.html" shape="rect">melting glaciers</a>
      around the world kinda bummed me out
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/82668" shape="rect">Restless Day</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538757" shape="rect">5:59 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538775" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/81093/The-Earth-is-a-Harsh-Mistress#2538742" shape="rect">Hairy Lobster</a>
      : &quot;
      <i>a path of decline today would probably look significantly different from anything that has occurred before.</i>
      &quot;
      <br clear="none"></br>
      <br clear="none"></br>
      There are
      <a href="http://www.ucsusa.org/nuclear_weapons_and_global_security/nuclear_weapons/technical_issues/worldwide-nuclear-arsenals.html" shape="rect">25,000 nuclear weapons</a>
      now, for one thing.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/84281" shape="rect">Joe Beese</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538775" shape="rect">6:16 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538872" shape="rect"></a>
    <div class="comments">
      <em>In asking us to picture an earth devoid of humanity, cracked, shriveled, and dry, they give us a snapshot of their own souls, poor bastards.</em>
      <br clear="none"></br>
      <br clear="none"></br>
      I hear this a lot. It has the stink of received wisdom and is a poor excuse for actual discourse.
      <br clear="none"></br>
      <br clear="none"></br>
      As for that old metals bet, Simon would have lost like a motherfucker a couple years back. Volatility increases as scarcity looms, and as always in markets, timing is everything. It was a stupid bet and Ehrlich should never have made it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66965" shape="rect">adamdschneider</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538872" shape="rect">8:01 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538963" shape="rect"></a>
    <div class="comments">
      Harping about population control is no more than an attempt to find a cheap no-brainer way out of massive social, political, economical, scientific and philosophical problems.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/41173" shape="rect">No Robots</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538963" shape="rect">9:35 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2538982" shape="rect"></a>
    <div class="comments">
      Yeah, dude, we get it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66965" shape="rect">adamdschneider</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2538982" shape="rect">10:04 PM</a>
        on April 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2539051" shape="rect"></a>
    <div class="comments">
      To provide some context - world food production per capita
      <a href="http://en.wikipedia.org/wiki/File:Food_production_per_capita_1961-2005.png" shape="rect">index 1963-2005</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19893" shape="rect">sien</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2539051" shape="rect">11:19 PM</a>
        on April 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2539051" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2539929" shape="rect"></a>
    <div class="comments">
      A salient
      <a href="http://www.theoildrum.com/node/5330" shape="rect">article</a>
      from the always-interesting Oil Drum.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66965" shape="rect">adamdschneider</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2539929" shape="rect">2:45 PM</a>
        on April 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2541142" shape="rect"></a>
    <div class="comments">
      adamdschneider, that was actually
      <a href="http://www.metafilter.com/76809/Prophesy-of-economic-collapse-coming-true" shape="rect">previously on the blue</a>
      .   Problem is that we're still in the &quot;growth as normal&quot; stage, which isn't really the significant point they'd made.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45871" shape="rect">FuManchu</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2541142" shape="rect">6:36 PM</a>
        on April 25, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2541162" shape="rect"></a>
    <div class="comments">
      Surely not that specific article. Your link is from November, but as far as I can tell the link and the article it refers to are both current.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66965" shape="rect">adamdschneider</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2541162" shape="rect">6:51 PM</a>
        on April 25, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2542601" shape="rect"></a>
    <div class="comments">
      Oh, right, it's not the same article.  But the points made are exactly the same, aren't they?  Maybe the previous one was just a working paper of the later one.  The graph certainly looks better this go-round.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45871" shape="rect">FuManchu</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2542601" shape="rect">10:13 AM</a>
        on April 27, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2559447" shape="rect"></a>
    <div class="comments">
      Interestingly, the title of this thread is the same name of a fictional book in Ken Macleod's SF novel,
      <i>'The Star Fraction'</i>
      . Just saying.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17291" shape="rect">axon</a>
        at
        <a target="_self" href="/81093/The-Earth-is-a-Harsh-Mistress#2559447" shape="rect">5:49 AM</a>
        on May 10, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/81092/The-Bothy-Band" shape="rect">« Older</a>
      The Bothy Band...  |  It's been only two years since...
      <a target="_self" href="/81094/Happy-PixelStained-Technopeasant-Day" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/116248/Meep-Meep" shape="rect">Meep! Meep!</a>
      <span class="smallcopy">May 23, 2012</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/115115/The-National-Map-US" shape="rect">The National Map (US)</a>
      <span class="smallcopy">April 20, 2012</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/101281/The-Definitive-Look-at-the-Diversity-of-Our-Planet" shape="rect">The Definitive Look at the Diversity of Our Planet</a>
      <span class="smallcopy">March 7, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/88584/Contact-is-the-secret-is-the-moment-when-everything-happens-Contact" shape="rect">Contact is the secret, is the moment, when...</a>
      <span class="smallcopy">January 25, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/38194/Collapse" shape="rect">Collapse!</a>
      <span class="smallcopy">December 28, 2004</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    	addresses   +;     	increased   +h     	solutions   1�     It's   ��     
Scientific   *�     Civilization's   -J     but   -�     stabilization   /�     	Shortages   *�     	diversion   +�         ,http://en.wikipedia.org/wiki/Lester_R._Brown    Lester R. Brown   )�     �Login New User Tags: environment malthus malthusianism collapse ecopocalypse Share: Twitter Facebook The Earth is a Harsh Mistress April 23, 2009 2:30 PM   Subscribe    �, of Worldwatch and the Earth Policy Institute , has an article in May's Scientific American magazine: "Could Food Shortages Bring Down Civilization?" In the    Lester R. Brown      9202a8c04000641f8000000000586e60     1http://en.wikipedia.org/wiki/Worldwatch_Institute    
Worldwatch   )�     �malthus malthusianism collapse ecopocalypse Share: Twitter Facebook The Earth is a Harsh Mistress April 23, 2009 2:30 PM   Subscribe Lester R. Brown , of    �and the Earth Policy Institute , has an article in May's Scientific American magazine: "Could Food Shortages Bring Down Civilization?" In the article he addresses    
Worldwatch      9202a8c04000641f8000000000041bab     3http://en.wikipedia.org/wiki/Earth_Policy_Institute    Earth Policy Institute   *N     �ecopocalypse Share: Twitter Facebook The Earth is a Harsh Mistress April 23, 2009 2:30 PM   Subscribe Lester R. Brown , of Worldwatch and the    �, has an article in May's Scientific American magazine: "Could Food Shortages Bring Down Civilization?" In the article he addresses three major food-security threats: increased    Earth Policy Institute      9202a8c04000641f8000000000a68051    >��    [http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too   Q<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Dorothy, When You See Sophia in Heaven, Send Her Our Love, Too! | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too/rss" title="Comments on: Dorothy, When You See Sophia in Heaven, Send Her Our Love, Too!" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/BeaArthur" shape="rect">BeaArthur</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Maude" shape="rect">Maude</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/GoldenGirls" shape="rect">GoldenGirls</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Obituary" shape="rect">Obituary</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Obit" shape="rect">Obit</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Dorothy%2C%20When%20You%20See%20Sophia%20in%20Heaven%2C%20Send%20Her%20Our%20Love%2C%20Too%21%20http%3A%2F%2Fmefi%2Eus%2Fw%2F81147" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Dorothy, When You See Sophia in Heaven, Send Her Our Love, Too!
        <br clear="none"></br>
        <span class="smallcopy">
          April 25, 2009 1:03 PM  
          <a href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://www.youtube.com/watch?v=apk_ymHWr94" shape="rect">Bea Arthur</a>
        <a href="http://www.msnbc.msn.com/id/30407408/" shape="rect">has died</a>
        . She is best known for her portrayal of
        <a href="http://en.wikipedia.org/wiki/Maude_Findlay" shape="rect">Maude Findlay</a>
        , Edith Bunker's cousin on
        <a href="http://en.wikipedia.org/wiki/All_in_the_Family" shape="rect">All in the Family</a>
        . Her character spawned a CBS spin-off --
        <a href="http://en.wikipedia.org/wiki/Maude_(TV_series)" shape="rect">Maude</a>
        . In
        <a href="http://www.dailymotion.com/video/x6cvnb_today-show-with-bea-arthur-1985_shortfilms" shape="rect">1985</a>
        Arthur was cast as Dorothy Zbornak in the hit sitcom the
        <a href="http://en.wikipedia.org/wiki/The_Golden_Girls" shape="rect">Golden Girls</a>
        . Bea --
        <a href="http://www.youtube.com/watch?v=QFl7r2dUmTA" shape="rect">thank you for being a friend</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
          (157 comments total)
          <span id="favcnt181147">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/81147" shape="rect">7 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2540741" shape="rect"></a>
      <div class="comments">
        Oh sad.
        <br clear="none"></br>
        <br clear="none"></br>
        I always got a kick out of Bea Arthur.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15122" shape="rect">kbanas</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540741" shape="rect">1:03 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540743" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14223" shape="rect">Smart Dalek</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540743" shape="rect">1:04 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540746" shape="rect"></a>
      <div class="comments">
        Archive of American Television
        <a href="http://www.youtube.com/watch?v=z2PUgDa1jy4" shape="rect"> interview</a>
        with Bea Arthur &quot;about the origins of her stage name and how she started out in plays, off and on Broadway.&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540746" shape="rect">1:07 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540746" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540748" shape="rect"></a>
      <div class="comments">
        I'm still discovering the ways in which her work affected me. 'Night, Bea...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24933" shape="rect">hermitosis</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540748" shape="rect">1:08 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540749" shape="rect"></a>
      <div class="comments">
        A comedic great
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/430" shape="rect">Mick</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540749" shape="rect">1:08 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540750" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/84281" shape="rect">Joe Beese</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540750" shape="rect">1:08 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540751" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14215" shape="rect">JoanArkham</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540751" shape="rect">1:08 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540752" shape="rect"></a>
      <div class="comments">
        Here's Bea in a
        <a href="http://www.youtube.com/watch?v=LMLITlAA0QM" shape="rect">Sex and the City</a>
        parody.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50006" shape="rect">waitingtoderail</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540752" shape="rect">1:09 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540752" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540753" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14561" shape="rect">kjh</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540753" shape="rect">1:09 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540755" shape="rect"></a>
      <div class="comments">
        Let's not forget her singing role in the
        <em>Star Wars Xmas Special.</em>
        Oh wait. We should probably forget that.
        <br clear="none"></br>
        <br clear="none"></br>
        She had a very long and interesting acting life before
        <em>Maude</em>
        and after. IMDB
        <a href="http://www.imdb.com/name/nm0037735/#actress" shape="rect">link</a>
        goes back at least to 1951.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18778" shape="rect">emjaybee</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540755" shape="rect">1:10 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540755" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540759" shape="rect"></a>
      <div class="comments">
        Also worth noting: Her extraordinary body of work in the theater.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/31765" shape="rect">Astro Zombie</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540759" shape="rect">1:11 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540760" shape="rect"></a>
      <div class="comments">
        Oh fucking hell, J.G. Ballard and Bea Arthur in the same week.  Honestly, I think the woman made me genuinely laugh at least as many times as Ballard put strange images in my head, and I'm hard put to value one over the other. She just had the flawless make-you-laugh-even-if-you're-too-cool-to-laugh-at-Bea-Arthur timing.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23930" shape="rect">Your Time Machine Sucks</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540760" shape="rect">1:11 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540760" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540761" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/36993" shape="rect">EatTheWeak</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540761" shape="rect">1:11 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540763" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Deadpool is going to be so sad!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66601" shape="rect">bettafish</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540763" shape="rect">1:13 PM</a>
          on April 25, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540763" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540766" shape="rect"></a>
      <div class="comments">
        May she fight, feast, and die throughout eternity in her
        <a href="http://www.brandonbird.com/bea.html" shape="rect">own private Valhalla</a>
        . Hail to thee, acerbic crone warrior!
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14478" shape="rect">bunnytricks</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540766" shape="rect">1:14 PM</a>
          on April 25, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540766" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540767" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42921" shape="rect">aerotive</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540767" shape="rect">1:15 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540769" shape="rect"></a>
      <div class="comments">
        <a href="http://www.youtube.com/watch?v=RzXKySxPFCI" shape="rect">
          Bea Arthur singing in
          <em>The Star Wars Holiday Special</em>
          <br clear="none"></br>
          <br clear="none"></br>
          .
        </a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17563" shape="rect">grouse</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540769" shape="rect">1:16 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540769" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540770" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49133" shape="rect">raxast</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540770" shape="rect">1:17 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540771" shape="rect"></a>
      <div class="comments">
        I always liked that old broad.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/58108" shape="rect">Senator</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540771" shape="rect">1:17 PM</a>
          on April 25, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540771" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540772" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19077" shape="rect">PlusDistance</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540772" shape="rect">1:18 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540773" shape="rect"></a>
      <div class="comments">
        Aw man, that sucks. I always liked her. I just watched the Futurama episode where she voices the FemPuter (&quot;I sentence you to death! ...by snu-snu!&quot;). She had a long life and a great career, though, and will always be remembered as the ultimate gravel-voiced sassy old lady.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66958" shape="rect">DecemberBoy</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540773" shape="rect">1:20 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540773" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540774" shape="rect"></a>
      <div class="comments">
        Aw, Pussycat!
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/13237" shape="rect">amarynth</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540774" shape="rect">1:20 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540774" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540776" shape="rect"></a>
      <div class="comments">
        Holy crap. I was just watcing
        <a href="http://en.wikipedia.org/wiki/Homie_the_Clown" shape="rect">an episode of the SImpsons</a>
        from 1995 where Krusty asks his accountant, &quot;Did you send those thousand roses to Bea Arthur's grave?&quot; She'd deserve every one of them.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71801" shape="rect">Marisa Stole the Precious Thing</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540776" shape="rect">1:20 PM</a>
          on April 25, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540776" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540780" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19348" shape="rect">gcbv</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540780" shape="rect">1:23 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540781" shape="rect"></a>
      <div class="comments">
        She deserves this post AND the double right above it!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20428" shape="rect">R. Mutt</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540781" shape="rect">1:24 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540781" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540783" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/68399" shape="rect">Durn Bronzefist</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540783" shape="rect">1:25 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540787" shape="rect"></a>
      <div class="comments">
        Her Emmy-nominated guest appearance on Malcolm in the Middle was wonderful. I strongly recommend looking for if you haven't seen it.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/3410" shape="rect">gimli</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540787" shape="rect">1:27 PM</a>
          on April 25, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540787" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540788" shape="rect"></a>
      <div class="comments">
        .2
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18416" shape="rect">HyperBlue</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540788" shape="rect">1:27 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540793" shape="rect"></a>
      <div class="comments">
        *Invokes the &quot;Let Bea Arthur Have Two Obituary Posts&quot; Act.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20428" shape="rect">R. Mutt</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540793" shape="rect">1:29 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540793" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540797" shape="rect"></a>
      <div class="comments">
        .-. .. .--.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14267" shape="rect">found missing</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540797" shape="rect">1:32 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540801" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <br clear="none"></br>
        She is everyone's new grandma now.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/37455" shape="rect">Powerful Religious Baby</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540801" shape="rect">1:35 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540801" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540805" shape="rect"></a>
      <div class="comments">
        <a href="http://www.youtube.com/watch?v=e3VbSfQ3nAM" shape="rect">She was regal, she was bawdy, she was ...beyond. </a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24983" shape="rect">applemeat</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540805" shape="rect">1:40 PM</a>
          on April 25, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540805" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540810" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24306" shape="rect">longsleeves</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540810" shape="rect">1:42 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540812" shape="rect"></a>
      <div class="comments">
        An awesome old broad has bit the dust: the world's a little lessened.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19530" shape="rect">jrochest</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540812" shape="rect">1:43 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540822" shape="rect"></a>
      <div class="comments">
        Her reactions to Betty White's stories made the 5:30 daily reruns of Golden Girls required viewing in our house.
        <br clear="none"></br>
        <br clear="none"></br>
        Also, this: (
        <a href="http://www.youtube.com/watch?v=vgsdEw54rNo" shape="rect">1</a>
        ,
        <a href="http://www.youtube.com/watch?v=6uU2XHthUEM" shape="rect">2</a>
        ,
        <a href="http://www.youtube.com/watch?v=8qPM0rxpV-4" shape="rect">3</a>
        )
        <br clear="none"></br>
        <br clear="none"></br>
        Archie: You gonna get outta [my chair]?
        <br clear="none"></br>
        Maude: Get lost!
        <br clear="none"></br>
        Archie: Well, I got the secret weapon that can lay this little lady right away. Here we go: THIS COUNTRY WAS RUINED BY FRANKLIN DELANO ROOSEVELT!
        <br clear="none"></br>
        Maude: (slow burn) You're fat.
        <br clear="none"></br>
        Archie: Sticks and stones may break my bones, but FRANKLIN DELANO ROOSEVELT!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21587" shape="rect">evilcolonel</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540822" shape="rect">1:47 PM</a>
          on April 25, 2009 [
          <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540822" shape="rect">8 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540824" shape="rect"></a>
      <div class="comments">
        . (I didn't do it)
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57425" shape="rect">le morte de bea arthur</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540824" shape="rect">1:48 PM</a>
          on April 25, 2009 [
          <a title="38 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540824" shape="rect">38 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540827" shape="rect"></a>
      <div class="comments">
        A dot for both obituaries
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        This sucks.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50358" shape="rect">The Light Fantastic</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540827" shape="rect">1:51 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540830" shape="rect"></a>
      <div class="comments">
        Right on, Maude.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16106" shape="rect">mazola</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540830" shape="rect">1:52 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540833" shape="rect"></a>
      <div class="comments">
        She was in the Marines, too.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20011" shape="rect">merelyglib</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540833" shape="rect">1:53 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540833" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540836" shape="rect"></a>
      <div class="comments">
        <em>
          . (I didn't do it)
          <br clear="none"></br>
          posted by le morte de bea arthur at 2:48 PM on April 25 [+] [!]
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        Eponytragic.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21587" shape="rect">evilcolonel</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540836" shape="rect">1:53 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540836" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540845" shape="rect"></a>
      <div class="comments">
        It's really weird when a celebrity dies, and you didn't think you would be, but you totally are upset and saddened by it.
        <br clear="none"></br>
        <br clear="none"></br>
        RIP, Bea.
        <br clear="none"></br>
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20896" shape="rect">nooneyouknow</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540845" shape="rect">1:57 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540850" shape="rect"></a>
      <div class="comments">
        <a href="http://www.spike.com/video/roast-of-pamela/2693999" shape="rect">Here she is roasting Pam Anderson</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/47959" shape="rect">tylerfulltilt</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540850" shape="rect">2:02 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540850" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540853" shape="rect"></a>
      <div class="comments">
        Oh Jesus. I'm a huge Golden Girls fan and I honestly feel like my grandmother just died.
        <br clear="none"></br>
        <br clear="none"></br>
        I wonder if Rufus Wainwright feels
        <a href="http://www.oberlin.edu/stupub/ocreview/archives/2002.03.01/arts/article4.htm" shape="rect">the same way</a>
        ?
        <br clear="none"></br>
        <br clear="none"></br>
        <i>
          RW: We were doing an AIDS benefit together and she was the emcee. And I was there...and I had always wanted to meet her because I obsess over â€œThe Golden Girls,â€� one of my favorite shows for a long time, that and â€œMary Tyler Moore,â€� both of which were mentioned in the song â€œCaliforniaâ€� (a song on Poses). I essentially, ya know, went up to her and told her that I was a huge fan of hers and that I watched her a lot when I was very lonely in Los Angeles and wasnâ€™t with my family. And I told her that she became my sort of grandmother â€” my TV grandmother. And she turned to me and said â€œIâ€™m not your fucking grandmother!â€� and walked away.
        </i>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/88976" shape="rect">two or three cars parked under the stars</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540853" shape="rect">2:04 PM</a>
          on April 25, 2009 [
          <a title="56 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540853" shape="rect">56 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540854" shape="rect"></a>
      <div class="comments">
        TV Tears.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24295" shape="rect">doctorschlock</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540854" shape="rect">2:06 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540858" shape="rect"></a>
      <div class="comments">
        Dang, dang, dang.
        <br clear="none"></br>
        <br clear="none"></br>
        For a few years now, my favourite Bea Arthur television moment has been the Malcolm in the Middle ep where she babysits Dewey, even though she leaves in an ambulance. It highlights so much of her charm and brilliance.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/36360" shape="rect">batmonkey</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540858" shape="rect">2:10 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540872" shape="rect"></a>
      <div class="comments">
        I like to think that &quot;Fiddler on the Roof&quot; was written specifically so she could play Yente.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/8053" shape="rect">RavinDave</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540872" shape="rect">2:23 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540873" shape="rect"></a>
      <div class="comments">
        <em>And then, there's Maude.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/53038" shape="rect">porn in the woods</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540873" shape="rect">2:23 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540878" shape="rect"></a>
      <div class="comments">
        she wasn't
        <a href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540853" shape="rect">my fucking grandmother</a>
        either, but she sure did feel like one of the family for a whole lot of years. rest in peace, maude.
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18711" shape="rect">msconduct</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540878" shape="rect">2:25 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540878" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540880" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <a href="http://www.youtube.com/watch?v=e3VbSfQ3nAM" shape="rect">Here she is singing &quot;Sniff Swig Puff&quot; with Rock Hudson.</a>
        Class act.  I'm sad to see her go.  &quot;Bea Arthur nudes&quot; is not a meme.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/70193" shape="rect">christhelongtimelurker</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540880" shape="rect">2:29 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540880" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540882" shape="rect"></a>
      <div class="comments">
        Bea and Angela Lansbury
        <a href="http://www.youtube.com/watch?v=ilV5K8tw_6o" shape="rect">reprise their famous &quot;Bosom Buddies&quot; duet</a>
        from
        <i>Mame</i>
        for the Tony Awards. (YT)
        <br clear="none"></br>
        <br clear="none"></br>
        Bea runs around Logan Airport screaming &quot;The terrorists! The terrorists!&quot; when a TSA agent
        <a href="http://www.kuro5hin.org/story/2004/8/26/222025/747" shape="rect">discovered that she'd forgotten to take her pocketknife out of her purse before boarding a plane.</a>
        <br clear="none"></br>
        <br clear="none"></br>
        Bye, Bea.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20459" shape="rect">tzikeh</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540882" shape="rect">2:30 PM</a>
          on April 25, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540882" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540884" shape="rect"></a>
      <div class="comments">
        Telling someone you're like their gramma is like saying you don't look half as fat in person as you do on TV.  We know you mean well, but ...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/8053" shape="rect">RavinDave</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540884" shape="rect">2:30 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540889" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14073" shape="rect">WolfDaddy</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540889" shape="rect">2:33 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540890" shape="rect"></a>
      <div class="comments">
        <a href="http://www.youtube.com/view_play_list?p=4FE3FD7282B7DCB6" shape="rect">Archive of American Television interview.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42440" shape="rect">Ambrosia Voyeur</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540890" shape="rect">2:34 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540890" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540891" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <br clear="none"></br>
        When I first started dated the guy who'd become my husband, it came up in conversation that Bea was his father's first cousin. I immediately passed on this info to all of my gay friends in New York, and the instant response was: &quot;Wow! Keep this guy!&quot; (This actually wasn't the reason we stayed together, but it's been ten years this weekend.)
        <br clear="none"></br>
        <br clear="none"></br>
        I met her briefly on our honeymoon, after seeing her one-woman show -- she was extremely friendly and hilarious even backstage, with a very firm handshake. Popular culture needs more smart, straight-talking women like her. RIP.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15982" shape="rect">lisa g</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540891" shape="rect">2:34 PM</a>
          on April 25, 2009 [
          <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540891" shape="rect">6 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540893" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/54518" shape="rect">betafilter</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540893" shape="rect">2:36 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540895" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/33546" shape="rect">MythMaker</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540895" shape="rect">2:37 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540897" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/39867" shape="rect">greta simone</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540897" shape="rect">2:38 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540900" shape="rect"></a>
      <div class="comments">
        Man I loved her. Thanks for everything, Bea!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23593" shape="rect">trip and a half</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540900" shape="rect">2:39 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540903" shape="rect"></a>
      <div class="comments">
        . with a stiff drink
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/48427" shape="rect">LMGM</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540903" shape="rect">2:41 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540903" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540904" shape="rect"></a>
      <div class="comments">
        Man, anybody else remember her bits on SheTV, a brief miniseries of sketch comedy from women? Most of what I remember was her doing some emcee act and the repeated punchline, &quot;Gallic funboy, Gerard Depardieu.&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23558" shape="rect">klangklangston</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540904" shape="rect">2:42 PM</a>
          on April 25, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540904" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540906" shape="rect"></a>
      <div class="comments">
        This thread might be useless without
        <a href="http://www.flickr.com/photos/docinaustin/2218075444/" shape="rect"> pictures.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42440" shape="rect">Ambrosia Voyeur</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540906" shape="rect">2:45 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540906" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540910" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/40838" shape="rect">Jilder</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540910" shape="rect">2:51 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540911" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/46544" shape="rect">thankyoujohnnyfever</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540911" shape="rect">2:51 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540913" shape="rect"></a>
      <div class="comments">
        And oh those commercials for Shoppers Drug Mart!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18017" shape="rect">stevil</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540913" shape="rect">2:53 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540913" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540914" shape="rect"></a>
      <div class="comments">
        &quot;God'll getcha for that, Walter.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        *sigh*
        <br clear="none"></br>
        <br clear="none"></br>
        Right on, Maude!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/74627" shape="rect">Ron Thanagar</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540914" shape="rect">2:54 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540916" shape="rect"></a>
      <div class="comments">
        [
        <em>
          Scene: on the set of the
          <i>Golden Girls</i>
          . Dorothy is trying to figure out how she's going to pay her half of the IRS debt her ex-husband managed to accrue]
          <br clear="none"></br>
          <br clear="none"></br>
          Dorothy, resignedly: I think I'm going to have to sell some of my stuff.
          <br clear="none"></br>
          <br clear="none"></br>
          Sophia: Absolutely not! No daughter of mine is going to sell her stuff! It's illegal, it's immoral, and let's face it, Dorothy, lately you can't give it away.
          <br clear="none"></br>
          <br clear="none"></br>
          Dorothy: I was talking about selling some of my
          <b>belongings</b>
          , Ma!!!
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        Thanks for giving us your stuff, Bea.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15969" shape="rect">orange swan</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540916" shape="rect">2:54 PM</a>
          on April 25, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540916" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540918" shape="rect"></a>
      <div class="comments">
        <a href="http://mmeiser.com/blog/2004/08/bea-arthur-of-golden-girls-tv-show.html" shape="rect">The terrorist put a knife in my purse! We're all doomed!</a>
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14511" shape="rect">jonp72</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540918" shape="rect">2:57 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540919" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/64285" shape="rect">runincircles</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540919" shape="rect">2:57 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540922" shape="rect"></a>
      <div class="comments">
        Bea was awesome, even when she was
        <a href="http://www.youtube.com/watch?v=SEPfxI0BO98" shape="rect">shilling for Shoppers Drug Mart</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Special added bonus:
        <a href="http://www.youtube.com/watch?v=SEPfxI0BO98" shape="rect"> Johnny Cash shilling for Canada Trust</a>
        (another version
        <a href="http://www.youtube.com/watch?v=jt5mdIYWRc4" shape="rect">here</a>
        ).
        <br clear="none"></br>
        <br clear="none"></br>
        For a brief period in the 80s, Canada was your Japan next door, convincing your icons to do commercials they wouldn't do at home.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/801" shape="rect">maudlin</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540922" shape="rect">3:01 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540922" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540924" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/67288" shape="rect">esmerelda_jenkins</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540924" shape="rect">3:01 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540925" shape="rect"></a>
      <div class="comments">
        <i>Let's not forget her singing role in the Star Wars Xmas Special. Oh wait. We should probably forget that.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Sadly, that was the first thing that popped into my head when I read the FPP.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16459" shape="rect">deanc</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540925" shape="rect">3:01 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540932" shape="rect"></a>
      <div class="comments">
        Damn.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21820" shape="rect">orthogonality</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540932" shape="rect">3:07 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540933" shape="rect"></a>
      <div class="comments">
        A legend. Thanks for keeping it real, Bea.
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/32087" shape="rect">kimdog</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540933" shape="rect">3:11 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540935" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/22666" shape="rect">cerebus19</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540935" shape="rect">3:12 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540937" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27438" shape="rect">cybercoitus interruptus</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540937" shape="rect">3:12 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540949" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/25718" shape="rect">brandz</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540949" shape="rect">3:27 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540954" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/1324" shape="rect">Ugh</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540954" shape="rect">3:32 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540960" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15091" shape="rect">condour75</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540960" shape="rect">3:37 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540962" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17774" shape="rect">contrariwise</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540962" shape="rect">3:41 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540963" shape="rect"></a>
      <div class="comments">
        Sigh. I guess I'm doing my solo &quot;Golden Girls&quot; watch party today. Goodnight, Pussycat.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42786" shape="rect">notjustfoxybrown</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540963" shape="rect">3:42 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540963" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540969" shape="rect"></a>
      <div class="comments">
        Some
        <a href="http://www.metafilter.com/71622/After-being-in-the-business-for-such-a-long-time-Ive-done-everything-but-rodeo-and-porno#2112816" shape="rect">great stuff </a>
        in last May's Bea Arthur Birthday thread.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15461" shape="rect">stupidsexyFlanders</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540969" shape="rect">3:45 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540976" shape="rect"></a>
      <div class="comments">
        Is it okay to link to the
        <a href="http://www.metafilter.com/81148/" shape="rect">deleted thread?</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20011" shape="rect">merelyglib</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540976" shape="rect">3:56 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540976" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540979" shape="rect"></a>
      <div class="comments">
        Bummer.  Damn.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/58356" shape="rect">heyho</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540979" shape="rect">4:00 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540985" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://www.comedycentral.com/videos/index.jhtml?videoId=167541&amp;title=fembot" shape="rect">Why, WHY?</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/28907" shape="rect">mrzarquon</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540985" shape="rect">4:04 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540987" shape="rect"></a>
      <div class="comments">
        &quot;The Golden Girls&quot; was one of the first shows I could understand when I was learning English, and the silliness of it was something that helped me forget a lot of problems, at least for a while.  I always like Bea Arthur's characters - their pragmatic nature and serious attempts to maintain sanity and logic in the face of lunacy.  And anyone who names Lotte Lenya as a heroine has me as an admirer.  I never understood the many remarks about her appearance either - even in her 70s, the woman was quite striking.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/45778" shape="rect">Dee Xtrovert</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540987" shape="rect">4:05 PM</a>
          on April 25, 2009 [
          <a title="8 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2540987" shape="rect">8 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2540993" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/91079" shape="rect">jeoc</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540993" shape="rect">4:16 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541020" shape="rect"></a>
      <div class="comments">
        I guess now is as good a time as any to post this
        <a href="http://twitpic.com/25tlk" shape="rect">topless Bea Arthur</a>
        painting.
        <br clear="none"></br>
        <br clear="none"></br>
        :(
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/26602" shape="rect">Brittanie</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541020" shape="rect">4:41 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541020" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541028" shape="rect"></a>
      <div class="comments">
        Aww man.  My favorite part about her acting on Golden Girls was her stares.  She would have me cracking up again and again, with a damn stare.  I love that.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49538" shape="rect">cashman</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541028" shape="rect">4:46 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541028" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541039" shape="rect"></a>
      <div class="comments">
        I looked for a youtube video of the original Andrew Gold version of &quot;Thank You For Being a Friend,&quot; and all I could find was this
        <a href="http://www.youtube.com/watch?v=LBZa5zhI3Uo" shape="rect">awful skateboarding video</a>
        . (Warning: NSFW language, gruesome broken arm shot.)
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50142" shape="rect">HeroZero</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541039" shape="rect">5:00 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541054" shape="rect"></a>
      <div class="comments">
        Eh, never loved the Golden Girls. But damn, Bea Arthur...she was the original Lucy Brown in the 1955 Broadway production of Threepenny Opera.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21365" shape="rect">desuetude</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541054" shape="rect">5:12 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541057" shape="rect"></a>
      <div class="comments">
        Not until now, looking at the relative ages of the Golden Girls, did I know that Estelle Getty was actually younger than Bea Arthur when they made the show. Betty White was the oldest and Rue McClanahan had twelve years on them.
        <br clear="none"></br>
        <br clear="none"></br>
        Thanks for a great career, Bea.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57973" shape="rect">crossoverman</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541057" shape="rect">5:18 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541059" shape="rect"></a>
      <div class="comments">
        I loved The Golden Girls as a kid.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/52138" shape="rect">Pope Guilty</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541059" shape="rect">5:20 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541062" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <a href="http://www.youtube.com/watch?v=bU_O-3Ys1S0" shape="rect">with madame, 1980</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21856" shape="rect">sexyrobot</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541062" shape="rect">5:22 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541066" shape="rect"></a>
      <div class="comments">
        ?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19215" shape="rect">blaneyphoto</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541066" shape="rect">5:24 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541068" shape="rect"></a>
      <div class="comments">
        The world is a little less sassy today.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38995" shape="rect">gomichild</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541068" shape="rect">5:24 PM</a>
          on April 25, 2009 [
          <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541068" shape="rect">6 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541089" shape="rect"></a>
      <div class="comments">
        Us tall gals are all a little sadder tonight.
        <br clear="none"></br>
        <br clear="none"></br>
        Rest Well Bea.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50229" shape="rect">pearlybob</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541089" shape="rect">5:39 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541089" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541099" shape="rect"></a>
      <div class="comments">
        Awww... so sad. My man just called to tell me about it and I didn't believe it.
        <br clear="none"></br>
        <br clear="none"></br>
        One of the best things MeFi ever gave me was this picture of
        <a href="http://www.brandonbird.com/bea.html" shape="rect">Bea Vs. Velociraptors</a>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Sad that now I'll never be able to fulfill my gay life's dream of having tea with Bea and her best friend Angela Lansbury.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/31444" shape="rect">yellowbinder</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541099" shape="rect">5:48 PM</a>
          on April 25, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541099" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541149" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/9131" shape="rect">SuzySmith</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541149" shape="rect">6:43 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541166" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18387" shape="rect">exlotuseater</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541166" shape="rect">7:01 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541168" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49020" shape="rect">babybuns</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541168" shape="rect">7:07 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541173" shape="rect"></a>
      <div class="comments">
        Who else remembers her in
        <a href="http://www.imdb.com/title/tt0084973/" shape="rect">Amanda's</a>
        , a misguided attempt at an American version of Fawlty Towers?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/22220" shape="rect">stargell</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541173" shape="rect">7:14 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541173" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541176" shape="rect"></a>
      <div class="comments">
        Slideshow -- &quot;
        <a href="http://www.msnbc.msn.com/id/30407714/displaymode/1247/" shape="rect">Bea Arthur: A look back at the golden girl's life and career</a>
        .&quot;
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541176" shape="rect">7:18 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541179" shape="rect"></a>
      <div class="comments">
        Feh.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16954" shape="rect">FormlessOne</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541179" shape="rect">7:23 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541185" shape="rect"></a>
      <div class="comments">
        Archie Bunker's nemesis.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21880" shape="rect">WaterSprite</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541185" shape="rect">7:29 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541189" shape="rect"></a>
      <div class="comments">
        A legend indeed and definitely one of the golden girls.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/53569" shape="rect">Mael Oui</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541189" shape="rect">7:31 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541190" shape="rect"></a>
      <div class="comments">
        May her penis be forever preserved, so that future generations may scorn and reject people with it.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/58042" shape="rect">Auden</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541190" shape="rect">7:31 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541195" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23057" shape="rect">oddman</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541195" shape="rect">7:36 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541202" shape="rect"></a>
      <div class="comments">
        Ah, she was pretty great.
        <br clear="none"></br>
        <br clear="none"></br>
        RIP, Bea.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/39010" shape="rect">flapjax at midnite</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541202" shape="rect">7:42 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541203" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17021" shape="rect">edmcbride</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541203" shape="rect">7:42 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541209" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/67967" shape="rect">sonascope</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541209" shape="rect">7:46 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541219" shape="rect"></a>
      <div class="comments">
        Aw hell. :(  Such an incredible person, both onscreen and off.  RIP.
        <br clear="none"></br>
        <br clear="none"></br>
        <b>.</b>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18312" shape="rect">zarq</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541219" shape="rect">7:56 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541220" shape="rect"></a>
      <div class="comments">
        I saw a recent picture of her, she looked so old.   Nothing like when she was on the show.  RIP
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/91153" shape="rect">jackson5</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541220" shape="rect">7:57 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541224" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/85667" shape="rect">miratime</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541224" shape="rect">8:00 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541249" shape="rect"></a>
      <div class="comments">
        <em>Who else remembers her in Amanda's, a misguided attempt at an American version of Fawlty Towers?</em>
        <br clear="none"></br>
        <br clear="none"></br>
        I don't, but I do remember
        <em>The Golden Palace</em>
        -- the Bea-free hotel-based spinoff of
        <em>The Golden Girls</em>
        co-starring Cheech Marin.
        <br clear="none"></br>
        <br clear="none"></br>
        Funny, that.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66149" shape="rect">Sys Rq</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541249" shape="rect">8:38 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541254" shape="rect"></a>
      <div class="comments">
        Since
        <a href="http://www.metafilter.com/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2540922" shape="rect">maudlin</a>
        borked the link:
        <br clear="none"></br>
        <br clear="none"></br>
        Shoppers Drug Mart
        <a href="http://www.youtube.com/watch?v=Hc38-oLaooM" shape="rect">1</a>
        <a href="http://www.youtube.com/watch?v=gl_dldsIVeA" shape="rect">2 </a>
        <a href="http://www.youtube.com/watch?v=w1Aa1GiJaYY" shape="rect">3</a>
        <a href="http://www.youtube.com/watch?v=jU7VE9W9Sc0" shape="rect">4</a>
        <a href="http://www.youtube.com/watch?v=kX_3ATPN-hQ" shape="rect">5</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66149" shape="rect">Sys Rq</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541254" shape="rect">8:44 PM</a>
          on April 25, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541254" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541264" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17389" shape="rect">John Kenneth Fisher</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541264" shape="rect">9:05 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541265" shape="rect"></a>
      <div class="comments">
        I've loved her since I was 8 years old and I saw my first episode of Golden Girls.
        <br clear="none"></br>
        <br clear="none"></br>
        Rose: Well, I'm here if you want to pick my brain.
        <br clear="none"></br>
        Dorothy: Rose, honey. Maybe we should leave it alone and let it heal.
        <br clear="none"></br>
        <br clear="none"></br>
        Dorothy: Good night, Rose. Go to sleep, honey. Pray for brains.
        <br clear="none"></br>
        <br clear="none"></br>
        Blanche:
        <em> [looking after Rose, who has just left the lanai crying]</em>
        What's the matter with her?
        <br clear="none"></br>
        Dorothy: She's upset.
        <br clear="none"></br>
        Blanche: Is it about Arnie?
        <br clear="none"></br>
        Dorothy: No, Blanche. She's upset because they keep changing the taste of Coke!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/12408" shape="rect">jerseygirl</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541265" shape="rect">9:05 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541280" shape="rect"></a>
      <div class="comments">
        She was my Fairy Broadmother.
        <br clear="none"></br>
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/54479" shape="rect">louche mustachio</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541280" shape="rect">9:27 PM</a>
          on April 25, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541280" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541287" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        Exhibit Bea in rebuttal of any bullshit claim that women can't be funny.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10648" shape="rect">kirkaracha</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541287" shape="rect">9:36 PM</a>
          on April 25, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541287" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541293" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/87766" shape="rect">hamida2242</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541293" shape="rect">9:41 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541303" shape="rect"></a>
      <div class="comments">
        no!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/47357" shape="rect">Green Eyed Monster</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541303" shape="rect">9:59 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541318" shape="rect"></a>
      <div class="comments">
        <a href="http://www.youtube.com/watch?v=ZPy0wxIdiGw&amp;feature=PlayList&amp;p=DFCEA65019E17471&amp;playnext=1&amp;playnext_from=PL&amp;index=11" shape="rect">
          <em>Ah, a bullshit artist</em>
        </a>
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/32700" shape="rect">khaibit</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541318" shape="rect">10:28 PM</a>
          on April 25, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541355" shape="rect"></a>
      <div class="comments">
        Damn.  I can only hope that I make it to her age... and if I do, that I'm half the broad she was.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16239" shape="rect">scody</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541355" shape="rect">12:28 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541359" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23303" shape="rect">BrotherCaine</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541359" shape="rect">12:42 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541404" shape="rect"></a>
      <div class="comments">
        She was a sister who really cooked.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/22039" shape="rect">quietalittlewild</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541404" shape="rect">4:36 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541407" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19226" shape="rect">oonh</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541407" shape="rect">5:03 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541409" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/57074" shape="rect">cupcakeninja</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541409" shape="rect">5:14 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541410" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19153" shape="rect">fairmettle</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541410" shape="rect">5:15 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541416" shape="rect"></a>
      <div class="comments">
        That does not fempute!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20821" shape="rect">Eideteker</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541416" shape="rect">5:35 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541419" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/1370" shape="rect">zarah</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541419" shape="rect">5:41 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541444" shape="rect"></a>
      <div class="comments">
        'We've been expecting you, Mrs Arthur. The stage is yours.'
        <br clear="none"></br>
        <br clear="none"></br>
        RIP.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/27011" shape="rect">waxbanks</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541444" shape="rect">6:45 AM</a>
          on April 26, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541444" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541512" shape="rect"></a>
      <div class="comments">
        Oh man, this means I have to call my Grandma today.  She's probably a wreck, fer'real.  When I lived with her oh so many years ago, I swear she found an all 'Golden Girls' channel that she kept running on every television in the house.
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/41510" shape="rect">Bageena</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541512" shape="rect">8:56 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541526" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/39217" shape="rect">kuppajava</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541526" shape="rect">9:13 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541539" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16988" shape="rect">PigAlien</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541539" shape="rect">9:21 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541568" shape="rect"></a>
      <div class="comments">
        <i>
          . (I didn't do it)
          <br clear="none"></br>
          posted by le morte de bea arthur at 1:48 PM on April 25 [24 favorites]
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        Yeah, The moment I heard the news, I was really hoping that you would start the FPP for this story.
        <br clear="none"></br>
        <br clear="none"></br>
        . Bye Bea
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/72823" shape="rect">Avelwood</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541568" shape="rect">10:07 AM</a>
          on April 26, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2541568" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541608" shape="rect"></a>
      <div class="comments">
        . .
        <br clear="none"></br>
        <br clear="none"></br>
        One dot for each of us reading this post. I always wondered if during the filming of &quot;Airheads&quot;, did they actually get her to take those nude photos?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21723" shape="rect">SinisterPurpose</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541608" shape="rect">10:48 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541649" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18732" shape="rect">purephase</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541649" shape="rect">11:33 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541650" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/23738" shape="rect">the sobsister</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541650" shape="rect">11:33 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541656" shape="rect"></a>
      <div class="comments">
        Dot, Dot, what a gal I got.
        <br clear="none"></br>
        <br clear="none"></br>
        RIP Yoko Zbornak.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/7547" shape="rect">Oriole Adams</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541656" shape="rect">11:43 AM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541698" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/55365" shape="rect">CitizenD</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541698" shape="rect">1:08 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541755" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19064" shape="rect">killy willy</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541755" shape="rect">2:43 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541863" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18862" shape="rect">candyland</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541863" shape="rect">5:04 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541908" shape="rect"></a>
      <div class="comments">
        I'd like to think that Bea Arthur will rise again. Sometime around 2015, when people are picking out their new PCMacAir Internet Avatar/Profile, Bea Arthur will be a choice. Lots of gay men running around with Bea's voice and picture coming out of their Internet thingy, telling them who's calling them, or who's posted new pictures to facebook, when their tea time is...
        <br clear="none"></br>
        Of course lots of old stars are going to become personal Avatars for everyday people.
        <br clear="none"></br>
        (If they started it now, some of these old stars could get richer now. There's lots of stars that didn't turn to shit that haven't had a good paycheck in ten plus years. We should help them out...Right?)
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <br clear="none"></br>
        Will be missed.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/71095" shape="rect">QueerAngel28</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541908" shape="rect">5:47 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541929" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/35387" shape="rect">lordrunningclam</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541929" shape="rect">6:15 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2541947" shape="rect"></a>
      <div class="comments">
        This reminds me of spending Saturday nights with my grandmother, watching the Golden Girls. Like clockwork, every week. It makes me miss her.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/38748" shape="rect">CwgrlUp</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2541947" shape="rect">6:44 PM</a>
          on April 26, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542396" shape="rect"></a>
      <div class="comments">
        No. NOOO. :(
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42385" shape="rect">spec80</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542396" shape="rect">6:29 AM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542478" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16157" shape="rect">Mitheral</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542478" shape="rect">8:29 AM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542484" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17573" shape="rect">box</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542484" shape="rect">8:39 AM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542598" shape="rect"></a>
      <div class="comments">
        I grew up with
        <i>Golden Girls</i>
        as well, but I'm still way blown away by
        <i>Maude</i>
        .  Going back and watching the first season on DVD, it's funny how they were doing the kind of political stuff on TV in its time that the networks wouldn't even touch today.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/11251" shape="rect">troybob</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542598" shape="rect">10:09 AM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542662" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14346" shape="rect">joedan</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542662" shape="rect">10:55 AM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542795" shape="rect"></a>
      <div class="comments">
        I took an order for a box of fancy pears from her, years ago. I said, &quot;Can I get your name please,&quot; and she said, &quot;Beatrice Arthur,&quot; and I said, &quot;... I knew that.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24426" shape="rect">darksasami</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542795" shape="rect">12:04 PM</a>
          on April 27, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2542795" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2542960" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/90039" shape="rect">fyrebelley</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2542960" shape="rect">1:40 PM</a>
          on April 27, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2542960" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2543001" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/20842" shape="rect">bitter-girl.com</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2543001" shape="rect">2:12 PM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2543002" shape="rect"></a>
      <div class="comments">
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/80373" shape="rect">ahdeeda</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2543002" shape="rect">2:13 PM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2543126" shape="rect"></a>
      <div class="comments">
        Rue McClanahan and Betty White remember Bea Arthur [
        <a href="http://www.msnbc.msn.com/id/21134540/vp/30431823#30431823 " shape="rect">video</a>
        | 05:51].
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2543126" shape="rect">3:45 PM</a>
          on April 27, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2543126" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2543473" shape="rect"></a>
      <div class="comments">
        Goodnight, Pussycat.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18307" shape="rect">dirtynumbangelboy</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2543473" shape="rect">8:07 PM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2543521" shape="rect"></a>
      <div class="comments">
        I'm so sorry that this elegant and smart actor is gone.
        <br clear="none"></br>
        <br clear="none"></br>
        And here's to her, for being a feminist on prime-time television in the 70s! I think Maude was one of the first tv characters to get an abortion.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19002" shape="rect">goofyfoot</a>
          at
          <a target="_self" href="/81147/Dorothy-When-You-See-Sophia-in-Heaven-Send-Her-Our-Love-Too#2543521" shape="rect">8:48 PM</a>
          on April 27, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/81146/April-Harvest" shape="rect">« Older</a>
        Homophobia is still a bully's deadliest weapon....  |  Lunar Lander 3D in 5k...
        <a target="_self" href="/81149/Beautiful-beautiful-just-beautiful" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/109872/You-cant-regret-your-fate-although-I-do-regret-my-mother-didnt-marry-a-carpenter" shape="rect">&quot;You canâ€™t regret your fate, although I do regret...</a>
        <span class="smallcopy">November 28, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/108093/Steve-Jobs-RIP" shape="rect">Steve Jobs, RIP</a>
        <span class="smallcopy">October 5, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/92647/I-hear-babies-cry-and-I-watch-them-grow-Theyll-learn-much-more-than-well-know-And-I-think-to-myself-What-a-Wonderful-World" shape="rect">I hear babies cry and I watch them grow. They'll...</a>
        <span class="smallcopy">June 8, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/92477/Thank-You-for-Also-Being-A-Friend" shape="rect">Thank You for (Also) Being A Friend.</a>
        <span class="smallcopy">June 3, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/35246/Its-no-velociraptor-but" shape="rect">It's no velociraptor, but...</a>
        <span class="smallcopy">August 28, 2004</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    Bunker's   +}     See   (�     died   *�     Findlay   +j     April   )D     Edith   +w     Lunar  M�     Our   )     sitcom   ,�     best   +         *http://en.wikipedia.org/wiki/Maude_Findlay    Maude Findlay   +d     xSend Her Our Love, Too! April 25, 2009 1:03 PM   Subscribe Bea Arthur has died . She is best known for her portrayal of    y, Edith Bunker's cousin on All in the Family . Her character spawned a CBS spin-off -- Maude . In 1985 Arthur was cast as    Maude Findlay      9202a8c04000641f8000000006c0bbf8     .http://en.wikipedia.org/wiki/All_in_the_Family    All in the Family   +�     2009 1:03 PM   Subscribe Bea Arthur has died . She is best known for her portrayal of Maude Findlay , Edith Bunker's cousin on    . Her character spawned a CBS spin-off -- Maude . In 1985 Arthur was cast as Dorothy Zbornak in the hit sitcom the Golden Girls    All in the Family      9202a8c04000641f800000000012d68a     .http://en.wikipedia.org/wiki/Maude_(TV_series)    Maude   ,A     �best known for her portrayal of Maude Findlay , Edith Bunker's cousin on All in the Family . Her character spawned a CBS spin-off --    u. In 1985 Arthur was cast as Dorothy Zbornak in the hit sitcom the Golden Girls . Bea -- thank you for being a friend    Maude      9202a8c04000641f80000000001f1df4     -http://en.wikipedia.org/wiki/The_Golden_Girls    Golden Girls   -&     }the Family . Her character spawned a CBS spin-off -- Maude . In 1985 Arthur was cast as Dorothy Zbornak in the hit sitcom the    v. Bea -- thank you for being a friend . posted by ericb (157 comments total) 7 users marked this as a favorite Oh sad.    Golden Girls      9202a8c04000641f800000000016e3d6  