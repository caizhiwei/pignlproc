  >��    0http://www.lsdimension.com/tag/electronic-music/   <html lang="en-US" dir="ltr">
  <head profile="http://gmpg.org/xfn/11">
    <meta content="text/html charset=UTF-8" http-equiv="Content-Type"></meta>
    <title>Electronic Music | Light Sound Dimension</title>
    <meta 
    content="techno, Obama, CDA, indie, VVD, PVV, The Netherlands, WikiLeaks, Geert Wilders, electronica, PvdA, house, kabinet-Rutte, Republican Party, United Kingdom, verkiezingen 2010, United States, hipsters, marihuana, Sarah Palin, politics, electronic music, history, videos, philosophy, spirituality, america, the netherlands" name="keywords">
</meta>
    <meta content="Posts related to Tag:Electronic music" name="description"></meta>
    <link type="text/css" href="http://www.lsdimension.com?antisnews-my-style=load-style-antisnews" rel="stylesheet"></link>
    <link media="screen" type="text/css" href="http://www.lsdimension.com/wp-content/themes/antisnews/pagenavi-css.css" rel="stylesheet"></link>
    <link href="http://www.lsdimension.com/feed/" title="Light Sound Dimension RSS Feed" type="application/rss+xml" rel="alternate"></link>
    <link href="http://www.lsdimension.com/xmlrpc.php" rel="pingback"></link>
    <link href="/favicon.ico" type="image/x-icon" rel="shortcut icon"></link>
    <style media="screen" type="text/css">
      .socialwrap li.icon_text a img, .socialwrap li.iconOnly a img, .followwrap li.icon_text a img, .followwrap li.iconOnly a img{border-width:0 !important;background-color:none;}#follow.right {width:32px;position:fixed; right:0; top:0px;padding:10px 0;font-family:impact,charcoal,arial, helvetica,sans-serif;-moz-border-radius-topleft: 5px;-webkit-border-top-left-radius:5px;-moz-border-radius-bottomleft:5px;-webkit-border-bottom-left-radius:5px;}#follow.right ul {padding:0; margin:0; list-style-type:none !important;font-size:24px;color:black;}
#follow.right ul li {padding-bottom:10px;list-style-type:none !important;padding-left:4px;padding-right:4px}
#follow img{border:none;}#follow.right ul li.follow {margin:0 4px;}
#follow.right ul li.follow img {border-width:0;display:block;overflow:hidden; background:transparent url(http://www.lsdimension.nl/wp-content/plugins/share-and-follow/images/impact/follow-right.png) no-repeat -0px 0px;height:79px;width:20px;}
#follow.right ul li a {display:block;}
#follow.right ul li.follow span, #follow ul li a span {display:none}.share {margin:0 6px 6px 0;}
.phat span {display:inline;}
ul.row li {float:left;list-style-type:none;}
li.iconOnly a span.head {display:none}
#follow.left ul.size16 li.follow{margin:0px auto !important}
li.icon_text a {padding-left:0;margin-right:6px}
li.text_only a {background-image:none !important;padding-left:0;}
li.text_only a img {display:none;}
li.icon_text a span{background-image:none !important;padding-left:0 !important; }
li.iconOnly a span.head {display:none}
ul.socialwrap li {margin:0 6px 6px 0 !important;}
ul.socialwrap li a {text-decoration:none;}ul.row li {float:left;line-height:auto !important;}
ul.row li a img {padding:0}.size16 li a,.size24 li a,.size32 li a, .size48 li a, .size60 li a {display:block}ul.socialwrap {list-style-type:none !important;margin:0; padding:0;text-indent:0 !important;}
ul.socialwrap li {list-style-type:none !important;background-image:none;padding:0;list-style-image:none !important;}
ul.followwrap {list-style-type:none !important;margin:0; padding:0}
ul.followwrap li {margin-right:6px;margin-bottom:6px;list-style-type:none !important;}
#follow.right ul.followwrap li, #follow.left ul.followwrap li {margin-right:0px;margin-bottom:0px;}
.shareinpost {clear:both;padding-top:0px}.shareinpost ul.socialwrap {list-style-type:none !important;margin:0 !important; padding:0 !important}
.shareinpost ul.socialwrap li {padding-left:0 !important;background-image:none !important;margin-left:0 !important;list-style-type:none !important;text-indent:0 !important}
.socialwrap li.icon_text a img, .socialwrap li.iconOnly a img{border-width:0}ul.followrap li {list-style-type:none;list-style-image:none !important;}
div.clean {clear:left;}
div.display_none {display:none;}
    </style>
    <style media="print" type="text/css">
      body {background: white;font-size: 12pt;color:black;}
 * {background-image:none;}
 #wrapper, #content {width: auto;margin: 0 5%;padding: 0;border: 0;float: none !important;color: black;background: transparent none;}
 a { text-decoration : underline; color : #0000ff; }
#menu, #navigation, #navi, .menu {display:none}
    </style>
    <link href="" rel="image_src"></link>
    <link href="http://www.lsdimension.com/tag/electronic-music/feed/" title="Light Sound Dimension » electronic music Tag Feed" type="application/rss+xml" rel="alternate"></link>
    <script src="http://www.lsdimension.com/wp-includes/js/l10n.js?ver=20101110" type="text/javascript"></script>
    <script src="http://www.lsdimension.com/wp-includes/js/jquery/jquery.js?ver=1.4.4" type="text/javascript"></script>
    <link href="http://www.lsdimension.com/xmlrpc.php?rsd" title="RSD" type="application/rsd+xml" rel="EditURI"></link>
    <link href="http://www.lsdimension.com/wp-includes/wlwmanifest.xml" type="application/wlwmanifest+xml" rel="wlwmanifest"></link>
    <link href="http://www.lsdimension.com/" title="Light Sound Dimension" rel="index"></link>
    <link href="http://www.lsdimension.com/tag/electronic-music/" rel="canonical"></link>
    <link type="image/x-icon" href="http://www.lsdimension.nl/images/favicon.ico" rel="shortcut icon"></link>
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
    <script type="text/javascript"> jQuery(window).load(function(){ jQuery(&quot;#featured-content&quot;).loopedSlider({ autoStart: 3000, slidespeed: 500, containerClick: false, autoHeight: false }); }); </script>
  </head>
  <body>
    <div id="wrapper">
      <div id="maincontainer">
        <div id="sitetitle">
          <div class="logo">
            <a href="http://www.lsdimension.com" shape="rect">
              <img border="0" alt="Light Sound Dimension" src="http://www.lsdimension.com/wp-content/themes/antisnews/images/starchildlogo3.jpg"></img>
            </a>
          </div>
          <div class="clear"></div>
        </div>
        <div id="antisnav-navbar">
          <ul id="antisnav">
            <li>
              <a href="http://www.lsdimension.com" shape="rect">Home</a>
            </li>
            <li class="cat-item cat-item-3">
              <a title="View all posts filed under art / photography" href="http://www.lsdimension.com/category/art-photography/" shape="rect">art / photography</a>
            </li>
            <li class="cat-item cat-item-4">
              <a title="View all posts filed under books" href="http://www.lsdimension.com/category/books/" shape="rect">books</a>
            </li>
            <li class="cat-item cat-item-5">
              <a title="View all posts filed under Canadian politics" href="http://www.lsdimension.com/category/canadian-politics/" shape="rect">Canadian politics</a>
            </li>
            <li class="cat-item cat-item-6">
              <a title="View all posts filed under Dutch politics" href="http://www.lsdimension.com/category/dutch-politics/" shape="rect">Dutch politics</a>
            </li>
            <li class="cat-item cat-item-7">
              <a title="View all posts filed under electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
            </li>
            <li class="cat-item cat-item-8">
              <a title="View all posts filed under Europe" href="http://www.lsdimension.com/category/europe/" shape="rect">Europe</a>
            </li>
            <li class="cat-item cat-item-9">
              <a title="View all posts filed under gadgets / futuristic" href="http://www.lsdimension.com/category/gadgets-futuristic/" shape="rect">gadgets / futuristic</a>
            </li>
            <li class="cat-item cat-item-11">
              <a title="View all posts filed under history" href="http://www.lsdimension.com/category/history/" shape="rect">history</a>
            </li>
            <li class="cat-item cat-item-13">
              <a title="View all posts filed under movies" href="http://www.lsdimension.com/category/movies/" shape="rect">movies</a>
            </li>
            <li class="cat-item cat-item-15">
              <a title="View all posts filed under philosophy" href="http://www.lsdimension.com/category/philosophy/" shape="rect">philosophy</a>
            </li>
            <li class="cat-item cat-item-16">
              <a title="politics" href="http://www.lsdimension.com/category/politics/" shape="rect">politics</a>
            </li>
            <li class="cat-item cat-item-17">
              <a title="View all posts filed under privacy" href="http://www.lsdimension.com/category/privacy/" shape="rect">privacy</a>
            </li>
            <li class="cat-item cat-item-18">
              <a title="View all posts filed under psychedelics" href="http://www.lsdimension.com/category/psychedelics/" shape="rect">psychedelics</a>
            </li>
            <li class="cat-item cat-item-19">
              <a title="View all posts filed under random stuff" href="http://www.lsdimension.com/category/random-stuff/" shape="rect">random stuff</a>
            </li>
            <li class="cat-item cat-item-20">
              <a title="View all posts filed under science" href="http://www.lsdimension.com/category/science/" shape="rect">science</a>
            </li>
            <li class="cat-item cat-item-22">
              <a title="View all posts filed under spirituality" href="http://www.lsdimension.com/category/spirituality/" shape="rect">spirituality</a>
            </li>
            <li class="cat-item cat-item-24">
              <a title="View all posts filed under U.S. politics" href="http://www.lsdimension.com/category/u-s-politics/" shape="rect">U.S. politics</a>
            </li>
          </ul>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div class="datesearch">
          <div class="date">Wednesday October 3rd 2012</div>
          <div class="search">
            <form action="http://www.lsdimension.com" id="mysearchform" method="get" enctype="application/x-www-form-urlencoded">
              <input name="s" value="Search ..." onfocus="this.value='';" onblur="this.value = this.value || this.defaultValue; " id="mys" type="text"></input>
              <input title="Search" alt="Search" value="" id="mygo" type="submit"></input>
            </form>
          </div>
          <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <div id="contentcontainer">
          <div id="content">
            <div class="postarea">
              <h1>Posts Tagged ‘electronic music’</h1>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2012/05/18/rip-donna-summer/" shape="rect">RIP Donna Summer </a>
                </h2>
                <div class="byline"> Author: maartenp Published: May 18th, 2012 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2012/05/Donna-Summer.jpg" shape="rect">
                    <img height="390" width="520" alt="" src="http://www.lsdimension.com/wp-content/uploads/2012/05/Donna-Summer.jpg" title="Donna-Summer" class="aligncenter size-full wp-image-25890"></img>
                  </a>
                </p>
                <p>
                  A disco queen has passed away. She will be remembered for innovating dance music. Her 1977 cooperation with the innovative producer
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Giorgio_Moroder" shape="rect">Giorgio Moroder</a>
                  , which resulted in the single
                  <a target="_blank" href="http://youtu.be/fW99gJOpY5s?t=2m50s" shape="rect">
                    <em>I Feel Love</em>
                  </a>
                  , has given her a legendary status. This was one of the first dance tracks produced entirely with
                  <a target="_blank" href="http://www.youtube.com/watch?v=6lZO-3Uz0ps&amp;feature=related" shape="rect">synthesizers</a>
                  . It has served as an inspiration for countless of producers and dj’s through the decades and it still sounds fresh today. An amazing song:
                </p>
                <p>
                  <span class="youtube">
                    <object height="385" width="480">
                      <param value="http://www.youtube.com/v/9e3H6t6j3Rk?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0" name="movie" valuetype="data"></param>
                      <param value="true" name="allowFullScreen" valuetype="data"></param>
                      <param value="always" name="allowscriptaccess" valuetype="data"></param>
                      <embed 
                      height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/9e3H6t6j3Rk?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0">
</embed>
                    </object>
                  </span>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F05%2F18%2Frip-donna-summer%2F&amp;text=RIP Donna Summer&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F05%2F18%2Frip-donna-summer%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/disco/" shape="rect">disco</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/donna-summer/" shape="rect">Donna Summer</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/giorgio-moroder/" shape="rect">Giorgio Moroder</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/i-feel-love/" shape="rect">I Feel Love</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/man-in-the-moon-with-a-cocaine-spoon/" shape="rect">man in the moon with a cocaine spoon</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/studio-54/" shape="rect">Studio 54</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2012/04/26/all-hail-the-beat/" shape="rect">All Hail The Beat </a>
                </h2>
                <div class="byline"> Author: adriejan Published: April 26th, 2012 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2012/04/Roland-TR-808.jpg" shape="rect">
                    <img height="853" width="1280" alt="" src="http://www.lsdimension.com/wp-content/uploads/2012/04/Roland-TR-808.jpg" title="Roland-TR-808" class="aligncenter size-full wp-image-25674"></img>
                  </a>
                </p>
                <p>
                  A very short
                  <a target="_blank" href="http://vimeo.com/40094608" shape="rect"> documentary</a>
                  that sums up in three minutes the importance of the
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Roland_TR-808" shape="rect">Roland TR-808</a>
                  drum machine for electronic, hip hop and pop music in the last thirty years. Originally designed in 1980 as a tool for studio musicians to create demos, due to its relative cheapness it became used in the then-underground electronic and hip hop scenes to compose beats.
                </p>
                <p>
                  The by now vintage, distinctive, artificial sound of the 808 not only gave birth to the techno scene (in addition to tools like the
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Roland_TB-303" shape="rect">TB-303 bass synthesizer</a>
                  ), but also influenced the evolution of all kinds of relevant styles in the last decades. By now, their sounds are available digitally, but original machines are highly sought after. If you listen, you hear those kicks and hi-hats everywhere.
                </p>
                <iframe height="281" width="500" src="http://player.vimeo.com/video/40094608?title=1&amp;byline=1&amp;portrait=1" scrolling="auto" frameborder="0"></iframe>
                <p>
                  Also check out this video, already
                  <a target="_blank" href="http://www.lsdimension.com/2010/09/25/how-to-program-a-tr-808/" shape="rect">blogged</a>
                  about earlier, demonstrating the possibilities of the 808.
                </p>
                <iframe height="281" width="500" src="http://player.vimeo.com/video/15142220?title=1&amp;byline=1&amp;portrait=1" scrolling="auto" frameborder="0"></iframe>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F04%2F26%2Fall-hail-the-beat%2F&amp;text=All Hail The Beat&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F04%2F26%2Fall-hail-the-beat%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/1980s/" shape="rect">1980s</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/acid/" shape="rect">acid</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/acid-house/" shape="rect">acid house</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/acid-techno/" shape="rect">acid techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/afrika-bambaata/" shape="rect">Afrika Bambaata</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/beats/" shape="rect">beats</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/clap/" shape="rect">clap</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/cowbell/" shape="rect">cowbell</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/detroit/" shape="rect">Detroit</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/detroit-techno/" shape="rect">Detroit techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/drum-machine/" shape="rect">drum machine</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/funk/" shape="rect">funk</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/hi-hats/" shape="rect">hi-hats</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/hip-hop/" shape="rect">hip hop</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/josh-wink/" shape="rect">Josh Wink</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/juan-atkins/" shape="rect">Juan Atkins</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/kick-drum/" shape="rect">kick drum</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/plastikman/" shape="rect">Plastikman</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pop/" shape="rect">pop</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/roland/" shape="rect">Roland</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/roland-tr-808/" shape="rect">Roland TR-808</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2012/03/22/snoop-doggs-house-mix/" shape="rect">Snoop Dogg’s House Mix </a>
                </h2>
                <div class="byline"> Author: adriejan Published: March 22nd, 2012 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2012/03/dj-snoop.jpg" shape="rect">
                    <img height="349" width="523" alt="" src="http://www.lsdimension.com/wp-content/uploads/2012/03/dj-snoop.jpg" title="dj-snoop" class="aligncenter size-full wp-image-25165"></img>
                  </a>
                </p>
                <p>
                  Snoop Dogg has always been pretty much the only cool rapper around. The only one who takes the ridiculous misogynistic gangsta culture with an ironic twist, and actually makes decent music. I still think “Drop It Like It’s Hot” was one of the best tracks of the ’00s, in any genre. Not to mention his forays into
                  <a target="_blank" href="http://www.youtube.com/watch?v=fWCa3GvbNUE" shape="rect">country music</a>
                  .
                </p>
                <p>
                  And here he is: now dropping a
                  <a target="_blank" href="http://soundcloud.com/snoopdogg/01-tekno-euro-mixx" shape="rect">house mix</a>
                  . Snoop Dogg goes electronic, and it sounds pretty good! Of course, house music has much in common with hip hop, so in a way it doesn’t surprise. And he manages to put his own style in the mix, which is very smooth, relaxed and funky, with lots of deep house and nu disco.
                </p>
                <p>Listen to this, it’ll make you happy. Artists featured are Todd Terje, Tensnake, Martin Buttrich and Toby Tobias. Big kudos to Snoop!</p>
                <object width="100%" height="81">
                  <param value="http://player.soundcloud.com/player.swf?url=http%3A%2F%2Fsoundcloud.com%2Fsnoopdogg%2F01-tekno-euro-mixx&amp;g=1&amp;" name="movie" valuetype="data"></param>
                  <param value="always" name="allowscriptaccess" valuetype="data"></param>
                  <embed width="100%" type="application/x-shockwave-flash" src="http://player.soundcloud.com/player.swf?url=http%3A%2F%2Fsoundcloud.com%2Fsnoopdogg%2F01-tekno-euro-mixx&amp;g=1&amp;" height="81" allowscriptaccess="always"> </embed>
                </object>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F03%2F22%2Fsnoop-doggs-house-mix%2F&amp;text=Snoop Dogg’s House Mix&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F03%2F22%2Fsnoop-doggs-house-mix%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/deep-house/" shape="rect">deep house</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/hip-hop/" shape="rect">hip hop</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/house/" shape="rect">house</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/martin-buttrich/" shape="rect">Martin Buttrich</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/mix/" shape="rect">mix</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/nu-disco/" shape="rect">nu disco</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/rap/" shape="rect">rap</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/rapper/" shape="rect">rapper</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/snoop-dogg/" shape="rect">Snoop Dogg</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/tensnake/" shape="rect">Tensnake</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/toby-tobias/" shape="rect">Toby Tobias</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/todd-terje/" shape="rect">Todd Terje</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2012/01/06/recognizing-styles-in-electronic-music/" shape="rect">Recognizing Styles In Electronic Music </a>
                </h2>
                <div class="byline"> Author: adriejan Published: January 6th, 2012 </div>
                <p>
                  Very lucid explanation of how you can distinguish between the different genres in electronic music. Personally, I’m more of the “steady beat” (techno, house) rather than the “broken beat” school (dub, drum ‘n bass),Â on which this presentation focuses, but anyway,Â interesting nonetheless. Wonder if there’s anything that accurately puts into the words the differences between current genres in techno and house music.
                </p>
                <p>
                  <a href="http://www.youtube.com/watch?v=V7qnG5rBfO0&amp;feature=player_embedded" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/V7qnG5rBfO0?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/V7qnG5rBfO0?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F01%2F06%2Frecognizing-styles-in-electronic-music%2F&amp;text=Recognizing Styles In Electronic Music&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2012%2F01%2F06%2Frecognizing-styles-in-electronic-music%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/beats/" shape="rect">beats</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/broken-beat/" shape="rect">broken beat</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/dancehall/" shape="rect">dancehall</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/drum-n-bass/" shape="rect">drum 'n bass</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/dubstep/" shape="rect">dubstep</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/genres/" shape="rect">genres</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/grime/" shape="rect">grime</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/hip-hop/" shape="rect">hip hop</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/house/" shape="rect">house</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/steady-beat/" shape="rect">steady beat</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/styles/" shape="rect">styles</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/two-step/" shape="rect">two step</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in random stuff" href="http://www.lsdimension.com/category/random-stuff/" shape="rect">random stuff</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/11/17/one-hour-of-nachtdigital/" shape="rect">One Hour Of Nachtdigital 2011 </a>
                </h2>
                <div class="byline"> Author: adriejan Published: November 17th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/11/nachtdigital.jpg" shape="rect">
                    <img height="680" width="1024" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/11/nachtdigital.jpg" title="nachtdigital" class="aligncenter size-full wp-image-22716"></img>
                  </a>
                </p>
                <p>
                  One festival that’s high on my list to attend is
                  <a target="_blank" href="http://www.nachtdigital.de/" shape="rect">Nachtdigital</a>
                  Â (in Olganitz, about 140 km south-east of Berlin). No masses, no camping (but bungalows), and a crÃªme-de-la crÃªme electronic line-up.
                </p>
                <p>Enjoy this video of one hour of Nachtdigital 2011Â (for starters, check out the part around 38:30):</p>
                <p>
                  <a href="http://www.youtube.com/watch?v=nsJSbHV3ryA&amp;feature=player_embedded" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/nsJSbHV3ryA?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/nsJSbHV3ryA?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F11%2F17%2Fone-hour-of-nachtdigital%2F&amp;text=One Hour Of Nachtdigital 2011&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F11%2F17%2Fone-hour-of-nachtdigital%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/2011/" shape="rect">2011</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/festivals/" shape="rect">festivals</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/germany/" shape="rect">Germany</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/nachtdigital/" shape="rect">Nachtdigital</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/11/07/manuel-gottsching-e2-e4/" shape="rect">Manuel GÃ¶ttsching – E2-E4 </a>
                </h2>
                <div class="byline"> Author: maartenp Published: November 7th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/11/manuel-gttsching.jpg" shape="rect">
                    <img height="418" width="618" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/11/manuel-gttsching.jpg" title="manuel-gttsching" class="aligncenter size-full wp-image-22436"></img>
                  </a>
                </p>
                <p>
                  On December 12, 1981, krautrock guitarist
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Manuel_G%C3%B6ttsching" shape="rect">Manuel GÃ¶ttsching</a>
                  entered a studio in Berlin and recorded what can considered to be the first modern live dj set. Using only a drummachine, synths and a guitar he produced what would in 1984 be released under the name
                  <strong>
                    <em>E2-E4</em>
                  </strong>
                  . Throughout the recording a single motive is repeated for almost an hour, but with an extremely well crafted build-up and exciting variations it becomes a magnificent musical journey of repetition, much like a modern techno set by a great dj. The result is an entrancing and relentless piece of music. And although it loses some of its power when the guitar kicks in at about 30:00, as RA rightfully points out in
                  <a target="_blank" href="http://www.residentadvisor.net/review-view.aspx?id=4632" shape="rect">this review</a>
                  of the 25th anniversary edition (although I think they are being a way too negative in that review for the sake of having an offbeat opinion), it’s still a very exciting and beautiful piece, even in 2011. The album served as a major inspiration for Derrick May and Juan Atkins and for numerous other later pioneers in electronic music. LCD Soundsystem’s album
                  <em>
                    <a target="_blank" href="http://www.youtube.com/watch?v=iKOjhPvqxrU" shape="rect">45:33</a>
                  </em>
                  is a tribute to
                  <em>E2-E4</em>
                  . 30 years later GÃ¶ttsching has this to say about it:
                </p>
                <blockquote>
                  <p>
                    â€œAnd here I was with a finished, faultless  recording, which I had written, played and produced within the space of  one evening. Should I take the whole thing seriously or dismiss it as  playing around and shove it away in a drawer somewhere: an intermezzo  for the archives? I listened to the tape over and over again. It  certainly was playing around, but pretty damn good playing around. I had  no other choice but to give it a try. And anyway â€“ I already had a  great title.â€�
                  </p>
                </blockquote>
                <p>
                  GÃ¶ttsching still performs
                  <a target="_blank" href="http://www.youtube.com/watch?v=xxo0F-eeOGg&amp;feature=player_embedded" shape="rect">
                    <em>E2-E4</em>
                  </a>
                  and other works
                  <a target="_blank" href="http://www.ashra.com/concerts/welcome.htm" shape="rect">once in a while</a>
                  .
                </p>
                <p>Start here if you want to listen to the entire piece (which I strongly recommend):</p>
                <p>
                  <span class="youtube">
                    <object height="385" width="480">
                      <param value="http://www.youtube.com/v/lUiA0UOKIlc?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0" name="movie" valuetype="data"></param>
                      <param value="true" name="allowFullScreen" valuetype="data"></param>
                      <param value="always" name="allowscriptaccess" valuetype="data"></param>
                      <embed 
                      height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/lUiA0UOKIlc?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0">
</embed>
                    </object>
                  </span>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F11%2F07%2Fmanuel-gottsching-e2-e4%2F&amp;text=Manuel GÃ¶ttsching -- E2-E4&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F11%2F07%2Fmanuel-gottsching-e2-e4%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/ash-ra-tempel/" shape="rect">Ash Ra Tempel</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/derrick-may/" shape="rect">Derrick May</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/detroit-techno/" shape="rect">Detroit techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/juan-atkins/" shape="rect">Juan Atkins</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/krautrock/" shape="rect">Krautrock</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/lcd-soundsystem/" shape="rect">LCD Soundsystem</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/manuel-gottsching/" shape="rect">Manuel GÃ¶ttsching</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/resident-advisor/" shape="rect">Resident Advisor</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/10/07/speaking-in-code/" shape="rect">Speaking In Code </a>
                </h2>
                <div class="byline"> Author: adriejan Published: October 7th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/10/speakingincode.jpg" shape="rect">
                    <img height="370" width="600" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/10/speakingincode.jpg" title="speakingincode" class="aligncenter size-full wp-image-21882"></img>
                  </a>
                </p>
                <p>
                  Somebody has uploaded what by many is considered the best techno documentary ever,
                  <em>
                    <a target="_blank" href="http://speakingincode.com/" shape="rect">Speaking in Code</a>
                    Â 
                  </em>
                  (2009), to YouTube. It’s narrated in German, but that shouldn’t be a problem for any Dutch or German speaking native (sorry if you’re not). The documentary won a couple of independent film festival prizes, so it’s more than just an insiders-only movie.
                </p>
                <p>The film follows a couple of people,Â dj/producers as well as music lovers, in the European and American techno scenes as it existed a couple of years ago.</p>
                <p>
                  From
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Speaking_in_Code" shape="rect">Wikipedia</a>
                  :
                </p>
                <blockquote>
                  <p>
                    <strong>
                      <em>Speaking in Code</em>
                      is an account of people who are lost in music. Director Amy Grill follows a series of characters (including her techno-obsessed husband) over a number of years as some struggle to make it while others thrive in the world of electronic music.
                    </strong>
                  </p>
                  <p>
                    <strong>The film reveals six intertwined character studies and raw vÃ©ritÃ© views of new music. It’s a window into a world filled with warehouse parties, endless gigs, international travel, risks, inventions, triumphs and breakdowns.</strong>
                  </p>
                  <p>
                    The characters are:
                    <strong>Modeselektor</strong>
                    , a producer duo, jettisoned from playing a tiny room in the US to playing to 20,000 people at the
                    <a href="http://en.wikipedia.org/wiki/S%C3%B3nar" title="SÃ³nar" shape="rect">SÃ³nar</a>
                    festival in Barcelona; journalist
                    <strong>Philip Sherburne</strong>
                    , who leaves America to find a more complete techno lifestyle in Europe;
                    <strong>The Wighnomy Brothers</strong>
                    , catapulted from their idyllic world in
                    <a href="http://en.wikipedia.org/wiki/Jena" title="Jena" shape="rect">Jena</a>
                    , Germany to face their breaking point on camera;
                    <strong>Tobias Thomas </strong>
                    of
                    <a href="http://en.wikipedia.org/wiki/Kompakt" title="Kompakt" shape="rect">Kompakt</a>
                    , who contemplates the near-end of his career; and
                    <strong>Monolake</strong>
                    , an inventor of the
                    <a href="http://en.wikipedia.org/wiki/Ableton" title="Ableton" shape="rect">Ableton</a>
                    software that nearly all electronic musicians use to create their music, who continues his steady yet quirky approach to a life in music. While back in the US,
                    <strong>David Day </strong>
                    (Grill’s husband) tries tirelessly to turn
                    <a href="http://en.wikipedia.org/wiki/Boston" title="Boston" shape="rect">Boston</a>
                    from a rock-centric town to a techno city. Day’s wanton attempts to make electronic music popular put strain on his marriage to the director.
                  </p>
                </blockquote>
                <p>
                  And the soundtrack, I must say, is brilliant. If you got time,
                  <a target="_blank" href="http://www.youtube.com/watch?v=bFDdHvrJ0hU" shape="rect">check this out:</a>
                </p>
                <p>
                  <a href="http://www.youtube.com/watch?v=bFDdHvrJ0hU" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/bFDdHvrJ0hU?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/bFDdHvrJ0hU?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F10%2F07%2Fspeaking-in-code%2F&amp;text=Speaking In Code&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F10%2F07%2Fspeaking-in-code%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/amy-grill/" shape="rect">Amy Grill</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/david-day/" shape="rect">David Day</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/documentary/" shape="rect">documentary</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/europe/" shape="rect">Europe</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/film-festival/" shape="rect">film festival</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/german/" shape="rect">German</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/kompakt-label/" shape="rect">Kompakt label</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/minimal-techno/" shape="rect">minimal techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/modeselektor/" shape="rect">Modeselektor</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/monolake/" shape="rect">Monolake</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/north-america/" shape="rect">North America</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/philip-sherburne/" shape="rect">Philip Sherburne</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/speaking-in-code/" shape="rect">Speaking in Code</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/tobias-thomas/" shape="rect">Tobias Thomas</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/wighnomy-brothers/" shape="rect">Wighnomy Brothers</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/youtube/" shape="rect">YouTube</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="category tag" title="View all posts in movies" href="http://www.lsdimension.com/category/movies/" shape="rect">movies</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/09/30/missing-the-monoculture/" shape="rect">Missing The Monoculture </a>
                </h2>
                <div class="byline"> Author: adriejan Published: September 30th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/09/mj-live.jpg" shape="rect">
                    <img height="341" width="560" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/09/mj-live.jpg" title="mj-live" class="aligncenter size-full wp-image-21568"></img>
                  </a>
                </p>
                <p>
                  Here’s one sentiment I can say I don’t share: missing the pop monoculture.
                  <a target="_blank" href="http://www.salon.com/news/music/index.html?story=/ent/music/2011/09/28/how_niches_killed_culture" shape="rect">According to Toure at Salon.com</a>
                  , our culture is “poorer” today because we don’t have gigantic acts like Michael Jackson and Prince anymore, that everybody can gather around to and collectively love. This goes hand in hand with the decline of bigÂ TV and radio stations that everybody used to watch. There are no “massive music moments” anymore when, for instance, an album becomes a big hit. There is no real shared pop culture anymore with larger-than-life figures.
                </p>
                <p>
                  Well, personally, I have no longing
                  <em>at all </em>
                  to go back to that time. As a millennial, I’m old enough to remember the time when you only had one or two music stations on TV; a couple of radio stations; and the charts that were based on album sales. The time before The Internet, when you were dependent on this small set of big media to enjoy pre-selected pop music. Nowadays, I almost never watchÂ TV or listen to the radio anymore, and why would I? It means listening toÂ crappy music catered for the masses. I have the Internet.
                </p>
                <p>
                  What the author at Salon
                  <a target="_blank" href="http://www.salon.com/news/music/index.html?story=/ent/music/2011/09/28/how_niches_killed_culture" shape="rect">calls</a>
                  the “balkanization” of pop culture I totally applaud: the Internet has allowed people to get exposed to more music than ever before, and that is of great value.Â In fact, that’s the only real argument in favor of illegal downloading, I think: exposure to every possible music style of the past and present, expanding your knowledge of pop culture
                  <em>and</em>
                  , if you’re an artist, re-packaging that in something new. I think it’s great that a kid nowadays can listen to Joy Division and actually like it.
                </p>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/09/retromania2.jpg" shape="rect">
                    <img height="817" width="550" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/09/retromania2.jpg" title="retromania2" class="alignright size-full wp-image-21575"></img>
                  </a>
                  Of course, the negative drawback of this mass online availability of past music is the incessant
                  <a target="_blank" href="http://pitchfork.com/features/paper-trail/8010-paper-trail-simon-reynolds/" shape="rect">retromania</a>
                  that has dominated the first decade of the twenty-first century. There was a time when music used to look forward, be futuristic, but that is no longer the case: instead, every past musical niche gets exploited and is re-packaged. The hipster is the ultimate personification of the Internet era: no longer think of something new, but re-use past styles again and again. Nowadays I think only electronic music is still forward-looking, but even there you find more and more retro tunes and vibes. I wonder when something that is totally
                  <em>new</em>
                  will emerge; but before that, I guess first the entire musical and stylistic past must be dug up and re-used again.
                </p>
                <p>That’s something else, however, than missing the time of mainstream pop culture. I’m glad the domination of the musical-industrial complex is over, thank you very much. If that means missing what Toure calls “generational moments”, well, so be it.</p>
                <p>
                  <a target="_blank" href="http://www.salon.com/news/music/index.html?story=/ent/music/2011/09/28/how_niches_killed_culture" shape="rect">Salon.com:</a>
                </p>
                <blockquote>
                  <p>
                    <strong>I love Massive Music Moments.</strong>
                  </p>
                  <p>
                    <strong>I live for those times when an album explodes throughout American society as more than a product — but as a piece of art that speaks to our deepest longings and desires and anxieties. </strong>
                    In these Moments, an album becomes so ubiquitous it seems to blast through the windows, to chase you down until it’s impossible to ignore it. But you don’t want to ignore it, because the songs are holding up a mirror and telling you who we are at that moment in history.
                  </p>
                  <p>
                    <strong>These sorts of Moments can’t be denied. They leave an indelible imprint on the collective memory; when we look back at the year or the decade or the generation, there’s no arguing that the album had a huge impact on us.</strong>
                    It’s pop music not just as private joy, but as a unifier, giving us something to share and bond over.
                  </p>
                  <p>
                    <strong>Actually, I should say I loved Massive Music Moments. They don’t really happen anymore.</strong>
                  </p>
                  <p>
                    <strong>
                      The epic, collective roar — you know, the kind that followed
                      <a target="_blank" href="http://www.spike.com/video-clips/660mbu/michael-jackson-thriller" shape="rect">“Thriller,”</a>
                      <a target="_blank" href="http://www.youtube.com/watch?v=hTWKbfoikeg" shape="rect">“Nevermind,”</a>
                      <a target="_blank" href="http://www.youtube.com/watch?v=Ij-jM8CcQIQ" shape="rect">“Purple Rain,”</a>
                      <a target="_blank" href="http://www.youtube.com/watch?v=1INb5FM_1lE" shape="rect">“It Takes a Nation of Millions to Hold Us Back,”</a>
                      and other albums so gigantic you don’t even need to name the artist — just doesn’t happen today. Those Moments made you part of a large tribe linked by sounds that spoke to who you are or who you wanted to be. Today there’s no Moments, just moments. They’re smaller, less intense, shorter in duration and shared by fewer people. The Balkanization of pop culture, the overthrow of the monopoly on distribution, and the fracturing of the collective attention into a million pieces has made it impossible for us to coalesce around one album en masse. We no longer live in a monoculture.
                    </strong>
                    We can’t even agree to hate the same thing anymore, as we did with
                    <a target="_blank" href="http://www.youtube.com/watch?v=o-fEtF9NKfc" shape="rect">disco in the 1970s</a>
                    .
                  </p>
                  <div id="story_full_mps2049281">
                    <p>
                      <strong>If you’re under 25, you’ve never felt a true Massive Music Moment. </strong>
                      Not Lady Gaga. Not Adele. Not even
                      <a target="_blank" href="http://www.youtube.com/watch?v=9d8S_9PZ56M" shape="rect">Kanye</a>
                      . As the critic Chuck Klosterman has written, “There’s fewer specific cultural touchstones that every member of a generation shares.” Sure, Gaga’s
                      <a target="_blank" href="http://en.wikipedia.org/wiki/The_Fame_Monster" shape="rect">“The Fame Monster”</a>
                      spawned several hit singles. Adele’s “21″ and Jay-Z and Kanye West’s “Watch the Throne” were massively popular. Kanye’s brilliant
                      <a target="_blank" href="http://www.rollingstone.com/music/albumreviews/my-beautiful-dark-twisted-fantasy-20101109" shape="rect">“My Beautiful Dark Twisted Fantasy”</a>
                      was beloved and controversial and widely discussed enough to give a glimpse into the way things used to be. But those successes don’t compare to the explosive impact that “Thriller” and “Nevermind” had on American culture — really, will anyone ever commemorate “21″ at 20, the way the anniversary of Nirvana’s album has been
                      <a 
                      target="_blank" href="http://www.google.com/search?q=nirvana+anniversary&amp;ie=utf-8&amp;oe=utf-8&amp;aq=t&amp;rls=org.mozilla:en-US:official&amp;client=firefox-a#sclient=psy&amp;hl=en&amp;client=firefox-a&amp;rls=org.mozilla:en-US%3Aofficial&amp;tbm=nws&amp;source=hp&amp;q=nirvana+nevermind+20&amp;pbx=1&amp;oq=nirvana+nevermind+20&amp;aq=f&amp;aqi=&amp;aql=1&amp;gs_sm=e&amp;gs_upl=0l0l3l1376l0l0l0l0l0l0l0l0ll0l0&amp;bav=on.2,or.r_gc.r_pw.,cf.osb&amp;fp=d5327f6539374380&amp;biw=986&amp;bih=836" shape="rect">
                        memorialized
</a>
                      in the last month?
                    </p>
                    <p>
                      Numbers don’t tell the whole story about how these cultural atomic bombs detonated and dominated pop culture. But at its peak, “Thriller” sold 500,000 copies a week. These days, the No. 1 album on the Billboard charts often sells less than 100,000 copies a week. What we have today are smaller detonations, because pop culture’s ability to unify has been crippled.
                    </p>
                    <p>
                      <strong>I miss Moments. I love being obsessed by a new album at the same time as many other people are. </strong>
                      The last two albums that truly grabbed an enormous swath of America by the throat and made us lose our collective mind were “Nevermind” and Dr. Dre’s “The Chronic.” They sprung from something deep in the country’s soul and spoke to a generation’s disaffection and nihilism. They announced new voices on the national stage who would become legends (Kurt Cobain and Snoop Dogg) and introduced the maturation of subgenres that would have tremendous impact (grunge and gangsta rap).
                    </p>
                    <p>(…)</p>
                    <p>
                      <strong>Nowadays my music conversations run like this:</strong>
                    </p>
                    <p>â€œSo what are you listening to?â€�</p>
                    <p>
                      â€œAw, you gotta check out
                      <a target="_blank" href="http://www.spin.com/articles/danny-browns-geeked-freaky-tales" shape="rect">Danny Brown</a>
                      and
                      <a target="_blank" href="http://www.abbemay.com/" shape="rect">Abbe May</a>
                      and
                      <a target="_blank" href="http://dasracist.net/" shape="rect">Das Racist</a>
                      .â€�
                    </p>
                    <p>â€œOK, cool. I’ve never heard of them.â€�</p>
                    <p>â€œWhat are you listening to?â€�</p>
                    <p>
                      â€œ
                      <a target="_blank" href="http://pitchfork.com/news/41313-the-horrors-frontman-faris-badwan-starts-new-band-called-cats-eyes-performs-at-the-vatican/" shape="rect">Cat’s Eye</a>
                      and
                      <a target="_blank" href="http://www.arielpink.com/" shape="rect">Ariel Pink</a>
                      and
                      <a target="_blank" href="http://www.myspace.com/littledragon" shape="rect">Little Dragon</a>
                      .â€�
                    </p>
                    <p>â€œOh. I gotta check them out.â€�</p>
                    <p>
                      No connection is made. Pop music has historically been great at creating Moments that brought people together.
                      <strong>Now we’re all fans traveling in much smaller tribes, never getting the electric thrill of being in a big, ecstatic stampede. </strong>
                      It’s reflected in the difference between the boombox and the iPod. The box was a public device that broadcast your choices to everyone within earshot and shaped the public discourse. The man with the box had to choose something current (or classic) that spoke to what the people wanted to hear.
                      <strong>Now the dominant device, the iPod, privatizes the music experience, shutting you and your music off from the world. The iPod also makes it easy to travel with a seemingly infinite collection of songs</strong>
                      — which means whatever you recently downloaded has to compete for your attention with everything you’ve ever owned. The iPod tempts you not to connect with the present, but to wallow in sonic comfort food from the past.
                    </p>
                    <p>
                      <strong>Back when MTV played videos, it functioned like a televised boombox. It was the central way for many people to experience music they loved and learn about new artists. Thus MTV directed and funneled the conversation. Now there’s no central authority. </strong>
                      Fuse, where I work, plays videos and concerts and introduces people to new artists. But people also watch videos online, where there’s an endless library of everything ever made but no curation, killing its unifying potential.
                    </p>
                    <p>
                      These days, there are many more points of entry into the culture for a given album or artist. That can be a good thing — MTV, after all, played a limited number of videos in heavy rotation. Now there’s the potential to be exposed to more music. But where there used to be a finite number of gatekeepers, now there’s way too many: anyone with a blog. This is great for the individual listener who’s willing to sift through the chatter to find new bands. But society loses something when pop music does not speak to the entire populace.
                    </p>
                    <p>(…)</p>
                    <p>
                      <strong>Hollywood, too, is struggling to unite us.</strong>
                      “Star Wars” and “The Matrix” and “Pulp Fiction” were so big they changed American film — as well as our visual language and Madison Avenue. You didn’t need to actually see the films to feel as if you had consumed them. Their impact was so pervasive, they seemed to bang down your door and announce themselves.
                      <strong>The Harry Potter films and “Avatar” stand out for the size of the marketing and ticket buying associated with them. But did they bring large, diverse swaths of America together? Did they speak to something deep in the American soul?</strong>
                    </p>
                  </div>
                </blockquote>
                <div id="story_full_mps2049281">
                  <p>It really seems to speak from a deep-seated insecurity of the author, doesn’t it? Please, go explore music that isn’t spit out over the masses and find a niche you like!</p>
                </div>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F09%2F30%2Fmissing-the-monoculture%2F&amp;text=Missing The Monoculture&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F09%2F30%2Fmissing-the-monoculture%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/albums/" shape="rect">albums</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/bands/" shape="rect">bands</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/downloading/" shape="rect">downloading</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/futurism/" shape="rect">futurism</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/hipsters/" shape="rect">hipsters</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/internet/" shape="rect">Internet</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/ipod/" shape="rect">iPod</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/itunes/" shape="rect">iTunes</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/mainstream/" shape="rect">mainstream</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/monoculture/" shape="rect">monoculture</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/music/" shape="rect">music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/music-industry/" shape="rect">music industry</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/niches/" shape="rect">niches</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pop/" shape="rect">pop</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pop-culture/" shape="rect">pop culture</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pop-music/" shape="rect">pop music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/radio/" shape="rect">radio</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/retro/" shape="rect">retro</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/retromania/" shape="rect">retromania</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/television/" shape="rect">television</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in gadgets / futuristic" href="http://www.lsdimension.com/category/gadgets-futuristic/" shape="rect">gadgets / futuristic</a>
                  ,
                  <a rel="category tag" title="View all posts in history" href="http://www.lsdimension.com/category/history/" shape="rect">history</a>
                  ,
                  <a rel="category tag" title="View all posts in random stuff" href="http://www.lsdimension.com/category/random-stuff/" shape="rect">random stuff</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/08/23/a-trip-round-acid-house/" shape="rect">A Trip Round Acid House </a>
                </h2>
                <div class="byline"> Author: adriejan Published: August 23rd, 2011 </div>
                <p>
                  <img height="609" width="1167" alt="" src="http://1.bp.blogspot.com/_n0YpaaD_r9I/S73GA77edtI/AAAAAAAAAIo/oZzSkp79TJs/s1600/tb-303.jpg" title="acidhouse" class="aligncenter"></img>
                </p>
                <p>
                  A while ago, we presented y’all a documentary on the early 1980sÂ origins of warehouse raves andÂ techno,Â 
                  <a target="_blank" href="http://www.lsdimension.com/2011/08/10/real-scenes-detroit/" shape="rect">Real Scenes: Detroit</a>
                  . Now, get ready to submerge in the following documentary on its British successor movement:
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Acid_house" shape="rect">acid house</a>
                  !
                </p>
                <p>
                  During the late 1980s, acid house, with its distinctive soundÂ produced by Roland bassÂ synthesizers and drum machines such as the
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Roland_TB-303" shape="rect">TB 303</a>
                  and
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Roland_TR-808" shape="rect">TR 808</a>
                  ,Â presented the first full-blown electronic dance music movement in Europe, including a booming underground scene. It also presented the first coming to the surface of
                  <a target="_blank" href="http://www.lsdimension.com/tag/xtc/" shape="rect">ecstasy</a>
                  , which contributed to the summers of 1988-9 being called the
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Second_Summer_of_Love" shape="rect">second Summer of Love </a>
                  (after the lsd-fueled first one in 1969). A
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/08/acidhousesmiley.jpg" shape="rect">
                    <img height="200" width="200" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/08/acidhousesmiley.jpg" title="acidhousesmiley" class="alignright size-full wp-image-20647"></img>
                  </a>
                  cid house parties took place in warehouses and out in the open, thus continuing the Detroit phenomenon of the “rave”. Fueled by sensationalist media reporting, however, British authorities came
                  <a target="_blank" href="http://www.lsdimension.com/2011/01/24/the-chemical-generation/" shape="rect">crashing down</a>
                  on the acid house scene.
                </p>
                <p>
                  <a target="_blank" href="http://www.dangerousminds.net/comments/the_rave_years_pt_1_a_trip_round_acid_house_1988/" shape="rect">Dangerous Minds</a>
                  on the 1988 BBC documentary
                  <a target="_blank" href="http://www.youtube.com/watch?v=VjwNGM_6yU8&amp;feature=player_embedded" shape="rect">A Trip Round Acid House</a>
                  :
                </p>
                <blockquote>
                  <p>
                    <strong>This great documentary from the BBCâ€™s World in Action strand is like a full blown acid house flashback.</strong>
                    Broadcast in 1988 at height of acid house fever, it follows the typical weekend rituals of a group of very young fans, tracks the working life of an illegal party promoter, speaks to some of the producers of the music and charts the the then-growing moral panic which surrounded the scene and its copious drug taking.
                    <strong>Raving, and acid house, had a huge (if subtle) effect on British culture, bringing people together in new, democratised contexts free of class and social boundaries, opening peopleâ€™s ears up to a new world of music and opening their minds to new ideas.</strong>
                  </p>
                </blockquote>
                <p>So here’s the entire documentary. Enjoy!</p>
                <p>
                  <a href="http://www.youtube.com/watch?v=VjwNGM_6yU8&amp;feature=player_embedded" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/VjwNGM_6yU8?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/VjwNGM_6yU8?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <p>
                  <a href="http://www.youtube.com/watch?v=GfzFiECOWU4&amp;feature=related" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/GfzFiECOWU4?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=related" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/GfzFiECOWU4?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=related">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <p>
                  <a href="http://www.youtube.com/watch?v=gVUhRgWBXKo&amp;feature=related" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/gVUhRgWBXKo?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=related" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/gVUhRgWBXKo?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=related">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <p>
                  <strong>More electronic music historyÂ documentaries on LSD:</strong>
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2011/08/10/real-scenes-detroit/" shape="rect">Real Scenes: Detroit</a>
                  Â (techno)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2011/05/10/high-tech-soul-the-creation-of-techno/" shape="rect">High Tech Soul: The Creation of Techno</a>
                  Â (techno)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2011/01/24/the-chemical-generation/" shape="rect">The Chemical Generation</a>
                  Â (acid house)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2010/12/11/house-gewoon-uit-je-dak/" shape="rect">House? Gewoon uit je dak</a>
                  Â (acid house, house)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2011/01/13/studio-54-the-story/" shape="rect">Studio 54 -- The Story</a>
                  (discoÂ rather thanÂ electronic, but highly relevant)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2010/05/14/the-summer-of-rave/" shape="rect">The Summer Of Rave</a>
                  Â (acid house)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2010/03/15/speaking-in-code-documentary-about-techno-artists/" shape="rect">Speaking In Code: Documentary About Techno Artists</a>
                  Â (techno)
                </p>
                <p>
                  <a target="_blank" href="http://www.lsdimension.com/2010/02/17/docu-kraftwerk-and-the-electronic-revolution/" shape="rect">Kraftwerk And The Electronic Revolution</a>
                  Â (electronica)
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F23%2Fa-trip-round-acid-house%2F&amp;text=A Trip Round Acid House&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F23%2Fa-trip-round-acid-house%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/1980s/" shape="rect">1980s</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/1988/" shape="rect">1988</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/a-trip-round-acid-house/" shape="rect">A Trip Round Acid House</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/acid-house/" shape="rect">acid house</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/bass-synthesizer/" shape="rect">bass synthesizer</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/bbc/" shape="rect">BBC</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/detroit/" shape="rect">Detroit</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/documentary/" shape="rect">documentary</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/drum-machine/" shape="rect">drum machine</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/rave/" shape="rect">rave</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/roland/" shape="rect">Roland</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/second-summer-of-love/" shape="rect">Second Summer of Love</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/tb-303/" shape="rect">TB-303</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/tr-808/" shape="rect">TR-808</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/united-kingdom/" shape="rect">United Kingdom</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/warehouse-rave/" shape="rect">warehouse rave</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/xtc/" shape="rect">xtc</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="category tag" title="View all posts in history" href="http://www.lsdimension.com/category/history/" shape="rect">history</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/08/17/red-strand-oog-in-al/" shape="rect">Red Strand Oog in Al! </a>
                </h2>
                <div class="byline"> Author: adriejan Published: August 17th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/08/strand.jpg" shape="rect">
                    <img height="225" width="480" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/08/strand.jpg" title="strand" class="aligncenter size-full wp-image-20520"></img>
                  </a>
                </p>
                <p>
                  Uitgaan in Utrecht is ruk. Tenzij je houdt van overvolle studentenkroegen met domme muziek, ofÂ tenten voor asocialenÂ met nogÂ dommere muziek, is “de stad ingaan” in deze plaats meer survival dan lol. Jarenlang mooi gevonden, maar op een avond word je ineens wakker, kijk je om je heen,Â en realiseer je je: ‘Wat is dit kut.’
                </p>
                <p>
                  Voor een beetje aardige muziek, bij voorkeur elektronisch, en dito mensen dient men zich dan ook te wenden tot het illegale circuit, de hoofdstad, of tot de vele festivalletjes die er, toegegeven, steeds meer komen. Sinds enige tijd echter gloort er ook meer hoop aan de horizon:
                  <a target="_blank" href="http://www.elevation-events.com/events/strand-oog-in-al" shape="rect">Strand Oog in Al</a>
                  !
                </p>
                <p>
                  Dit stadsstrand met houten strandtent kan omschreven worden als een kleine oase: de Utrechtse versie van het BerlijnseÂ 
                  <a target="_blank" href="http://www.lsdimension.com/2010/10/24/bar25-der-film/" shape="rect">Bar25</a>
                  , waar wel leuke dj’s draaien, en geen vervelend volk komt. Zich verheugend in toenemende populariteit, maar nog steeds redelijk onontdekt. De zon die ondergaat tegen het industriÃ«le decor zorgt voor romantische taferelen.
                </p>
                <p>
                  Maar niets is zo leuk of het moet weer verdwijnen. De vergunning voor Strand Oog in Al
                  <a target="_blank" href="http://www.geluidnieuws.nl/2008/aug2008/strand.html" shape="rect">loopt af</a>
                  , en de gemeente wil deze niet verlengen. Als Utrechter ben je dus zo dadelijk weer veroordeeld om te kiezen tussen deze of die lompe toko. Een groot verlies, dat het coolheidsgehalte van de stad zeker niet ten goede komt. En dat terwijl het zo’n leuke en mooie locatie is.
                </p>
                <p>
                  <strong>
                    <a target="_blank" href="http://www.elevation-events.com/strandooginal-moet-blijven" shape="rect">Teken daarom deze petitie voor behoud van Strand Oog in Al!</a>
                  </strong>
                </p>
                <p>
                  <em>Opdat we zo dadelijk niet weer naar Zanger RinusÂ in De Kneus hoeven te luisteren…</em>
                </p>
                <p>
                  <em>
                    <a href="http://www.lsdimension.com/wp-content/uploads/2011/08/strandooginal.jpg" shape="rect">
                      <img height="360" width="1000" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/08/strandooginal.jpg" title="strandooginal" class="aligncenter size-full wp-image-20523"></img>
                    </a>
                  </em>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F17%2Fred-strand-oog-in-al%2F&amp;text=Red Strand Oog in Al!&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F17%2Fred-strand-oog-in-al%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/bar25/" shape="rect">Bar25</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/elevation-events/" shape="rect">Elevation Events</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/gemeente-utrecht/" shape="rect">gemeente Utrecht</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/oog-in-al/" shape="rect">Oog in Al</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/petitie/" shape="rect">petitie</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/sluiting/" shape="rect">sluiting</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/stadsstrand/" shape="rect">stadsstrand</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/strand/" shape="rect">strand</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/strand-oog-in-al/" shape="rect">Strand Oog in Al</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/utrecht/" shape="rect">Utrecht</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/vergunning/" shape="rect">vergunning</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in random stuff" href="http://www.lsdimension.com/category/random-stuff/" shape="rect">random stuff</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/08/07/the-sound-of-berlin-ipad-app/" shape="rect">The Sound Of Berlin iPad App </a>
                </h2>
                <div class="byline"> Author: adriejan Published: August 7th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/05/berlin_berghain_club_klein_vntg1.jpg" shape="rect">
                    <img height="388" width="600" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/05/berlin_berghain_club_klein_vntg1.jpg" title="berlin_berghain_club_klein_vntg" class="aligncenter size-full wp-image-16940"></img>
                  </a>
                </p>
                <p>
                  Pretty cool: an
                  <a target="_blank" href="http://de-bug.de/gadgets/archives/gelandet-unsere-erste-ipad-app.html" shape="rect">iPad app</a>
                  fully dedicated to the history and here-and-now of Berlin as electronic party paradise. Explore food joints with Modeselektor, urban architecture with Ben de Biel,Â day parties with Kotelett and Zadak, as well as hidden pieces of street art,Â the process ofÂ gentrification and hardware shopping.
                </p>
                <p>Makes me want to go back to Berlin really bad…</p>
                <iframe height="281" width="500" src="http://player.vimeo.com/video/26909717?title=1&amp;byline=1&amp;portrait=1" scrolling="auto" frameborder="0"></iframe>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F07%2Fthe-sound-of-berlin-ipad-app%2F&amp;text=The Sound Of Berlin iPad App&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F07%2Fthe-sound-of-berlin-ipad-app%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/app/" shape="rect">app</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/apps/" shape="rect">apps</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/architecture/" shape="rect">architecture</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/ben-de-biel/" shape="rect">Ben de Biel</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/berlin/" shape="rect">Berlin</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/clubs/" shape="rect">clubs</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/food/" shape="rect">food</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/friedrichshain/" shape="rect">Friedrichshain</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/gentrification/" shape="rect">gentrification</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/germany/" shape="rect">Germany</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/ipad/" shape="rect">iPad</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/kotelett/" shape="rect">Kotelett</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/kreuzberg/" shape="rect">Kreuzberg</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/modeselektor/" shape="rect">Modeselektor</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/prenzlauer-berg/" shape="rect">Prenzlauer Berg</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/street-art/" shape="rect">street art</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/underground/" shape="rect">underground</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/urban-art/" shape="rect">urban art</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/zadak/" shape="rect">Zadak</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in gadgets / futuristic" href="http://www.lsdimension.com/category/gadgets-futuristic/" shape="rect">gadgets / futuristic</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/08/04/halim-el-dabh-1940s-electronic-music-pioneer-from-egypt/" shape="rect">Halim El-Dabh, 1940s Electronic Music Pioneer From Egypt </a>
                </h2>
                <div class="byline"> Author: adriejan Published: August 4th, 2011 </div>
                <p>
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/08/halimeldab.jpg" shape="rect">
                    <img height="514" width="771" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/08/halimeldab.jpg" title="halimeldab" class="aligncenter size-full wp-image-20146"></img>
                  </a>
                </p>
                <p>
                  Electronic music as an art form is often credited to start with the likes of pioneers such as
                  <a target="_blank" href="http://www.lsdimension.com/2010/09/17/karlheinz-stockhausen-on-sounds/" shape="rect">Karlheinz Stockhausen</a>
                  Â and
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Pierre_Schaeffer" shape="rect">Pierre Schaeffer</a>
                  , in the 1940s and 1950s. However, one guy in Egypt was there earlier:
                  <a target="_blank" href="http://www.halimeldabh.com/" shape="rect">Halim El-Dabh</a>
                  (1921), who in 1944 hit the streets of Cairo to record ambient sounds and music, and experiment with it afterwards.
                </p>
                <p>
                  <a target="_blank" href="http://boingboing.net/2011/08/03/halim-el-dabh-electronic-music-pioneer.html" shape="rect">Boing Boing</a>
                  has more:
                </p>
                <blockquote>
                  <p>
                    <strong>
                      While Pierre Schaeffer is often thought of as the father of the electronic music form known as
                      <em>musique concrÃšte</em>
                      the gentleman above, Halim El-Dabh, actually got there several years before, 1944 to be exact
                    </strong>
                    . Born in Egypt in 1921, El-Dabh studied agriculture at Cairo University while playing piano and other traditional instruments as a pastime.
                    <strong>
                      One day, the student and a friend borrowed a wire recorder — a device predating magnetic tape — from the Middle East Radio Station and hit the streets to capture ambient sounds. El-Dabh recorded a spirit-summoning ritual called a zaar ceremony and ultimately found that he could use the sounds as the raw ingredients for a new composition.
                    </strong>
                  </p>
                </blockquote>
                <p>
                  An excerpt from the 1944 composition called “The Expression of Zaar”Â is here below, credited as ‘the earliest piece of electronic music ever produced’. I don’t know whether that’s true, but it sounds very ambient and cool. Not too surprising if you realizeÂ you’re listening to a spiritual ceremony from 1940s Cairo:
                </p>
                <p>
                  <a href="http://www.youtube.com/watch?v=j_kbNSdRvgo&amp;feature=player_embedded" shape="rect">
                    <span class="youtube">
                      <object height="385" width="480">
                        <param value="http://www.youtube.com/v/j_kbNSdRvgo?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded" name="movie" valuetype="data"></param>
                        <param value="true" name="allowFullScreen" valuetype="data"></param>
                        <param value="always" name="allowscriptaccess" valuetype="data"></param>
                        <embed 
                        height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/j_kbNSdRvgo?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=player_embedded">
</embed>
                      </object>
                    </span>
                  </a>
                </p>
                <p>
                  The
                  <a target="_blank" href="http://emfinstitute.emf.org/articles/gluck.eldabh.html" shape="rect">Electronic Music Foundation</a>
                  has an interview with El-Dabh, who is currently Professor Emeritus of African Ethnomusicology at Kent State University. About the 1944 piece:
                </p>
                <blockquote>
                  <p>
                    <strong>We had to sneak in (to the ritual) with our heads covered like the women, since men were not allowed in.</strong>
                    I recorded the music and brought the recording back to the radio station and experimented with modulating the recorded sounds. I emphasized the harmonics of the sound by removing the fundamental tones and changing the reverberation and echo by recording in a space with movable walls. I did some of this using voltage controlled devices. It was not easy to do. I didn’t think of it as electronic music, but just as an experience. I called the piece Ta’abir al-Zaar, (The Expression of Zaar). A short version of it has become known as Wire Recorder Piece.
                    <strong>At the time in Egypt, nobody else was working with electronic sounds. I was just ecstatic about sounds.</strong>
                  </p>
                </blockquote>
                <p>
                  Check out Mr. El-Dabh’s
                  <a target="_blank" href="http://www.halimeldabh.com/" shape="rect">website</a>
                  .
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F04%2Fhalim-el-dabh-1940s-electronic-music-pioneer-from-egypt%2F&amp;text=Halim El-Dabh, 1940s Electronic Music Pioneer From Egypt&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F08%2F04%2Fhalim-el-dabh-1940s-electronic-music-pioneer-from-egypt%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/1940s/" shape="rect">1940s</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/1944/" shape="rect">1944</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/1950s/" shape="rect">1950s</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/ambient/" shape="rect">ambient</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/cairo/" shape="rect">Cairo</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/egypt/" shape="rect">Egypt</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music-foundation/" shape="rect">Electronic Music Foundation</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/halim-el-dabh/" shape="rect">Halim El-Dabh</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/karlheinz-stockhausen/" shape="rect">Karlheinz Stockhausen</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/musique-concrete/" shape="rect">musique concrÃšte</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pierre-schaeffer/" shape="rect">Pierre Schaeffer</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/pioneers/" shape="rect">pioneers</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/the-expression-of-zaar/" shape="rect">The Expression of Zaar</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/wire-recorder/" shape="rect">wire recorder</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/zaar-ceremony/" shape="rect">zaar ceremony</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="category tag" title="View all posts in history" href="http://www.lsdimension.com/category/history/" shape="rect">history</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/01/18/thomas-fehlmann-dfm/" shape="rect">Thomas Fehlmann – DFM </a>
                </h2>
                <div class="byline"> Author: adriejan Published: January 18th, 2011 </div>
                <p style="text-align:center;">
                  <a href="http://www.lsdimension.com/wp-content/uploads/2011/01/fehlmann.jpg" shape="rect">
                    <img height="300" width="400" alt="" src="http://www.lsdimension.com/wp-content/uploads/2011/01/fehlmann.jpg" title="fehlmann" class="aligncenter size-full wp-image-12011"></img>
                  </a>
                </p>
                <p>
                  <a target="_blank" href="http://www.flowing.de/" shape="rect">Thomas Fehlmann</a>
                  is a Swiss composer and producer of electronic music, born in 1957. His career has been stellar: after joining the German avant garde band
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Palais_Schaumburg_(band)" shape="rect">Palais Schaumburg</a>
                  , he moved to Berlin in 1984, where he built a home studio to focus on electronic music. Four years later he founded the label “Teutonic Beats”, to which among others the pioneering German techno dj
                  <a target="_blank" href="http://en.wikipedia.org/wiki/WestBam" shape="rect">Westbam</a>
                  belonged. In 1990 he started working with the epochal British ambient techno group
                  <a target="_blank" href="http://en.wikipedia.org/wiki/The_Orb" shape="rect">The Orb</a>
                  (he is credited for such tracks als “
                  <a target="_blank" href="http://www.youtube.com/watch?v=WXIym7GhLLk" shape="rect">Little Fluffy Clouds</a>
                  ” and “
                  <a target="_blank" href="http://www.youtube.com/watch?v=Edo3cp5NM7k" shape="rect">Blue Room</a>
                  “), as well as playing in the infamous Berlin Tresor club. For Tresor Records he worked among others with the first wave of Detroit techno dj’s, such asÂ Juan Atkins and Blake Baxter.
                </p>
                <p>
                  Fehlmann has a string of albums of his own, moreover, such as
                  <em>
                    <a target="_blank" href="http://www.flowing.de/visions.html" shape="rect">Visions of Blah</a>
                  </em>
                  (2002),
                  <em>
                    <a target="_blank" href="http://www.flowing.de/lowflow.html" shape="rect">Lowflow</a>
                  </em>
                  (2004),
                  <em>
                    <a target="_blank" href="http://www.flowing.de/honig.html" shape="rect">Honigpumpe</a>
                  </em>
                  (2007) and
                  <em>
                    <a target="_blank" href="http://pitchfork.com/reviews/albums/14081-gute-luft/" shape="rect">Gute Luft</a>
                  </em>
                  (2010), all on the Cologne-based German minimal techno
                  <a target="_blank" href="http://en.wikipedia.org/wiki/Kompakt" shape="rect">Kompakt</a>
                  label. The latter two albumsÂ are full of delightful minimal techno music, filled with little sounds and musical textures, like it seems only Germans (or in this case, the Swiss)Â can create.
                </p>
                <p>
                  So just now, he released the brilliant minimal track “DFM”, which can be listened to over
                  <strong>
                    <a target="_blank" href="http://pitchfork.com/reviews/tracks/12077-dfm/" shape="rect">here</a>
                  </strong>
                  . As Pitchfork has it:
                </p>
                <blockquote>
                  <p>
                    “DFM” is a reworking of
                    <a target="_blank" href="http://www.youtube.com/watch?v=8DfN2mJhDG4" shape="rect">“Du Fehlst Mir”</a>
                    , which was a cut from Fehlmann’s 2002 release,
                    <a target="_blank" href="http://pitchfork.com/reviews/albums/3024-visions-of-blah/" shape="rect">
                      <em>Visions of Blah</em>
                    </a>
                    , and bears all the hallmarks of his classical counterparts, as scrapes of discordant violin and twinkly vibraphone ripple across his gently burbling surface drones. It’s around the 3:40 mark of the nine-minute-plus track that the ideas really coalesce into something magical, as a burst of percussion lifts the song beyond its ambient origins and sends it twirling into airy wonderment. Impressively, there’s a lightness of touch at work here despite the classical riches at Fehlmann’s fingertips, and the song never feels cluttered despite the dovetailing strings and loops in its final third, which reaches a heart-crushing crescendo via a delicately worked violin coda somewhat reminiscent of Sean O’Hagan’s arrangements for
                    <a target="_blank" href="http://pitchfork.com/artists/3945-stereolab/" shape="rect">Stereolab</a>
                    .
                  </p>
                </blockquote>
                <p>Â Listen to it. Ideal for chilling in the grass in the sun.</p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F01%2F18%2Fthomas-fehlmann-dfm%2F&amp;text=Thomas Fehlmann – DFM&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F01%2F18%2Fthomas-fehlmann-dfm%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/ambient/" shape="rect">ambient</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/berlin/" shape="rect">Berlin</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/detroit/" shape="rect">Detroit</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/germany/" shape="rect">Germany</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/gute-luft/" shape="rect">Gute Luft</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/honigpumpe/" shape="rect">Honigpumpe</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/juan-atkins/" shape="rect">Juan Atkins</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/kompakt-label/" shape="rect">Kompakt label</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/lowflow/" shape="rect">Lowflow</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/minimal/" shape="rect">minimal</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/techno/" shape="rect">techno</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/teutonic-beats-label/" shape="rect">Teutonic Beats label</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/the-orb/" shape="rect">The Orb</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/thomas-fehlmann/" shape="rect">Thomas Fehlmann</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/tresor/" shape="rect">Tresor</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/visions-of-blah/" shape="rect">Visions of Blah</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/westbam/" shape="rect">Westbam</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2011/01/10/fract-indie-electronic-music-adventure-game/" shape="rect">FRACT: Indie Electronic Music Adventure Game </a>
                </h2>
                <div class="byline"> Author: adriejan Published: January 10th, 2011 </div>
                <iframe height="281" width="500" src="http://player.vimeo.com/video/18548118?title=1&amp;byline=1&amp;portrait=1" scrolling="auto" frameborder="0"></iframe>
                <p>
                  Some interesting visuals and sounds in this trailer. Download the beta
                  <a target="_blank" href="http://richardeflanagan.com/lab/10-fract-beta-come-and-play" shape="rect">here</a>
                  .
                </p>
                <blockquote>
                  <p>FRACT is an atmospheric adventure game set in an abstract forgotten world of analog sounds, samples and glitches. Myst + Rez with a heavy dose of Tron.</p>
                  <p>
                    FRACT is a first person puzzle game â€“ very much in the vein of the classic Myst titles.
                    <strong>The player is let loose into an abstract world built on sound and structures inspired by electronic music.</strong>
                    Itâ€™s up to the player to resurrect and revive the long forgotten machinery of this musical world, in order to unlock itsâ€™ inner workings!
                  </p>
                </blockquote>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F01%2F10%2Ffract-indie-electronic-music-adventure-game%2F&amp;text=FRACT: Indie Electronic Music Adventure Game&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2011%2F01%2F10%2Ffract-indie-electronic-music-adventure-game%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/beta/" shape="rect">beta</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/fract/" shape="rect">FRACT</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/games/" shape="rect">games</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="category tag" title="View all posts in gadgets / futuristic" href="http://www.lsdimension.com/category/gadgets-futuristic/" shape="rect">gadgets / futuristic</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2010/12/19/rock-fans-outraged-as-bob-dylan-goes-electronica/" shape="rect">Rock Fans Outraged As Bob Dylan Goes Electronica </a>
                </h2>
                <div class="byline"> Author: adriejan Published: December 19th, 2010 </div>
                <p style="text-align:center;">
                  <img height="336" width="540" alt="" src="http://o.onionstatic.com/images/articles/article/17699/dylan_large.jpg" title="dylan" class="aligncenter"></img>
                </p>
                <p>
                  <a target="_blank" href="http://www.theonion.com/articles/rock-fans-outraged-as-bob-dylan-goes-electronica,17699/" shape="rect">The Onion:</a>
                </p>
                <blockquote>
                  <p>
                    NEWPORT, RIâ€”Audience members at the Newport Rock Festival were “outraged” Monday when rock icon Bob Dylan followed up such classic hits as “Like A Rolling Stone” and “Maggie’s Farm” with an electronica set composed of atonal drones, hyperactive drumbeats, and the repeated mechanized lyric “Dance to the club life!” “We came here to see the authentic Dylan, the one with the Stratocaster guitar and signature wild blues-rock band behind him,” audience member Robert Hochschild said. “Then he walks out with these puffy headphones, some turntables, and a laptop? The guy’s a Judas.” When asked later about his musical transformation by reporters, Dylan said he had nothing to say about the beats he programs, he just programs them.
                  </p>
                </blockquote>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F12%2F19%2Frock-fans-outraged-as-bob-dylan-goes-electronica%2F&amp;text=Rock Fans Outraged As Bob Dylan Goes Electronica&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F12%2F19%2Frock-fans-outraged-as-bob-dylan-goes-electronica%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/bob-dylan/" shape="rect">Bob Dylan</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/newport-folk-festival/" shape="rect">Newport Folk Festival</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/the-onion/" shape="rect">The Onion</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="category tag" title="View all posts in random stuff" href="http://www.lsdimension.com/category/random-stuff/" shape="rect">random stuff</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2010/09/20/aphex-twin-vs-stockhausen/" shape="rect">Aphex Twin vs. Stockhausen </a>
                </h2>
                <div class="byline"> Author: maartenp Published: September 20th, 2010 </div>
                <p style="text-align:center;">
                  <img height="294" width="400" alt="" src="http://www.lsdimension.nl/wp-content/uploads/2010/09/stockhausen_04.jpg" title="Stockhausen_04" class="aligncenter size-full wp-image-6749"></img>
                  <a href="http://www.lsdimension.nl/wp-content/uploads/2010/09/aphextwinrdj.jpg" shape="rect">
                    <img height="260" width="400" alt="" src="http://www.lsdimension.nl/wp-content/uploads/2010/09/aphextwinrdj.jpg" title="Aphex+Twin+RDJ" class="aligncenter size-full wp-image-6751"></img>
                  </a>
                </p>
                <p>
                  Last week I showed you a
                  <a target="_blank" href="http://lsdimension.wordpress.com/2010/09/17/karlheinz-stockhausen-on-sounds/" shape="rect">speech</a>
                  by the brilliant musical inovator Karl Heinz Stockhausen (1928-2007). Now take a look at the following
                  <a target="_blank" href="http://www.stockhausen.org/ksadvice.html" shape="rect">interview</a>
                  by Wire magazine. It was taken in 1995, when Stockhausen was still creating sounds and making
                  <a target="_blank" href="http://www.youtube.com/watch?v=K0h0ApJAeSg" shape="rect">music</a>
                  . Prior to the interview they sent some tapes with “modern” electronic music from that era, including artists like
                  <a target="_blank" href="http://www.youtube.com/watch?v=GgMrf2pjZ0w&amp;has_verified=1" shape="rect">Aphex Twin</a>
                  ,
                  <a target="_blank" href="http://www.youtube.com/watch?v=Nsct-e-HVE0" shape="rect">Plastikman</a>
                  and Scanner. Then they asked Stockhausen, the “inventor of electronic music” in the 50′s, about his opinion on the songs.
                </p>
                <p>His reaction:</p>
                <blockquote>
                  <p>
                    <em>
                      Can we talk about the music we sent you? It was very good of you to listen
                      <br clear="none"></br>
                      to it. I wonder if you could give some advice to these musicians.
                      <br clear="none"></br>
                    </em>
                    <br clear="none"></br>
                    <strong>
                      I wish those musicians would not allow themselves any repetitions, and would
                      <br clear="none"></br>
                      go faster in developing their ideas or their findings, because I don’t
                      <br clear="none"></br>
                      appreciate at all this permanent repetitive language.
                    </strong>
                    It is like someone who
                    <br clear="none"></br>
                    is stuttering all the time, and can’t get words out of his mouth. I think
                    <br clear="none"></br>
                    musicians should have very concise figures and not rely on this fashionable
                    <br clear="none"></br>
                    psychology.
                    <strong>
                      I don’t like psychology whatsoever: using music like a drug is
                      <br clear="none"></br>
                      stupid. One shouldn’t do that : music is the product of the highest human
                      <br clear="none"></br>
                      intelligence, and of the best senses, the listening senses and of
                      <br clear="none"></br>
                      imagination and intuition.
                    </strong>
                    <strong>
                      And as soon as it becomes just a means for
                      <br clear="none"></br>
                      ambiance, as we say, environment, or for being used for certain purposes,
                      <br clear="none"></br>
                      then music becomes a whore, and one should not allow that really; one should
                      <br clear="none"></br>
                      not serve any existing demands or in particular not commercial values.
                    </strong>
                    That
                    <br clear="none"></br>
                    would be terrible: that is selling out the music.
                  </p>
                  <p>
                    I heard the piece Aphex Twin of Richard James carefully: I think it would be
                    <br clear="none"></br>
                    very helpful if he listens to my work Song Of The Youth, which is electronic
                    <br clear="none"></br>
                    music, and a young boy’s voice singing with himself. Because he would then
                    <br clear="none"></br>
                    immediately stop with all these post-African repetitions, and he would look
                    <br clear="none"></br>
                    for changing tempi and changing rhythms, and he would not allow to repeat
                    <br clear="none"></br>
                    any rhythm if it were varied to some extent and if it did not have a
                    <br clear="none"></br>
                    direction in its sequence of variations.
                  </p>
                  <p>
                    And the other composer – musician, I don’t know if they call themselves
                    <br clear="none"></br>
                    composers…
                  </p>
                  <p>
                    <strong>They’re sometimes called ‘sound artists’…</strong>
                  </p>
                  <p>
                    No, ‘Technocrats’, you called them. He’s called Plasticman, and in public,
                    <br clear="none"></br>
                    Richie Hawtin. It starts with 30 or 40 – I don’t know, I haven’t counted
                    <br clear="none"></br>
                    them – fifths in parallel, always the same perfect fifths, you see, changing
                    <br clear="none"></br>
                    from one to the next, and then comes in hundreds of repetitions of one small
                    <br clear="none"></br>
                    section of an African rhythm: duh-duh-dum, etc, and I think it would be
                    <br clear="none"></br>
                    helpful if he listened to Cycle for percussion, which is only a 15 minute
                    <br clear="none"></br>
                    long piece of mine for a percussionist, but there he will have a hell to
                    <br clear="none"></br>
                    understand the rhythms, and I think he will get a taste for very interesting
                    <br clear="none"></br>
                    non-metric and non-periodic rhythms.
                    <strong>
                      I know that he wants to have a special
                      <br clear="none"></br>
                      effect in dancing bars, or wherever it is, on the public who like to dream
                      <br clear="none"></br>
                      away with such repetitions, but he should be very careful, because the
                      <br clear="none"></br>
                      public will sell him out immediately for something else, if a new kind of
                      <br clear="none"></br>
                      musical drug is on the market.
                    </strong>
                    So he should be very careful and separate as
                    <br clear="none"></br>
                    soon as possible from the belief in this kind of public.
                  </p>
                  <p>
                    The other is Robin Rimbaud, Scanner, I’ve heard, with radio noises. He is
                    <br clear="none"></br>
                    very experimental, because he is searching in a realm of sound which is not
                    <br clear="none"></br>
                    usually used for music. But I think he should transform more what he finds.
                    <br clear="none"></br>
                    He leaves it too much in a raw state. He has a good sense of atmosphere, but
                    <br clear="none"></br>
                    he is too repetitive again. So let him listen to my work Hymnen. There are
                    <br clear="none"></br>
                    found objects – a lot like he finds with his scanner, you see. But I think
                    <br clear="none"></br>
                    he should learn from the art of transformation, so that what you find sounds
                    <br clear="none"></br>
                    completely new, as I sometimes say, like an apple on the moon.
                  </p>
                </blockquote>
                <p>Aphex Twin then reacted to Stockhausen’s remarks at a later time:</p>
                <blockquote>
                  <p>
                    <em>
                      Following Stockhausen’s advice to our Technocrats, we decided to play them
                      <br clear="none"></br>
                      excerpts from the compositions which the German composer suggested they
                      <br clear="none"></br>
                      listen to and learn from. Here’s what they had to say…
                      <br clear="none"></br>
                    </em>
                    <br clear="none"></br>
                    Aphex Twin on Song Of The Youth
                  </p>
                  <p>
                    Mental! I’ve heard that song before; I like it. I didn’t agree with him.
                    <strong>
                      I
                      <br clear="none"></br>
                      thought he should listen to a couple of tracks of mine: “
                      <a target="_blank" href="http://www.youtube.com/watch?v=IPEW_2Q8ejI" shape="rect">Didgeridoo</a>
                      “, then
                      <br clear="none"></br>
                      he’d stop making abstract, random patterns you can’t dance to.
                    </strong>
                    Do you reckon
                    <br clear="none"></br>
                    he can dance? You could dance to Song of the Youth, but it hasn’t got a
                    <br clear="none"></br>
                    groove in it, there’s no bassline. I know it was probably made in the 50s,
                    <br clear="none"></br>
                    but I’ve got plenty of wicked percussion records made in the 50s that are
                    <br clear="none"></br>
                    awesome to dance to. And they’ve got basslines. I could remix it: I don’t
                    <br clear="none"></br>
                    know about making it better; I wouldn’t want to make it into a dance
                    <br clear="none"></br>
                    version, but I could probably make it a bit more anally technical. But I’m
                    <br clear="none"></br>
                    sure he could these days, because tape is really slow. I used to do things
                    <br clear="none"></br>
                    like that with tape, but it does take forever, and I’d never do anything
                    <br clear="none"></br>
                    like that again with tape.
                    <strong>
                      Once you’ve got your computer sorted out, it
                      <br clear="none"></br>
                      pisses all over stuff like that, you can do stuff so fast. It has a
                      <br clear="none"></br>
                      different sound, but a bit more anal.
                    </strong>
                  </p>
                  <p>
                    I haven’t heard anything new by him; the last thing was a vocal record,
                    <br clear="none"></br>
                    Stimmung, and I didn’t really like that. Would I take his comments to heart?
                    <br clear="none"></br>
                    The ideal thing would be to meet him in a room and have a wicked discussion.
                    <br clear="none"></br>
                    For all I know, he could be taking the piss. It’s a bit hard to have a
                    <br clear="none"></br>
                    discussion with someone via other people.
                  </p>
                  <p>
                    <strong>
                      I don’t think I care about what he thinks. It is interesting, but it’s
                      <br clear="none"></br>
                      disappointing, because you’d imagine he’d say that anyway. It wasn’t
                      <br clear="none"></br>
                      anything surprising.
                    </strong>
                    I don’t know anything about the guy, but I expected him
                    <br clear="none"></br>
                    to have that sort of attitude. Loops are good to dance to…
                  </p>
                  <p>
                    He should hang out with me and my mates: that would be a laugh. I’d be quite
                    <br clear="none"></br>
                    into having him around.
                  </p>
                </blockquote>
                <p>
                  <a target="_blank" href="http://www.stockhausen.org/ksadvice.html" shape="rect">Read more</a>
                  .
                </p>
                <p>Here are someÂ of theÂ tracks Stockhausen listened to:</p>
                <p>
                  <span class="youtube">
                    <object height="385" width="480">
                      <param value="http://www.youtube.com/v/mUT3KoxVzQg?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0" name="movie" valuetype="data"></param>
                      <param value="true" name="allowFullScreen" valuetype="data"></param>
                      <param value="always" name="allowscriptaccess" valuetype="data"></param>
                      <embed 
                      height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/mUT3KoxVzQg?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0">
</embed>
                    </object>
                  </span>
                </p>
                <p>
                  <span class="youtube">
                    <object height="385" width="480">
                      <param value="http://www.youtube.com/v/ZBzLXq84QIE?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0" name="movie" valuetype="data"></param>
                      <param value="true" name="allowFullScreen" valuetype="data"></param>
                      <param value="always" name="allowscriptaccess" valuetype="data"></param>
                      <embed 
                      height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/ZBzLXq84QIE?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0">
</embed>
                    </object>
                  </span>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F09%2F20%2Faphex-twin-vs-stockhausen%2F&amp;text=Aphex Twin vs. Stockhausen&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F09%2F20%2Faphex-twin-vs-stockhausen%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/aphex-twin/" shape="rect">Aphex Twin</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/karlheinz-stockhausen/" shape="rect">Karlheinz Stockhausen</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/plastikman/" shape="rect">Plastikman</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/scanner/" shape="rect">Scanner</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/wire/" shape="rect">Wire</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="entry">
                <h2>
                  <a rel="bookmark" href="http://www.lsdimension.com/2010/09/17/karlheinz-stockhausen-on-sounds/" shape="rect">Karlheinz Stockhausen On Sounds </a>
                </h2>
                <div class="byline"> Author: maartenp Published: September 17th, 2010 </div>
                <p>
                  The inventor of
                  <a target="_blank" href="http://www.youtube.com/watch?v=5_NWwUB6Dis&amp;feature=related" shape="rect">electronic music</a>
                  describes in this lecture how he started to synthesize sounds in the 1950′s:
                </p>
                <p>
                  <span class="youtube">
                    <object height="385" width="480">
                      <param value="http://www.youtube.com/v/pIPVc2Jvd0w?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=channel" name="movie" valuetype="data"></param>
                      <param value="true" name="allowFullScreen" valuetype="data"></param>
                      <param value="always" name="allowscriptaccess" valuetype="data"></param>
                      <embed 
                      height="385" width="480" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" src="http://www.youtube.com/v/pIPVc2Jvd0w?color1=d6d6d6&amp;color2=f0f0f0&amp;border=0&amp;fs=1&amp;hl=en&amp;autoplay=0&amp;showinfo=0&amp;iv_load_policy=3&amp;showsearch=0&amp;rel=0&amp;feature=channel">
</embed>
                    </object>
                  </span>
                </p>
                <div style="padding: 10px 0 " class="interactive_bottom">
                  <iframe 
                  style="width:65px; height:21px;" src="http://platform.twitter.com/widgets/tweet_button.html?url=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F09%2F17%2Fkarlheinz-stockhausen-on-sounds%2F&amp;text=Karlheinz Stockhausen On Sounds&amp;count=horizontal&amp;lang=&amp;via=lsdimension  " allowtransparency="true" scrolling="no" frameborder="0">
</iframe>
                  <iframe 
                  allowtransparency="true" style="border:none; overflow:hidden; width:85px; height:21px;" src="http://www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.lsdimension.com%2F2010%2F09%2F17%2Fkarlheinz-stockhausen-on-sounds%2F&amp;layout=button_count&amp;show_faces=false&amp;width=85&amp;action=like&amp;font=arial&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0">
</iframe>
                </div>
                <div class="clear"></div>
                <p class="postmetadata">
                  Tags:
                  <a rel="tag" href="http://www.lsdimension.com/tag/electronic-music/" shape="rect">electronic music</a>
                  ,
                  <a rel="tag" href="http://www.lsdimension.com/tag/karlheinz-stockhausen/" shape="rect">Karlheinz Stockhausen</a>
                  <br clear="none"></br>
                  Category
                  <a rel="category tag" title="View all posts in electronic music" href="http://www.lsdimension.com/category/electronic-music/" shape="rect">electronic music</a>
                  |
                </p>
                <div class="clear"></div>
              </div>
              <div class="clear"></div>
              <div class="paginav"> </div>
            </div>
            <div id="postsidebar">
              <div class="widget">
                <div class="widgetinside">
                  <h2>latest posts</h2>
                  <ul class="advanced-recent-posts">
                    <li>
                      <span class="date"></span>
                      <a title="John Talabot - Tragedial / Mai Mes" href="http://www.lsdimension.com/2012/09/17/john-talabot-tragedial-mai-mes/" shape="rect">
                        <b>John Talabot - Tragedial / Mai Mes</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Friday Night Special #11" href="http://www.lsdimension.com/2012/09/07/friday-night-special-11/" shape="rect">
                        <b>Friday Night Special #11</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Friday Night Special #10" href="http://www.lsdimension.com/2012/08/24/friday-night-special-10/" shape="rect">
                        <b>Friday Night Special #10</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="2299 Exoplanets Orbiting A Single Star" href="http://www.lsdimension.com/2012/08/23/2299-exoplanets-orbiting-a-single-star/" shape="rect">
                        <b>2299 Exoplanets Orbiting A Single Star</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Interactive Drake Equation" href="http://www.lsdimension.com/2012/08/23/interactive-drake-equation/" shape="rect">
                        <b>Interactive Drake Equation</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Free Pussy Riot" href="http://www.lsdimension.com/2012/08/15/free-pussy-riot/" shape="rect">
                        <b>Free Pussy Riot</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Alle Farben - Luminous Green (DJ-set)" href="http://www.lsdimension.com/2012/08/01/alle-farben-luminous-green-dj-set/" shape="rect">
                        <b>Alle Farben - Luminous Green (DJ-set)</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Brain" href="http://www.lsdimension.com/2012/07/31/brain/" shape="rect">
                        <b>Brain</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="DJ Tennis - The Outcast [ft. PillowTalk]" href="http://www.lsdimension.com/2012/07/27/dj-tennis-the-outcast-ft-pillowtalk/" shape="rect">
                        <b>DJ Tennis - The Outcast [ft. PillowTalk]</b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Johannes Heil @ Fusion Festival, 30-6-2012" href="http://www.lsdimension.com/2012/07/24/johannes-heil-fusion-festival-30-6-2012/" shape="rect">
                        <b>Johannes Heil @ Fusion Festival, 30-6-2012</b>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>recent comments</h2>
                  <ul id="recentcomments">
                    <li class="recentcomments">
                      <a rel="external nofollow" href="http://www.lsdimension.com/2012/09/07/friday-night-special-11/" class="url" shape="rect">Friday Night Special #11 | Light Sound Dimension</a>
                      on
                      <a href="http://www.lsdimension.com/2011/06/10/dominik-eulberg-der-tanz-der-gluhwurmchen/#comment-5357" shape="rect">Dominik Eulberg – Der Tanz Der GlÃŒhwÃŒrmchen</a>
                    </li>
                    <li class="recentcomments">
                      adriejan on
                      <a href="http://www.lsdimension.com/2012/07/20/ehrm-handhaaft-sgp-uitspraak-hoge-raad/#comment-5258" shape="rect">EHRM handhaaft SGP-uitspraak Hoge Raad</a>
                    </li>
                    <li class="recentcomments">
                      geert on
                      <a href="http://www.lsdimension.com/2012/07/20/ehrm-handhaaft-sgp-uitspraak-hoge-raad/#comment-5257" shape="rect">EHRM handhaaft SGP-uitspraak Hoge Raad</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <ul class="followwrap row">
                    <li class="icon_text">
                      <a title="RSS feed" href="http://www.lsdimension.com/feed/" target="_blank" rel="nofollow me" shape="rect">
                        <img 
                        alt="RSS feed" style="background: transparent url(http://www.lsdimension.com/wp-content/plugins/share-and-follow/default/16/sprite-16.png) no-repeat;padding:0;margin:0;height:16px;width:16px;background-position:-748px 0px" width="16" height="16" src="http://www.lsdimension.com/wp-content/plugins/share-and-follow/images/blank.gif">
</img>
                        <span class="head">RSS feed</span>
                      </a>
                    </li>
                    <li class="icon_text">
                      <a title="Twitter" href="http://www.twitter.com/lsdimension" target="_blank" rel="nofollow me" shape="rect">
                        <img 
                        alt="Twitter" style="background: transparent url(http://www.lsdimension.com/wp-content/plugins/share-and-follow/default/16/sprite-16.png) no-repeat;padding:0;margin:0;height:16px;width:16px;background-position:-901px 0px" width="16" height="16" src="http://www.lsdimension.com/wp-content/plugins/share-and-follow/images/blank.gif">
</img>
                        <span class="head">Twitter</span>
                      </a>
                    </li>
                  </ul>
                  <div class="clean"></div>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>like us</h2>
                  <iframe style="border:none; overflow:hidden; width:200px; height:300px" allowtransparency="true" src="http://www.facebook.com/plugins/fan.php?id=153971541303772&amp;width=200&amp;connections=6&amp;stream=false&amp;header=true&amp;locale=en_US" scrolling="no" frameborder="0"></iframe>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <div>
                    <h2>
                      <a target="_blank" href="http://twitter.com/@lsdimension" title="Twitter: @lsdimension" class="twitterwidget twitterwidget-title" shape="rect">@lsdimension</a>
                    </h2>
                    <ul>
                      <li>
                        <span class="entry-content">
                          is this stream also being recorded? (
                          <a target="_blank" href="http://twitter.com/occupyeye" class="twitter-user" shape="rect">@occupyeye</a>
                          live at
                          <a target="_blank" href="http://t.co/rRgH7wmU" shape="rect">http://t.co/rRgH7wmU</a>
                          )
                        </span>
                        <span class="entry-meta">
                          <span class="time-meta">
                            <a target="_blank" href="http://twitter.com/lsdimension/statuses/2.4781899637051E+17" shape="rect">10:07:07 PM September 17, 2012</a>
                          </span>
                          <span class="from-meta">
                            from
                            <a rel="nofollow" href="http://www.ustream.tv" shape="rect">Ustream.TV</a>
                          </span>
                        </span>
                      </li>
                      <li>
                        <span class="entry-content">
                          Een onvervalst
                          <a target="_blank" href="http://twitter.com/ajboekestijn" class="twitter-user" shape="rect">@ajboekestijn</a>
                          -tje:
                          <a target="_blank" href="http://t.co/CN4GJHHM" shape="rect">http://t.co/CN4GJHHM</a>
                        </span>
                        <span class="entry-meta">
                          <span class="time-meta">
                            <a target="_blank" href="http://twitter.com/lsdimension/statuses/2.470283246464E+17" shape="rect">05:45:16 PM September 15, 2012</a>
                          </span>
                          <span class="from-meta">from web</span>
                        </span>
                      </li>
                      <li>
                        <span class="entry-content">
                          Laat de mediastorm beginnen. 1 hoop: uniform afwijzen aanpak RTL4/Petra Grijzen van debatten. Een nieuw dieptepunt
                          <a target="_blank" href="http://search.twitter.com/search?q=%23carredebat" class="twitter-hashtag" shape="rect">#carredebat</a>
                          <a target="_blank" href="http://search.twitter.com/search?q=%23watkiestNL" class="twitter-hashtag" shape="rect">#watkiestNL</a>
                        </span>
                        <span class="entry-meta">
                          <span class="time-meta">
                            <a target="_blank" href="http://twitter.com/lsdimension/statuses/2.4308408575134E+17" shape="rect">08:32:16 PM September 04, 2012</a>
                          </span>
                          <span class="from-meta">from web</span>
                        </span>
                      </li>
                      <li>
                        <span class="entry-content">
                          Hahaha wtf was dit
                          <a target="_blank" href="http://search.twitter.com/search?q=%23petragrijzen" class="twitter-hashtag" shape="rect">#petragrijzen</a>
                          <a target="_blank" href="http://search.twitter.com/search?q=%23carredebat" class="twitter-hashtag" shape="rect">#carredebat</a>
                          <a target="_blank" href="http://search.twitter.com/search?q=%23samsom" class="twitter-hashtag" shape="rect">#samsom</a>
                          <a target="_blank" href="http://search.twitter.com/search?q=%23pvda" class="twitter-hashtag" shape="rect">#pvda</a>
                        </span>
                        <span class="entry-meta">
                          <span class="time-meta">
                            <a target="_blank" href="http://twitter.com/lsdimension/statuses/2.4308371949211E+17" shape="rect">08:30:49 PM September 04, 2012</a>
                          </span>
                          <span class="from-meta">from web</span>
                        </span>
                      </li>
                      <li>
                        <span class="entry-content">
                          Samsom OWNED Petra Grijzen
                          <a target="_blank" href="http://search.twitter.com/search?q=%23carredebat" class="twitter-hashtag" shape="rect">#carredebat</a>
                        </span>
                        <span class="entry-meta">
                          <span class="time-meta">
                            <a target="_blank" href="http://twitter.com/lsdimension/statuses/2.4308347232599E+17" shape="rect">08:29:50 PM September 04, 2012</a>
                          </span>
                          <span class="from-meta">from web</span>
                        </span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>tag cloud</h2>
                  <div class="tagcloud">
                    <a style="font-size: 10.84375pt;" title="37 topics" href="http://www.lsdimension.com/tag/1980s/" class="tag-link-46" shape="rect">1980s</a>
                    <a style="font-size: 8.875pt;" title="30 topics" href="http://www.lsdimension.com/tag/acid-house/" class="tag-link-98" shape="rect">acid house</a>
                    <a style="font-size: 11.0625pt;" title="38 topics" href="http://www.lsdimension.com/tag/afghanistan/" class="tag-link-117" shape="rect">Afghanistan</a>
                    <a style="font-size: 9.96875pt;" title="34 topics" href="http://www.lsdimension.com/tag/ambient/" class="tag-link-160" shape="rect">ambient</a>
                    <a style="font-size: 8.21875pt;" title="28 topics" href="http://www.lsdimension.com/tag/amsterdam/" class="tag-link-167" shape="rect">Amsterdam</a>
                    <a style="font-size: 9.53125pt;" title="32 topics" href="http://www.lsdimension.com/tag/balkenende/" class="tag-link-289" shape="rect">Balkenende</a>
                    <a style="font-size: 9.96875pt;" title="34 topics" href="http://www.lsdimension.com/tag/berlin/" class="tag-link-332" shape="rect">Berlin</a>
                    <a style="font-size: 20.03125pt;" title="98 topics" href="http://www.lsdimension.com/tag/cda/" class="tag-link-502" shape="rect">CDA</a>
                    <a style="font-size: 11.5pt;" title="40 topics" href="http://www.lsdimension.com/tag/d66/" class="tag-link-687" shape="rect">D66</a>
                    <a style="font-size: 8.21875pt;" title="28 topics" href="http://www.lsdimension.com/tag/dubstep/" class="tag-link-853" shape="rect">dubstep</a>
                    <a style="font-size: 9.3125pt;" title="31 topics" href="http://www.lsdimension.com/tag/egypt/" class="tag-link-894" shape="rect">Egypt</a>
                    <a style="font-size: 8.65625pt;" title="29 topics" href="http://www.lsdimension.com/tag/electro/" class="tag-link-910" shape="rect">electro</a>
                    <a style="font-size: 14.5625pt;" title="55 topics" href="http://www.lsdimension.com/tag/electronica/" class="tag-link-912" shape="rect">electronica</a>
                    <a style="font-size: 9.3125pt;" title="31 topics" href="http://www.lsdimension.com/tag/facebook/" class="tag-link-982" shape="rect">Facebook</a>
                    <a style="font-size: 14.78125pt;" title="57 topics" href="http://www.lsdimension.com/tag/geert-wilders/" class="tag-link-1120" shape="rect">Geert Wilders</a>
                    <a style="font-size: 8pt;" title="27 topics" href="http://www.lsdimension.com/tag/germany/" class="tag-link-1147" shape="rect">Germany</a>
                    <a style="font-size: 11.71875pt;" title="41 topics" href="http://www.lsdimension.com/tag/hipsters/" class="tag-link-1293" shape="rect">hipsters</a>
                    <a style="font-size: 13.90625pt;" title="51 topics" href="http://www.lsdimension.com/tag/house/" class="tag-link-1324" shape="rect">house</a>
                    <a style="font-size: 17.1875pt;" title="73 topics" href="http://www.lsdimension.com/tag/indie/" class="tag-link-1392" shape="rect">indie</a>
                    <a style="font-size: 11.28125pt;" title="39 topics" href="http://www.lsdimension.com/tag/internet/" class="tag-link-1417" shape="rect">Internet</a>
                    <a style="font-size: 13.03125pt;" title="47 topics" href="http://www.lsdimension.com/tag/kabinet-rutte/" class="tag-link-1546" shape="rect">kabinet-Rutte</a>
                    <a style="font-size: 9.3125pt;" title="31 topics" href="http://www.lsdimension.com/tag/libya/" class="tag-link-3694" shape="rect">Libya</a>
                    <a style="font-size: 9.75pt;" title="33 topics" href="http://www.lsdimension.com/tag/lsd/" class="tag-link-1714" shape="rect">lsd</a>
                    <a style="font-size: 11.71875pt;" title="41 topics" href="http://www.lsdimension.com/tag/marihuana/" class="tag-link-1761" shape="rect">marihuana</a>
                    <a style="font-size: 9.96875pt;" title="34 topics" href="http://www.lsdimension.com/tag/mark-rutte/" class="tag-link-1763" shape="rect">Mark Rutte</a>
                    <a style="font-size: 8pt;" title="27 topics" href="http://www.lsdimension.com/tag/minimal/" class="tag-link-1850" shape="rect">minimal</a>
                    <a style="font-size: 21.125pt;" title="111 topics" href="http://www.lsdimension.com/tag/obama/" class="tag-link-2037" shape="rect">Obama</a>
                    <a style="font-size: 8.875pt;" title="30 topics" href="http://www.lsdimension.com/tag/protests/" class="tag-link-2267" shape="rect">protests</a>
                    <a style="font-size: 14.34375pt;" title="54 topics" href="http://www.lsdimension.com/tag/pvda/" class="tag-link-2288" shape="rect">PvdA</a>
                    <a style="font-size: 16.75pt;" title="69 topics" href="http://www.lsdimension.com/tag/pvv/" class="tag-link-2289" shape="rect">PVV</a>
                    <a style="font-size: 9.53125pt;" title="32 topics" href="http://www.lsdimension.com/tag/rechts-kabinet/" class="tag-link-2337" shape="rect">rechts kabinet</a>
                    <a style="font-size: 13.03125pt;" title="47 topics" href="http://www.lsdimension.com/tag/republican-party/" class="tag-link-2368" shape="rect">Republican Party</a>
                    <a style="font-size: 11.71875pt;" title="41 topics" href="http://www.lsdimension.com/tag/sarah-palin/" class="tag-link-2458" shape="rect">Sarah Palin</a>
                    <a style="font-size: 9.3125pt;" title="31 topics" href="http://www.lsdimension.com/tag/social-media/" class="tag-link-2574" shape="rect">social media</a>
                    <a style="font-size: 9.75pt;" title="33 topics" href="http://www.lsdimension.com/tag/star-wars/" class="tag-link-2634" shape="rect">Star Wars</a>
                    <a style="font-size: 8.875pt;" title="30 topics" href="http://www.lsdimension.com/tag/synth/" class="tag-link-2721" shape="rect">synth</a>
                    <a style="font-size: 9.3125pt;" title="31 topics" href="http://www.lsdimension.com/tag/tea-party-movement/" class="tag-link-2734" shape="rect">Tea Party movement</a>
                    <a style="font-size: 22pt;" title="122 topics" href="http://www.lsdimension.com/tag/techno/" class="tag-link-2737" shape="rect">techno</a>
                    <a style="font-size: 15.4375pt;" title="61 topics" href="http://www.lsdimension.com/tag/the-netherlands/" class="tag-link-2828" shape="rect">The Netherlands</a>
                    <a style="font-size: 12.59375pt;" title="45 topics" href="http://www.lsdimension.com/tag/united-kingdom/" class="tag-link-2978" shape="rect">United Kingdom</a>
                    <a style="font-size: 11.9375pt;" title="42 topics" href="http://www.lsdimension.com/tag/united-states/" class="tag-link-2980" shape="rect">United States</a>
                    <a style="font-size: 12.59375pt;" title="45 topics" href="http://www.lsdimension.com/tag/verkiezingen-2010/" class="tag-link-3020" shape="rect">verkiezingen 2010</a>
                    <a style="font-size: 16.96875pt;" title="71 topics" href="http://www.lsdimension.com/tag/vvd/" class="tag-link-3059" shape="rect">VVD</a>
                    <a style="font-size: 15.4375pt;" title="61 topics" href="http://www.lsdimension.com/tag/wikileaks/" class="tag-link-3122" shape="rect">WikiLeaks</a>
                    <a style="font-size: 8.65625pt;" title="29 topics" href="http://www.lsdimension.com/tag/xtc/" class="tag-link-3174" shape="rect">xtc</a>
                  </div>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>blogroll</h2>
                  <ul class="xoxo blogroll">
                    <li>
                      <a target="_blank" href="http://www.adbusters.org/" shape="rect">Adbusters</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://english.aljazeera.net/" shape="rect">Al Jazeera</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://andrewsullivan.theatlantic.com/" shape="rect">Andrew Sullivan</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://antiterra.tumblr.com/" shape="rect">antiterra</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://barracudanls.blogpost.com/" shape="rect">Barracuda</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.beatport.com/" shape="rect">Beatport</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://beatsandbeyond.com/" shape="rect">Beats and Beyond</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://bof.nl/" shape="rect">Bits of Freedom</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://blog.rebellen.info/" shape="rect">Blogrebellen Kreuzberg</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://boingboing.net/" shape="rect">Boing Boing</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.cinematical.com/" shape="rect">Cinematical</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.cracktwo.com/" shape="rect">Crack Two</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.dailykos.com/" shape="rect">Daily Kos</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://dangerousminds.net/" shape="rect">Dangerous Minds</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.darkroastedblend.com/" shape="rect">Dark Roasted Blend</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.kraftfuttermischwerk.de/blogg" shape="rect">Das Kraftfuttermischwerk</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://denaaktemens.nl/" shape="rect">De Naakte Mens</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.volkskrant.nl/" shape="rect">De Volkskrant</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.everythingisterrible.com/" shape="rect">Everything Is Terrible</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://fasel.soup.io/" shape="rect">fasels Suppe</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://feingut.com/" shape="rect">Feingut</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://fok.nl/" shape="rect">FOK!</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.froot.nl/" shape="rect">Froot</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.geenstijl.nl/" shape="rect">GeenStijl</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.gizmodo.com/" shape="rect">Gizmodo</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.salon.com/news/opinion/glenn_greenwald/" shape="rect">Glenn Greenwald</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.hardhoofd.com/" shape="rect">hard//hoofd</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.hipsterrunoff.com" shape="rect">Hipster Runoff</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.howtobearetronaut.com/" shape="rect">How To Be A Retronaut</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://interweb3000.blogspot.com/" shape="rect">Interweb3000</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://io9.com" shape="rect">io9</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.joop.nl/" shape="rect">Joop</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://lhote.blogspot.com/" shape="rect">L'HÃŽte</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.littlewhiteearbuds.com" shape="rect">Little White Earbuds</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://lsdex.ru/" shape="rect">LSDEX</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.slate.com/blogs/moneybox.html" shape="rect">Matthew Yglesias</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.metacritic.com/" shape="rect">Metacritic</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.mindsdelight.de/" shape="rect">Minds Delight</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.misterhonk.de/" shape="rect">Mister Honk</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.nerdcore.de/" shape="rect">Nerdcore</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.humanedgetech.com/expedition/hdv/" shape="rect">Never Ending Voyage</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.nrc.nl/" shape="rect">NRC Handelsblad</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.outernational.nl/" shape="rect">Outernational</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.overdose.am/" shape="rect">Overdose.am</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.overthinkingit.com/" shape="rect">Overthinking It</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.panzerfaust.org/" shape="rect">Panzerfaust</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.pbh2.com/" shape="rect">PBH2</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://pgzlog.wordpress.com/" shape="rect">Permanent Gecontroleerde Zones</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.pitchfork.com/" shape="rect">Pitchfork</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.politico.com/" shape="rect">Politico</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.popmatters.com/" shape="rect">PopMatters</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.publiekrechtenpolitiek.nl/" shape="rect">Publiekrecht en politiek</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.residentadvisor.net/" shape="rect">Resident Advisor</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://rop.gonggri.jp/" shape="rect">Rop Gonggrijp</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.rottentomatoes.com/" shape="rect">Rotten Tomatoes</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.salon.com/" shape="rect">Salon</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.sargasso.nl/" shape="rect">Sargasso</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://schlijper.nl/" shape="rect">Schlijper</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://harpers.org/subjects/NoComment" shape="rect">Scott Horton</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.simonvinkenoog.nl/" shape="rect">Simon Vinkenoog</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.slate.com/" shape="rect">Slate</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www1.stadtkind.com/" shape="rect">Stadtkind Berlin</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.stuffwhitepeoplelike.com/" shape="rect">Stuff White People Like</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.tpmcafe.com/" shape="rect">Talking Points Memo</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.theatlantic.com/" shape="rect">The Atlantic</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://thedailywh.at/" shape="rect">The Daily What</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.bigempire.com/filthy/" shape="rect">The Filthy Critic</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://guardian.co.uk/" shape="rect">The Guardian</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.huffingtonpost.com/" shape="rect">The Huffington Post</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://hypem.com/" shape="rect">The Hype Machine</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://blogs.ssrc.org/tif/" shape="rect">The Immanent Frame</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.tnr.com/" shape="rect">The New Republic</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.nyt.com/" shape="rect">The New York Times</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.newyorker.com/" shape="rect">The New Yorker</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.onion.com/" shape="rect">The Onion</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://thisisnthappiness.com/" shape="rect">this isn't happiness</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.trouw.nl/" shape="rect">Trouw</a>
                    </li>
                    <li>
                      <a href="http://www.versvermaak.nl/" shape="rect">Vers Vermaak</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.vimeo.com/" shape="rect">Vimeo</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://vuistdikkeramlat.web-log.nl/" shape="rect">Vuistedikkeramlat</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.welikethat.de/" shape="rect">We Like That</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.wikileaks.ch/" shape="rect">WikiLeaks</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://www.wired.com/" shape="rect">Wired</a>
                    </li>
                    <li>
                      <a target="_blank" href="http://xenophilius.wordpress.com/" shape="rect">Xenophilius</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div id="sidebarone">
              <script type="text/javascript"> var sc_project=6352606; var sc_invisible=1; var sc_security=&quot;6f64cd8e&quot;; </script>
              <script src="http://www.statcounter.com/counter/counter.js" type="text/javascript"></script>
              <noscript>
                <div class="statcounter">
                  <a target="_blank" href="http://statcounter.com/wordpress.com/" title="wordpress analytics" shape="rect">
                    <img alt="wordpress analytics" src="http://c.statcounter.com/6352606/0/6f64cd8e/1/" class="statcounter"></img>
                  </a>
                </div>
              </noscript>
              <div class="widget">
                <div class="widgetinside">
                  <h2>
                    <a href="http://www.lsdimension.com/?cat=7" shape="rect">electronic music</a>
                  </h2>
                  <ul class="advanced-recent-posts">
                    <li>
                      <span class="date"></span>
                      <a title="John Talabot - Tragedial / Mai Mes" href="http://www.lsdimension.com/2012/09/17/john-talabot-tragedial-mai-mes/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="John Talabot - Tragedial / Mai Mes" src="http://www.lsdimension.com/wp-content/uploads/2012/09/johntalabot.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          John Talabot - Tragedial / Mai Mes
                        </b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Friday Night Special #11" href="http://www.lsdimension.com/2012/09/07/friday-night-special-11/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="Friday Night Special #11" src="http://www.lsdimension.com/wp-content/uploads/2012/09/fridayheidelberg2.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          Friday Night Special #11
                        </b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Friday Night Special #10" href="http://www.lsdimension.com/2012/08/24/friday-night-special-10/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="Friday Night Special #10" src="http://www.lsdimension.com/wp-content/uploads/2012/08/fnspecialindiansummer.gif" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          Friday Night Special #10
                        </b>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>politics</h2>
                  <ul class="advanced-recent-posts">
                    <li>
                      <span class="date"></span>
                      <a title="Free Pussy Riot" href="http://www.lsdimension.com/2012/08/15/free-pussy-riot/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="Free Pussy Riot" src="http://www.lsdimension.com/wp-content/uploads/2012/08/pussyriot4.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          Free Pussy Riot
                        </b>
                      </a>
                      <br clear="none"></br>
                      Peaches, the twenty-first century torchbearer of feminist punk, just released a video and track in support of Pussy Riot, the Russian female anarc
                      <a href="http://www.lsdimension.com/2012/08/15/free-pussy-riot/" shape="rect">...</a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="EHRM handhaaft SGP-uitspraak Hoge Raad" href="http://www.lsdimension.com/2012/07/20/ehrm-handhaaft-sgp-uitspraak-hoge-raad/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="EHRM handhaaft SGP-uitspraak Hoge Raad" src="http://www.lsdimension.com/wp-content/uploads/2011/03/sgpvrouwen.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          EHRM handhaaft SGP-uitspraak Hoge Raad
                        </b>
                      </a>
                      <br clear="none"></br>
                      Dat ging nog best snel: het Europese Hof voor de Rechten van de Mens (EHRM) heeft zich uitgesproken over de vrouwen uitsluitende praktijk van de S
                      <a href="http://www.lsdimension.com/2012/07/20/ehrm-handhaaft-sgp-uitspraak-hoge-raad/" shape="rect"></a>
                      <a href="http://www.lsdimension.com/2012/08/15/free-pussy-riot/" shape="rect">...</a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="SchrÃ¶dinger's Candidate" href="http://www.lsdimension.com/2012/07/06/schrodingers-candidate/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="SchrÃ¶dinger's Candidate" src="http://www.lsdimension.com/wp-content/uploads/2012/07/schrodingerromney.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          SchrÃ¶dinger's Candidate
                        </b>
                      </a>
                      <br clear="none"></br>
                      via
                      <a href="http://www.lsdimension.com/2012/07/06/schrodingers-candidate/" shape="rect"></a>
                      <a href="http://www.lsdimension.com/2012/07/20/ehrm-handhaaft-sgp-uitspraak-hoge-raad/" shape="rect"></a>
                      <a href="http://www.lsdimension.com/2012/08/15/free-pussy-riot/" shape="rect">...</a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>
                    <a href="http://www.lsdimension.com/?cat=3" shape="rect">art / photography</a>
                  </h2>
                  <ul class="advanced-recent-posts">
                    <li>
                      <span class="date"></span>
                      <a title="Smashing The Sound Barrier" href="http://www.lsdimension.com/2012/06/23/smashing-the-sound-barrier/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="Smashing The Sound Barrier" src="http://www.lsdimension.com/wp-content/uploads/2012/06/jetsoundbarrier.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          Smashing The Sound Barrier
                        </b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="A Brief History Of John Baldessari" href="http://www.lsdimension.com/2012/05/30/a-brief-history-of-john-baldessari/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="A Brief History Of John Baldessari" src="http://www.lsdimension.com/wp-content/uploads/2012/05/johnbaldessari.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          A Brief History Of John Baldessari
                        </b>
                      </a>
                    </li>
                    <li>
                      <span class="date"></span>
                      <a title="Ferienne" href="http://www.lsdimension.com/2012/05/30/ferienne/" shape="rect">
                        <b>
                          <img style=" width: 180px;" title="Ferienne" src="http://www.lsdimension.com/wp-content/uploads/2012/05/ferienne.jpg" class="recent-posts-thumb"></img>
                          <br clear="none"></br>
                          Ferienne
                        </b>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>calendar</h2>
                  <div id="calendar_wrap">
                    <table summary="Calendar" id="wp-calendar">
                      <caption>October 2012</caption>
                      <thead>
                        <tr>
                          <th title="Monday" scope="col" rowspan="1" colspan="1">M</th>
                          <th title="Tuesday" scope="col" rowspan="1" colspan="1">T</th>
                          <th title="Wednesday" scope="col" rowspan="1" colspan="1">W</th>
                          <th title="Thursday" scope="col" rowspan="1" colspan="1">T</th>
                          <th title="Friday" scope="col" rowspan="1" colspan="1">F</th>
                          <th title="Saturday" scope="col" rowspan="1" colspan="1">S</th>
                          <th title="Sunday" scope="col" rowspan="1" colspan="1">S</th>
                        </tr>
                      </thead>
                      <tfoot>
                        <tr>
                          <td id="prev" rowspan="1" colspan="3">
                            <a title="View posts for September 2012" href="http://www.lsdimension.com/2012/09/" shape="rect">« Sep</a>
                          </td>
                          <td class="pad" rowspan="1" colspan="1"> </td>
                          <td id="next" class="pad" rowspan="1" colspan="3"> </td>
                        </tr>
                      </tfoot>
                      <tbody>
                        <tr>
                          <td rowspan="1" colspan="1">1</td>
                          <td rowspan="1" colspan="1">2</td>
                          <td id="today" rowspan="1" colspan="1">3</td>
                          <td rowspan="1" colspan="1">4</td>
                          <td rowspan="1" colspan="1">5</td>
                          <td rowspan="1" colspan="1">6</td>
                          <td rowspan="1" colspan="1">7</td>
                        </tr>
                        <tr>
                          <td rowspan="1" colspan="1">8</td>
                          <td rowspan="1" colspan="1">9</td>
                          <td rowspan="1" colspan="1">10</td>
                          <td rowspan="1" colspan="1">11</td>
                          <td rowspan="1" colspan="1">12</td>
                          <td rowspan="1" colspan="1">13</td>
                          <td rowspan="1" colspan="1">14</td>
                        </tr>
                        <tr>
                          <td rowspan="1" colspan="1">15</td>
                          <td rowspan="1" colspan="1">16</td>
                          <td rowspan="1" colspan="1">17</td>
                          <td rowspan="1" colspan="1">18</td>
                          <td rowspan="1" colspan="1">19</td>
                          <td rowspan="1" colspan="1">20</td>
                          <td rowspan="1" colspan="1">21</td>
                        </tr>
                        <tr>
                          <td rowspan="1" colspan="1">22</td>
                          <td rowspan="1" colspan="1">23</td>
                          <td rowspan="1" colspan="1">24</td>
                          <td rowspan="1" colspan="1">25</td>
                          <td rowspan="1" colspan="1">26</td>
                          <td rowspan="1" colspan="1">27</td>
                          <td rowspan="1" colspan="1">28</td>
                        </tr>
                        <tr>
                          <td rowspan="1" colspan="1">29</td>
                          <td rowspan="1" colspan="1">30</td>
                          <td rowspan="1" colspan="1">31</td>
                          <td class="pad" rowspan="1" colspan="4"> </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>about</h2>
                  <div class="textwidget">
                    <img width="185" src="http://www.lsdimension.nl/wp-content/uploads/2010/04/starchild.jpg"></img>
                    <br clear="none"></br>
                    <br clear="none"></br>
                    <span hovercolor="ffffff" style="font-size:11px;">
                      We just opened our
                      <a href="http://www.lsdimension.com/2011/02/27/welcome-visitor/" shape="rect">new site</a>
                      . More site announcements
                      <a href="http://www.lsdimension.com/category/site-announcements/" shape="rect">here</a>
                      .
                    </span>
                    <br clear="none"></br>
                    <br clear="none"></br>
                    <span style="font-size: 11px;">
                      <a href="mailto:lsdimension1@gmail.com" shape="rect">
                        <strong>E-mail us</strong>
                      </a>
                    </span>
                  </div>
                </div>
              </div>
              <div class="widget">
                <div class="widgetinside">
                  <h2>meta</h2>
                  <ul>
                    <li>
                      <a href="http://www.lsdimension.com/wp-login.php" shape="rect">Log in</a>
                    </li>
                    <li>
                      <a title="Syndicate this site using RSS 2.0" href="http://www.lsdimension.com/feed/" shape="rect">
                        Entries
                        <abbr title="Really Simple Syndication">RSS</abbr>
                      </a>
                    </li>
                    <li>
                      <a title="The latest comments to all posts in RSS" href="http://www.lsdimension.com/comments/feed/" shape="rect">
                        Comments
                        <abbr title="Really Simple Syndication">RSS</abbr>
                      </a>
                    </li>
                    <li>
                      <a title="Powered by WordPress, state-of-the-art semantic personal publishing platform." href="http://wordpress.org/" shape="rect">WordPress.org</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="clearall"></div>
        <div id="footer">
          <div class="tools">
            <ul>
              <li></li>
              <li>
                <a href="http://www.lsdimension.com/wp-login.php" shape="rect">Log in</a>
              </li>
            </ul>
          </div>
          <script src="http://s.gravatar.com/js/gprofiles.js?p&amp;ver=3.1.1" type="text/javascript"></script>
          <script type="text/javascript"> /* &lt;![CDATA[ */ var WPGroHo = { my_hash: &quot;&quot; }; /* ]]&gt; */ </script>
          <script src="http://www.lsdimension.com/wp-content/plugins/jetpack/modules/wpgroho.js?ver=3.1.1" type="text/javascript"></script>
          <div style="display:none"> </div>
          <script type="text/javascript" src="http://stats.wordpress.com/e-201240.js"></script>
          <script type="text/javascript"> st_go({v:'ext',j:'1',blog:'17310122',post:'0'}); var load_cmc = function(){linktracker_init(17310122,0,2);}; if ( typeof addLoadEvent != 'undefined' ) addLoadEvent(load_cmc); else load_cmc(); </script>
          Copyright © 2012 	Light Sound Dimension	All rights reserved		Antisnews designed by
          <a href="http://www.antisocialmediallc.com" shape="rect">antisocialmediallc.com</a>
        </div>
      </div>
    </div>
    <script src="http://www.lsdimension.com/wp-content/themes/antisnews/js/loopedSlider.js" type="text/javascript"></script>
  </body>
</html>     
    decent   L     sensationalist   �      struggle   ��     name   �X     crashing   �     	traveling   �C     infinite   ϖ     chatter   �o     iPad        applaud   ��         *http://en.wikipedia.org/wiki/Roland_TR-808    Roland TR-808   9�     �| All Hail The Beat Author: adriejan Published: April 26th, 2012 A very short documentary that sums up in three minutes the importance of the    �drum machine for electronic, hip hop and pop music in the last thirty years. Originally designed in 1980 as a tool for studio musicians to    Roland TR-808      9202a8c04000641f80000000001275cb     *http://en.wikipedia.org/wiki/Roland_TB-303    TB-303 bass synthesizer   ;�     �beats. The by now vintage, distinctive, artificial sound of the 808 not only gave birth to the techno scene (in addition to tools like the    �), but also influenced the evolution of all kinds of relevant styles in the last decades. By now, their sounds are available digitally, but original    TB-303 bass synthesizer      9202a8c04000641f8000000000033b0a     'http://en.wikipedia.org/wiki/S%C3%B3nar    SÃ³nar   ��     �breakdowns. The characters are: Modeselektor , a producer duo, jettisoned from playing a tiny room in the US to playing to 20,000 people at the    �festival in Barcelona; journalist Philip Sherburne , who leaves America to find a more complete techno lifestyle in Europe; The Wighnomy Brothers , catapulted from    SÃ³nar      !http://en.wikipedia.org/wiki/Jena    Jena   ��     �Philip Sherburne , who leaves America to find a more complete techno lifestyle in Europe; The Wighnomy Brothers , catapulted from their idyllic world in    �, Germany to face their breaking point on camera; Tobias Thomas of Kompakt , who contemplates the near-end of his career; and Monolake , an    Jena      9202a8c04000641f8000000000147cfc     $http://en.wikipedia.org/wiki/Kompakt    Kompakt   �}     �in Europe; The Wighnomy Brothers , catapulted from their idyllic world in Jena , Germany to face their breaking point on camera; Tobias Thomas of    �, who contemplates the near-end of his career; and Monolake , an inventor of the Ableton software that nearly all electronic musicians use to create    Kompakt      9202a8c04000641f80000000009d38e0     $http://en.wikipedia.org/wiki/Ableton    Ableton   �(     �face their breaking point on camera; Tobias Thomas of Kompakt , who contemplates the near-end of his career; and Monolake , an inventor of the    �software that nearly all electronic musicians use to create their music, who continues his steady yet quirky approach to a life in music. While back    Ableton      9202a8c04000641f8000000000510dcb     #http://en.wikipedia.org/wiki/Boston    Boston   �]     �who continues his steady yet quirky approach to a life in music. While back in the US, David Day (Grill’s husband) tries tirelessly to turn    �from a rock-centric town to a techno city. Day’s wanton attempts to make electronic music popular put strain on his marriage to the director. And    Boston      9202a8c04000641f800000000000af9f     'http://en.wikipedia.org/wiki/Acid_house    
acid house   �b     �the early 1980sÂ origins of warehouse raves andÂ techno,Â  Real Scenes: Detroit . Now, get ready to submerge in the following documentary on its British successor movement:    �! During the late 1980s, acid house, with its distinctive soundÂ produced by Roland bassÂ synthesizers and drum machines such as the TB 303 and TR 808    
acid house      9202a8c04000641f8000000000177d58     2http://en.wikipedia.org/wiki/Second_Summer_of_Love    second Summer of Love   �     �booming underground scene. It also presented the first coming to the surface of ecstasy , which contributed to the summers of 1988-9 being called the    �(after the lsd-fueled first one in 1969). A cid house parties took place in warehouses and out in the open, thus continuing the Detroit phenomenon    second Summer of Love      9202a8c04000641f8000000000409b3b     -http://en.wikipedia.org/wiki/Pierre_Schaeffer    Pierre Schaeffer  /�     �Published: August 4th, 2011 Electronic music as an art form is often credited to start with the likes of pioneers such as Karlheinz Stockhausen Â and    �, in the 1940s and 1950s. However, one guy in Egypt was there earlier: Halim El-Dabh (1921), who in 1944 hit the streets of Cairo    Pierre Schaeffer      9202a8c04000641f800000000006ab0c     5http://en.wikipedia.org/wiki/Palais_Schaumburg_(band)    Palais Schaumburg  K�     �Fehlmann is a Swiss composer and producer of electronic music, born in 1957. His career has been stellar: after joining the German avant garde band    ~, he moved to Berlin in 1984, where he built a home studio to focus on electronic music. Four years later he founded the label    Palais Schaumburg      9202a8c04000641f80000000034847d1     $http://en.wikipedia.org/wiki/WestBam    Westbam  L�     �home studio to focus on electronic music. Four years later he founded the label “Teutonic Beats”, to which among others the pioneering German techno dj    �belonged. In 1990 he started working with the epochal British ambient techno group The Orb (he is credited for such tracks als “ Little Fluffy    Westbam      9202a8c04000641f8000000003accb74     $http://en.wikipedia.org/wiki/The_Orb    The Orb  M�     �“Teutonic Beats”, to which among others the pioneering German techno dj Westbam belonged. In 1990 he started working with the epochal British ambient techno group    �(he is credited for such tracks als “ Little Fluffy Clouds ” and “ Blue Room “), as well as playing in the infamous Berlin    The Orb      9202a8c04000641f800000000009a988     $http://en.wikipedia.org/wiki/Kompakt    Kompakt  Qz     �of his own, moreover, such as Visions of Blah (2002), Lowflow (2004), Honigpumpe (2007) and Gute Luft (2010), all on the Cologne-based German minimal techno    �label. The latter two albumsÂ are full of delightful minimal techno music, filled with little sounds and musical textures, like it seems only Germans (or in    Kompakt      9202a8c04000641f80000000009d38e0     -http://en.wikipedia.org/wiki/The_Fame_Monster    âThe Fame Monsterâ   �     9202a8c04000641f8000000012e6105b    >��    2http://www.metafilter.com/79876/The-Baedeker-Blitz    ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>The Baedeker Blitz | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/79876/The-Baedeker-Blitz" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/79876/The-Baedeker-Blitz/rss" title="Comments on: The Baedeker Blitz" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/baedeker" shape="rect">baedeker</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/travel" shape="rect">travel</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20The%20Baedeker%20Blitz%20http%3A%2F%2Fmefi%2Eus%2Fw%2F79876" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/79876/The-Baedeker-Blitz" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        The Baedeker Blitz
        <br clear="none"></br>
        <span class="smallcopy">
          March 11, 2009 2:03 PM  
          <a href="http://www.metafilter.com/79876/The-Baedeker-Blitz/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/79876/The-Baedeker-Blitz/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        &quot;Loot the
        <a href="http://en.wikipedia.org/wiki/Baedeker" shape="rect">Baedeker</a>
        I did, all the details of a time and place I had never been to, right down to the names of the diplomatic corps.&quot; - Thomas Pynchon from
        <a href="http://www.pynchon.pomona.edu/slowlearner/index.html" shape="rect">Slow Learner</a>
        .
        <br clear="none"></br>
        Baedeker's were the de facto travel guide for
        <a href="http://www.unesco.org/courier/1999_08/uk/dossier/txt12.htm" shape="rect">international men of leisure</a>
        :  &quot;Baedekerâ€™s publications, which covered most of Europe, became so popular that Kaiser Wilhelm of Germany was quoted as saying that he stationed himself at a particular palace window each noon because â€œItâ€™s written in Baedeker that I watch the changing of the guard from that window, and the people have come to expect it.â€�
        <a href="http://contueor.com/baedeker/links.htm" shape="rect">Baedeker maps</a>
        online.
        <a href="http://www.archive.org/search.php?query=publisher%3A%22Leipzig%20%3A%20K.%20Baedeker%3B%20New%20York%2C%20C.%20Scribner's%20sons%3B%20%5Betc.%2C%20etc.%5D%22" shape="rect">Baedeker books</a>
        online.
        <a href="http://news.bbc.co.uk/1/hi/magazine/7174904.stm" shape="rect">
          <br clear="none"></br>
          Are the old ones the best ones?
        </a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/10705" shape="rect">vacapinta</a>
          (13 comments total)
          <span id="favcnt179876">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/79876" shape="rect">27 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2483474" shape="rect"></a>
      <div class="comments">
        That archive.org link is an
        <i>amazing</i>
        thing to browse around.  Here's a taste, almost at random (from
        <a href="http://www.archive.org/stream/mediterraneansea00karl/mediterraneansea00karl_djvu.txt" shape="rect">The Mediterranean</a>
        , apparently 1911):
        <blockquote>
          <b>IV. Intercourse with Orientals.</b>
          <br clear="none"></br>
          The objects and pleasures of travel are so unintelligible to most Orientals that they are apt to regard the European traveller as a lunatic, or at all events as a Croesus, and therefore to be exploited on every possible occasion. Hence their constant demands for 'bakshish' ('a gift'). To check this demoralizing cupidity the traveller should never give bakshish except for services rendered, unless occasionally to aged or crippled beggars.
        </blockquote>
        And I can't resist recommending Mina Loy's
        <a href="http://books.google.com/books?id=WTxJHgAACAAJ" shape="rect">Lost Lunar Baedeker</a>
        here, too.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/42695" shape="rect">RogerB</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483474" shape="rect">2:19 PM</a>
          on March 11, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2483474" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483491" shape="rect"></a>
      <div class="comments">
        Throw your Baedeker into the Arno.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/24306" shape="rect">longsleeves</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483491" shape="rect">2:32 PM</a>
          on March 11, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2483491" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483520" shape="rect"></a>
      <div class="comments">
        Great post. From the BBC link:
        <br clear="none"></br>
        <br clear="none"></br>
        <em>
          The world wars were disastrous for a German company reliant on the free flow of wealthy Europeans, but the books did prove useful to soldiers and airmen. The Baedeker raids of 1942, the bombings of historic English cities, were so-called because the Luftwaffe had supposedly vowed to destroy every British building marked with three stars in the guide.
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        I learned about Baedeker's guides in a Hemingway class I took as an undergrad. They can be wonderful snapshots of a place and time.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17654" shape="rect">marxchivist</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483520" shape="rect">2:52 PM</a>
          on March 11, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483524" shape="rect"></a>
      <div class="comments">
        Here's a better
        <a href="http://www.archive.org/search.php?query=(creator%3ABaedeker%20OR%20subject%3ABaedeker%20OR%20title%3ABaedeker%20OR%20description%3ABaedeker)%20AND%20mediatype%3Atexts" shape="rect">Internet Archive link</a>
        (279 hits).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/1915" shape="rect">stbalbach</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483524" shape="rect">2:54 PM</a>
          on March 11, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483525" shape="rect"></a>
      <div class="comments">
        on the same token ... from
        <a href="http://www.archive.org/stream/dominioncanada00karl" shape="rect">The Dominion of Canada</a>
        :
        <blockquote>
          X. Sports and Pasttimes
          <br clear="none"></br>
          <br clear="none"></br>
          {... following a lengthy, multi-page treatise on fishing and hunting in the Canadian wilderness ...}
          <br clear="none"></br>
          <br clear="none"></br>
          <b>Lacrosse</b>
          is the national game of Canada and takes precedence of all others in the public estimation.
          <br clear="none"></br>
          <br clear="none"></br>
          <b>Cricket.</b>
          The principal clubs are those of Toronto, Montreal, Ottawa, Quebec, Winnipeg, Victoria, St. John, and Halifax.  There is an
          <i>Association</i>
          , which selects players to represent All Canada in the annual match with the United States and against other visiting teams.  The game, however, excites little general interest.
        </blockquote>
        what is this nation that loves lacrosse and plays cricket against its southern neighbor (a national US cricket team?  really?)  and where has it gone?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/15340" shape="rect">bl1nk</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483525" shape="rect">2:55 PM</a>
          on March 11, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483529" shape="rect"></a>
      <div class="comments">
        this is just an awesome fpp.  I had no idea this even existed, and now i'm hooked.  thanks.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21045" shape="rect">shmegegge</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483529" shape="rect">2:57 PM</a>
          on March 11, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483677" shape="rect"></a>
      <div class="comments">
        Give it to me; I shan't let you carry it. We will simply drift.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21365" shape="rect">desuetude</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483677" shape="rect">4:58 PM</a>
          on March 11, 2009 [
          <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2483677" shape="rect">3 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2483872" shape="rect"></a>
      <div class="comments">
        One of my favorite all time stories, though probably not true:
        <blockquote>Verlag Karl Baedeker was raised by several nannies, each of whom spoke a different language. He claims that for some time he thought that every person in the world spoke a different language, and that he would need to learn a new language for every new person he met.</blockquote>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14751" shape="rect">alms</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2483872" shape="rect">7:25 PM</a>
          on March 11, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2483872" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2484072" shape="rect"></a>
      <div class="comments">
        &quot;Verlag&quot; is not his first name - it means &quot;publisher&quot; in German...
        <br clear="none"></br>
        <br clear="none"></br>
        Anyways, interesting FPP!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/26693" shape="rect">Harald74</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2484072" shape="rect">1:28 AM</a>
          on March 12, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2484251" shape="rect"></a>
      <div class="comments">
        <i>the de facto travel guide for international men of leisure:</i>
        <br clear="none"></br>
        <br clear="none"></br>
        I'd like a travel guide for
        <a href="http://www.imdb.com/title/tt0118655/" shape="rect">international men of mystery</a>
        .  It'd show you all the places where you could shag now or shag later.  Yeah, baby, yeah!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14511" shape="rect">jonp72</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2484251" shape="rect">7:24 AM</a>
          on March 12, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2484546" shape="rect"></a>
      <div class="comments">
        I love Baedekers; thanks for the post!
        <a href="http://www.ctrarebooks.com/home//Baedeker/baedeker.pdf" shape="rect">Here</a>
        's a wonderful article by Edward Mendelson about them (pdf file); I wrote about one aspect of it
        <a href="http://www.languagehat.com/archives/002683.php" shape="rect">here</a>
        (where I also brag about my 1905 edition of the
        <em>Austria-Hungary</em>
        guide—I have a reprint of the famous 1914
        <em>Russia </em>
        as well).  Those maps are things of beauty; just compare the Alexandria one to the crappy modern one in that last link.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14752" shape="rect">languagehat</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2484546" shape="rect">10:11 AM</a>
          on March 12, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2485068" shape="rect"></a>
      <div class="comments">
        <a href="http://content.cricinfo.com/ci-icc/content/image/380360.html" shape="rect">The USA cricket team.</a>
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/39712" shape="rect">Helga-woo</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2485068" shape="rect">2:26 PM</a>
          on March 12, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2485553" shape="rect"></a>
      <div class="comments">
        Oo yeah, thanks for this!  I recently bought a Murray's Japan (similar to Baedeker's in content and color) and looked up my old stomping grounds - shockingly little has changed in the past 100 years, including the main tourist attraction: a waterfall and spring that used to dispense sake.  The maps are little works of origami.
        <br clear="none"></br>
        I've done some repair work on these little babies and depending on when and where they were assembled, the staple bindings are either still intact (pre-war = good metal) or post-war (crappy metal that is now rusting and eating away at the paper).
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49974" shape="rect">ikahime</a>
          at
          <a target="_self" href="/79876/The-Baedeker-Blitz#2485553" shape="rect">9:54 PM</a>
          on March 12, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/79875/Ill-be-glad-when-Im-not-still-the-only-one" shape="rect">« Older</a>
        Alice Randall is best known, perhaps, for her nove...  |  Jordan Mechner's way-ahead-of-...
        <a target="_self" href="/79877/All-aboard" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/115859/The-Stanford-Geospatial-Network-Model-of-the-Roman-World" shape="rect">The Stanford Geospatial Network Model of the Roman...</a>
        <span class="smallcopy">May 11, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/96562/The-mother-of-all-airplane-trips" shape="rect">The mother of all airplane trips</a>
        <span class="smallcopy">October 11, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/96280/And-all-I-got-was-this-lousy-Tshirt" shape="rect">And all I got was this lousy T-shirt</a>
        <span class="smallcopy">October 2, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/72855/Matt-is-back" shape="rect">Matt is back</a>
        <span class="smallcopy">June 27, 2008</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/57025/Auf-Der-Walz" shape="rect">Auf Der Walz.</a>
        <span class="smallcopy">December 14, 2006</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    he   )~     people   *"     perhaps   R      details   '�     It's   )�     Loot   '6     were   (i     did   '~     Thomas   '�     so   ):         %http://en.wikipedia.org/wiki/Baedeker    Baedeker   'o     �Popular Best Of Random Login New User Tags: baedeker travel Share: Twitter Facebook The Baedeker Blitz March 11, 2009 2:03 PM   Subscribe "Loot the    sI did, all the details of a time and place I had never been to, right down to the names of the diplomatic corps." -    Baedeker      9202a8c04000641f8000000000085c53    >��    (http://www.metafilter.com/79976/Ig-Nobel    �}<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Ig Nobel | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/79976/Ig-Nobel" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/79976/Ig-Nobel/rss" title="Comments on: Ig Nobel" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/pseudoscience" shape="rect">pseudoscience</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/quackery" shape="rect">quackery</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/aids" shape="rect">aids</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/patents" shape="rect">patents</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/priority" shape="rect">priority</a>
              <br clear="none"></br>
              <a title="intellectual_theft" rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/intellectual%5Ftheft" shape="rect">intellectual_th</a>
              ...
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Ig%20Nobel%20http%3A%2F%2Fmefi%2Eus%2Fw%2F79976" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/79976/Ig-Nobel" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Ig Nobel
        <br clear="none"></br>
        <span class="smallcopy">
          March 15, 2009 4:42 AM  
          <a href="http://www.metafilter.com/79976/Ig-Nobel/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/79976/Ig-Nobel/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://en.wikipedia.org/wiki/Luc_Montagnier" shape="rect">Professor Luc Montagnier,</a>
        <a href="http://nobelprize.org/nobel_prizes/medicine/laureates/2008/index.html" shape="rect">2008 Nobel Prize Laureate for Medicine</a>
        , is no stranger to
        <a href="http://www.dallasvoice.com/artman/publish/article_2666.php" shape="rect">controversy</a>
        . Recently, he has been
        <a href="http://www.colombre.it/montagnier" shape="rect">touting his approval</a>
        for the
        <a href="http://br.geocities.com/criticandokardec/benveniste02.pdf" shape="rect">ignominiously debunked</a>
        &quot;water memory&quot; theories of the late French immunologist
        <a href="http://en.wikipedia.org/wiki/Jacques_Benveniste" shape="rect">Dr. Jacques Benveniste</a>
        . This is not altogether surprising, given that Montagnier has filed a
        <a href="http://v3.espacenet.com/publicationDetails/originalDocument?CC=WO&amp;NR=2007068831A2&amp;KC=A2&amp;FT=D&amp;date=20070621&amp;DB=EPODOC&amp;locale=en_EP" shape="rect">patent application</a>
        for a method for characterising &quot;biologically active biochemical elements&quot; based on Benveniste's
        <a href="http://en.wikipedia.org/wiki/Jacques_Benveniste#Digital_Biology" shape="rect">more outlandish theories</a>
        . But there's more...
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        First of all, the patent examiner who has drafted the International Search Report, in his
        <a href="http://www.wipo.int/pctdb/en/wads.jsp?IA=FR2006002735&amp;LANGUAGE=EN&amp;ID=id00000006560269&amp;VOL=89&amp;DOC=000162&amp;WO=07/068831&amp;WEEK=NA&amp;TYPE=NA&amp;DOC_TYPE=ETWOS&amp;PAGE=1" shape="rect">Written Opinion</a>
        on patentability, seems less than impressed by Montagnier's invention. The killer quote comes in page 10:
        <br clear="none"></br>
        <em>
          <br clear="none"></br>
          &quot;This is all the more problematic since: (i) the invention is based on phenomena which contradict the basic principles of physics and of chemistry, i.e. the existence of a biological activity or effect without an active molecule, and (ii) no explanation or theoretical basis makes it possible at the current time to explain the results obtained.&quot;
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        Secondly, a man called Bruno Robert claims that Montagnier
        <a href="http://www.telegraph.co.uk/news/worldnews/europe/france/4959505/Man-who-co-discovered-HIV-accused-of-stealing-rights-to-Aids-cure.html" shape="rect">stole the invention from him</a>
        . Most disturbingly, Robert filed a
        <a href="http://v3.espacenet.com/publicationDetails/originalDocument?CC=WO&amp;NR=2007071856A2&amp;KC=A2&amp;FT=D&amp;date=20070628&amp;DB=EPODOC&amp;locale=en_EP" shape="rect">nearly identical patent application</a>
        right before Montagnier.
        <br clear="none"></br>
        <br clear="none"></br>
        BTW, this may not be Montagnier's
        <a href="http://www.sciencemag.org/cgi/content/summary/297/5588/1803d" shape="rect">first brush with quackery</a>
        .
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17643" shape="rect">Skeptic</a>
        (13 comments total)
        <span id="favcnt179976">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/79976" shape="rect">1 user marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2488079" shape="rect"></a>
    <div class="comments">
      <em>This is all the more problematic since: (i) the invention is based on phenomena which contradict the basic principles of physics and of chemistry...</em>
      <br clear="none"></br>
      <br clear="none"></br>
      It also contradicts the basic principles of
      <a href="http://www.metafilter.com/66687/Homeopathy#1917902" shape="rect">logic</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18901" shape="rect">weapons-grade pandemonium</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488079" shape="rect">5:21 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488085" shape="rect"></a>
    <div class="comments">
      <strong>pandemonium</strong>
      By the diplomatic standards of patent examination documents, that sentence already is as damning as it gets. It isn't often that a patent examiner tells a patent applicant (never mind an applicant who happens to be a world-famous Nobel laureate) that he's, quite basically, full of sh*t.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17643" shape="rect">Skeptic</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488085" shape="rect">5:37 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488089" shape="rect"></a>
    <div class="comments">
      I'm actually pretty shocked that the Nobel committee would honor a homeopath.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/52138" shape="rect">Pope Guilty</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488089" shape="rect">5:47 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488099" shape="rect"></a>
    <div class="comments">
      I find it hard to believe that Montagnier copied his invention from Bruno Robert.  Robert fails to teach or even suggest the vital Figure 9 of Montagnier, showing a &quot;HiFi Amplifier,&quot; in stereo with 2x100W.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/27180" shape="rect">exogenous</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488099" shape="rect">6:21 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488153" shape="rect"></a>
    <div class="comments">
      Giving someone antioxidants is not a &quot;brush with quackery.&quot; The brief note doesn't say Montagnier made any outrageous claims of their benefits.  The touting his approval link is in French so I personally can't comment on that.  The patent link is in French so I can't comment on that. The Telegraph article isn't about homeopathy - it says the invention is &quot;a technique whereby the Aids virus and other serious ailments, including Parkinson's and Alzheimer's disease, can be pinpointed by their electromagnetic &quot;signatures&quot;.&quot;
      <br clear="none"></br>
      Those diseases exist, so I suspect some probe could be made of them.
      <br clear="none"></br>
      The rest of the links are about Montagnier in general or Benveniste, a nut. If this is Montagnier touting homeopathy, you need a better job of documenting it.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21503" shape="rect">dances_with_sneetches</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488153" shape="rect">7:26 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488187" shape="rect"></a>
    <div class="comments">
      <strong>dances_with_sneetches</strong>
      : I hate to intervene for a second time in my own thread, but:
      <br clear="none"></br>
      <br clear="none"></br>
      a) This is not about Montagnier touting homeopathy, but about him touting something
      <em>even nuttier</em>
      as his own invention. Something which, even worse, does not appear to actually be his own invention;
      <br clear="none"></br>
      <br clear="none"></br>
      b) I have actually gone out of my way to find English-language links: for instance, I've linked to an
      <a href="http://www.wipo.int/pctdb/en/wads.jsp?IA=FR2006002735&amp;LANGUAGE=EN&amp;ID=id00000006560269&amp;VOL=89&amp;DOC=000162&amp;WO=07/068831&amp;WEEK=NA&amp;TYPE=NA&amp;DOC_TYPE=ETWOS&amp;PAGE=1" shape="rect">English translation of the examiner's Written Opinion</a>
      , which is quite informative about the nature of the invention, and moreover cites as closest prior art a patent application and an article,
      <em>both by Benveniste</em>
      . Unfortunately, not all documentation is available in English: this is not the umpteenth predigested newsfilter FPP linking to the Guardian. I'm sorry that you can't read French, but both Montagnier's and Robert's patent applications clearly cite Benveniste by name, and that in the second video in the &quot;touting his approval&quot; link, Montagnier is sitting right behind a sign that says &quot;Fondation Benveniste&quot;;
      <br clear="none"></br>
      <br clear="none"></br>
      c) While prescribing antioxydants is not quackery, Montagnier's shameless shilling of the fermented papaya pills, and his exaggerated claims on their behalf, have been given
      <a href="http://www.google.be/search?hl=en&amp;q=papaye+montagnier&amp;btnG=Google+Search&amp;meta=" shape="rect">ample</a>
      (and amused) coverage in French. That short article in &quot;Science&quot; seemed to me the best English-language link.
      <br clear="none"></br>
      <br clear="none"></br>
      I've been quite shocked to find out this story: Prof. Montagnier's merit in the HIV discovery is undisputable, and in my view he clearly was the victim in the Montagnier-Gallo controversy. Nevertheless, the documents here speak for themselves (even if sometimes only in French).
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17643" shape="rect">Skeptic</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488187" shape="rect">8:10 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488210" shape="rect"></a>
    <div class="comments">
      Weird, why is it always
      <a href="http://www.normanallan.com/Sci/bs.html" shape="rect">virologists</a>
      who get caught up in homeopathy? (It's an interesting read, quackery or not.)
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18374" shape="rect">greatgefilte</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488210" shape="rect">8:35 AM</a>
        on March 15, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2488210" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488239" shape="rect"></a>
    <div class="comments">
      <a href="http://jacques.benveniste.org/Benveniste-conference-Lugano-POSTER.pdf" shape="rect">Benveniste conference poster with Montagnier as featured speaker.</a>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17643" shape="rect">Skeptic</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488239" shape="rect">9:05 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488290" shape="rect"></a>
    <div class="comments">
      Astonishing, greatgefilte.
      <br clear="none"></br>
      <br clear="none"></br>
      How weird that solutions which show activity far beyond the point where they should be diluted to zero inspire these two virologists to mysticism about &quot;water memory&quot; rather than serious concern about the effectiveness of test tube washing techniques in their own labs.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/32678" shape="rect">jamjam</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488290" shape="rect">9:39 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488333" shape="rect"></a>
    <div class="comments">
      Hmmm, maybe Joan of Arc caliber faith in the effectiveness of isolation and cleaning techniques is necessary for the mental health of virologists dealing with deadly human pathogens, when you consider that a single virus particle (a &quot;virion&quot;) is apparently
      <a href="http://www.sciencedaily.com/releases/2009/03/090313150254.htm" shape="rect">capable of producing an infection</a>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      Then again, I think it's entirely possible Montagnier is suffering from some sort of dementia as a result of contracting an infection by one of the many viruses and other pathogens he has studied and come in contact with over the years in the course of his research, and cannot really be held responsible for these actions.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/32678" shape="rect">jamjam</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488333" shape="rect">10:12 AM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488620" shape="rect"></a>
    <div class="comments">
      Okay, Skeptic, I don't want to pick a fight but you did link to something you called &quot;quackery&quot; and it was just giving the pope some glutathione and papaya juice and making no great claims about them. The Telegraph article suggested intrigue - but isn't the telegraph a Murdoch paper? The fact that he has been seen with Beneviste is bad - but how bad would depend on the translation. As for the device requiring &quot;water memory,&quot; maybe it does. But if you are scanning for &quot;electronic signatures&quot; of specific molecules, well that can be done in a number of manners, emr, nmr. All of this post boils down to the patent examiners response, which does say quackery, but I think there should have been more supporting the claim.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21503" shape="rect">dances_with_sneetches</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488620" shape="rect">1:45 PM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2488799" shape="rect"></a>
    <div class="comments">
      Frankly,
      <strong>dances_with_sneetches</strong>
      , you could bother having a look at my links. Anyway, if everything I've shown is not enough for you, just note the name of Montagnier's co-speaker in that Benveniste conference (which BTW was a conference
      <em>about</em>
      Jacques Benveniste, not with Jacques Benveniste, who was incoveniently dead at the time): Jamal Aissa.
      <br clear="none"></br>
      <br clear="none"></br>
      Jamal Aissa happens to be a veteran of Benveniste's lab. In particular, he was cited in the
      <a href="http://www.fasebj.org/cgi/content/full/20/1/23" shape="rect">DARPA paper</a>
      which definitely buried Benveniste's claims, as
      <em>the</em>
      researcher whose presence seemed to be essential to successfully reproduce Benveniste's experiments. As you may know, &quot;the results couldn't be reproduced unless person A was present&quot; is, since
      <a href="http://en.wikipedia.org/wiki/Prosper-Ren%C3%A9_Blondlot" shape="rect">Blondlot</a>
      , a BIG red flag.
      <br clear="none"></br>
      <br clear="none"></br>
      Anyway, if you look at
      <a href="http://www.fasebj.org/cgi/content/full/20/1/23/F1" shape="rect">figure 1</a>
      of that DARPA paper, showing the experimental set-up of Benveniste, what do you see? Well,
      <em>exactly the same picture</em>
      as
      <a href="http://v3.espacenet.com/publicationDetails/originalDocument?CC=WO&amp;NR=2007068831A2&amp;KC=A3&amp;FT=D&amp;date=20070809&amp;DB=EPODOC&amp;locale=en_EP" shape="rect">figure 9 of Montagnier's patent application</a>
      , the one with the 2x100W &quot;HiFi Amplifier&quot;
      <strong>exogenous</strong>
      has mocked above.
      <br clear="none"></br>
      <br clear="none"></br>
      Still any doubt? Well, Montagnier has filed
      <a href="http://v3.espacenet.com/publicationDetails/biblio?CC=WO&amp;NR=2007147982A2&amp;KC=A2&amp;FT=D&amp;date=20071227&amp;DB=EPODOC&amp;locale=en_EP" shape="rect">yet another patent application</a>
      on the same subject, this time with that same Jamal Aissa as co-inventor.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17643" shape="rect">Skeptic</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2488799" shape="rect">4:59 PM</a>
        on March 15, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2489338" shape="rect"></a>
    <div class="comments">
      I was reluctant to post once again, but since you decided to insult me to suggest I didn't read the posts, the problem was I did read them. You started with Wikipedia. A minor sin, but forgiveable. It tells us who Montagnier is, but added nothing to the matter of the controversy in question. You followed that up by the Nobel Prize site. He did win a Nobel Prize, but the site didn't add to what he is doing that is controversial. Okay, you were only giving background.
      <br clear="none"></br>
      <br clear="none"></br>
      No stranger to controversy? I've linked to the Dallas News article on Metafilter before. Yes, there was a controversy surrounding the discovery of AIDS and the patent of HIV antibody detection. I don't think Montagnier is to blame for this.
      <br clear="none"></br>
      <br clear="none"></br>
      Then you link to an Italian site where videos are side by side with Benveniste claiming Montagnier is touting his approval for water memory theories. Is Montagnier &quot;touting his approval&quot; for &quot;water memory theories&quot; - I don't know. I'm at work now, I don't have sound on my computer, but I seem to recall the videos were in a language other than English. I'm not going to jump to the conclusion that Montagnier is a nut because he has a video on the same page below a nut.
      <br clear="none"></br>
      <br clear="none"></br>
      Then you went to the patent application. I'm supposed to evaluate a patent application written in French. (I am multilingual, French doesn't happen to be one of the languages.)
      <br clear="none"></br>
      So you linked to Benveniste's more outlandish theories, water memory again, this time the digital variety. I don't have anything yet that tells me this is relevant to the patent controversy.
      <br clear="none"></br>
      <br clear="none"></br>
      So we go on to the patent examiner's report. That is damning, as I conceded above. Even now I don't see the &quot;water memory&quot; aspect of the invention, just the statement that it has some of the classical hallmarks of quackery. But - so far this is all I've got - and I don't know how to weigh the statement of a single patent examiner. Many are not experts in their fields.
      <br clear="none"></br>
      <br clear="none"></br>
      So then I have the link &quot;a man called Bruno Robert claims that Montagnier stole the invention from him.&quot; It takes me to an advertisement I have to click past saying &quot;Read World News and Prophecy Magazine to know your future.&quot; Click on it and you come to &quot;Find the answers in Bible prophecy.&quot;  I get past that to a Telegraph article that begins:
      <br clear="none"></br>
      <br clear="none"></br>
      &quot;Man who co-discovered HIV accused of stealing rights to Aids cure
      <br clear="none"></br>
      <br clear="none"></br>
      A Nobel prize-winning French researcher who co-discovered the virus that leads to Aids but sparked controversy after his colleague said he had claimed all the glory, has now been accused of stealing the rights to a revolutionary invention that may provide a cure to the disease, it emerged yesterday.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      So basically it is a sleaze article that opens by claiming the invention is revolutionary. Every skeptical bone in my body is screaming.
      <br clear="none"></br>
      <br clear="none"></br>
      The article goes on to say that the argument does not seem to be whether Montagnier is claiming intellectual rights to the invention, but rather whether he paid for the right to patent it. Which will be decided in court on May 20. Moderately interesting stuff garnished by tabloid journalism, innuendo and snark.
      <br clear="none"></br>
      <br clear="none"></br>
      The line related to the invention: &quot;the Aids virus and other serious ailments, including Parkinson's and Alzheimer's disease, can be pinpointed by their electromagnetic &quot;signatures&quot;.
      <br clear="none"></br>
      <br clear="none"></br>
      The hope is that once identified, the diseases can be blocked or neutralised with an opposite electromagnetic signal.&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      The second statement &quot;the hope...&quot; is a whopper, but doesn't seem to be a claim of Montagnier or this patent. The first statement, I would say is within the realm of possibility. Parkinson's is an entire tissue deficit and some kind of imaging could find it. I'm uncertain how it would apply to HIV but maybe in a high concentration area like the lymph nodes an electronic spin based image could quantify the virus population - a useful tool in measuring the efficacy of treatment.
      <br clear="none"></br>
      <br clear="none"></br>
      You go on to present another patent application in French and finish off by citing some of Montagnier's folksy advice about antioxidants as a sign of quackery. The latter statement is akin to Montagnier saying &quot;take a cold shower in the morning and a glass of red wine.&quot; I just can't get excited about it. The guy can't recommend papaya juice and glutathione? I suppose if he puts his face on a patent medicine I'll get my dander up.
      <br clear="none"></br>
      <br clear="none"></br>
      So, this leaves the question, does the Montagnier patent rely on something as ridiculous as water memory? Maybe. Maybe if I understood French I could make the final judgment on that. My problem is that I read this post as a skeptic, rather than accepting the conclusions of the post.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/21503" shape="rect">dances_with_sneetches</a>
        at
        <a target="_self" href="/79976/Ig-Nobel#2489338" shape="rect">7:16 AM</a>
        on March 16, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/79975/The-sap-is-flowing" shape="rect">« Older</a>
      Up in Maple country The   season is right for maki...  |  The Musical Mystery of Connie ...
      <a target="_self" href="/79977/Anyone-Who-Ever-Asks" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/107549/Foldit-Crystal-structure-of-a-monomeric-retroviral-protease-solved-by-protein-folding-game-players" shape="rect">Foldit - Crystal structure of a monomeric...</a>
      <span class="smallcopy">September 18, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/95194/90-Days" shape="rect">90 Days</a>
      <span class="smallcopy">August 27, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/91775/BBC-World-Service-Documentaries" shape="rect">BBC World Service Documentaries</a>
      <span class="smallcopy">May 8, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/89385/Luna-Commons" shape="rect">Luna Commons</a>
      <span class="smallcopy">February 20, 2010</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/7990/US-drug-patients-vs-the-world" shape="rect">US drug patients vs. the world</a>
      <span class="smallcopy">May 31, 2001</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    Maple   u�     theoretical   0�     French   +�     problematic   /�     
principles   0
     called   1"     	existence   0;     method   ,�     brush   3m     he   *�         +http://en.wikipedia.org/wiki/Luc_Montagnier    Professor Luc Montagnier,   )�     �Of Random Login New User Tags: pseudoscience quackery aids patents priority intellectual_th ... Share: Twitter Facebook Ig Nobel March 15, 2009 4:42 AM   Subscribe    �2008 Nobel Prize Laureate for Medicine , is no stranger to controversy . Recently, he has been touting his approval for the ignominiously debunked "water    Professor Luc Montagnier,      9202a8c04000641f800000000036dbd5     /http://en.wikipedia.org/wiki/Jacques_Benveniste    Dr. Jacques Benveniste   +�     �is no stranger to controversy . Recently, he has been touting his approval for the ignominiously debunked "water memory" theories of the late French immunologist    �. This is not altogether surprising, given that Montagnier has filed a patent application for a method for characterising "biologically active biochemical elements" based on    Dr. Jacques Benveniste      9202a8c04000641f800000000041bf3d    >��    Nhttp://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago    ��<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>Billions and Billions....OK, make that 29 years ago | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago/rss" title="Comments on: Billions and Billions....OK, make that 29 years ago" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/CarlSagan" shape="rect">CarlSagan</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Sagan" shape="rect">Sagan</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/Cosmos" shape="rect">Cosmos</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/video" shape="rect">video</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/science" shape="rect">science</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20Billions%20and%20Billions%2E%2E%2E%2EOK%2C%20make%20that%2029%20years%20ago%20http%3A%2F%2Fmefi%2Eus%2Fw%2F80234" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        Billions and Billions....OK, make that 29 years ago
        <br clear="none"></br>
        <span class="smallcopy">
          March 23, 2009 3:53 PM  
          <a href="http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://en.wikipedia.org/wiki/Cosmos:_A_Personal_Voyage" shape="rect">
          <i>Cosmos: A Personal Voyage</i>
        </a>
        premiered on PBS on September 28, 1980. (
        <a href="http://www.metafilter.com/19831/" shape="rect">Previously</a>
        ). With
        <a href="http://www.carlsagan.com/" shape="rect">Carl Sagan</a>
        as guide, on a &quot;cosmic journey across space and time,&quot; on a &quot;spaceship of the imagination,&quot; few shows inspired as many people to investigate science, many of whom went on to be scientists.
        <div style="border-top:1px dotted #777;margin-top:6px;padding-right:20px;"></div>
        <br clear="none"></br>
        It was the most-watched PBS series in history before Ken Burns's
        <i>The Civil War</i>
        and
        <a href="http://www.imdb.com/title/tt0081846/awards" shape="rect">won</a>
        three prime time Emmys and a Peabody Award.
        <br clear="none"></br>
        <br clear="none"></br>
        As
        <i>Astronomy</i>
        magazine
        <a href="http://web.ipac.caltech.edu/staff/jarrett/sagan/Saganeul.html" shape="rect">said</a>
        upon Sagan's death in 1996, &quot;The universe lost one of its best friends a few days before Christmas 1996,&quot; and &quot;he accomplished more to interest the public in astronomy and space exploration than anyone else of his time.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        All thirteen episodes of
        <i>Cosmos</i>
        are now
        <a href="http://www.hulu.com/cosmos" shape="rect">streaming online</a>
        , thanks to Hulu.com.
      </div>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50006" shape="rect">waitingtoderail</a>
        (38 comments total)
        <span id="favcnt180234">
          <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/80234" shape="rect">38 users marked this as a favorite</a>
        </span>
      </span>
    </div>
    <br clear="none"></br>
    <div style="margin-top:0px;margin-bottom:12px;" class="copy">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <a name="2498612" shape="rect"></a>
    <div class="comments">
      <i>Sorry, currently our video library can only be streamed from within the United States</i>
      <br clear="none"></br>
      <br clear="none"></br>
      Who speaks for Earth?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16106" shape="rect">mazola</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498612" shape="rect">3:57 PM</a>
        on March 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498612" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498615" shape="rect"></a>
    <div class="comments">
      <em>thanks to Hulu.com</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Unless you're somewhere outside of the U.S., goddamnit.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/47454" shape="rect">Curry</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498615" shape="rect">3:59 PM</a>
        on March 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498615" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498624" shape="rect"></a>
    <div class="comments">
      I, for one, welcome our new xenophobic Hulu overlords.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17340" shape="rect">jester69</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498624" shape="rect">4:05 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498629" shape="rect"></a>
    <div class="comments">
      <a href="http://www.metafilter.com/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498615" shape="rect">Curry</a>
      : &quot;
      <i>Unless you're somewhere outside of the U.S., goddamnit.</i>
      &quot;
      <br clear="none"></br>
      <br clear="none"></br>
      And that's the case for
      <em>billions </em>
      of people.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/84281" shape="rect">Joe Beese</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498629" shape="rect">4:09 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498629" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498630" shape="rect"></a>
    <div class="comments">
      I'm the one weird guy who doesn't find spiritual significance in shit floating around in space.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66354" shape="rect">norabarnacl3</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498630" shape="rect">4:09 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498636" shape="rect"></a>
    <div class="comments">
      <i>Who speaks for Earth?</i>
      <br clear="none"></br>
      <br clear="none"></br>
      That would be the United States.  I'm sorry you had to find out like this.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/32115" shape="rect">The Tensor</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498636" shape="rect">4:15 PM</a>
        on March 23, 2009 [
        <a title="6 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498636" shape="rect">6 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498638" shape="rect"></a>
    <div class="comments">
      <em>Billions and Billions</em>
      <br clear="none"></br>
      <br clear="none"></br>
      Sagan never actually uses this exact phrase anywhere in Cosmos. Go ahead, watch the whole thing and check. He says &quot;billions&quot; a lot, but never &quot;billions and billions&quot;. The phrase comes directly from Johnny Carson's good-natured parody of Sagan.
      <br clear="none"></br>
      <br clear="none"></br>
      Sagan is a hero of mine. If atheism/secular humanism somehow could have saints, he would be Saint #1. He was a wonderful, brilliant man. If you've never seen Cosmos before, you really should - it's one of the cultural touchstones of the recent years of our civilization. No one before or since has explained the awesome complexity of the universe in such an accessible, anyone-can-understand way.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66958" shape="rect">DecemberBoy</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498638" shape="rect">4:17 PM</a>
        on March 23, 2009 [
        <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498638" shape="rect">4 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498642" shape="rect"></a>
    <div class="comments">
      The wonder in the cosmos isn't that there is stuff floating around in space.
      <br clear="none"></br>
      <br clear="none"></br>
      The wonder in the cosmos is that it exists with some kind of organization at all and the fact that you can write down a page of equations that explain most of the behavior of it all.
      <br clear="none"></br>
      <br clear="none"></br>
      That and the fact that corduroy pants and turtlenecks are appropriate to wear in both spaceships of the imagination and the library of Alexandria.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19893" shape="rect">sien</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498642" shape="rect">4:21 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498642" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498644" shape="rect"></a>
    <div class="comments">
      <i>Cosmos</i>
      was formative for me. Thanks Carl, Mom, and Dad!
      <br clear="none"></br>
      <br clear="none"></br>
      <small>And PBS!</small>
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19016" shape="rect">everichon</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498644" shape="rect">4:26 PM</a>
        on March 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498644" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498645" shape="rect"></a>
    <div class="comments">
      Dude, I'm a previous!!!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14835" shape="rect">thanotopsis</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498645" shape="rect">4:27 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498647" shape="rect"></a>
    <div class="comments">
      I was in fourth grade when
      <em>Cosmos</em>
      was first aired on PBS and I never missed an episode. It fueled my interest in science more than other program before, or since. A couple of years ago I checked out the DVDs from the library and re-watched all 13 episodes over the course of three evenings. It holds up really well.
      <br clear="none"></br>
      <br clear="none"></br>
      In conclusion, I miss Carl Sagan. If he were still alive I'd want him to hold a cabinet position in Obama's administration.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/89721" shape="rect">Ratio</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498647" shape="rect">4:29 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498648" shape="rect"></a>
    <div class="comments">
      I'm not in the US. What sort of anonymizer-proxy-whatever hack can you recommend so I can watch this?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/41543" shape="rect">chillmost</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498648" shape="rect">4:30 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498649" shape="rect"></a>
    <div class="comments">
      'To create an apple pie from scratch, you first must create the universe'
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15347" shape="rect">PenDevil</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498649" shape="rect">4:32 PM</a>
        on March 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498649" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498650" shape="rect"></a>
    <div class="comments">
      I earned a couple of credits in college to watch Cosmos, even years after it at been aired.  I attended a seminar by him some years later in San Diego.  He was so erudite and affable it was like listening to your learned uncle chatting in your living room.  He is also a hero of mine.  Great find.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17132" shape="rect">elendil71</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498650" shape="rect">4:32 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498651" shape="rect"></a>
    <div class="comments">
      <a href="http://www.lifehacker.com.au/tips/2008/10/01/how_to_watch_videos_on_hulu_from_anywhere-2.html" shape="rect">Tips here</a>
      on how to watch Hulu outside the US.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/50006" shape="rect">waitingtoderail</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498651" shape="rect">4:33 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498660" shape="rect"></a>
    <div class="comments">
      Unless you're somewhere outside of the U.S.
      <br clear="none"></br>
      <br clear="none"></br>
      Yeah sure, like there really is an outside the US. That'd be awesome, like Stargate.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/33757" shape="rect">mattoxic</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498660" shape="rect">4:41 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498660" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498661" shape="rect"></a>
    <div class="comments">
      <a href="http://www.youtube.com/watch?v=BlpyGhABXRA" shape="rect">'To create an apple pie from scratch, you first must create the universe'</a>
      <br clear="none"></br>
      <br clear="none"></br>
      Obligatory?
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23894" shape="rect">washburn</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498661" shape="rect">4:41 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498664" shape="rect"></a>
    <div class="comments">
      And I'm the guy who can never quite grasp what &quot;spiritual&quot; really means.
      <br clear="none"></br>
      <br clear="none"></br>
      Also, I really miss Carl Sagan.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/34406" shape="rect">belvidere</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498664" shape="rect">4:52 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498665" shape="rect"></a>
    <div class="comments">
      According to my parents, Cosmos sent me into a bout of kiddie depression for a week. Apparently this was due to me not understanding that the Sun wasn't going to turn into a red giant in my lifetime.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45498" shape="rect">keep_evolving</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498665" shape="rect">4:53 PM</a>
        on March 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498665" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498670" shape="rect"></a>
    <div class="comments">
      norabarnacl3, I am somehow not surprised.
      <br clear="none"></br>
      <br clear="none"></br>
      I started reading -- okay, coloring with crayons, but reading very shortly thereafter -- my parents' copy of
      <em>Cosmos </em>
      the hardback when I was three, and they let me have it.  I loved that book till it fell apart.  Later in life, I found that many other people also took to it at about the same age.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/63748" shape="rect">Countess Elena</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498670" shape="rect">5:01 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498672" shape="rect"></a>
    <div class="comments">
      Carl Sagan was extraordinarily good at making Astronomy and Physics relevant for the average joe without either dumbing it down to the nth degree or talking down the audience. Further he was able to impart a sense of wonder to the subject that made a significant impression on me as a young 6 year old. The fact that he was able to speak to me as a kid and to an audience of older PBS viewers was a special gift indeed.
      <br clear="none"></br>
      <br clear="none"></br>
      Interesting enough public television had a large number of presenters during that time period that could really excite the curiosity. David  Attenborough did that with his nature programs (and is still doing it), James Burke was able to do with his history series, and there was some crazy bearded guy who did it with Dinosaurs.
      <br clear="none"></br>
      <br clear="none"></br>
      It seems that Neil Degrasse Tyson has sort of inherited Sagan's role as physics and astronomy expert to the masses, but I just don't connect to him nearly as much as I enjoyed Sagan. I guess they both had a degree of  self-promotion but Sagan seemed more subtle about it than Neil does.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/81450" shape="rect">vuron</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498672" shape="rect">5:03 PM</a>
        on March 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498672" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498673" shape="rect"></a>
    <div class="comments">
      Carl Sagan wasn't &quot;just&quot; a scientist with a passion for divulgation and awe insipiring daydreaming, as if those qualities weren't enough to admire the man.
      <br clear="none"></br>
      <br clear="none"></br>
      He was also quite a pragmatist, very worried by the prospect of a
      <a href="http://www.mindfully.org/Nucs/Sagan-Nuclear-Consequences31oct83.htm" shape="rect">Nuclear Winter</a>
      .
      <br clear="none"></br>
      <br clear="none"></br>
      For those among you too young to remember, not so many years ago (between 1980 and 90) there was a lot of talk going on about the atmospheric effects of a series of nuclear explosions resulting from a prolonged war. Among the possible scenarios, that of a nuclear winter (sharp and prolonged decrease of global average temperature) caused by projection of particles in the atmosphere. Quoting Sagan
      <blockquote>
        Even much smaller temperature declines are known to have serious consequences. The explosion of the Tambora volcano in Indonesia in 1815 was the probable cause of an average global temperature decline of less than 1Â°C, due to the obscuration of sunlight by the fine dust propelled into the stratosphere. The hard freezes the following year were so severe that 1816 has been known in Europe and America as, respectively, &quot;the year without a summer,&quot; and &quot;eighteen-hundred-and-froze-to-death.&quot; A 1Â°C cooling would nearly eliminate wheat growing in Canada.
        <br clear="none"></br>
      </blockquote>
      Unlike the &quot;terror&quot; threat, which is mostly a a product of mass manipulation based on a single catastrophic event (9/11), the possibility of having multiple warheads detonate at the same time was considered as quite realistic, as many world leaders of the past had a track record of being a bunch of mass murders affected by delusions of omnipotence and the memory of the massacre of the second world war was still quite present in many minds, including that of the Hiroshima and Nagasaki bombs.
      <br clear="none"></br>
      <br clear="none"></br>
      It was a fantastic time for the miltary industrial complex, that was quite interested into selling more missles and more armaments. At the same time, people started realizing, also thanks to Sagan, the insanity of waging a nuclear war and that no one could have possibly won a war resulting in global annihilation ; that helped dispelling some of the effects of  a persistant propaganda suggesting that any price, including a nuclear war, was a price worth paying if that could have  saved our &quot;freedom&quot;. Anything including death by nuclear detonation was better than surrendering to the enemy, an &quot;honourable&quot; way to die.
      <br clear="none"></br>
      <br clear="none"></br>
      After watching Sagan's work, I urge you to rent the movie &quot;Dr Strangelove&quot;, which is not only an entertaining funny movie, but an excellent portrait of how too much power in the hands of lunatics can cause you to lose your precious bodily fluids permanently. And life, too.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/3801" shape="rect">elpapacito</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498673" shape="rect">5:03 PM</a>
        on March 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498673" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498678" shape="rect"></a>
    <div class="comments">
      Cosmos was what finally turned me into someone who would gladly take a seat to go die on Mars.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/45704" shape="rect">autodidact</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498678" shape="rect">5:08 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498678" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498682" shape="rect"></a>
    <div class="comments">
      I was really sad that I didn't get to meet Carl Sagan in American Samoa the last time Halley's Comet came around. I was living in a compound for foreign workers, and three of my neighbors were amateur astronomers who were very excited about his visit. Anyway,
      <a href="http://photos-c.ak.facebook.com/photos-ak-snc1/v342/73/13/1004097829/n1004097829_30151610_8341.jpg" shape="rect">pic related</a>
      .
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18384" shape="rect">mullingitover</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498682" shape="rect">5:10 PM</a>
        on March 23, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498682" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498728" shape="rect"></a>
    <div class="comments">
      This post is so full of fondly-remembering-my-nerdy-kid-self win. Thanks.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/32956" shape="rect">Emperor SnooKloze</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498728" shape="rect">6:00 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498731" shape="rect"></a>
    <div class="comments">
      The series itself was good but what *really* inspired me was Carl Sagan's crazy voice - I can still hear his oddly compelling intonation in my head.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/18306" shape="rect">bluesky43</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498731" shape="rect">6:01 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498745" shape="rect"></a>
    <div class="comments">
      This reminds me that it is nearly time for my Annual Rewatching of The Cosmos. A one-weekend ritual I've practiced since the release of the DVDs.
      <br clear="none"></br>
      <br clear="none"></br>
      Also, every time I break up with a girl, the first cheery thought is always: On the bright side, I get to re-experience watching Cosmos for the first time with somebody new.
      <br clear="none"></br>
      <br clear="none"></br>
      Also, my first-born will probably be named Sagan.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/7776" shape="rect">BoatMeme</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498745" shape="rect">6:17 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498745" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498766" shape="rect"></a>
    <div class="comments">
      Watching Cosmos with Dad as a very young child was one of the few bonding experiences I've ever had with him.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/23306" shape="rect">JHarris</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498766" shape="rect">6:37 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498767" shape="rect"></a>
    <div class="comments">
      Thank you
      <b>so much</b>
      . I've never seen this, and long wanted to. I love that man's voice.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17670" shape="rect">phrontist</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498767" shape="rect">6:38 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498794" shape="rect"></a>
    <div class="comments">
      There's a reason one of the protagonists of my Old Man's War series of books is named &quot;Jane Sagan.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/15351" shape="rect">jscalzi</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498794" shape="rect">7:03 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498794" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498811" shape="rect"></a>
    <div class="comments">
      I was in Ithaca, NY, in the mid-1990s, visiting a couple of friends at college. A bunch of us decided to have a picnic lunch one afternoon after some shopping, so we bought sandwiches at Subway, and hiked down to the bottom of one of the gorges, and spread out comfortably on the grass, in the sun. Just a stone's throw away, in a little nook behind some trees, two gentlemen started having an argument, and we soon heard definite sounds of scuffle and melee. A shirtless dude in a denim jacket then hightailed it up the gorge. We could just see the feet of the other guy, laid out flat on his back.
      <br clear="none"></br>
      <br clear="none"></br>
      I managed to lose at choosies, and got appointed to investigate. Still, I dragged one of the girls along with me for protection. This poor gentleman had had his face pummeled into breakfast fruit. He was lying there, refusing our help, obviously high as a kite, his face bloody and his eyes swollen shut; his poor, upset Rottweiler sitting loyally by his side. We proceeded to go find the nearest phone.
      <br clear="none"></br>
      <br clear="none"></br>
      It was Cornell's graduation that weekend, and we happened to knock on the door of a house filled to the brim with friends and family sitting around eating a buffet lunch, paper plates balanced on their laps. I'm directed to a phone in the living room, dial 911, and start giving out the whos and wheres and why fors. Everybody's just eating their lunch, telling stories and laughing. At one point, I actually had to shush them. &quot;Hey, Cornell! I'm on the phone with the cops!&quot;
      <br clear="none"></br>
      <br clear="none"></br>
      So the cops arrive, and we give the officers a horribly inaccurate description, and EMTs haul our friend into a bus and cart him off. Animal Control comes for the dog, and eventually the cops come back down the gorge with denim jacket guy who lent his pal the beating. Apparently, they had some sort of disagreement over some heroin. The house where we made the phone call had emptied by this time, and all the neighboring houses, and everybody and their mom and dad were watching from the porch.
      <br clear="none"></br>
      <br clear="none"></br>
      Finally, we get to go back and sit down and finish our subs, and my friend turns to me, points up the side of the gorge and goes, &quot;That's Carl Sagan's house.&quot;
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/16167" shape="rect">steef</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498811" shape="rect">7:33 PM</a>
        on March 23, 2009 [
        <a title="3 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498811" shape="rect">3 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498828" shape="rect"></a>
    <div class="comments">
      If you've never listened to it before,
      <a href="http://radiolab.org" shape="rect">Radiolab</a>
      has a great
      <a href="http://www.wnyc.org/shows/radiolab/episodes/2006/05/12" shape="rect">episode</a>
      about Space. The first segment includes an awesome, touching story by Ann Druyan about her and Carl Sagan.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/86847" shape="rect">kmz</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498828" shape="rect">7:46 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498830" shape="rect"></a>
    <div class="comments">
      Oh, awesome.  Between this and Connections, I really learned how to explore and think, and that it was ok to do so.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/14601" shape="rect">lysdexic</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498830" shape="rect">8:00 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498963" shape="rect"></a>
    <div class="comments">
      I was an 8 year old when my parents planted me on the carpet and made me watch this every week. I was sucked into our school's gifted program two years later.
      <br clear="none"></br>
      <br clear="none"></br>
      I'm not convinced I would have qualified for the program without COSMOS. I was armed and ready in class and when I took those entry tests. I'm fairly sure many other kids who were passed by for the same program would have made it had they spent those 12 weeks hearing Sagan rather than watching Silver Spoons.
      <br clear="none"></br>
      <br clear="none"></br>
      My favorite quote, other than the apple pie one: Imagime a Hiroshima, happening every two minutes, over the course of a Sunday afternoon.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/19728" shape="rect">sourwookie</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498963" shape="rect">10:47 PM</a>
        on March 23, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2498985" shape="rect"></a>
    <div class="comments">
      <a href="http://www.marijuana-uses.com/essays/002.html" shape="rect">Carl Sagan was a pothead.</a>
      And he thought about the Universe a lot.  So did me and my friend Jeff, when we were potheads.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/76438" shape="rect">twoleftfeet</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2498985" shape="rect">11:42 PM</a>
        on March 23, 2009 [
        <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2498985" shape="rect">2 favorites</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2499074" shape="rect"></a>
    <div class="comments">
      1980. Ha! I hope you kids realize just how lucky you were, to be sitting in your parent's homes, watching Sagan on TV. When I was in 1980, I didn't have TV. I couldn't afford the time to watch. I was much too busy playing my own bit part in pioneering those new-fangled microcomputers, so y'all could yap about Sagan on the internet, 29 years later.
      <br clear="none"></br>
      <br clear="none"></br>
      I've never seen the show. I suppose I never think about Cosmos, when shopping for DVDs. It's not like I don't buy that sort of thing. It's not like I don't have a shelf full of books on cosmology and physics (the popular kind, I'm not up to the serious stuff). I heard about the show, but I was used to just dismissing anything about television from my mind.
      <br clear="none"></br>
      <br clear="none"></br>
      I guess it's time to order those DVDs.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/17342" shape="rect">Goofyy</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2499074" shape="rect">4:39 AM</a>
        on March 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2499210" shape="rect"></a>
    <div class="comments">
      I hope that all y'all hoo-mons realize that
      <em>Cosmos</em>
      was the only reason that we of 40 Eridanii decided not to wipe out this mudball, and that was based on the premise that you were working on cloning Sagan. Hop to it, hairless apes.
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/66724" shape="rect">Halloween Jack</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2499210" shape="rect">7:44 AM</a>
        on March 24, 2009
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <a name="2499519" shape="rect"></a>
    <div class="comments">
      I have fond memories of the Spaceship of the Imagination. Now I wonder if Sagan was perhaps a little embarrassed by it, but when I was eight  I thought it was super cool to see him sidle up to an illuminated, unlabelled control panel and tap a few times to get the next segment of the show rolling.
      <br clear="none"></br>
      <br clear="none"></br>
      Nice post!
      <br clear="none"></br>
      <span class="smallcopy">
        posted by
        <a target="_self" href="http://www.metafilter.com/user/88003" shape="rect">werkzeuger</a>
        at
        <a target="_self" href="/80234/Billions-and-BillionsOK-make-that-29-years-ago#2499519" shape="rect">11:46 AM</a>
        on March 24, 2009 [
        <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2499519" shape="rect">1 favorite</a>
        ]
      </span>
    </div>
    <br clear="none"></br>
    <br clear="none"></br>
    <p style="font-size:11px;" class="copy whitesmallcopy">
      <a target="_self" href="/80233/Amazing-Waves" shape="rect">« Older</a>
      Clark Little takes amazing photos of waves.  See m...  |  Writing, seemingly, a book a d...
      <a target="_self" href="/80235/Coming-Soon-Metafilter-The-Novelisation-by-Alan-Dean-Foster" shape="rect">Newer »</a>
    </p>
    <br clear="none"></br>
    <div class="comments">
      <script language="JavaScript">
        var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
      </script>
      <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
    </div>
    <p class="comments">This thread has been archived and is closed to new comments</p>
    <br clear="none"></br>
    <br clear="none"></br>
    <div id="related" class="recently copy">
      <div style="margin-bottom:4px;">Related Posts</div>
      <a style="font-weight:normal;" href="http://www.metafilter.com/109982/Lost-Episode-of-Cosmos-Found" shape="rect">Lost Episode of &quot;Cosmos&quot; Found</a>
      <span class="smallcopy">December 1, 2011</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/86195/We-are-all-connected" shape="rect">We are all connected</a>
      <span class="smallcopy">October 28, 2009</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/85428/I-miss-Carl-Sagan" shape="rect">I miss Carl Sagan.</a>
      <span class="smallcopy">September 27, 2009</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/85330/Carl-Sagan-and-Stephen-Hawking-lay-it-out-in-song" shape="rect">Carl Sagan and Stephen Hawking lay it out, in song</a>
      <span class="smallcopy">September 24, 2009</span>
      <br clear="none"></br>
      <a style="font-weight:normal;" href="http://www.metafilter.com/19831/22-years-ago-13-hours-of-television-changed-my-life" shape="rect">22 years ago, 13 hours of television changed my life.</a>
      <span class="smallcopy">September 9, 2002</span>
      <br clear="none"></br>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    thirteen   .n     more   -�     episodes   .w     waves   ��     Hulu   .�     Writing   �     book   �-     people   +�     universe   -�     series   ,D         6http://en.wikipedia.org/wiki/Cosmos:_A_Personal_Voyage    Cosmos: A Personal Voyage   *H     �User Tags: CarlSagan Sagan Cosmos video science Share: Twitter Facebook Billions and Billions....OK, make that 29 years ago March 23, 2009 3:53 PM   Subscribe    �premiered on PBS on September 28, 1980. ( Previously ). With Carl Sagan as guide, on a "cosmic journey across space and time," on a    Cosmos: A Personal Voyage      9202a8c04000641f800000000011527e    >��    Mhttp://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988   	�<html>
  <head>
    <meta content="IE=edge" http-equiv="X-UA-Compatible"></meta>
    <meta content="DCFfHJ4UQbMnfKaS453mfXvyeqtaeZwGSKSjFmv3" name="readability-verification"></meta>
    <script type="text/javascript">var _sf_startpt=(new Date()).getTime()</script>
    <title>When the Shuttle program nearly ended - in 1988 | MetaFilter</title>
    <link type="text/css" rel="stylesheet" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/comments010712-min.css"></link>
    <style type="text/css">
      .copy{font-size:10pt;font-family:Verdana,sans-serif;}
.accentcopy{font-size:10pt;font-family:Verdana,sans-serif;}
p{font-size:10pt;font-family:Verdana,sans-serif;}
blockquote{font-size:10pt;font-family:Verdana,sans-serif;}
.smallcopy{font-size:8pt;font-family:Verdana,sans-serif;}
a{text-decoration:none;}
.comments{font-size:10pt;font-family:Verdana,sans-serif;}
.recently{background:#004D73;margin-top:20px;margin-left:75px;margin-right:70px;margin-bottom:10px;padding:10px;width:475px;}
.clearfix:after{content:&quot;.&quot;;display:block;height:0;clear:both;visibility:hidden;}
.clearfix{display:inline-block;}
.clearfix{display:block;}
.cselected{background-color:#666;padding:5px;}
.googleads{margin:0px 10px 20px 45px;width:736px;float:none;}
.yahooright{float:right;margin:10px;}
.skip{display:none;}
.oldFav{display:none;}
.new{color:#fff;}
#triangle {position: absolute;display:none;line-height:0;height:0;width:0;left:0;top:0;border:10px solid transparent;border-left-color:#cc0;}
.google-ad{margin:0 0 10px 0;}
.google-label a{color:#aaa;text-transform:uppercase;font-size:10px;font-weight:400;padding:3px 3px 3px 0;} .google-text{overflow:hidden;line-height:140%;padding:6px 0;}
.google-text-last{padding-bottom:0;}
.google-html{min-height:200px;}
.url{font-size:16px;font-weight:700;}
.visible-url{font-size:11px;font-weight:400;} #page #menu {word-wrap:break-word;margin-left:-177px;}
    </style>
    <meta content="gEOzJ94HBqDkKWgGb+DkZb3ztZIprg+2l8JVSh7CaQM=" name="verify-v1"></meta>
    <meta content="off" http-equiv="x-dns-prefetch-control"></meta>
    <link href="/apple-touch-icon.png" rel="apple-touch-icon"></link>
    <base target="_self"></base>
    <link type="image/ico" href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="icon"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/favicon.ico" rel="SHORTCUT ICON"></link>
    <link title="MeFi Site Search" href="http://www.metafilter.com/opensearch.xml" type="application/opensearchdescription+xml" rel="search"></link>
    <link href="http://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988" rel="canonical" id="canonical"></link>
    <link href="http://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988/rss" title="Comments on: When the Shuttle program nearly ended - in 1988" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularPosts" title="Popular Posts" type="application/rss+xml" rel="alternate"></link>
    <link href="http://feeds.feedburner.com/mefi/PopularComments" title="Popular Comments" type="application/rss+xml" rel="alternate"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/mefi/handheld042210.css" media="handheld" type="text/css" rel="stylesheet"></link>
    <link href="http://d217i264rvtnq0.cloudfront.net/styles/print010712-min.css" media="print" type="text/css" rel="stylesheet"></link>
    <script type="text/javascript">
      function addEvent(b,a,c){if(b.addEventListener){b.addEventListener(a,c,false);return true}else return b.attachEvent?b.attachEvent(&quot;on&quot;+a,c):false}
var cid,lid,sp;
function dtm(){var b=new Array(&quot;January&quot;,&quot;February&quot;,&quot;March&quot;,&quot;April&quot;,&quot;May&quot;,&quot;June&quot;,&quot;July&quot;,&quot;August&quot;,&quot;September&quot;,&quot;October&quot;,&quot;November&quot;,&quot;December&quot;),a=new Date,c=&quot;&quot;;c=a.getDay();var e=a.getDate(),f=a.getMonth(),g=a.getFullYear(),d=a.getHours();a=a.getMinutes();c=d&lt;12?&quot;AM&quot;:&quot;PM&quot;;if(d==0)d=12;if(d&gt;12)d-=12;a+=&quot;&quot;;if(a.length==1)a=&quot;0&quot;+a;return b[f]+&quot; &quot;+e+&quot;, &quot;+g+&quot; &quot;+d+&quot;:&quot;+a+&quot; &quot;+c};
var google_adnum = 0;
function google_ad_request_done(a){if(!(a.length&lt;1)){var b=&quot;&quot;,c;b+='&lt;div class=&quot;google-ad&quot;&gt;';b+='&lt;div class=&quot;google-label&quot;&gt;';google_info.feedback_url&amp;&amp;(b+='&lt;a href=&quot;'+google_info.feedback_url+'&quot;&gt;');b+=&quot;Ads by Google&quot;;google_info.feedback_url&amp;&amp;(b+=&quot;&lt;/a&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;if(a[0].type==&quot;flash&quot;)b+='&lt;div class=&quot;google-flash&quot;&gt;',b+='&lt;object classid=&quot;clsid:D27CDB6E-AE6D-11cf-96B8-444553540000&quot; codebase=&quot;http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot;&gt; &lt;PARAM NAME=&quot;movie&quot; VALUE=&quot;'+google_ad.image_url+'&quot;&gt;&lt;PARAM NAME=&quot;quality&quot; VALUE=&quot;high&quot;&gt;&lt;PARAM NAME=&quot;AllowScriptAccess&quot; VALUE=&quot;never&quot;&gt;&lt;EMBED src=&quot;'+google_ad.image_url+'&quot; WIDTH=&quot;'+google_ad.image_width+'&quot; HEIGHT=&quot;'+google_ad.image_height+'&quot; TYPE=&quot;application/x-shockwave-flash&quot; AllowScriptAccess=&quot;never&quot;  PLUGINSPAGE=&quot;http://www.macromedia.com/go/getflashplayer&quot;&gt;&lt;/EMBED&gt;&lt;/OBJECT&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;image&quot;)b+='&lt;div class=&quot;google-image&quot;&gt;',b+='&lt;a href=&quot;'+a[0].url+'&quot; target=&quot;_top&quot; title=&quot;go to '+a[0].visible_url+'&quot; onmouseout=&quot;window.status=\'\'&quot; onmouseover=&quot;window.status=\'go to '+a[0].visible_url+'\';return true&quot;&gt;&lt;img border=&quot;0&quot; src=&quot;'+a[0].image_url+'&quot;width=&quot;'+a[0].image_width+'&quot;height=&quot;'+a[0].image_height+'&quot;&gt;&lt;/a&gt;',b+=&quot;&lt;/div&gt;&quot;;else if(a[0].type==&quot;html&quot;)b+='&lt;div class=&quot;google-html&quot;&gt;'+a[0].snippet+'&lt;/div&gt;&lt;div class=&quot;clearfix&quot;&gt;&lt;/div&gt;';else if(a[0].type==&quot;text&quot;)for(c=0;c&lt;3;c++)a[c]&amp;&amp;typeof a[c]!=&quot;undefined&quot;&amp;&amp;(b+='&lt;div class=&quot;google-text',c==2&amp;&amp;(b+=&quot; google-text-last&quot;),b+='&quot;&gt;',b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;url&quot;&gt;'+a[c].line1+&quot;&lt;/a&gt;&quot;,b+=&quot;&lt;br&gt;&quot;,b+='&lt;a title =&quot;'+a[c].visible_url+'&quot; href=&quot;'+a[c].url+'&quot; onmouseover=&quot;window.status=\''+a[c].visible_url+'\'; return true;&quot; onmouseout=&quot;window.status=\'\'; return true;&quot; target=&quot;_blank&quot; class=&quot;visible-url&quot;&gt;'+a[c].visible_url+&quot;&lt;/a&gt;&quot;,b+=&quot; &quot;+a[c].line2,a[c].line3!=null&amp;&amp;a[c].line3!=&quot;&quot;&amp;&amp;(b+=&quot; &quot;,b+=a[c].line3),b+=&quot;&lt;/div&gt;&quot;);b+=&quot;&lt;/div&gt;&quot;;document.write(b);a[0].bidtype==&quot;CPC&quot;&amp;&amp;(google_adnum+=a.length)}};
    </script>
  </head>
  <body id="body">
    <a href="#content" class="skip" shape="rect">skip to main content</a>
    <div id="logo">
      <a target="_self" href="http://www.metafilter.com/" shape="rect">
        <img border="0" height="80" width="196" alt="MetaFilter" src="http://d217i264rvtnq0.cloudfront.net/images/mefi/metafilter.png"></img>
      </a>
    </div>
    <div id="topline">
      <ul id="navglobal">
        <li>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
        </li>
        <li>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
        </li>
        <li>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
        </li>
        <li>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
        </li>
        <li>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
        </li>
        <li>
          <a target="_self" href="http://podcast.metafilter.com/" shape="rect">Podcast</a>
        </li>
        <li>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
        </li>
        <li>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </li>
      </ul>
    </div>
    <div id="yellowbar">
      <script type="text/javascript">document.write(dtm());</script>
    </div>
    <div id="bottomline">
      <div style="width:300px;text-align:right;padding-right:6px;" id="search">
        <form style="margin:0px;padding:0px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
          <div>
            <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
            <input value="FORID:10" name="cof" type="hidden"></input>
            <input value="UTF-8" name="ie" type="hidden"></input>
            <input style="width:120px;" size="31" name="q" type="text"></input>
            <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
          </div>
        </form>
        <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
      </div>
      <ul id="navseldom">
        <li>
          <a target="_self" href="/" shape="rect">Home</a>
        </li>
        <li>
          <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
        </li>
        <li>
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
        </li>
        <li>
          <a target="_self" href="/tags/" shape="rect">Tags</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/favorites/all" shape="rect">Popular</a>
        </li>
        <li>
          <a target="_self" href="http://bestof.metafilter.com/" shape="rect">Best Of</a>
        </li>
        <li>
          <a target="_self" href="/random" shape="rect">Random</a>
        </li>
      </ul>
      <br clear="none"></br>
      <ul id="navoften">
        <li>
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
        </li>
        <li>
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </li>
      </ul>
    </div>
    <br clear="all"></br>
    <a name="content" shape="rect"></a>
    <div id="page">
      <div style="float:right;">
        <div align="right">
          <div class="tags">
            Tags:
            <div id="taglist">
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/space" shape="rect">space</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/spaceflight" shape="rect">spaceflight</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/spaceshuttle" shape="rect">spaceshuttle</a>
              <br clear="none"></br>
              <a rel="tag" style="font-size:11px; font-weight:normal;text-decoration:underline;" href="http://www.metafilter.com/tags/columbia" shape="rect">columbia</a>
              <br clear="none"></br>
            </div>
          </div>
          <br clear="none"></br>
          <div style="background:none;" id="sharelinks" class="tags">
            Share:
            <br clear="none"></br>
            <a target="_blank" href="http://twitter.com/intent/tweet?text=MeFi%3A%20When%20the%20Shuttle%20program%20nearly%20ended%20%2D%20in%201988%20http%3A%2F%2Fmefi%2Eus%2Fw%2F80383" id="tshare" class="shareicon twitter" shape="rect">Twitter</a>
            <br clear="none"></br>
            <a target="_blank" href="http://www.facebook.com/sharer.php?u=http://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988" id="fbshare" class="shareicon facebook" shape="rect">Facebook</a>
          </div>
          <br clear="none"></br>
        </div>
      </div>
      <h1 class="posttitle threedee">
        When the Shuttle program nearly ended - in 1988
        <br clear="none"></br>
        <span class="smallcopy">
          March 28, 2009 3:36 AM  
          <a href="http://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988/rss" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a href="http://www.metafilter.com/80383/When-the-Shuttle-program-nearly-ended-in-1988/rss" shape="rect">Subscribe</a>
        </span>
      </h1>
      <div class="copy">
        <a href="http://spaceflightnow.com/shuttle/sts119/090327sts27/" shape="rect">&quot;I said to myself, 'we are going to die.'&quot;</a>
        Space Shuttle commander Hoot Gibson on his reaction as he saw pictures from the Shuttle's robot arm of gouged and missing tiles along its underbelly. Shades of
        <em>Columbia</em>
        - but this was mission
        <a href="http://en.wikipedia.org/wiki/STS-27" shape="rect">STS-27</a>
        , over fourteen years earlier. Yet mission control discounted the reports from orbit, perhaps misled by the poor quality of the downlinked images that resulted from encryption demanded by the mission's secretive military profile. In the end,
        <em>Atlantis</em>
        made it back, but with
        <a href="http://upload.wikimedia.org/wikipedia/commons/7/71/Sts-27_Landing.jpg" shape="rect">visible damage</a>
        along her right flank. But like most classified DoD missions of the time, little was reported, and NASA was arguably wary of drawing attention to the near-loss of only the second flight since the
        <em>Challenger</em>
        disaster. But if this near-miss had been better known, might NASA have been more concerned about
        <a href="http://en.wikipedia.org/wiki/Space_Shuttle_Columbia_disaster#Flight_risk_management" shape="rect">indications of debris damage</a>
        during the launch of STS-107?
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/60801" shape="rect">Major Clanger</a>
          (28 comments total)
          <span id="favcnt180383">
            <a target="_self" style="font-weight:normal;" href="http://www.metafilter.com/favorited/1/80383" shape="rect">12 users marked this as a favorite</a>
          </span>
        </span>
      </div>
      <br clear="none"></br>
      <div style="margin-top:0px;margin-bottom:12px;" class="copy">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <a name="2504637" shape="rect"></a>
      <div class="comments">
        We're lucky we only lost two crews on that death-trap.
        <br clear="none"></br>
        <br clear="none"></br>
        Here's to the next generation of manned flight.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19707" shape="rect">bardic</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504637" shape="rect">5:23 AM</a>
          on March 28, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504637" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504674" shape="rect"></a>
      <div class="comments">
        so, basically, NASA knew exactly how much damage falling insulation foam could do to the shuttle but kept on flying anyway? so who exactly was held accountable for Columbia?
        <blockquote> Years later, Gibson would be asked to brief the Columbia Accident Investigation Board about his experiences aboard Atlantis and as the tale was told, &quot;their jaws dropped,&quot; he said. </blockquote>
        Their jaws dropped because they realized they were going to have to paper over what would amount to involuntary manslaughter in any private industry. I think NASA is another one of those cold war institutions that needs a stable cleaning. maybe you could just start fresh.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50202" shape="rect">geos</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504674" shape="rect">6:47 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504688" shape="rect"></a>
      <div class="comments">
        This really pisses me off, what the hell.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/66302" shape="rect">Stonestock Relentless</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504688" shape="rect">7:01 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504703" shape="rect"></a>
      <div class="comments">
        The next generation of manned flight, hopefully run privately by folks with fear of massive wrongful death lawsuits.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16263" shape="rect">leotrotsky</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504703" shape="rect">7:36 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504706" shape="rect"></a>
      <div class="comments">
        All manned launchers, and space flight in general, are pretty dangerous compared to the every day levels of risk that most of us face. The participants are all very well aware of the danger they face. Which is not to excuse the bad design and operational decisions that have made things even more dangerous than necessary, but I don't think it's fair to apply regular industrial safety expectations. This is more like the early explorers venturing out to discover the new world, knowing they might not make it.
        <br clear="none"></br>
        <br clear="none"></br>
        I wonder how much the Space Shuttle's resemblance to a plane causes an expectation of plane-like safety levels? Because oddly enough it's that very resemblance to a plane that causes some extra safety risks compared to a traditional capsule design. Lots of other design decisions have turned out to be bad ideas too.
        <br clear="none"></br>
        <br clear="none"></br>
        For instance, if you want to bring back the main engines for re-use, this leads to putting them on the orbiter, which then has to be mounted on the side of an external tank, rather than being essentially a glider sitting on top of a launcher. Which seemed OK at the time, before NASA understood the potential damage that foam and ice shed from the tank could cause.
        <br clear="none"></br>
        <br clear="none"></br>
        Originally the goal was not to even have an external tank (since it can't be re-used) and if all the fuel had been carried internally then that would also have prevented these kinds of problems.
        <br clear="none"></br>
        <br clear="none"></br>
        My impression of the Shuttle's development history is of a process that started with a set of goals to be met, and then the design got gradually altered to take various practicalities and limitations into account, to the point where many of the goals were not being met any more and the overall safety and operational cost got way out of control. One of those sequences of decisions where somebody should have said wait a minute, we are so far from where we thought we'd be that we should start over.
        <br clear="none"></br>
        <br clear="none"></br>
        Then in a final irony, some of the goals that were still being met (such as large cross-range ability for certain anticipated military missions that never happened) became irrelevant, but the design compromises necessary to meet them (such as large wings vulnerable to damage) couldn't be changed any more.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/87842" shape="rect">FishBike</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504706" shape="rect">7:41 AM</a>
          on March 28, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504706" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504711" shape="rect"></a>
      <div class="comments">
        <em>hopefully run privately by folks with fear of massive wrongful death lawsuits.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Nononononononono.
        <br clear="none"></br>
        <br clear="none"></br>
        The problem here, and with the shuttle itself was
        <a href="http://www.metafilter.com/48654/Jan-28-1986#1189388" shape="rect">the military having too much say over it's construction</a>
        and this specific flight. Why the hell did the pictures have to be encrypted if they're looking at the tiles? That's just flat out stupid paranoia.
        <br clear="none"></br>
        <br clear="none"></br>
        Keep the civilian and military space programs separate. They can share technologies, sure, but their missions have different aims. The military is used to risking lives and those are the last people you want  with final say so over a civilian mission or program.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17675" shape="rect">Brandon Blatcher</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504711" shape="rect">7:46 AM</a>
          on March 28, 2009 [
          <a title="5 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504711" shape="rect">5 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504721" shape="rect"></a>
      <div class="comments">
        Great post.
        <br clear="none"></br>
        <br clear="none"></br>
        While space travel is inherently dangerous, it is far safer than routine long distance sailing voyages in the 'new world' era when losses of hundreds of men per ship were commonplace.
        <br clear="none"></br>
        <br clear="none"></br>
        IMHO, we should continue Shuttle flights until the Ares/Orion systems are ready.  Maintaining the skill sets and launch capability is important.  While I applaud private space launch efforts, they simply can't compare to the Shuttle's load capacity and flexibility of mission at this time.
        <br clear="none"></br>
        <br clear="none"></br>
        Efforts like the final Hubble repair are only realized by the shuttle at this time.  No private spacecraft in development could handle that effort.  Nor could Ares/Orion...
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14135" shape="rect">Argyle</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504721" shape="rect">7:57 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504739" shape="rect"></a>
      <div class="comments">
        <em>maybe you could just start fresh.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Yes, it's a mess. Divide US space efforts up a little more honestly.
        <br clear="none"></br>
        <br clear="none"></br>
        In one division, concentrate on missile development, orbital fighter pilots, spy satellites, interceptors, planting American flags and pulling up Russian and Chinese flags, etc. All the Buck Rogers, Us-vs-Them stuff. This is the military service you join if you want to see space like air force pilots see the sky. If you fly, you might die. That's part of the job.
        <br clear="none"></br>
        <br clear="none"></br>
        In the other division, concentrate on research to benefit everyone. Pure science, international cooperation, open systems, unmanned scientific instruments, etc. To get things into space, pay the US missile division or any other governmental or commercial space service in the world -- whoever has the best price and reliability. No people in this division go to space unless people are the subject of the experiment. This is the division you join if you want to do real science (with no ulterior military or commercial motives) and discover new worlds (without putting your dirty Earth feet on them). You won't die in action in this division unless an office vending machine falls over on you.
        <br clear="none"></br>
        <br clear="none"></br>
        The divisions could share services and facilities, but the philosophies and goals would be different. And let businesses remain an informal third division that develops commercial satellites and buys and sells launch services via any rocketry group anywhere in the world, including the US missile division if it offers competitive services.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/3518" shape="rect">pracowity</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504739" shape="rect">8:39 AM</a>
          on March 28, 2009 [
          <a title="2 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504739" shape="rect">2 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504852" shape="rect"></a>
      <div class="comments">
        ok...the REAL villian in this piece is a little company called (and by little, i mean multi-billion-dollar defense contractor) Lockheed Martin, who designed and built the tiles.
        <a href="http://www.amazon.com/exec/obidos/ASIN/0963397451/metafilter-20/ref=nosim/" shape="rect">this book</a>
        (which is so super-amazing-excellent btw...a complete encyclopedia of information about the shuttle) tells the whole story of lockheeds immense and CRAZY costly failure with these tiles.  know how they're attached?  they're GLUED to a big piece of FELT, which is GLUED to the bottom of the shuttle. that's it. now, retaining pins would conduct heat, so thats out, but even simple shaping of the tiles (like those in a
        <a href="http://images.google.com/images?hl=en&amp;q=15%20puzzle&amp;um=1&amp;ie=UTF-8&amp;sa=N&amp;tab=wi" shape="rect">15 puzzle</a>
        for example) would keep these things from doing what they like to do in orbit, i.e. falling off.  the cost of shaping the tiles was seen as too expensive early on in development, but if they had simply bitten the bullet and done it, it's unlikely that these things would have gone hundreds of BILLIONS of dollars over budget with the acres of problems involved in getting a piece of foam to stick to a piece of felt without crushing the foam, and still pretty much being a total failure...tiles have fallen off on pretty much EVERY mission. these tiles are the single most expensive part of the shuttle and pretty much the only reason the STS went over budget. and by 'over budget', i mean like a trillion dollars over the last 30 yrs.  lockheed sucks ass.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21856" shape="rect">sexyrobot</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504852" shape="rect">11:37 AM</a>
          on March 28, 2009 [
          <a title="4 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504852" shape="rect">4 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504861" shape="rect"></a>
      <div class="comments">
        In related news: Space Shuttle Discovery is due to land in under 28 minutes. Watch it live online
        <a href="http://www.msnbc.msn.com/id/21134540/vp/22887392#22887392" shape="rect">here</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19102" shape="rect">ericb</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504861" shape="rect">11:45 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504872" shape="rect"></a>
      <div class="comments">
        you can't have a truly private space program because the liabilities are just too large: sending huge amounts of explosive/toxic material high into the air being chased by fire! the same problem applies to nuclear energy.
        <br clear="none"></br>
        <br clear="none"></br>
        but basically NASA decided that the lives of the flight crews of the shuttles weren't worth the political cost of shutting down the shuttle program.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>
          <br clear="none"></br>
          In one division, concentrate on missile development, orbital fighter pilots, spy satellites, interceptors, planting American flags and pulling up Russian and Chinese flags, etc. All the Buck Rogers, Us-vs-Them stuff. This is the military service you join if you want to see space like air force pilots see the sky. If you fly, you might die. That's part of the job.
          <br clear="none"></br>
          <br clear="none"></br>
          In the other division, concentrate on research to benefit everyone.
        </i>
        <br clear="none"></br>
        <br clear="none"></br>
        but that's not the way it works. the civilian and scientific projects are floating on the foundation  of the military-industrial complex: the business of space is sending up defense/intelligence satellites.  without those satellites you wouldn't have the trained people and technology to do the other stuff. the US space program has always been a military program with a civilian pr front office.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/50202" shape="rect">geos</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504872" shape="rect">11:59 AM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504923" shape="rect"></a>
      <div class="comments">
        <em>&quot;Why the hell did the pictures have to be encrypted if they're looking at the tiles? That's just flat out stupid paranoia&quot;</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Yup.
        <br clear="none"></br>
        <br clear="none"></br>
        You'd think - that if security was that much a concern - they would have a simple real time algorithm that didn't kill the quality of the images.  That's just plain pathetic.  I mean dirty gutter masturbatory schizophrenic hobo pathetic.
        <br clear="none"></br>
        <br clear="none"></br>
        Of course, there is the possibility  that military forces expected from the get go that any video sent from space might have something to hide.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/72612" shape="rect">Xoebe</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504923" shape="rect">1:01 PM</a>
          on March 28, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2504923" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2504997" shape="rect"></a>
      <div class="comments">
        <em>I wonder how much the Space Shuttle's resemblance to a plane causes an expectation of plane-like safety levels? </em>
        <br clear="none"></br>
        <br clear="none"></br>
        That may be part of the problem, but I think the main problem with expectations is that they get a nice mix of nice-looking civilian-looking people (Jewish woman, Japanese American man, African American man, and an Irish-Lebanese-German-English-Native-American New England schoolteacher) and they all go off smiling and waving like it's just a little field trip, so you don't figure it could be all that dangerous. Whereas reality is closer to a couple of hardened military test pilots hanging on for dear life to the controls of a big scary overcomplicated and slightly used rocket plane that is strapped like Wile E. Coyote to the side of a couple of giant July 4th rockets.
        <br clear="none"></br>
        <br clear="none"></br>
        And
        <a href="http://en.wikipedia.org/wiki/File:Challenger_crew_hearses.jpg" shape="rect">then</a>
        .
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/3518" shape="rect">pracowity</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2504997" shape="rect">2:29 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505065" shape="rect"></a>
      <div class="comments">
        Human space flight:
        <a href="http://en.wikipedia.org/wiki/Space_accidents_and_incidents#Fatal_accidents_with_ground_crew_and_civilian_fatalities" shape="rect">odds of getting yourself killed:</a>
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://en.wikipedia.org/wiki/List_of_NASA_missions#Human_spaceflight" shape="rect">Shuttle Launches</a>
        : 123
        <br clear="none"></br>
        Shuttle Disasters: 2
        <br clear="none"></br>
        <br clear="none"></br>
        <a href="http://en.wikipedia.org/wiki/List_of_Soviet_and_Russian_manned_space_missions" shape="rect">Soviet/Russian</a>
        Capsule Launches: 96
        <br clear="none"></br>
        Soviet/Russian Capsule Disasters: 2 (Soyuz 1, Soyuz 11)
        <br clear="none"></br>
        <br clear="none"></br>
        Overall, if you go up in space you're looking at about a 2% chance of getting yourself killed.  It doesn't seem to matter much what you're flying.  The space shuttle has obvious, glaring safety problems, but space flight is so inherently risky that the lethal flaws in the next design are likely to become apparent only after one of them blows up.  The reason to replace the shuttle is cost.  It was supposed to save money by being reusable, but that didn't happen.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/53775" shape="rect">justsomebodythatyouusedtoknow</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505065" shape="rect">4:04 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505074" shape="rect"></a>
      <div class="comments">
        I'm so accustomed to live streaming video of shuttle missions that I can't comprehend a mission where even mission control didn't get pictures. But of course it's easy to forget that cold war paranoia was very tangible in 1988.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/41613" shape="rect">Chinese Jet Pilot</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505074" shape="rect">4:13 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505152" shape="rect"></a>
      <div class="comments">
        <i>The next generation of manned flight, hopefully run privately by folks with fear of massive wrongful death lawsuits.</i>
        <br clear="none"></br>
        <br clear="none"></br>
        lolwhat
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/49143" shape="rect">DU</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505152" shape="rect">5:48 PM</a>
          on March 28, 2009 [
          <a title="1 user marked this as favorite" style="font-weight:normal;" href="/favorited/2/2505152" shape="rect">1 favorite</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505192" shape="rect"></a>
      <div class="comments">
        <em>&quot;You'd think - that if security was that much a concern - they would have a simple real time algorithm that didn't kill the quality of the images. That's just plain pathetic. I mean dirty gutter masturbatory schizophrenic hobo pathetic.&quot;</em>
        <br clear="none"></br>
        <br clear="none"></br>
        This had to be done for video with computers available in 1988.  Better would have been the ability to send encrypted high resolution still photos.  Easy to say in hind sight.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/16157" shape="rect">Mitheral</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505192" shape="rect">6:39 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505197" shape="rect"></a>
      <div class="comments">
        To get military funding, the shuttle's requirements were to include launching KH-11 spy satellites, which are pretty big. The shuttle's payload bay is exactly the size of a KH-11.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/68527" shape="rect">Cosmo7</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505197" shape="rect">6:47 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505287" shape="rect"></a>
      <div class="comments">
        <i>Yet mission control discounted the reports from orbit, perhaps misled by the poor quality of the downlinked images</i>
        <br clear="none"></br>
        <br clear="none"></br>
        It was mission control that asked them to take a look in the first place. I don't buy this line. I think Houston believed they were dead, too, but policy prevented them from saying so. In fact, there may have even been a ghoulish debate of the effect, We need them to take photos so we know if they don't get back.
        <br clear="none"></br>
        <br clear="none"></br>
        Really, it's a pretty odd culture NASA has, blending scientists and test pilots and bureaucrats. The astronauts are just tools, and they know it.
        <br clear="none"></br>
        <br clear="none"></br>
        <i>But if this near-miss had been better known, might NASA have been more concerned about indications of debris damage during the launch of STS-107? </i>
        <br clear="none"></br>
        <br clear="none"></br>
        In fact, and it remains surprising that this did not change after Challenger,
        <a href="http://www.amazon.com/exec/obidos/ASIN/0226851761/metafilter-20/ref=nosim/" shape="rect">the NASA culture encourages normalization of risk</a>
        . That STS-27 survived simply added to the data showing that some tile damage wasn't all that bad.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/654" shape="rect">dhartung</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505287" shape="rect">9:15 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505309" shape="rect"></a>
      <div class="comments">
        <em>the NASA culture encourages normalization of risk. </em>
        <br clear="none"></br>
        Could be because it's a great death.
        <br clear="none"></br>
        Taking the assholery out of the equation I mean (Lockheed, the Joint Chiefs, intel community, all that).
        <br clear="none"></br>
        Plenty of mundane ways to go: slip in the shower, car accident, heart attack. Plenty of nasty ways to go: slow cancer, colostomy bag, painful infection. Plenty of stupid ways, plenty of scary ways - million ways to die.
        <br clear="none"></br>
        Death in space while on a space mission? Not at the bottom of my list. Not up there with dying saving kids from a fire or something, but you apply to be an astronaut you're probably not the 'die peacefully in my sleep' type of person. You're probably a bit more on edge. Like strap on a diaper and drive hundreds of miles on a motorcycle at high speed type on edge (but y'know, more in a good way mostly).
        <br clear="none"></br>
        Unfortunately assholery is part of the equation. So why put people on the spacecraft if you're not going to listen to the people on the spacecraft?
        <br clear="none"></br>
        The most advanced feedback system available to the human brain is another human brain. And in the final analysis, it's the most important on not only the most fundamental levels, but on a wide spectrum of interconnected levels.
        <br clear="none"></br>
        Your gauge might be perfectly correct about how fast you were going, they're still going to take the cop's word for it.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/18567" shape="rect">Smedleyman</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505309" shape="rect">9:57 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505316" shape="rect"></a>
      <div class="comments">
        Hey, good post!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19069" shape="rect">killdevil</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505316" shape="rect">10:15 PM</a>
          on March 28, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505448" shape="rect"></a>
      <div class="comments">
        <em>
          ...and still pretty much being a total failure...tiles have fallen off on pretty much EVERY mission. these tiles are the single most expensive part of the shuttle and pretty much the only reason the STS went over budget. and by 'over budget', i mean like a trillion dollars over the last 30 yrs.
        </em>
        <br clear="none"></br>
        <br clear="none"></br>
        A lot of unsubstantiated ranting here. One thing I take issue with is how are the tiles a total failure? The tiles were designed to protect the orbiter during reentry. Since there has never been a failure of the tiles resulting in a loss of the orbiter, I'd have to say they've so far achieved the goal they were shooting for (Columbia's loss was a failure of the carbon panels on the wing leading edge, NOT the tiles.) My impression is that the process was not understood and trained for correctly early in the process, but has since been improved greatly.
        <br clear="none"></br>
        <br clear="none"></br>
        I would say the failure here and with Columbia wasn't the thermal protection system, but the design flaw of configuring the launch vehicle so that the thermal protection system was subject to debris coming off the orbiter.
        <br clear="none"></br>
        <br clear="none"></br>
        The shuttle has several crucial issues, but the tiles, glued to felt, have proven to be pretty dependable.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21940" shape="rect">Mcable</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505448" shape="rect">6:52 AM</a>
          on March 29, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505451" shape="rect"></a>
      <div class="comments">
        Oh, and great post Major Clanger!
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/21940" shape="rect">Mcable</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505451" shape="rect">6:55 AM</a>
          on March 29, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505717" shape="rect"></a>
      <div class="comments">
        NASA's biggest mistake in operating the space shuttle program is that from an early stage they would accept anomalies that were not necessarily &quot;Crit-1 Events&quot; (ie: those that would lead to loss of vehicle and crew) as normal operating procedure. Worse still, they would use those recorded anomalies after successful flights as benchmarks - as in, &quot;well, we did witness some burn-through of the SRB O-Ring on flights X, Y, and Z, but since it wasn't more than XX%, we'll accept this as a tolerable level.&quot;
        <br clear="none"></br>
        <br clear="none"></br>
        Not only did STS 27 have problems with debris causing damage to tiles, Columbia had extensive damage on her maiden flight from debris falling from the external tank, along with tiles that were poorly bonded falling off of the vehicle.  Notably there were tiles that Young and Crippen saw missing from the front of the OMS pods at the rear of the craft.  Young, being smart, knew that if there were tiles missing from the OMS pods (relatively minimal concern for reentry), there was a good likelihood of tiles missing from the belly of the ship as well (massive concern for reentry).  With no ability to scan the bottom to check, this missing tile phenomenon because &quot;acceptable risk&quot; throughout the program.
        <br clear="none"></br>
        <br clear="none"></br>
        A little known story about STS-1 is that she almost didn't even complete the maiden flight.  On ignition of the SRBs there was a massive acoustic wave from the ignition blast that reverberated back up and smacked the lower tail flap that extends below the main engines of the orbiter. This wave rotated the elevator in such a way that controllers were fearful it was damaged.  Mission control never informed Young and Crippen of the event and luckily the orbiter returned successfully.  After the mission Young commented that had he known what had occurred at ignition, and with no way of knowing the extent of damage to the elevon, he would have proceeded to an RTLS abort, a none-too-pleasant idea in itself.  The idea behind RTLS (return to launch site) is that immediately following SRB separation the vehicle continues to travel  for a bit, then, literally, flips itself around to travel in the opposite direction of its forward momentum to burn off speed, then jettison the external tank and land back at Kennedy.
        <br clear="none"></br>
        <br clear="none"></br>
        RTLS has, thankfully, never been tried - although the original flightplan for STS-1 (ironically enough) was for it to be an RTLS abort, which, after seeing the abort option on paper, Young flat out refused to fly, considering it more of a suicide option than anything else: swinging the orbiter and ET stack around to go opposite its already considerable momentum was fraught with danger - you'd almost be safer trying to ditch in Spain or Africa.
        <br clear="none"></br>
        <br clear="none"></br>
        Back on topic:
        <br clear="none"></br>
        <br clear="none"></br>
        If you go back and look over the post-flight operations reports for the early shuttle flights in particular it becomes striking how incredibly lucky we were to not have lost a vehicle and crew within the first dozen flights, nevertheless the 25th.  NASA accepted so many tolerable risks, from thermal protection to APU failures (I believe it was STS-3 or 4 where the APUs caught fire and the only saving grace was that the fire started just after touchdown so the ground crew could extinguish it without too much damage), O-Ring malfunctions, computer errors, landing gear problems, tire explosions on landing, electrical malfunctions, etc, that it really is shocking.
        <br clear="none"></br>
        <br clear="none"></br>
        Just beacuse the vehicle and crew came home safely doesn't mean you don't have a problem that needs to be investigated and the causal chain better understood.  NASA was willing to overlook these risks for a variety of reasons: schedule pressure, Congressional pressure, managerial hubris, etc. I have always said, and will continue to say, that it is a God-given miracle each time those birds launch and land successfully.  The complexity is mindboggling, and the sad fact is that it is only now, almost 30 years after first flying, that seasoned engineers are comfortable understanding most (not all!) of the dynamics and limits and management is humble enough to recognize when to hit the pause button.  Sadly, it took two major disasters to teach about the importance of managerial dissent and root cause analysis in complex systems, but doing so has made the vehicles immensely more safe.  In both losses the problem was not engineering, it was managerial: the ships performed to their engineered specifications and beyond, it was management who failed to understand and respect this complexity when someone says, &quot;I think we need to re-visit this problem&quot;.
        <br clear="none"></br>
        <br clear="none"></br>
        NASA made the shuttle program &quot;operational&quot; after its 4th flight.  Arguably, it is still &quot;experimental&quot; after 30 years.  NASA could have and should have grounded the shuttle after those first flights and made all of the fixes that their engineers were crying for, but political pressure was too great after all of the delays in getting Columbia in the air in 1981.  Thankfully, NASA was willing to do this more throughout the 1990s, famously for a major wiring defect they detected, then later for various problems related to valves or other pieces of equipment shared among the orbiters.
        <br clear="none"></br>
        <br clear="none"></br>
        Almost 30 years on, I think you'd find many at NASA who privately say they're finally confident in the processes, procedures and systems in place.  The biggest take away from the entire shuttle program, however, may not be so much the engineering feat that it is, but the lessons for management of complex systems.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/14719" shape="rect">tgrundke</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505717" shape="rect">12:06 PM</a>
          on March 29, 2009 [
          <a title="7 users marked this as favorite" style="font-weight:normal;" href="/favorited/2/2505717" shape="rect">7 favorites</a>
          ]
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505820" shape="rect"></a>
      <div class="comments">
        <em>Young flat out refused to fly, considering it more of a suicide option than anything else:</em>
        <br clear="none"></br>
        <br clear="none"></br>
        John Young has been a hero of me since I was in the sixth grade. What an incredible man. He had a helluva career, flying the Gemini spacecraft, Apollo Command/Service Module, Apollo Lunar Module, the Space Shuttle and driving the Lunar Roving Vehicle on the moon.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/17675" shape="rect">Brandon Blatcher</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505820" shape="rect">1:52 PM</a>
          on March 29, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2505995" shape="rect"></a>
      <div class="comments">
        <em>The next generation of manned flight, hopefully run privately by folks with fear of massive wrongful death lawsuits.</em>
        <br clear="none"></br>
        <br clear="none"></br>
        Leotrotsky, I think you've got a contradiction in terms here: folks who have a fear of wrongful death suits aren't going to do manned flights.  That's why I'm skeptical of the whole &quot;let's privatize space travel&quot; concept; instead of space colonization, you'll just get unmanned satellite launches, and the occasional suborbital flight for millionaire thrillseekers..
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/83292" shape="rect">happyroach</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2505995" shape="rect">4:55 PM</a>
          on March 29, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2506138" shape="rect"></a>
      <div class="comments">
        <i>RTLS has, thankfully, never been tried [...]</i>
        <br clear="none"></br>
        <br clear="none"></br>
        Yes, thankfully, in the sense that it looks like a pretty dubious procedure. This also highlights one of the reasons space flight continues to be so dangerous. None of the Shuttle's abort options have ever been tried, and for the first couple of minutes, there aren't any abort options at all.
        <br clear="none"></br>
        <br clear="none"></br>
        Compare this to, say, takeoff in an airliner, where they are careful to make sure there are always abort options, and they've all been tried many times before any new design enters service. For there to be real safety improvements in space flight, there's going to have to be a change to a different mindset much more like airliner design and testing.
        <br clear="none"></br>
        <br clear="none"></br>
        I don't know if it's the right time for that to happen yet, but that's what it's going to take.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/87842" shape="rect">FishBike</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2506138" shape="rect">7:27 PM</a>
          on March 29, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <a name="2506709" shape="rect"></a>
      <div class="comments">
        I don't have a problem with it being dangerous to go to space, or even with tiles falling off the shuttle once.
        <br clear="none"></br>
        <br clear="none"></br>
        I am horrified that no lessons were learned from the mistakes that were made. NASA is more broken than the shuttles, and it hurts to say that. I adore NASA. Unfortunately, they seem to be about as functional as that crazy uncle the family refuses to talk about, the one who died ranting in a snow storm under an overpass.
        <br clear="none"></br>
        <span class="smallcopy">
          posted by
          <a target="_self" href="http://www.metafilter.com/user/19098" shape="rect">QIbHom</a>
          at
          <a target="_self" href="/80383/When-the-Shuttle-program-nearly-ended-in-1988#2506709" shape="rect">10:31 AM</a>
          on March 30, 2009
        </span>
      </div>
      <br clear="none"></br>
      <br clear="none"></br>
      <p style="font-size:11px;" class="copy whitesmallcopy">
        <a target="_self" href="/80382/I-was-picturing-a-basket" shape="rect">« Older</a>
        The trailer for &quot;After Last Season&quot; quietly appear...  |  Pics of the new Tesla S-Model ...
        <a target="_self" href="/80384/Hydrogen-Its-the-fuel-of-the-future-and-it-always-will-be" shape="rect">Newer »</a>
      </p>
      <br clear="none"></br>
      <div class="comments">
        <script language="JavaScript">
          var google_ad_client = 'pub-8621957794194569';
var google_ad_channel = '4697483699';
var google_ad_output = 'js';
var google_max_num_ads = '3';
var google_ad_type = 'text_html';
var google_image_size = '336x280,300x250';
var google_feedback = 'on';
var google_skip = google_adnum;
        </script>
        <script src="http://pagead2.googlesyndication.com/pagead/show_ads.js" language="JavaScript"></script>
      </div>
      <p class="comments">This thread has been archived and is closed to new comments</p>
      <br clear="none"></br>
      <br clear="none"></br>
      <div id="related" class="recently copy">
        <div style="margin-bottom:4px;">Related Posts</div>
        <a style="font-weight:normal;" href="http://www.metafilter.com/115523/Obviously-a-major-malfunction" shape="rect">&quot;Obviously a major malfunction.&quot;</a>
        <span class="smallcopy">May 2, 2012</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/103898/It-is-in-the-DNA-of-our-great-country-to-reach-for-the-stars-and-explore" shape="rect">It is in the DNA of our great country to reach for...</a>
        <span class="smallcopy">May 26, 2011</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/92263/Space-an-expensive-frontier" shape="rect">Space, an expensive frontier</a>
        <span class="smallcopy">May 26, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/91434/All-summer-In-A-Night" shape="rect">All summer In A Night</a>
        <span class="smallcopy">April 27, 2010</span>
        <br clear="none"></br>
        <a style="font-weight:normal;" href="http://www.metafilter.com/90694/Space-Shuttle-20" shape="rect">Space Shuttle 2.0</a>
        <span class="smallcopy">April 3, 2010</span>
        <br clear="none"></br>
      </div>
    </div>
    <br clear="all"></br>
    <div id="footer">
      <div style="width:24%;float:left;">
        <div class="footpad">
          <p>
            <strong>Features</strong>
          </p>
          -
          <a target="_self" href="https://login.metafilter.com/" shape="rect">Login</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/newuser.mefi" shape="rect">New User</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Links</strong>
          </p>
          -
          <a target="_self" href="/" shape="rect">Home</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/archive.mefi" shape="rect">Archives</a>
          <br clear="none"></br>
          -
          <a target="_self" href="/tags/" shape="rect">Tags</a>
          <br clear="none"></br>
          -
          <a target="_self" href="http://www.metafilter.com/about.mefi" shape="rect">About</a>
          <br clear="none"></br>
          -
          <a href="http://mssv.net/wiki" shape="rect">MeFi Wiki</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <p>
            <strong>Sites</strong>
          </p>
          -
          <a href="http://feeds.feedburner.com/Metafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://www.metafilter.com/" shape="rect">MetaFilter</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/AskMetafilter" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://ask.metafilter.com/" shape="rect">AskMeFi</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Projects" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://projects.metafilter.com/" shape="rect">Projects</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/mefi/Music" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://music.metafilter.com/" shape="rect">Music</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/Jobs" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://jobs.metafilter.com/" shape="rect">Jobs</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFiIRL" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://irl.metafilter.com/" shape="rect">IRL</a>
          <br clear="none"></br>
          -
          <a href="http://feeds.feedburner.com/MeFi/MetaTalk" shape="rect">
            <i class="feedicon"></i>
          </a>
          <a target="_self" href="http://metatalk.metafilter.com/" shape="rect">MetaTalk</a>
        </div>
      </div>
      <div style="width:25%;float:left;">
        <div class="footpad">
          <form style="margin-top:15px;" action="/search.mefi" id="cse-search-box" method="get" enctype="application/x-www-form-urlencoded">
            <div>
              <input value="partner-pub-8621957794194569:1154310032" name="cx" type="hidden"></input>
              <input value="FORID:10" name="cof" type="hidden"></input>
              <input value="UTF-8" name="ie" type="hidden"></input>
              <input style="width:120px;" size="31" name="q" type="text"></input>
              <input style="margin-left:3px;" value="Search" name="sa" type="submit"></input>
            </div>
          </form>
          <script src="http://www.google.com/coop/cse/brand?form=cse-search-box&amp;lang=en" type="text/javascript"></script>
          <span class="fineprint">
            © 1999-2012
            <a target="_self" href="http://www.metafilter.net/" shape="rect">MetaFilter Network Inc.</a>
            <br clear="none"></br>
            All posts are © their original authors.
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <span class="fineprint">
            <a target="_self" href="http://faq.metafilter.com/" shape="rect">FAQ</a>
            |
            <a target="_self" href="http://www.metafilter.com/contact/" shape="rect">Contact</a>
          </span>
          <br clear="none"></br>
          <br clear="none"></br>
          <br clear="none"></br>
        </div>
      </div>
      <br clear="all"></br>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.3/jquery.min.js" type="text/javascript"></script>
    <script src="http://d217i264rvtnq0.cloudfront.net/scripts/mefi/nonmembers102011b-min.js" type="text/javascript"></script>
    <script type="text/javascript">
      var hash = window.location.hash.substr(1);
$(function(){
$(window).hashchange(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));})
$(window).resize(function(){hash=window.location.hash.substr(1);target(location.hash.substr(1));});
});
    </script>
    <script type="text/javascript">
      var _gaq=_gaq||[];_gaq.push([&quot;_setAccount&quot;,&quot;UA-251263-1&quot;]);_gaq.push([&quot;_setDomainName&quot;,&quot;metafilter.com&quot;]);_gaq.push([&quot;_setAllowHash&quot;,!1]);_gaq.push([&quot;_setCustomVar&quot;,1,&quot;User Type&quot;,&quot;non-member&quot;,1]);_gaq.push([&quot;_trackPageview&quot;]);(function(){var a=document.createElement(&quot;script&quot;);a.type=&quot;text/javascript&quot;;a.async=!0;a.src=(&quot;https:&quot;==document.location.protocol?&quot;https://ssl&quot;:&quot;http://www&quot;)+&quot;.google-analytics.com/ga.js&quot;;var b=document.getElementsByTagName(&quot;script&quot;)[0];b.parentNode.insertBefore(a,b)})();
var _sf_async_config={uid:2515,domain:&quot;www.metafilter.com&quot;};(function(){function b(){window._sf_endpt=(new Date).getTime();var a=document.createElement(&quot;script&quot;);a.setAttribute(&quot;language&quot;,&quot;javascript&quot;);a.setAttribute(&quot;type&quot;,&quot;text/javascript&quot;);a.setAttribute(&quot;src&quot;,(&quot;https:&quot;==document.location.protocol?&quot;https://a248.e.akamai.net/chartbeat.download.akamai.com/102508/&quot;:&quot;http://static.chartbeat.com/&quot;)+&quot;js/chartbeat.js&quot;);document.body.appendChild(a)}var c=window.onload;window.onload=typeof window.onload!=&quot;function&quot;?b:function(){c();b()}})();
    </script>
  </body>
</html>     
    Hoot   )�     Season   ��     have   -     gouged   *M     DoD   ,�     during   .     
discounted   +     After   ��     more   -�     launch   .(         #http://en.wikipedia.org/wiki/STS-27    STS-27   *�     �as he saw pictures from the Shuttle's robot arm of gouged and missing tiles along its underbelly. Shades of Columbia - but this was mission    �, over fourteen years earlier. Yet mission control discounted the reports from orbit, perhaps misled by the poor quality of the downlinked images that resulted    STS-27      9202a8c04000641f800000000027c91b  